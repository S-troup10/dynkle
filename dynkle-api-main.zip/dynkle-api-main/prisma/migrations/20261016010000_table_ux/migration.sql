-- Table payments UX: tag health, auto-clear setting, catalogue import undo.
ALTER TABLE "dining_tables" ADD COLUMN "lastTappedAt" TIMESTAMP(3);
ALTER TABLE "merchants" ADD COLUMN "tableAutoClearMinutes" INTEGER;

CREATE TABLE "catalog_imports" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "createdIds" JSONB NOT NULL,
    "previous" JSONB NOT NULL,
    "categories" JSONB NOT NULL,
    "added" INTEGER NOT NULL,
    "updated" INTEGER NOT NULL,
    "source" TEXT,
    "undoneAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT "catalog_imports_pkey" PRIMARY KEY ("id")
);
CREATE INDEX "catalog_imports_merchantId_createdAt_idx" ON "catalog_imports"("merchantId", "createdAt");
ALTER TABLE "catalog_imports" ADD CONSTRAINT "catalog_imports_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;
