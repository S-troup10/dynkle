-- CreateEnum
CREATE TYPE "PaymentChannel" AS ENUM ('DYNK_ONLINE', 'DYNK_OFFLINE_BLE', 'WEB_WALLET');

-- CreateEnum
CREATE TYPE "PaymentOption" AS ENUM ('DIRECT', 'SHORTFALL');

-- CreateEnum
CREATE TYPE "PaymentAttemptStatus" AS ENUM ('PRECHECKED', 'BUILT', 'SIGNED', 'SUBMITTED', 'CONFIRMED', 'FAILED', 'EXPIRED', 'DECLINED');

-- AlterTable
ALTER TABLE "orders" ADD COLUMN     "displayNumber" SERIAL NOT NULL,
ADD COLUMN     "itemCount" INTEGER NOT NULL DEFAULT 0,
ADD COLUMN     "paymentLock" TEXT,
ADD COLUMN     "tapPayAmount" BIGINT,
ADD COLUMN     "tapPayDeviceId" TEXT,
ADD COLUMN     "tapPayFee" BIGINT,
ADD COLUMN     "tapPayMint" TEXT,
ADD COLUMN     "tapPayRecipient" TEXT;

-- CreateTable
CREATE TABLE "payment_intents" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "version" INTEGER NOT NULL,
    "kid" INTEGER NOT NULL,
    "payload" BYTEA NOT NULL,
    "bleSessionId" BYTEA NOT NULL,
    "terminalEphemeralPub" BYTEA NOT NULL,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "supersededAt" TIMESTAMP(3),

    CONSTRAINT "payment_intents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "payment_attempts" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "channel" "PaymentChannel" NOT NULL,
    "customerPubkey" TEXT NOT NULL,
    "option" "PaymentOption" NOT NULL DEFAULT 'DIRECT',
    "quoteId" TEXT NOT NULL,
    "shortfallQuoteId" TEXT,
    "messageBytes" BYTEA,
    "messageHash" TEXT,
    "lastValidBlockHeight" BIGINT,
    "quoteExpiresAt" TIMESTAMP(3),
    "amount" BIGINT NOT NULL,
    "fee" BIGINT NOT NULL,
    "txSignature" TEXT,
    "status" "PaymentAttemptStatus" NOT NULL,
    "failureCode" TEXT,
    "receipt" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "payment_attempts_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "duplicate_payments" (
    "id" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "txSignature" TEXT NOT NULL,
    "detectedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "resolvedAt" TIMESTAMP(3),
    "note" TEXT,

    CONSTRAINT "duplicate_payments_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE INDEX "payment_intents_orderId_createdAt_idx" ON "payment_intents"("orderId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "payment_attempts_quoteId_key" ON "payment_attempts"("quoteId");

-- CreateIndex
CREATE UNIQUE INDEX "payment_attempts_txSignature_key" ON "payment_attempts"("txSignature");

-- CreateIndex
CREATE INDEX "payment_attempts_orderId_createdAt_idx" ON "payment_attempts"("orderId", "createdAt");

-- CreateIndex
CREATE UNIQUE INDEX "duplicate_payments_txSignature_key" ON "duplicate_payments"("txSignature");

-- CreateIndex
CREATE INDEX "duplicate_payments_orderId_idx" ON "duplicate_payments"("orderId");

-- CreateIndex
CREATE UNIQUE INDEX "orders_displayNumber_key" ON "orders"("displayNumber");

-- CreateIndex
CREATE UNIQUE INDEX "orders_paymentLock_key" ON "orders"("paymentLock");

-- AddForeignKey
ALTER TABLE "payment_intents" ADD CONSTRAINT "payment_intents_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "payment_attempts" ADD CONSTRAINT "payment_attempts_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

