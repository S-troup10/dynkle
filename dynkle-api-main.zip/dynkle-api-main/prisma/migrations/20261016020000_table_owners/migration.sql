-- Table payments: waiter ownership of a table's bill, how a generated bill is paid, venue service mode.
ALTER TABLE "dining_tables" ADD COLUMN "ownerKey" TEXT;
ALTER TABLE "dining_tables" ADD COLUMN "ownerLabel" TEXT;
ALTER TABLE "dining_tables" ADD COLUMN "payMode" TEXT NOT NULL DEFAULT 'TAG';
ALTER TABLE "merchants" ADD COLUMN "serviceMode" TEXT;
