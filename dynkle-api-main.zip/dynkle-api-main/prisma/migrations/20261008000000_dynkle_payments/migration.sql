-- DYNKLE payments spec (02_TECHNICAL_SPEC §10): channel and option names,
-- customer decline, QR / TAP intents with the tap blockhash.

-- Channels by entry and path (existing rows keep their meaning).
ALTER TYPE "PaymentChannel" RENAME VALUE 'DYNK_OFFLINE_BLE' TO 'QR_BLE';
ALTER TYPE "PaymentChannel" RENAME VALUE 'DYNK_ONLINE' TO 'QR_INTERNET';
ALTER TYPE "PaymentChannel" RENAME VALUE 'WEB_WALLET' TO 'WEBSITE';
ALTER TYPE "PaymentChannel" ADD VALUE 'TAP_ONLINE';
ALTER TYPE "PaymentChannel" ADD VALUE 'TAP_OFFLINE';

-- "Swap and Pay" everywhere.
ALTER TYPE "PaymentOption" RENAME VALUE 'SHORTFALL' TO 'SWAP';
ALTER TABLE "payment_attempts" RENAME COLUMN "shortfallQuoteId" TO "swapQuoteId";

ALTER TYPE "PaymentAttemptStatus" ADD VALUE 'CUSTOMER_DECLINED';
ALTER TABLE "payment_attempts" ADD COLUMN "declineNotice" JSONB;

CREATE TYPE "PaymentIntentKind" AS ENUM ('QR', 'TAP');
ALTER TABLE "payment_intents" ADD COLUMN "kind" "PaymentIntentKind" NOT NULL DEFAULT 'QR',
  ADD COLUMN "recentBlockhash" TEXT,
  ADD COLUMN "lastValidBlockHeight" BIGINT;
DROP INDEX "payment_intents_orderId_createdAt_idx";
CREATE INDEX "payment_intents_orderId_kind_createdAt_idx" ON "payment_intents"("orderId", "kind", "createdAt");
