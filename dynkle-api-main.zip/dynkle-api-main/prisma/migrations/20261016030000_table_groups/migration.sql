-- Connected tables (events): one bill for several tables; the first tag tapped locks the group's payment.
ALTER TABLE "dining_tables" ADD COLUMN "groupLeaderId" TEXT;
ALTER TABLE "dining_tables" ADD COLUMN "groupName" TEXT;
ALTER TABLE "dining_tables" ADD COLUMN "groupClaimTag" TEXT;
ALTER TABLE "dining_tables" ADD COLUMN "groupClaimUntil" TIMESTAMP(3);
CREATE INDEX "dining_tables_groupLeaderId_idx" ON "dining_tables"("groupLeaderId");
