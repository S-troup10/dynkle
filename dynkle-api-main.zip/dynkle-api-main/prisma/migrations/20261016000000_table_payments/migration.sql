-- Table payments: floor plans and dining tables with NFC tags.
CREATE TABLE "floor_plans" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "zones" JSONB NOT NULL,
    "sort" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "floor_plans_pkey" PRIMARY KEY ("id")
);

CREATE TABLE "dining_tables" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "floorPlanId" TEXT NOT NULL,
    "zoneId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "seats" INTEGER NOT NULL DEFAULT 2,
    "shape" TEXT NOT NULL DEFAULT 'rect',
    "x" INTEGER NOT NULL DEFAULT 0,
    "y" INTEGER NOT NULL DEFAULT 0,
    "w" INTEGER NOT NULL DEFAULT 80,
    "h" INTEGER NOT NULL DEFAULT 64,
    "tagCode" TEXT,
    "status" TEXT NOT NULL DEFAULT 'FREE',
    "items" JSONB NOT NULL DEFAULT '[]',
    "boundOrderId" TEXT,
    "sentAt" TIMESTAMP(3),
    "paidAt" TIMESTAMP(3),
    "lockedBy" TEXT,
    "lockLabel" TEXT,
    "lockedUntil" TIMESTAMP(3),
    "version" INTEGER NOT NULL DEFAULT 0,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,
    CONSTRAINT "dining_tables_pkey" PRIMARY KEY ("id")
);

CREATE INDEX "floor_plans_merchantId_idx" ON "floor_plans"("merchantId");
CREATE UNIQUE INDEX "dining_tables_tagCode_key" ON "dining_tables"("tagCode");
CREATE INDEX "dining_tables_merchantId_idx" ON "dining_tables"("merchantId");
CREATE INDEX "dining_tables_boundOrderId_idx" ON "dining_tables"("boundOrderId");

ALTER TABLE "floor_plans" ADD CONSTRAINT "floor_plans_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "dining_tables" ADD CONSTRAINT "dining_tables_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;
ALTER TABLE "dining_tables" ADD CONSTRAINT "dining_tables_floorPlanId_fkey" FOREIGN KEY ("floorPlanId") REFERENCES "floor_plans"("id") ON DELETE CASCADE ON UPDATE CASCADE;
