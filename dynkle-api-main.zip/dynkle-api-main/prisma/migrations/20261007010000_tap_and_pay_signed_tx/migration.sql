-- AlterTable
ALTER TABLE "payment_attempts" ADD COLUMN     "signedTx" BYTEA;

