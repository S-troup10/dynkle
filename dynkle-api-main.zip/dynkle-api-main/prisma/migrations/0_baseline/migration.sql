-- CreateEnum
CREATE TYPE "UserStatus" AS ENUM ('PENDING', 'ACTIVE', 'SUSPENDED');

-- CreateEnum
CREATE TYPE "MerchantRole" AS ENUM ('OWNER', 'ADMIN', 'MANAGER', 'CASHIER');

-- CreateEnum
CREATE TYPE "KybStatus" AS ENUM ('DRAFT', 'SUBMITTED', 'PENDING', 'REQUIRES_INFORMATION', 'MANUAL_REVIEW', 'APPROVED', 'REJECTED');

-- CreateEnum
CREATE TYPE "TerminalStatus" AS ENUM ('UNPAIRED', 'PAIRING', 'CONNECTED', 'READY', 'ARMED', 'PROCESSING', 'SUCCESS', 'ERROR', 'OFFLINE', 'REVOKED');

-- CreateEnum
CREATE TYPE "OrderStatus" AS ENUM ('CREATED', 'QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER', 'CUSTOMER_DETECTED', 'AWAITING_APPROVAL', 'SUBMITTED', 'CONFIRMING', 'PAID', 'SETTLING', 'SETTLED', 'RECEIPT_READY', 'REFUNDED', 'EXPIRED', 'CANCELLED', 'PAYMENT_FAILED', 'SETTLEMENT_FAILED', 'PRICE_MOVED');

-- CreateEnum
CREATE TYPE "SplitBucket" AS ENUM ('TAX', 'EXPENSES', 'OWNER_PAY', 'PROFIT');

-- CreateEnum
CREATE TYPE "SettlementMode" AS ENUM ('STABLE', 'CRYPTO');

-- CreateEnum
CREATE TYPE "ShippingStatus" AS ENUM ('PENDING', 'PROCESSING', 'SHIPPED', 'IN_TRANSIT', 'OUT_FOR_DELIVERY', 'DELIVERED', 'FAILED');

-- CreateTable
CREATE TABLE "users" (
    "id" TEXT NOT NULL,
    "email" TEXT NOT NULL,
    "phone" TEXT,
    "passwordHash" TEXT NOT NULL,
    "emailVerified" BOOLEAN NOT NULL DEFAULT false,
    "phoneVerified" BOOLEAN NOT NULL DEFAULT false,
    "status" "UserStatus" NOT NULL DEFAULT 'PENDING',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "refresh_tokens" (
    "id" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "tokenHash" TEXT NOT NULL,
    "revoked" BOOLEAN NOT NULL DEFAULT false,
    "expiresAt" TIMESTAMP(3) NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "refresh_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "merchants" (
    "id" TEXT NOT NULL,
    "legalName" TEXT NOT NULL,
    "tradingName" TEXT NOT NULL,
    "businessType" TEXT NOT NULL,
    "abn" TEXT,
    "registeredAddress" TEXT,
    "status" TEXT NOT NULL DEFAULT 'setup',
    "counterMode" TEXT NOT NULL DEFAULT 'SINGLE',
    "onboardingStep" INTEGER NOT NULL DEFAULT 1,
    "kybStatus" "KybStatus" NOT NULL DEFAULT 'DRAFT',
    "kitPaid" BOOLEAN NOT NULL DEFAULT false,
    "kitPaymentId" TEXT,
    "industry" TEXT,
    "catalogCategories" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "merchants_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "merchant_users" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "userId" TEXT NOT NULL,
    "role" "MerchantRole" NOT NULL DEFAULT 'CASHIER',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "merchant_users_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "business_profiles" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "logoUrl" TEXT,
    "operatingHours" JSONB,
    "supportContact" TEXT,
    "disputeContact" TEXT,
    "brandingColor" TEXT DEFAULT '#FF7A29',

    CONSTRAINT "business_profiles_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "kyb_verifications" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "verificationProvider" TEXT NOT NULL DEFAULT 'internal_abn',
    "verificationId" TEXT,
    "status" "KybStatus" NOT NULL DEFAULT 'PENDING',
    "submittedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "reviewedAt" TIMESTAMP(3),
    "rejectionReason" TEXT,
    "metadata" JSONB,

    CONSTRAINT "kyb_verifications_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "kyb_documents" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "docType" TEXT NOT NULL,
    "storageKey" TEXT NOT NULL,
    "filename" TEXT NOT NULL,
    "mimeType" TEXT NOT NULL,
    "fileSize" INTEGER NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'uploaded',
    "uploadedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "kyb_documents_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "kit_shipments" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "trackingNumber" TEXT,
    "carrier" TEXT NOT NULL DEFAULT 'Australia Post',
    "status" "ShippingStatus" NOT NULL DEFAULT 'PENDING',
    "address" TEXT NOT NULL,
    "items" JSONB NOT NULL,
    "shippedAt" TIMESTAMP(3),
    "deliveredAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "kit_shipments_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "terminals" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "terminalId" TEXT NOT NULL,
    "label" TEXT NOT NULL DEFAULT 'Main Counter',
    "serialNumber" TEXT NOT NULL,
    "pairingToken" TEXT,
    "firmwareVersion" TEXT NOT NULL DEFAULT '2.4.1',
    "status" "TerminalStatus" NOT NULL DEFAULT 'UNPAIRED',
    "lastSeenCounter" INTEGER NOT NULL DEFAULT 0,
    "lastSeenAt" TIMESTAMP(3),
    "pairedAt" TIMESTAMP(3),
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "terminals_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "wallets" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "label" TEXT NOT NULL,
    "blockchain" TEXT NOT NULL DEFAULT 'solana',
    "address" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'active',
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "wallets_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "revenue_split_rules" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "bucket" TEXT NOT NULL,
    "basisPoints" INTEGER NOT NULL,
    "settlementMode" "SettlementMode" NOT NULL DEFAULT 'STABLE',
    "destinationWalletId" TEXT NOT NULL,

    CONSTRAINT "revenue_split_rules_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "accepted_tokens" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "tokenSymbol" TEXT NOT NULL,
    "blockchain" TEXT NOT NULL,
    "mintAddress" TEXT,
    "enabled" BOOLEAN NOT NULL DEFAULT true,
    "customerFeeType" TEXT NOT NULL DEFAULT 'percentage',
    "customerFeeValue" DECIMAL(18,4) NOT NULL,

    CONSTRAINT "accepted_tokens_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "products" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "name" TEXT NOT NULL,
    "category" TEXT NOT NULL DEFAULT 'General',
    "description" TEXT,
    "price" DECIMAL(10,2) NOT NULL,
    "currency" TEXT NOT NULL DEFAULT 'AUD',
    "meta" JSONB,
    "active" BOOLEAN NOT NULL DEFAULT true,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "updatedAt" TIMESTAMP(3) NOT NULL,

    CONSTRAINT "products_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "orders" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "orderNumber" TEXT NOT NULL,
    "subtotalAUD" DECIMAL(10,2) NOT NULL,
    "customerFeeAUD" DECIMAL(10,4) NOT NULL,
    "totalAUD" DECIMAL(10,2) NOT NULL,
    "gstAUD" DECIMAL(10,2) NOT NULL,
    "tokenSymbol" TEXT NOT NULL,
    "cryptoAmount" DECIMAL(18,6) NOT NULL,
    "quotePrice" DECIMAL(18,4) NOT NULL,
    "quoteCreatedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "quoteExpiresAt" TIMESTAMP(3) NOT NULL,
    "status" "OrderStatus" NOT NULL DEFAULT 'CREATED',
    "terminalId" TEXT NOT NULL,
    "referenceKey" TEXT NOT NULL,
    "customerWallet" TEXT,
    "items" JSONB NOT NULL,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,
    "paidAt" TIMESTAMP(3),

    CONSTRAINT "orders_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "transactions" (
    "id" TEXT NOT NULL,
    "merchantId" TEXT NOT NULL,
    "orderId" TEXT NOT NULL,
    "blockchain" TEXT NOT NULL,
    "token" TEXT NOT NULL,
    "amount" DECIMAL(18,6) NOT NULL,
    "senderAddress" TEXT NOT NULL,
    "receiverAddress" TEXT NOT NULL,
    "txHash" TEXT NOT NULL,
    "status" TEXT NOT NULL DEFAULT 'confirmed',
    "blockNumber" BIGINT,
    "confirmedAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "settlement_transactions" (
    "id" TEXT NOT NULL,
    "transactionId" TEXT NOT NULL,
    "bucket" TEXT NOT NULL,
    "basisPoints" INTEGER NOT NULL,
    "amountAUD" DECIMAL(10,2) NOT NULL,
    "tokenAmount" DECIMAL(18,6) NOT NULL,
    "tokenSymbol" TEXT NOT NULL,
    "destinationWallet" TEXT NOT NULL,
    "settlementTxHash" TEXT,
    "status" TEXT NOT NULL DEFAULT 'settled',
    "failureReason" TEXT,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "settlement_transactions_pkey" PRIMARY KEY ("id")
);

-- CreateTable
CREATE TABLE "audit_logs" (
    "id" TEXT NOT NULL,
    "userId" TEXT,
    "merchantId" TEXT,
    "action" TEXT NOT NULL,
    "resource" TEXT NOT NULL,
    "resourceId" TEXT,
    "ipAddress" TEXT,
    "metadata" JSONB,
    "createdAt" TIMESTAMP(3) NOT NULL DEFAULT CURRENT_TIMESTAMP,

    CONSTRAINT "audit_logs_pkey" PRIMARY KEY ("id")
);

-- CreateIndex
CREATE UNIQUE INDEX "users_email_key" ON "users"("email");

-- CreateIndex
CREATE UNIQUE INDEX "refresh_tokens_tokenHash_key" ON "refresh_tokens"("tokenHash");

-- CreateIndex
CREATE UNIQUE INDEX "merchant_users_merchantId_userId_key" ON "merchant_users"("merchantId", "userId");

-- CreateIndex
CREATE UNIQUE INDEX "business_profiles_merchantId_key" ON "business_profiles"("merchantId");

-- CreateIndex
CREATE UNIQUE INDEX "terminals_terminalId_key" ON "terminals"("terminalId");

-- CreateIndex
CREATE UNIQUE INDEX "terminals_serialNumber_key" ON "terminals"("serialNumber");

-- CreateIndex
CREATE UNIQUE INDEX "accepted_tokens_merchantId_tokenSymbol_blockchain_key" ON "accepted_tokens"("merchantId", "tokenSymbol", "blockchain");

-- CreateIndex
CREATE UNIQUE INDEX "orders_orderNumber_key" ON "orders"("orderNumber");

-- CreateIndex
CREATE UNIQUE INDEX "orders_referenceKey_key" ON "orders"("referenceKey");

-- CreateIndex
CREATE UNIQUE INDEX "transactions_orderId_key" ON "transactions"("orderId");

-- CreateIndex
CREATE UNIQUE INDEX "transactions_blockchain_txHash_key" ON "transactions"("blockchain", "txHash");

-- AddForeignKey
ALTER TABLE "refresh_tokens" ADD CONSTRAINT "refresh_tokens_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "merchant_users" ADD CONSTRAINT "merchant_users_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "merchant_users" ADD CONSTRAINT "merchant_users_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "business_profiles" ADD CONSTRAINT "business_profiles_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kyb_verifications" ADD CONSTRAINT "kyb_verifications_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kyb_documents" ADD CONSTRAINT "kyb_documents_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "kit_shipments" ADD CONSTRAINT "kit_shipments_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "terminals" ADD CONSTRAINT "terminals_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "wallets" ADD CONSTRAINT "wallets_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "revenue_split_rules" ADD CONSTRAINT "revenue_split_rules_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "revenue_split_rules" ADD CONSTRAINT "revenue_split_rules_destinationWalletId_fkey" FOREIGN KEY ("destinationWalletId") REFERENCES "wallets"("id") ON DELETE RESTRICT ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "accepted_tokens" ADD CONSTRAINT "accepted_tokens_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "products" ADD CONSTRAINT "products_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "orders" ADD CONSTRAINT "orders_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "transactions" ADD CONSTRAINT "transactions_orderId_fkey" FOREIGN KEY ("orderId") REFERENCES "orders"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "settlement_transactions" ADD CONSTRAINT "settlement_transactions_transactionId_fkey" FOREIGN KEY ("transactionId") REFERENCES "transactions"("id") ON DELETE CASCADE ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_userId_fkey" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE SET NULL ON UPDATE CASCADE;

-- AddForeignKey
ALTER TABLE "audit_logs" ADD CONSTRAINT "audit_logs_merchantId_fkey" FOREIGN KEY ("merchantId") REFERENCES "merchants"("id") ON DELETE SET NULL ON UPDATE CASCADE;

