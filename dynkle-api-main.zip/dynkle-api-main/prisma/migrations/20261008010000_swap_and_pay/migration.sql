ALTER TABLE "payment_attempts" ADD COLUMN "swapQuote" JSONB;
