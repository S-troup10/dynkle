import { PrismaClient } from '@prisma/client';
import bcrypt from 'bcryptjs';

const prisma = new PrismaClient();

async function seed() {
  console.log('[Seed] Starting database seed...');

  const passwordHash = await bcrypt.hash('Password123!', 10);

  // Check if default user exists
  let user = await prisma.user.findUnique({
    where: { email: 'merchant@beanandbrew.com.au' }
  });

  if (!user) {
    user = await prisma.user.create({
      data: {
        email: 'merchant@beanandbrew.com.au',
        phone: '+61412345678',
        passwordHash,
        emailVerified: true,
        phoneVerified: true,
        status: 'ACTIVE'
      }
    });
    console.log('[Seed] Created default user:', user.email);
  }

  // Check if default merchant exists
  let merchant = await prisma.merchant.findFirst({
    where: { tradingName: 'Bean & Brew Café' }
  });

  if (!merchant) {
    merchant = await prisma.merchant.create({
      data: {
        legalName: 'Bean & Brew Café Pty Ltd',
        tradingName: 'Bean & Brew Café',
        businessType: 'company',
        abn: '51824753556',
        registeredAddress: '123 Collins Street, Melbourne VIC 3000',
        status: 'live',
        onboardingStep: 7,
        kybStatus: 'APPROVED',
        kitPaid: true,
        kitPaymentId: 'pi_seed_starter_kit_199'
      }
    });
    console.log('[Seed] Created default merchant:', merchant.tradingName);

    // Link Owner
    await prisma.merchantUser.create({
      data: {
        merchantId: merchant.id,
        userId: user.id,
        role: 'OWNER'
      }
    });

    // Create Business Profile
    await prisma.businessProfile.create({
      data: {
        merchantId: merchant.id,
        brandingColor: '#FF7A29',
        supportContact: 'support@beanandbrew.com.au',
        operatingHours: { monday: '07:00-17:00', tuesday: '07:00-17:00', wednesday: '07:00-17:00', thursday: '07:00-17:00', friday: '07:00-17:00' }
      }
    });

    // Create Wallets
    const solanaAddress = '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH';
    const taxWallet = await prisma.wallet.create({
      data: { merchantId: merchant.id, label: 'Tax Reserves (ATO)', blockchain: 'solana', address: solanaAddress }
    });
    const opexWallet = await prisma.wallet.create({
      data: { merchantId: merchant.id, label: 'Operating Expenses', blockchain: 'solana', address: solanaAddress }
    });
    const ownerWallet = await prisma.wallet.create({
      data: { merchantId: merchant.id, label: 'Owner Drawings', blockchain: 'solana', address: solanaAddress }
    });
    const profitWallet = await prisma.wallet.create({
      data: { merchantId: merchant.id, label: 'Retained Profit', blockchain: 'solana', address: solanaAddress }
    });

    // Create 100% Revenue Split Rules (15% Tax, 20% OpEx, 20% Owner, 45% Profit = 10,000 bps)
    await prisma.revenueSplitRule.createMany({
      data: [
        { merchantId: merchant.id, bucket: 'TAX', basisPoints: 1500, destinationWalletId: taxWallet.id },
        { merchantId: merchant.id, bucket: 'EXPENSES', basisPoints: 2000, destinationWalletId: opexWallet.id },
        { merchantId: merchant.id, bucket: 'OWNER_PAY', basisPoints: 2000, destinationWalletId: ownerWallet.id },
        { merchantId: merchant.id, bucket: 'PROFIT', basisPoints: 4500, destinationWalletId: profitWallet.id },
      ]
    });

    // Create Accepted Tokens
    await prisma.acceptedToken.createMany({
      data: [
        { merchantId: merchant.id, tokenSymbol: 'SOL', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.0100 },
        { merchantId: merchant.id, tokenSymbol: 'DYNK', blockchain: 'solana', enabled: true, customerFeeType: 'flat', customerFeeValue: 0.0100 },
        { merchantId: merchant.id, tokenSymbol: 'USDC', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.0050 },
        { merchantId: merchant.id, tokenSymbol: 'ETH', blockchain: 'evm', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.0100 },
      ]
    });

    // Create Default Products
    await prisma.product.createMany({
      data: [
        { merchantId: merchant.id, name: 'Flat White (Regular)', category: 'Drinks > Coffee > Hot', price: 4.50, currency: 'AUD', active: true },
        { merchantId: merchant.id, name: 'Cold Brew 12oz', category: 'Drinks > Coffee > Iced', price: 6.00, currency: 'AUD', active: true },
        { merchantId: merchant.id, name: 'Almond Croissant', category: 'Bakery > Pastries', price: 5.50, currency: 'AUD', active: true },
        { merchantId: merchant.id, name: 'Avocado Toast', category: 'Food > Breakfast', price: 14.00, currency: 'AUD', active: true },
        { merchantId: merchant.id, name: 'Iced Latte', category: 'Drinks > Coffee > Iced', price: 5.00, currency: 'AUD', active: true },
        { merchantId: merchant.id, name: 'Toasted Banana Bread', category: 'Bakery > Pastries', price: 4.50, currency: 'AUD', active: true }
      ]
    });

    // Create Terminal DY-009
    await prisma.terminal.create({
      data: {
        merchantId: merchant.id,
        terminalId: 'DY-009',
        serialNumber: 'SN-DY-9001',
        firmwareVersion: '2.4.1',
        status: 'READY'
      }
    });

    // Create initial kit shipment
    await prisma.kitShipment.create({
      data: {
        merchantId: merchant.id,
        trackingNumber: 'AP-DYNK-092144-VIC',
        carrier: 'Australia Post Express',
        status: 'DELIVERED',
        address: '123 Collins Street, Melbourne VIC 3000',
        items: [
          { item: 'DYNKLE Countertop Screenless NFC Device', qty: 1, serialNumber: 'SN-DY-9001' },
          { item: 'NFC Countertop Acrylic Stand & QR Plate', qty: 1 },
          { item: 'Window & Register Decal Pack ("DYNK Accepted")', qty: 4 }
        ],
        deliveredAt: new Date()
      }
    });

    console.log('[Seed] Default merchant, terminal DY-009, products, and wallets successfully seeded.');
  }

  await prisma.$disconnect();
}

seed().catch(err => {
  console.error('[Seed Error]:', err);
  process.exit(1);
});
