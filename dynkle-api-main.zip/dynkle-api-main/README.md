# dynkle-api

A crypto point-of-sale system for in-person merchants. The cashier enters a bill
in AUD, and the customer pays it from their phone wallet (Phantom, Solflare,
MetaMask, and others) by tapping an NFC tag or scanning a QR code. The server
builds the transaction with the amount already in it, so the customer can only
approve or reject. They never type an amount.

The same Node server also runs merchant onboarding (account, business and
counters, POS device order, payouts, products, go-live), the FP9810 counter
devices, product management, P&L tracking on crypto holdings, and automatic
stablecoin swaps. It serves the website from
[dynkle-web](https://github.com/Dynk-IO/dynkle-web) (clone it as a `frontend`
sibling folder, or point `FRONTEND_DIR` at it).

Also in this repo: [`programs/dynkle-auto-swap`](programs/dynkle-auto-swap), a
reference (not deployed) Solana Anchor program for non-custodial on-chain
auto-swap of merchant revenue splits. The live auto-swap feature in this
backend is an off-chain simulation and does not call this program.

See [`docs/specs`](docs/specs) for the full money-flow specification. The
terminal app is [dynkle-terminal](https://github.com/Dynk-IO/dynkle-terminal).

---

## Contents

- [How it works](#how-it-works)
- [Project layout](#project-layout)
- [Quick start](#quick-start)
- [Environment variables](#environment-variables)
- [Dev mode (`OTP_DEV_BYPASS`)](#dev-mode-otp_dev_bypass)
- [Testing on a real phone](#testing-on-a-real-phone)
- [Web pages](#web-pages)
- [Order lifecycle](#order-lifecycle)
- [API reference](#api-reference)
- [Real-time channels](#real-time-channels)
- [Counter devices (FP9810)](#counter-devices-fp9810)
- [Background jobs](#background-jobs)
- [Tests](#tests)
- [Known limitations and production checklist](#known-limitations-and-production-checklist)

---

## How it works

```
 Cashier (index.html)                Server (Express + Prisma)            Blockchain
 ────────────────────                ─────────────────────────            ──────────
 enter bill in AUD ──POST /api/orders──▶ price quote, order row
                                         arm terminal over WebSocket
                                                │
 Customer taps NFC tag / scans QR               ▼
   /t/POS_001 ──────────────────────────▶ first-tap lock → pay.html?orderId=…
                                                │
 pay.html: pick wallet                          │
   ├─ POST /:id/preflight ──────────────▶ real balance check ───────────▶ RPC
   │   (not enough funds? told here, before leaving for the wallet,
   │    and the cashier is alerted too)
   └─ open wallet deep link
        Solana: Solana Pay Transaction Request → server builds an unsigned tx
        EVM:    EIP-681 payment link (MetaMask / Trust) with an order tag in the
                wei amount → server finds it on Sepolia (services/evmWatch.js)
                                                │
 customer approves in wallet ──────────────────────────────────────────▶ broadcast
                                                │
 POST /:id/submit (tx hash) ────────────▶ verify on-chain: amount, recipient,
                                         mint, not reused ◀────────────── RPC
                                         mark PAID → write settlement records
 cashier screen flips to PAID ◀── polling + WebSocket
```

Key design points:

- **Server-fixed amount.** For Solana, the QR or deep link points to a
  [Solana Pay Transaction Request](https://docs.solanapay.com/core/transaction-request/merchant-integration)
  URL on this server (`/api/solana-pay/:orderId`). The wallet posts its
  address, and the server returns a ready-to-sign transaction.
- **Single treasury.** All of a payment goes to one merchant address. The
  revenue "splits" (Tax, Expenses, Profit, and so on) are bookkeeping records
  (`SettlementTransaction` rows). They are **not** separate on-chain transfers.
- **Preflight before handoff.** The customer's balance is checked before their
  wallet opens. A shortfall is reported in plain language on the checkout page,
  pushed to the cashier's screen, and sent as a Web Push notification where the
  browser supports it.
- **Verified settlement.** A submitted transaction hash is parsed on-chain to
  confirm the amount, recipient and token mint. The server also rejects a hash
  that was already used for another order. A payment that lands after the order
  was cancelled is recorded as a *stray payment*, not silently accepted.

---

## Project layout

```
dynkle-api/
├── src/
│   ├── index.js                 server entry: middleware, NFC tap routes, background loop, serves the website
│   ├── config.js                env parsing + defaults
│   ├── db.js                    Prisma client
│   ├── middleware/auth.js       JWT auth
│   ├── gateway/terminalGateway.js   WebSocket /ws/terminal (legacy tags + hands v2 devices to src/devices)
│   ├── devices/                 counter devices: the FP9810 Dynkle terminal app
│   │   ├── deviceRoutes.js      dashboard pairing/management + device API (/api/terminals/…)
│   │   ├── deviceHub.js         live device sockets, bills → device, real order status → device
│   │   ├── deviceAuth.js        EC key challenge → device JWT, reachable server address
│   │   └── deviceStore.js       devices_store.json, pairing codes, challenges
│   ├── routes/
│   │   ├── auth.js              register / login / refresh / OTP
│   │   ├── kyb.js               ABN lookup, document upload, KYB review
│   │   ├── terminals.js         legacy tag terminals: register, pair, arm/disarm
│   │   ├── orders.js            full order lifecycle, preflight, refunds, push
│   │   ├── solanaPay.js         Solana Pay Transaction Request endpoints
│   │   ├── merchant.js          dashboard: onboarding, products, wallets, P&L, kit
│   │   └── autoSwap.js          auto-swap policies, ledger, notifications
│   └── services/                solana, evm, preflight, pricing, P&L, OTP, KYB, push, NTAG 424 …
├── prisma/schema.prisma         database schema (PostgreSQL, database dynkle_pos_poc)
├── prisma/seed.js               demo merchant + user
├── tests/                       node:test suites (+ tests/e2e journey script)
├── uploads/                     KYB document uploads
├── docs/                        specs (.docx) and docs/scripts/ spec generators
└── programs/dynkle-auto-swap/   Solana (Anchor/Rust) auto-swap program (reference, not deployed)
```

The website is **not** inside this repo — see
[dynkle-web](https://github.com/Dynk-IO/dynkle-web). The server serves it as
static files (set `FRONTEND_DIR` to the cloned path). Pages and the API share
one origin, which `/api/*` calls and the `/ws/terminal` socket rely on.

The Android terminal app is [dynkle-terminal](https://github.com/Dynk-IO/dynkle-terminal).

---

## Quick start

### Prerequisites

- **Node.js 20+** (ES modules, `node --watch`, and the built-in `node:test` runner)
- **PostgreSQL 14+**. This machine's demo uses a local data folder on port
  5433. Start it with
  `/usr/lib/postgresql/14/bin/pg_ctl -D /home/nitya/DYNK-Latest/pgdata -o "-p 5433 -k /home/nitya/DYNK-Latest/pgdata" start`
  and use `DATABASE_URL=postgresql://<user>@localhost:5433/dynkle_pos_poc?host=/home/nitya/DYNK-Latest/pgdata`.
- Optional: **cloudflared** or **ngrok**, to test on a real phone

### 1. Install

```bash
cd dynkle-pos-demo/backend
npm install
cp .env.example .env
```

### 2. Configure `.env`

At minimum, set:

```dotenv
DATABASE_URL=postgresql://USER:PASSWORD@localhost:5432/dynkle_pos_poc
PORT=4100
PUBLIC_BASE_URL=http://localhost:4100
SOLANA_RPC=https://api.devnet.solana.com
MERCHANT_SOLANA_ADDRESS=<your devnet receiving address>
JWT_SECRET=<long random string>
JWT_REFRESH_SECRET=<different long random string>
```

For local development you almost certainly also want:

```dotenv
OTP_DEV_LOG=true
OTP_DEV_BYPASS=true
```

See [Environment variables](#environment-variables) for the full list.

### 3. Create the database schema and seed it

The project has no migration history, so push the schema directly:

```bash
npx prisma db push      # creates tables from prisma/schema.prisma
npx prisma generate     # generates the Prisma client
npm run db:seed         # demo merchant "Bean & Brew Café"
```

Seeded login: `merchant@beanandbrew.com.au` / `Password123!`

### 4. Run

```bash
npm run dev     # auto-restarts on file changes
# or
npm start
```

| URL | What |
|---|---|
| http://localhost:4100/index.html | Cashier / merchant dashboard |
| http://localhost:4100/onboarding.html | Merchant onboarding |
| http://localhost:4100/pay.html?orderId=… | Customer checkout (normally opened from a tap or QR) |
| http://localhost:4100/health | Health check |

At startup the server auto-registers the default counters `POS_001`, `POS_002`,
`POS_003` and `DY-009` against the oldest merchant.

---

## Environment variables

| Variable | Default | Purpose |
|---|---|---|
| `PORT` | `4000` (the POC `.env` sets `4100`) | HTTP + WebSocket port |
| `DATABASE_URL` | none (required) | PostgreSQL connection string |
| `PUBLIC_BASE_URL` | `http://localhost:4100` | Public URL for customer links (payment QR on the website and terminal, NFC tap, Solana Pay, push). A running cloudflared quick tunnel is detected and used first; local and LAN addresses are never used while a public one is known. See `src/services/publicUrl.js`. |
| `CLOUDFLARED_METRICS` | `20241,…,20245` | Ports where the tunnel's address is read (`/quicktunnel`). Empty turns detection off. |
| `NODE_ENV` | none | `test` enables test-only fake transaction hashes |
| `MERCHANT_NAME` | `Bean & Brew Café` | Fallback display name |
| `MERCHANT_SOLANA_ADDRESS` | System Program address (placeholder) | Solana treasury |
| `MERCHANT_EVM_ADDRESS` | `0x…dEaD` (placeholder) | EVM treasury |
| `MERCHANT_SOLANA_PRIVATE_KEY` | none | Needed **only for refunds**. Without it, refunds fail with `REFUND_KEY_NOT_CONFIGURED` rather than faking success. |
| `SOLANA_RPC` | `https://api.devnet.solana.com` | Solana RPC endpoint |
| `RPC_ETHEREUM`, `RPC_POLYGON`, `RPC_BASE`, `RPC_ARBITRUM`, `RPC_OPTIMISM`, `RPC_BSC`, `RPC_SEPOLIA` | public endpoints | EVM RPC overrides. Use a dedicated provider (Helius, Alchemy, QuickNode) for anything real. |
| `WALLETCONNECT_PROJECT_ID` | none | Needed for the WalletConnect EVM flow ([cloud.reown.com](https://cloud.reown.com)) |
| `JWT_SECRET`, `JWT_REFRESH_SECRET` | hard-coded demo values | **Must be set in production.** The defaults are public in this repo. |
| `OTP_DEV_BYPASS` | off | Master dev-mode switch. See [below](#dev-mode-otp_dev_bypass). |
| `OTP_DEV_LOG` | off | Logs generated OTP codes to the console |
| `MAX_ORDER_AUD` | `10000` | Maximum single bill (bypassed in dev mode) |
| `LARGE_AMOUNT_WARNING_AUD` | `500` | Above this, the customer gets an extra confirmation step |
| `VAPID_PUBLIC_KEY`, `VAPID_PRIVATE_KEY` | fixed demo pair | Web Push keys. Generate your own with `npx web-push generate-vapid-keys`. |
| `VAPID_CONTACT_EMAIL` | `mailto:admin@dynkle.example.com` | Web Push contact |
| `KYB_REVIEWER_API_KEY` | none | Admin key for `POST /api/kyb/review` |
| `NTAG424_MASTER_KEY` | all zeros | AES key for NTAG 424 DNA tag validation |
| `APPLE_TEAM_ID` | `DYNKTEAM` | iOS Universal Links (`/.well-known/apple-app-site-association`) |
| `ANDROID_PACKAGE_NAME`, `ANDROID_SHA256_FINGERPRINT` | demo values | Android App Links (`/.well-known/assetlinks.json`) |

Bills can be paid for **2 minutes (120 seconds)** after they are created
(`ORDER_TTL_SECONDS` in `src/config.js`, not configurable through env). The
register, the checkout page and the terminal all count down from the server's
`quoteExpiresAt`, so changing the constant changes it everywhere.

---

## Dev mode (`OTP_DEV_BYPASS`)

Setting `OTP_DEV_BYPASS=true` turns on **every** development shortcut from one
switch. With it off, all of the checks below are enforced.

| Area | What gets bypassed | Where |
|---|---|---|
| OTP | Any code is accepted, the code is always `123456`, and there is no rate limit | `services/otpService.js` |
| KYB | Any 11-digit ABN is accepted, with placeholder company data | `services/kybService.js` |
| Go-live | Missing prerequisites (kit paid, terminal, split rules) are auto-fulfilled | `routes/merchant.js` → `/onboarding/go-live` |
| Hardware kit payment | Missing or unknown payment intents are accepted | `services/paymentGateway.js` |
| Preflight | Every wallet reports a balance of 999999, so empty wallets can check out | `services/preflight.js` |
| Order cap | `MAX_ORDER_AUD` is ignored | `routes/orders.js` |
| Wallet addresses | An invalid Solana address is replaced with a valid default instead of being rejected | `routes/merchant.js` → `POST /wallets` |
| Payment verification | `sol_test_…` hashes are accepted as verified payments. `POST /api/orders/:id/submit` with `{"demoMode": true}` and no hash settles the order with a generated fake hash. | `services/solana.js`, `routes/orders.js` |

**Not bypassed:** refunds. `executeSolanaRefund` always needs a real
`MERCHANT_SOLANA_PRIVATE_KEY` and a real broadcast. It never reports a refund
that didn't happen.

> ⚠️ **Never enable `OTP_DEV_BYPASS` on a server that handles real money.**
> With it on, anyone can mark an order paid without paying.

Quick dev-mode smoke test:

```bash
BASE=http://localhost:4100
OID=$(curl -s -X POST $BASE/api/orders -H 'Content-Type: application/json' \
  -d '{"amountAUD":"25","terminalId":"POS_001","tokenSymbol":"SOL"}' | node -pe 'JSON.parse(require("fs").readFileSync(0)).id')
curl -s -X POST $BASE/api/orders/$OID/submit -H 'Content-Type: application/json' -d '{"demoMode":true}'
# → "status":"PAID", "txHash":"sol_test_…"
```

---

## Testing on a real phone

Customers open checkout links on their own phone, often on mobile data, so
`localhost` and the shop's LAN IP (`192.168.x.x`) won't work. Customer links
need a public HTTPS address.

```bash
npm start                                    # server on :4100
cloudflared tunnel --url http://localhost:4100
# prints https://<random-words>.trycloudflare.com
```

Then:

1. Nothing to configure: the server reads the tunnel's address from cloudflared
   (within 30 s) and logs `[publicUrl] Customer links use https://…`.
2. Create a bill. The QR on the website and on the terminal now opens
   `https://<…>.trycloudflare.com/pay.html?orderId=…` on the customer's phone.

Quick tunnels get a **new URL each time** they start; it is picked up
automatically. Bills already on screen keep the link they were shown with.
For a fixed address (a real domain), set `PUBLIC_BASE_URL` instead. If no
public address is known, links fall back to the LAN IP and a warning is logged.

**Web Push on iPhone:** iOS only delivers Web Push to sites that have been
**added to the Home Screen** (iOS 16.4+). It never works in a normal Safari
tab. Android Chrome and desktop browsers work normally. The in-page and
cashier-screen alerts work everywhere, whether or not push is available.

---

## Web pages

The pages live in [dynkle-web](https://github.com/Dynk-IO/dynkle-web); this server only serves them.

| Page | Who | Highlights |
|---|---|---|
| `index.html` | Cashier / merchant | Bill entry, live order status, merchant alerts banner, products, wallets & revenue categories (`?page=wallets`), P&L and holdings (`?page=pnl`), auto-swap, terminals |
| `pay.html` | Customer | Coin and wallet picker, preflight balance check, large-amount confirmation, express wallet auto-launch, "Opening wallet → Confirming your payment → receipt" screens with **Pay a different way**, Web Push opt-in, clear error screen for every flow code |
| `onboarding.html` | New merchant | Account (OTP) → business, kind of business and counters → POS device order → payouts → products → go-live. The device is paired later from Counter devices. |
| `standby.html` | Customer | Shown after an NFC tap when there is nothing to pay, the counter is in use, or a payment is already confirming |
| `landing.html` | Public | Marketing page |

### NFC / short links

| Route | Behaviour |
|---|---|
| `/t/:terminalId`, `/c/:terminalId`, `/api/tap/:terminalId` | Resolve a tap to the terminal's current bill |
| `/t/:merchantId/:terminalId`, `/m/:merchantId/:terminalId` | Same, scoped to a merchant |
| `?pair=true&pairCode=…` | Bind a tag to a merchant. The pair code comes from `POST /api/terminals/nfc-pair-code`. |
| `?picc=…&cmac=…` | NTAG 424 DNA SUN signature, checked for cloning and replay |

Terminal IDs are normalised: `1`, `c1`, `pos1` → `POS_001`, and so on.
**The first tap locks the bill.** A second customer tapping the same counter
sees "counter in use".

---

## Order lifecycle

```
CREATED → QUOTED → DEVICE_ARMED → WAITING_FOR_CUSTOMER → CUSTOMER_DETECTED
        → AWAITING_APPROVAL → SUBMITTED → CONFIRMING → PAID → SETTLING → SETTLED → RECEIPT_READY

Side exits:  EXPIRED (quote ran out) · CANCELLED (cashier cancel / terminal offline)
             PAYMENT_FAILED (submitted but never confirmed within 15 min)
             SETTLEMENT_FAILED · PRICE_MOVED · REFUNDED
```

Every customer-facing error is a named **flow code** from
`src/services/paymentFlows.js`, for example `INSUFFICIENT_BALANCE`,
`INSUFFICIENT_GAS`, `QUOTE_EXPIRED`, `DUPLICATE_PAYMENT`,
`STRAY_PAYMENT_RECEIVED`, `TERMINAL_OFFLINE` or `AMOUNT_EXCEEDS_LIMIT`. Each
code carries its HTTP status, whether it's retryable, whether funds moved,
whether to alert the cashier, and the customer-facing title, message and action.
`GET /api/orders/flows` returns the whole catalogue.

---

## API reference

All routes are under the prefixes below. Merchant routes resolve the merchant
from a JWT or the `x-merchant-id` header.

<details>
<summary><b>/api/auth</b> — accounts & OTP</summary>

| Method | Path | |
|---|---|---|
| POST | `/register` | Creates the user as `PENDING` / unverified |
| POST | `/send-otp` | Sends an email/phone OTP |
| POST | `/verify-otp` | Verifies the OTP. Marks email/phone verified and activates a `PENDING` user. |
| POST | `/login` | Access + refresh tokens |
| POST | `/refresh` | Rotates the refresh token. Replaying a revoked token revokes all of the user's tokens. |
| POST | `/logout` | |
| GET | `/me` | |
</details>

<details>
<summary><b>/api/orders</b> — order lifecycle</summary>

| Method | Path | |
|---|---|---|
| POST | `/` | Create an order `{amountAUD, terminalId, tokenSymbol}` |
| GET | `/` | List orders |
| GET | `/:id` | Order status (+ latest preflight result). `?watch=evm` also looks for the order's tagged Sepolia transfer (MetaMask/Trust payment links) and marks it paid when found. The scan runs in the background, so the call stays fast. |
| POST | `/:id/claim` | Customer claims the bill |
| POST | `/:id/preflight` | `{account, chain: "solana"\|"evm", chainId?, walletKey?}` → balance check |
| POST | `/:id/currency-choice` | Customer switches token |
| POST | `/:id/processing` | Customer is in their wallet |
| POST | `/:id/abandon` | Customer backed out |
| POST | `/:id/confirm`, `/:id/submit` | Submit a tx hash for on-chain verification |
| POST | `/:id/cancel` | Cashier cancel |
| POST | `/:id/refund` | Refund (needs `MERCHANT_SOLANA_PRIVATE_KEY`) |
| GET | `/:id/refund-receipt` | |
| GET | `/flows` | Flow-code catalogue |
| GET | `/solana-blockhash` | Recent blockhash |
| GET | `/push/vapid-public-key` | Web Push public key |
| POST | `/:id/push-subscribe` | Register a push subscription for this order |
</details>

<details>
<summary><b>/api/solana-pay</b> — Solana Pay Transaction Request</summary>

| Method | Path | |
|---|---|---|
| GET | `/:orderId` (alias `/order/:orderId`) | Merchant label + icon for the wallet |
| POST | `/:orderId` (alias `/order/:orderId`) | `{account}` → base64 unsigned transaction |
</details>

<details>
<summary><b>/api/terminals</b> — countertop devices</summary>

| Method | Path | |
|---|---|---|
| POST | `/register` | Register a device |
| GET | `/` | List terminals |
| POST | `/nfc-pair-code` | Short-lived code used to pair an NFC tag |
| POST | `/:terminalId/pair` | Pair a device |
| POST | `/:terminalId/arm`, `/:terminalId/disarm` | Arm or disarm a terminal for a bill |
| GET | `/:terminalId/status` | |
| GET | `/:terminalId/active-session` (and `/:merchantId/:terminalId/active-session`) | Current bill on a counter (polled by `standby.html`) |
</details>

<details>
<summary><b>/api/merchant</b> — dashboard</summary>

| Area | Routes |
|---|---|
| State | `GET /state`, `GET /list`, `GET /onboarding` |
| Onboarding | `POST /onboarding/account`, `/business`, `/counters`, `/kit-order`, `/pair-device`, `/go-live`, `/reset`, `/fake-complete` |
| Hardware kit | `POST /kit/checkout`, `POST /kit/confirm`, `GET /kit/shipping` |
| Terminals & tags | `GET /terminals`, `POST /pair-tag` |
| Products | `GET/POST /products`, `POST /products/bulk`, `PUT/DELETE /products/:id` |
| Wallets / categories | `POST /wallets` |
| Currencies | `GET/POST /currencies`, `POST /currencies/toggle`, `DELETE /currencies/:symbol`, `POST /tokens` |
| P&L | `GET /pnl`, `POST /pnl/reset` (reseeds **demo** data, flagged `isDemoData`), `POST /swap` |
| Auto-swap config | `GET/POST /autoswap/config` |
| Alerts | `GET /alerts`, `POST /alerts/:id/acknowledge` |
</details>

<details>
<summary><b>/api/kyb</b> — business verification</summary>

| Method | Path | |
|---|---|---|
| GET | `/abn/:abn` | ABN lookup |
| POST | `/documents` | Upload a document (multipart) |
| GET | `/documents` | List documents |
| GET | `/documents/:id/download` | Ownership-checked download (`/uploads/kyb` is blocked from direct access) |
| POST | `/submit` | Submit for review |
| GET | `/status` | |
| POST | `/review` | Approve/reject (needs `KYB_REVIEWER_API_KEY`) |
</details>

<details>
<summary><b>/api/auto-swap</b> — automatic stablecoin conversion</summary>

`GET /policies`, `POST /policy`, `POST /revoke`, `POST /trigger`,
`POST /simulate-payment`, `GET /ledger`, `GET /ledger/export`,
`GET /notifications`
</details>

---

## Real-time channels

- **WebSocket** at `/ws/terminal` (`src/gateway/terminalGateway.js`).
  Countertop devices connect here to be armed or disarmed and to receive
  payment events. The server pings devices and checks heartbeats every 15s. Critical messages are
  queued and replayed when a device reconnects, and reconnects are
  authenticated by serial number.
- **Counter devices (protocol v2).** The FP9810 Dynkle terminal app connects to the
  same `/ws/terminal` with `?token=<device JWT>`. It receives `CONFIG`, `ARM` (bill),
  `DISARM` (with who cancelled), `ORDER_STATUS` (PAID / PROCESSING / FAILED /
  EXPIRED) and `CUSTOMER_TAPPED`. The Counter devices page connects with
  `?role=dashboard&merchantId=…` and receives `DEVICE_ONLINE` / `DEVICE_OFFLINE` /
  `DEVICE_STATUS` / `DEVICE_PAIRED`. See [Counter devices](#counter-devices-fp9810).
- **Polling.** The cashier dashboard polls `GET /api/orders/:id` and
  `GET /api/merchant/alerts`.
- **Web Push.** Sent for insufficient-funds events when a customer has opted
  in on `pay.html` (service worker: `frontend/sw.js`).

---

## Counter devices (FP9810)

Code: `src/devices/`. App: [dynkle-terminal](https://github.com/Dynk-IO/dynkle-terminal).

**Pairing.** Dashboard → Counter devices → Add device → choose a counter → a
single-use 8-character code (10 minutes) and a QR. The QR carries the server
address. The device scans or types the code, registers its keystore EC key, then
signs in by challenge (`/auth/challenge` → `/auth/token`) for a 15-minute device JWT.

**Selling.** Charging a counter (`POST /api/orders` with `terminalId`) reaches the
gateway's `arm()`, which pushes the bill to that counter's device. The device is
told the real outcome. The hub also re-reads the armed order every 3 s, so paths
that don't notify the gateway still reach the device. A keypad sale on the
device (`POST /api/terminals/me/orders`) goes through the same `/api/orders` logic.

| Route | Who | Purpose |
|---|---|---|
| `GET /api/terminals/devices` | Dashboard | Devices + counters for the merchant, live online state |
| `POST /api/terminals/pairing-codes` | Dashboard | `{ terminalId \| newCounterLabel, label }` → code, QR payload, server address |
| `GET /api/terminals/pairing-codes/:id` | Dashboard | `PENDING` / `PAIRED` / `EXPIRED` |
| `PATCH /api/terminals/devices/:id` | Dashboard | Rename or move to another counter |
| `POST /api/terminals/devices/:id/revoke` | Dashboard | Unpair (device is signed out immediately) |
| `POST /api/terminals/pair` | Device | Claim a code with the device public key |
| `POST /api/terminals/auth/challenge`, `/auth/token` | Device | Sign-in by signed challenge |
| `GET /api/terminals/me/active-order` | Device | Restore the open bill after a reconnect |
| `POST /api/terminals/me/orders`, `/me/orders/:id/cancel` | Device | Keypad sale, cancel |
| `GET /api/terminals/me/orders` | Device | Recent transactions |
| `POST /api/terminals/me/staff/verify` | Device | Cashier PIN (`TERMINAL_STAFF_PIN`, default `1234`) |
| `POST /api/terminals/me/unpair` | Device | Unpaired from the device's Settings |
| `GET /api/terminals/me/catalog` | Device | The merchant's products (with option add-ons) and categories, for the device register |
| `POST /api/terminals/me/products` | Device | `{ name, priceCents, category, pin }`: add a product to the shared catalog (cashier PIN) |

Notes:
- The pairing QR/server address is one a real device can reach. A dashboard opened on
  `localhost` gets this machine's LAN IP. `DEVICE_BASE_URL` overrides it (e.g. a tunnel).
- The **payment** link the device shows (QR and NFC) is for the customer's phone,
  so it uses the public address (tunnel or `PUBLIC_BASE_URL`), not the device's LAN address.
- Devices match orders by counter id (`POS_001` …), which is unique across merchants.
- **Register sales from the device** send `items: [{ productId, variants, qty }]`, never
  prices. The server prices every line from the catalog (`src/devices/pricing.js`, same
  option rules as the web register: add-ons, line name "Product · Option A, Option B").
  A removed product or option returns `409` and the device re-syncs its bill.
- Pairing codes are in memory, so a restart voids an open code. Devices persist
  in `devices_store.json` (gitignored).

---

## Background jobs

Both start with the server:

- **Payment and expiry monitor** (every 5s, in `src/index.js`):
  - checks open orders on-chain and settles any that were paid
  - expires orders whose quote has run out
  - cancels orders on a terminal that has been offline for more than 30s
  - marks orders `PAYMENT_FAILED` if they were submitted but stayed
    unconfirmed for more than 15 minutes
- **Auto-swap keeper** (every 60s, in `services/autoSwapKeeperService.js`):
  runs merchants' auto-swap policies.

---

## Tests

```bash
npm test                                   # node:test suites in tests/*.test.js
node tests/e2e/test_merchant_sow_journey.cjs   # full merchant journey against a running server (PORT, default 4100)
```

| Suite | Covers |
|---|---|
| `tests/devices.test.js` | Pairing codes (single use), device signature check, challenge, device token + revoke, reachable server address |
| `tests/evmWatch.test.js` | MetaMask/Trust payment-link detection: order tag, matching the tagged Sepolia transfer, ignoring untagged or other-address transfers |
| `tests/pricing.test.js` | Register pricing from the catalog (product lines, options, quantities) |
| `tests/publicUrl.test.js` | Public customer-link address (tunnel detection, LAN fallback) |
| `tests/e2e/test_merchant_sow_journey.cjs` | Landing → onboarding → dashboard → checkout pages and APIs. **Resets onboarding data** (`/api/merchant/onboarding/reset`), so don't run it against data you want to keep. |

The older suites listed in earlier versions of this README (auth isolation, KYB,
rate-lock expiry …) are no longer in the repository.

---

## Known limitations and production checklist

Before handling real money:

- [ ] `OTP_DEV_BYPASS` and `OTP_DEV_LOG` are **unset**.
- [ ] `JWT_SECRET`, `JWT_REFRESH_SECRET`, the VAPID keys and
      `NTAG424_MASTER_KEY` are set to your own secrets. The code falls back to
      demo values that are public in this repo.
- [ ] `SOLANA_RPC` points to mainnet on a dedicated provider, and the merchant
      addresses are real.
- [ ] `MERCHANT_SOLANA_PRIVATE_KEY` is set only if you need refunds, and is
      stored in a secrets manager rather than a plain `.env`.
- [ ] `PUBLIC_BASE_URL` is a stable HTTPS domain, not a quick tunnel.
- [ ] CORS is locked down. The server currently sends
      `Access-Control-Allow-Origin: *`.

Known limitations:

- **In-memory state is lost on restart:** OTP codes, push subscriptions,
  preflight results, P&L ledgers and terminal sessions. Orders, users and
  settlements are stored in PostgreSQL.
- **Revenue splits are off-chain.** All funds land in one treasury address.
- **EVM checkout supports native tokens only** (ETH and similar). An EVM wallet
  can't pay a bill quoted in an SPL or ERC-20 token.
- **Swaps on the P&L page are ledger conversions.** No on-chain swap is
  broadcast.
- **The process swallows `uncaughtException`.** If the port is already taken,
  the server logs a warning and stays alive without listening. Use
  `lsof -i :4100` to find what holds the port.
- **EVM payment-link payments are matched by an order tag.** The pay page puts
  a 6-digit tag in the last digits of the wei amount, and
  `src/services/evmWatch.js` scans recent Sepolia blocks for a transfer to
  `MERCHANT_EVM_ADDRESS` ending in it. If the customer edits the amount in
  MetaMask, the tag is lost and the payment isn't matched automatically. The
  old `src/services/evm.js` (legacy JSON order store) is no longer used by the
  checkout.
- **Auto-swap state lives in JSON files.** `auto_swap_ledger.json` (about 7 MB
  already) and `auto_swap_policies.json` sit in the backend directory and grow
  over time.
