import { Router } from 'express';
import crypto from 'crypto';
import prisma from '../db.js';
import { requireAuth, requireMerchant, requireRole } from '../middleware/auth.js';
import { terminalGateway } from '../gateway/terminalGateway.js';

const router = Router();

/**
 * Short-lived, single-use NFC pairing codes.
 *
 * The physical-tap pairing route in index.js (`GET /t/:id?pair=true`) is a
 * bare, unauthenticated GET — it has to be, since a phone tapping an NFC tag
 * can't carry a bearer token. It used to trust a raw `merchantId` typed into
 * the URL/header with zero proof of ownership, meaning anyone could bind any
 * physical terminal to any merchant account. This mints a code through an
 * AUTHENTICATED route first; the physical tap must then present that exact
 * code, so the thing being trusted is "an owner/admin approved this pairing
 * moments ago," not "a caller typed a merchant id."
 */
const pendingNfcPairCodes = new Map(); // code -> { merchantId, terminalId, createdAt }
const NFC_PAIR_CODE_TTL_MS = 10 * 60 * 1000;

export function consumeNfcPairCode(code, terminalId) {
  const entry = pendingNfcPairCodes.get(code);
  if (!entry) return null;
  pendingNfcPairCodes.delete(code);
  if (Date.now() - entry.createdAt > NFC_PAIR_CODE_TTL_MS) return null;
  if (entry.terminalId && entry.terminalId !== terminalId) return null;
  return entry.merchantId;
}

// POST /api/terminals/nfc-pair-code - Mint a short-lived code an owner/admin
// can hand to the physical tap-to-pair flow. Requires real auth, unlike the
// tap route itself.
router.post('/nfc-pair-code', requireAuth, requireMerchant, requireRole('OWNER', 'ADMIN'), async (req, res) => {
  const { terminalId } = req.body || {};
  const code = crypto.randomBytes(6).toString('hex').toUpperCase();
  pendingNfcPairCodes.set(code, { merchantId: req.merchant.id, terminalId: terminalId || null, createdAt: Date.now() });
  res.json({ success: true, pairCode: code, expiresInSeconds: NFC_PAIR_CODE_TTL_MS / 1000 });
});

// POST /api/terminals/register - Register a new countertop terminal
router.post('/register', requireAuth, requireMerchant, requireRole('OWNER', 'ADMIN'), async (req, res) => {
  try {
    const { terminalId, serialNumber } = req.body;
    const tid = terminalId || `DY-${Math.floor(100 + Math.random() * 900)}`;
    const sn = serialNumber || `SN-${crypto.randomBytes(4).toString('hex').toUpperCase()}`;

    // Without this check, any authenticated OWNER/ADMIN of ANY merchant could
    // register with an existing terminalId and instantly reassign a
    // different merchant's already-paired terminal to themselves — rotating
    // its pairing token and knocking the real owner's device back to PAIRING.
    const existing = await prisma.terminal.findUnique({ where: { terminalId: tid } });
    if (existing && existing.merchantId !== req.merchant.id) {
      return res.status(403).json({
        error: 'TERMINAL_ALREADY_CLAIMED',
        message: 'This terminal ID is already registered to a different merchant.'
      });
    }

    // Cryptographic pairing token (e.g. PAIR-94A2)
    const pairingToken = `PAIR-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

    const terminal = await prisma.terminal.upsert({
      where: { terminalId: tid },
      update: {
        serialNumber: sn,
        pairingToken,
        status: 'PAIRING',
        merchantId: req.merchant.id
      },
      create: {
        merchantId: req.merchant.id,
        terminalId: tid,
        serialNumber: sn,
        pairingToken,
        firmwareVersion: '2.4.1',
        status: 'PAIRING'
      }
    });

    res.status(201).json({
      success: true,
      terminal: {
        id: terminal.id,
        terminalId: terminal.terminalId,
        serialNumber: terminal.serialNumber,
        pairingToken: terminal.pairingToken,
        status: terminal.status,
        firmwareVersion: terminal.firmwareVersion
      }
    });
  } catch (err) {
    console.error('[Terminal Register Error]:', err);
    res.status(500).json({ error: 'REGISTRATION_FAILED', message: err.message });
  }
});

// GET /api/terminals - List all merchant terminals
router.get('/', requireAuth, requireMerchant, async (req, res) => {
  try {
    const terminals = await prisma.terminal.findMany({
      where: { merchantId: req.merchant.id },
      orderBy: { createdAt: 'desc' }
    });

    const result = terminals.map(t => ({
      id: t.id,
      terminalId: t.terminalId,
      serialNumber: t.serialNumber,
      status: t.status,
      isOnline: terminalGateway.isOnline(t.terminalId),
      firmwareVersion: t.firmwareVersion,
      lastSeenAt: t.lastSeenAt,
      pairedAt: t.pairedAt
    }));

    res.json({ success: true, terminals: result });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/terminals/:terminalId/pair - Complete pairing with token
router.post('/:terminalId/pair', requireAuth, requireMerchant, requireRole('OWNER', 'ADMIN'), async (req, res) => {
  try {
    const { pairingToken } = req.body;
    const { terminalId } = req.params;

    if (!pairingToken || typeof pairingToken !== 'string') {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Pairing token is required.' });
    }

    const terminal = await prisma.terminal.findUnique({
      where: { terminalId }
    });

    if (!terminal || terminal.merchantId !== req.merchant.id) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Terminal not found.' });
    }

    if (terminal.pairingToken !== pairingToken.trim().toUpperCase()) {
      return res.status(400).json({ error: 'INVALID_TOKEN', message: 'Incorrect pairing token.' });
    }

    const updated = await prisma.terminal.update({
      where: { terminalId },
      data: {
        status: 'READY',
        pairedAt: new Date(),
        lastSeenAt: new Date(),
        pairingToken: null
      }
    });

    res.json({
      success: true,
      message: 'Terminal paired and online.',
      terminal: {
        terminalId: updated.terminalId,
        status: updated.status,
        pairedAt: updated.pairedAt
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'PAIRING_FAILED', message: err.message });
  }
});

// POST /api/terminals/:terminalId/arm - Arm terminal for order
router.post('/:terminalId/arm', requireAuth, requireMerchant, async (req, res) => {
  try {
    const { terminalId } = req.params;
    const { orderId, amountAUD, cryptoAmount, tokenSymbol, quoteExpiresAt } = req.body;

    const armed = await terminalGateway.arm(terminalId, {
      orderId,
      amountAUD,
      cryptoAmount,
      tokenSymbol,
      quoteExpiresAt
    });

    res.json({
      success: true,
      armed,
      terminalId,
      orderId,
      isOnline: terminalGateway.isOnline(terminalId)
    });
  } catch (err) {
    res.status(500).json({ error: 'ARM_FAILED', message: err.message });
  }
});

// POST /api/terminals/:terminalId/disarm - Disarm terminal
router.post('/:terminalId/disarm', requireAuth, requireMerchant, async (req, res) => {
  try {
    const { terminalId } = req.params;
    const disarmed = await terminalGateway.disarm(terminalId);
    res.json({ success: true, disarmed, terminalId });
  } catch (err) {
    res.status(500).json({ error: 'DISARM_FAILED', message: err.message });
  }
});

// GET /api/terminals/:terminalId/status - Live terminal status
router.get('/:terminalId/status', async (req, res) => {
  try {
    const { terminalId } = req.params;
    const terminal = await prisma.terminal.findUnique({
      where: { terminalId }
    });

    if (!terminal) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Terminal not found.' });
    }

    res.json({
      success: true,
      terminalId: terminal.terminalId,
      status: terminal.status,
      isOnline: terminalGateway.isOnline(terminal.terminalId),
      firmwareVersion: terminal.firmwareVersion,
      lastSeenAt: terminal.lastSeenAt
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

export default router;
