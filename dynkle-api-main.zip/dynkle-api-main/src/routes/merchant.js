import express from 'express';
import { PublicKey } from '@solana/web3.js';
import prisma from '../db.js';
import { createKitPaymentIntent, processKitPaymentSuccess } from '../services/paymentGateway.js';
import { getShipmentStatus } from '../services/shippingService.js';
import { terminalGateway } from '../gateway/terminalGateway.js';
import { validateNtag424Tap } from '../services/ntag424.js';
import { getMerchantPnlData, executeMerchantSwap, resetPnlLedger } from '../services/pnlService.js';
import { merchantState, getAutoSwapConfig, updateAutoSwapConfig, setMerchantWallets } from '../merchantStore.js';
import { DEMO_MODE } from '../config.js';

// POC catalogue helpers. `category` holds a path such as "Food > Starters > Soups";
// extra product details live in `meta` so any kind of business can describe items.
const PRODUCT_META_KEYS = ['icon', 'variants', 'variantLabel', 'image', 'cogs', 'tax', 'sku', 'stock', 'desc', 'isPopular', 'isVegan', 'isGlutenFree'];
// Product photos are small images the website shrinks before saving (about 70 KB at most).
const PRODUCT_IMAGE_RE = /^data:image\/(webp|jpeg|png);base64,[A-Za-z0-9+/=]+$/;
const PRODUCT_IMAGE_MAX = 100_000;
function productMeta(body) {
  const meta = {};
  for (const k of PRODUCT_META_KEYS) if (body[k] !== undefined) meta[k] = body[k];
  if (meta.image !== undefined && !(typeof meta.image === 'string' && meta.image.length <= PRODUCT_IMAGE_MAX && PRODUCT_IMAGE_RE.test(meta.image))) delete meta.image;
  if (meta.variantLabel !== undefined) meta.variantLabel = String(meta.variantLabel || '').trim().slice(0, 24);
  return meta;
}
export function mapProduct(p) {
  const meta = (p.meta && typeof p.meta === 'object') ? p.meta : {};
  return {
    ...meta,
    id: p.id,
    name: p.name,
    category: p.category,
    cat: p.category,
    description: p.description,
    desc: meta.desc ?? p.description ?? '',
    price: parseFloat(p.price.toString()),
    currency: p.currency
  };
}
export function cleanCategoryPath(v) {
  return String(v || '').split('>').map(x => x.trim()).filter(Boolean).slice(0, 8).join(' > ');
}

const router = express.Router();

// Helper to get active merchant
export async function getActiveMerchant(req) {
  const merchantId = req.headers['x-merchant-id'] || req.query?.merchantId || req.body?.merchantId;
  if (merchantId) {
    const found = await prisma.merchant.findUnique({ where: { id: merchantId } });
    if (found) return found;
  }
  return await prisma.merchant.findFirst({ orderBy: { updatedAt: 'desc' } }) || await prisma.merchant.findFirst({ orderBy: { createdAt: 'asc' } });
}


// Immutable template — DO NOT mutate this array directly. It used to be
// mutated in place by the /currencies routes below, which meant one
// merchant's custom "swap & send" currency (or disabling a currency) silently
// changed what every OTHER merchant on this process saw, and concurrent
// requests from different merchants could lose updates to each other via
// racing push/splice calls on the same shared array.
const DEFAULT_SWAP_AND_SEND_TEMPLATE = [
  { symbol: 'ETH',  name: 'Ethereum',     chain: 'Sepolia / EVM',  fee: 'Swap 0.5% (Payer)', direct: false, solver: 'Uniswap V2 / deBridge', icon: '⟠', priceAUD: 4120.50, speed: '~2.5s', payout: '100% USDC' },
  { symbol: 'BTC',  name: 'Bitcoin',      chain: 'Lightning L2',   fee: 'Swap 0.5% (Payer)', direct: false, solver: 'Lightning / Solana',    icon: '₿', priceAUD: 104500.00, speed: '~3.0s', payout: '100% USDC' },
  { symbol: 'TRX',  name: 'TRON Native',  chain: 'TRON Network',   fee: 'Swap 0.4% (Payer)', direct: false, solver: 'JustSwap / Bridge',     icon: '🔴', priceAUD: 0.35, speed: '~1.5s', payout: '100% USDC' },
  { symbol: 'USDT', name: 'Tether USD',   chain: 'Cross-Chain',    fee: 'Swap 0.3% (Payer)', direct: false, solver: 'deBridge Solver',       icon: '₮', priceAUD: 1.54, speed: '~1.8s', payout: '100% USDC' },
  { symbol: 'POL',  name: 'Polygon Native', chain: 'Polygon PoS',  fee: 'Swap 0.4% (Payer)', direct: false, solver: 'deBridge Solver',       icon: '🟣', priceAUD: 0.85, speed: '~2.0s', payout: '100% USDC' },
  { symbol: 'BONK', name: 'Bonk Memecoin',chain: 'Solana SPL',     fee: 'Swap 0.5% (Payer)', direct: false, solver: 'Jupiter DEX Solver',    icon: '🐶', priceAUD: 0.00003, speed: '< 1s', payout: '100% USDC' }
];

// Per-merchant "swap & send" list, seeded from the template on first access.
const merchantSwapAndSendLists = new Map();

function getSwapAndSendList(merchantId) {
  if (!merchantSwapAndSendLists.has(merchantId)) {
    merchantSwapAndSendLists.set(merchantId, DEFAULT_SWAP_AND_SEND_TEMPLATE.map(c => ({ ...c })));
  }
  return merchantSwapAndSendLists.get(merchantId);
}

export async function getMerchantCurrencies(merchantId) {
  const tokens = await prisma.acceptedToken.findMany({
    where: { merchantId }
  });

  const accepted = tokens.filter(t => t.enabled).map(t => {
    const sym = t.tokenSymbol.toUpperCase();
    const isSolana = t.blockchain === 'solana' || ['SOL', 'DYNK', 'BONK'].includes(sym);
    const isTron = t.blockchain === 'tron' || sym === 'TRX';
    const isBtc = t.blockchain === 'bitcoin' || sym === 'BTC';

    let name = sym;
    if (sym === 'SOL') name = 'Solana';
    else if (sym === 'DYNK') name = 'DYNK Token';
    else if (sym === 'USDC') name = 'USD Coin';
    else if (sym === 'ETH') name = 'Ethereum';
    else if (sym === 'BTC') name = 'Bitcoin';
    else if (sym === 'TRX') name = 'TRON Native';

    let icon = '🪙';
    if (sym === 'SOL') icon = '◎';
    else if (sym === 'DYNK') icon = '⚡';
    else if (sym === 'USDC') icon = '💵';
    else if (sym === 'ETH') icon = '⟠';
    else if (sym === 'BTC') icon = '₿';
    else if (sym === 'TRX') icon = '🔴';

    let chain = 'EVM';
    if (isSolana) chain = 'Solana SPL';
    else if (isTron) chain = 'TRON TRC-20';
    else if (isBtc) chain = 'Bitcoin Network';

    let price = 1.00;
    if (sym === 'SOL') price = 228.45;
    else if (sym === 'DYNK') price = 0.15;
    else if (sym === 'USDC') price = 1.54;
    else if (sym === 'ETH') price = 4120.50;
    else if (sym === 'BTC') price = 104500.00;
    else if (sym === 'TRX') price = 0.35;

    return {
      symbol: sym,
      name,
      chain,
      blockchain: t.blockchain || (isSolana ? 'solana' : (isTron ? 'tron' : (isBtc ? 'bitcoin' : 'evm'))),
      fee: t.customerFeeType === 'flat' ? '1¢ Flat Fee' : '1% Included',
      direct: true,
      solver: 'Direct Vault Deposit',
      icon,
      priceAUD: price,
      speed: '< 1 sec',
      payout: 'Native Vault Tokens'
    };
  });

  const swapAndSend = getSwapAndSendList(merchantId).filter(c => !accepted.some(a => a.symbol === c.symbol));

  return { accepted, swapAndSend };
}

// GET /api/merchant/state - Returns current configuration, wallets, products, and real KPIs
// GET /api/merchant/alerts - Unresolved money-needs-attention events
// (stray payments on cancelled orders, failed refund attempts). These never
// surface through per-order polling because the cashier has usually already
// moved on to a different, newer order by the time they happen.
router.get('/alerts', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) return res.json({ alerts: [] });

    const logs = await prisma.auditLog.findMany({
      where: {
        merchantId: merchant.id,
        action: { in: ['STRAY_PAYMENT_ON_CANCELLED_ORDER', 'MERCHANT_REFUND_FAILED'] },
        createdAt: { gte: new Date(Date.now() - 7 * 24 * 60 * 60 * 1000) }
      },
      orderBy: { createdAt: 'desc' },
      take: 20
    });

    const alerts = logs
      .filter(l => !l.metadata?.acknowledgedAt)
      .map(l => ({
        id: l.id,
        type: l.action,
        orderId: l.resourceId,
        metadata: l.metadata,
        createdAt: l.createdAt,
        severity: l.action === 'STRAY_PAYMENT_ON_CANCELLED_ORDER' ? 'high' : 'medium'
      }));

    res.json({ alerts });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message, alerts: [] });
  }
});

// POST /api/merchant/alerts/:id/acknowledge - Dismisses an alert from the
// register once the cashier has actually dealt with it (not merely closed
// the banner), by tagging the audit log entry itself.
router.post('/alerts/:id/acknowledge', async (req, res) => {
  try {
    const log = await prisma.auditLog.findUnique({ where: { id: req.params.id } });
    if (!log) return res.status(404).json({ error: 'NOT_FOUND' });

    await prisma.auditLog.update({
      where: { id: log.id },
      data: {
        metadata: { ...(log.metadata || {}), acknowledgedAt: new Date().toISOString() }
      }
    });
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

router.get('/state', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) {
      return res.status(404).json({ error: 'MERCHANT_NOT_FOUND', message: 'No merchant found.' });
    }

    const [
      profile,
      wallets,
      revenueSplitRules,
      acceptedTokens,
      products,
      terminals,
      settledOrders,
      settlementTransactions
    ] = await Promise.all([
      prisma.businessProfile.findUnique({ where: { merchantId: merchant.id } }),
      prisma.wallet.findMany({ where: { merchantId: merchant.id } }),
      prisma.revenueSplitRule.findMany({
        where: { merchantId: merchant.id },
        include: { destinationWallet: true }
      }),
      prisma.acceptedToken.findMany({ where: { merchantId: merchant.id } }),
      prisma.product.findMany({ where: { merchantId: merchant.id, active: true } }),
      prisma.terminal.findMany({ where: { merchantId: merchant.id } }),
      prisma.order.findMany({
        where: { merchantId: merchant.id, status: 'PAID' },
        select: { totalAUD: true, customerFeeAUD: true, tokenSymbol: true }
      }),
      prisma.settlementTransaction.findMany({
        where: { transaction: { merchantId: merchant.id } },
        select: { bucket: true, amountAUD: true }
      })
    ]);

    // Calculate Real KPIs
    const totalVolumeAUD = settledOrders.reduce((sum, o) => sum + parseFloat(o.totalAUD.toString()), 0);
    const totalTransactions = settledOrders.length;
    
    let taxAccruedAUD = 0;
    let opexAccruedAUD = 0;
    let ownerDrawingsAUD = 0;
    let profitAccruedAUD = 0;

    for (const st of settlementTransactions) {
      const amt = parseFloat(st.amountAUD.toString());
      if (st.bucket === 'TAX') taxAccruedAUD += amt;
      else if (st.bucket === 'EXPENSES') opexAccruedAUD += amt;
      else if (st.bucket === 'OWNER_PAY') ownerDrawingsAUD += amt;
      else if (st.bucket === 'PROFIT') profitAccruedAUD += amt;
    }

    // Format terminals with live WebSocket status
    const formattedTerminals = terminals.map(t => ({
      id: t.id,
      terminalId: t.terminalId,
      label: t.label || (t.terminalId === 'POS_001' ? 'Counter 1' : (t.terminalId === 'POS_002' ? 'Counter 2' : (t.terminalId === 'POS_003' ? 'Counter 3' : t.terminalId))),
      name: t.label || (t.terminalId === 'POS_001' ? 'Counter 1' : (t.terminalId === 'POS_002' ? 'Counter 2' : (t.terminalId === 'POS_003' ? 'Counter 3' : t.terminalId))),
      serialNumber: t.serialNumber,
      status: t.status,
      isOnline: terminalGateway.isOnline(t.terminalId),
      firmwareVersion: t.firmwareVersion,
      lastSeenAt: t.lastSeenAt,
      staticUrl: `/t/${merchant.id}/${t.terminalId}`
    }));

    const isDefaultMerchant = !merchant.legalName || merchant.tradingName === 'The Anchor Hotel' || merchant.legalName === 'The Anchor Hotel Pty Ltd';
    const baseRev = isDefaultMerchant ? 3412.60 : 0;
    const baseTx = isDefaultMerchant ? 187 : 0;
    const baseDynk = isDefaultMerchant ? 120 : 0;

    const walletMeta = {
      TAX: { color: '#4C7DF5', tagColor: '#7DA1F8', tagBg: 'rgba(76,125,245,0.12)', baseBalance: isDefaultMerchant ? 2174.98 : 0 },
      EXPENSES: { color: '#8B7CF6', tagColor: '#B2A4FA', tagBg: 'rgba(139,124,246,0.12)', baseBalance: isDefaultMerchant ? 2899.97 : 0 },
      OWNER_PAY: { color: '#3DD68C', tagColor: '#6FE0AC', tagBg: 'rgba(61,214,140,0.12)', baseBalance: isDefaultMerchant ? 2899.97 : 0 },
      PROFIT: { color: '#FF7A29', tagColor: '#FFA35C', tagBg: 'rgba(255,122,41,0.12)', baseBalance: isDefaultMerchant ? 6524.93 : 0 }
    };

    const palette = [
      { color: '#4C7DF5', tagColor: '#7DA1F8', tagBg: 'rgba(76,125,245,0.12)' },
      { color: '#8B7CF6', tagColor: '#B2A4FA', tagBg: 'rgba(139,124,246,0.12)' },
      { color: '#3DD68C', tagColor: '#6FE0AC', tagBg: 'rgba(61,214,140,0.12)' },
      { color: '#FF7A29', tagColor: '#FFA35C', tagBg: 'rgba(255,122,41,0.12)' },
      { color: '#EC4899', tagColor: '#F472B6', tagBg: 'rgba(236,72,153,0.12)' },
      { color: '#06B6D4', tagColor: '#22D3EE', tagBg: 'rgba(6,182,212,0.12)' },
      { color: '#F59E0B', tagColor: '#FBBF24', tagBg: 'rgba(245,158,11,0.12)' },
      { color: '#10B981', tagColor: '#34D399', tagBg: 'rgba(16,185,129,0.12)' }
    ];

    const defaultBucketLabels = {
      TAX: 'Tax Reserves (ATO)',
      EXPENSES: 'Operating Expenses',
      OWNER_PAY: 'Owner Drawings',
      PROFIT: 'Retained Profit'
    };

    const mappedWallets = revenueSplitRules.map((r, idx) => {
      const p = palette[idx % palette.length];
      const meta = walletMeta[r.bucket] || { color: p.color, tagColor: p.tagColor, tagBg: p.tagBg, baseBalance: 0 };
      const bucketAccrued = (r.bucket === 'TAX' ? taxAccruedAUD : (r.bucket === 'EXPENSES' ? opexAccruedAUD : (r.bucket === 'OWNER_PAY' ? ownerDrawingsAUD : profitAccruedAUD)));
      const currentBalance = meta.baseBalance + bucketAccrued;
      const pct = r.basisPoints / 100;
      const splitName = (r.destinationWallet?.label && r.destinationWallet.label !== 'Main Settlement Vault')
        ? r.destinationWallet.label
        : (defaultBucketLabels[r.bucket] || r.bucket);
      return {
        id: r.id,
        name: splitName,
        bucket: r.bucket,
        pct,
        percent: pct,
        split: `${pct.toFixed(0)}%`,
        basisPoints: r.basisPoints,
        balance: parseFloat(currentBalance.toFixed(2)),
        settle: r.settlementMode === 'STABLE' ? 'USDC' : 'Hold',
        mode: r.settlementMode,
        color: meta.color,
        tagColor: meta.tagColor,
        tagBg: meta.tagBg,
        address: r.destinationWallet?.address || merchant.solanaAddress || '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH',
        blockchain: r.destinationWallet?.blockchain || 'solana',
        locked: false
      };
    });

    const activeRev = baseRev + totalVolumeAUD;
    const activeTxCount = baseTx + totalTransactions;
    const activeDynkCount = baseDynk + settledOrders.filter(o => o.tokenSymbol === 'DYNK').length;
    const cardCost = activeRev * 0.016;
    const dynkCost = activeDynkCount * 0.01;
    const savedVsCard = Math.max(0, Math.round((cardCost - dynkCost) * 100) / 100);

    res.json({
      success: true,
      data: {
        merchant: {
          id: merchant.id,
          legalName: merchant.legalName,
          tradingName: merchant.tradingName,
          businessType: merchant.businessType,
          industry: merchant.industry || null,
          abn: merchant.abn,
          status: merchant.status,
          counterMode: merchant.counterMode || (terminals.length > 1 ? 'MULTIPLE' : 'SINGLE'),
          isLive: merchant.status === 'live',
          onboardingStep: merchant.onboardingStep,
          kybStatus: merchant.kybStatus,
          kitPaid: merchant.kitPaid
        },
        profile,
        wallets: mappedWallets,
        acceptedTokens,
        currencies: await getMerchantCurrencies(merchant.id),
        products: products.map(mapProduct),
        categories: Array.isArray(merchant.catalogCategories) ? merchant.catalogCategories : [],
        campaigns: [
          { id: 'camp1', title: 'Walk-Past Welcome Spin', desc: 'Triggered via NFC Beacon at storefront · 10% Off Bill', code: 'WELCOME10', discount: '10%', active: true },
          { id: 'camp2', title: 'Happy Hour 4-6 PM', desc: 'Automatic 15% discount on all Bar and Tap items', code: 'HAPPY15', discount: '15%', active: true },
          { id: 'camp3', title: 'Loyalty Coffee Stamp', desc: 'Every 6th Flat White is automatically credited free', code: 'PUNCHCARD', discount: 'Free', active: true }
        ],
        terminals: formattedTerminals,
        kpis: {
          revenue: parseFloat(activeRev.toFixed(2)),
          totalVolumeAUD: activeRev.toFixed(2),
          txCount: activeTxCount,
          totalTransactions: activeTxCount,
          dynkCount: activeDynkCount,
          savedVsCard: savedVsCard.toFixed(2),
          taxAccruedAUD: ((isDefaultMerchant ? 511.89 : 0) + taxAccruedAUD).toFixed(2),
          opexAccruedAUD: ((isDefaultMerchant ? 682.52 : 0) + opexAccruedAUD).toFixed(2),
          ownerDrawingsAUD: ((isDefaultMerchant ? 682.52 : 0) + ownerDrawingsAUD).toFixed(2),
          profitAccruedAUD: ((isDefaultMerchant ? 1535.67 : 0) + profitAccruedAUD).toFixed(2)
        }
      }
    });
  } catch (err) {
    console.error('[Merchant State Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

function buildSplitCategories(pnlData, merchant) {
  const totalGross = pnlData.totals?.totalGrossValueAUD || 0;
  const totalReceivable = pnlData.totals?.totalReceivableBatchedAUD || 0;
  return (merchantState.wallets || []).map(w => {
    const pct = w.pct || 0;
    const allocatedGrossAUD = parseFloat(((totalGross * pct) / 100).toFixed(2));
    const allocatedReceivableAUD = parseFloat(((totalReceivable * pct) / 100).toFixed(2));
    
    const tokenShares = (pnlData.rows || []).map(r => {
      const holdingNum = (typeof r.holdingNumeric === 'number') ? r.holdingNumeric : parseFloat(String(r.holding || '0').replace(/,/g, ''));
      const shareAmount = (holdingNum * pct) / 100;
      const decimals = r.symbol === 'BTC' ? 6 : (r.symbol === 'ETH' || r.symbol === 'SOL' ? 4 : (r.symbol === 'DYNK' ? 0 : 2));
      return {
        symbol: r.symbol,
        amount: parseFloat(shareAmount.toFixed(decimals)),
        valueAUD: parseFloat(((r.grossValueAUD * pct) / 100).toFixed(2))
      };
    });

    return {
      id: w.id,
      name: w.name,
      color: w.color,
      pct: w.pct,
      settleMode: w.settle,
      allocatedGrossAUD,
      allocatedReceivableAUD,
      tokenShares,
      custodyLocation: 'Merchant Treasury (Single Balance)',
      treasuryAddress: merchant?.solanaAddress || '8YLL...NYFH',
      accountingType: 'Virtual Ledger Entry (Off-Chain)',
      notes: 'Funds safely held in primary Merchant Treasury. Zero gas split.'
    };
  });
}

// GET /api/merchant/pnl - Real-time P&L, holdings, cost basis & live swap charges
router.get('/pnl', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) {
      return res.status(404).json({ error: 'MERCHANT_NOT_FOUND', message: 'No merchant found.' });
    }

    const pnlData = await getMerchantPnlData(merchant.id);
    const splitCategories = buildSplitCategories(pnlData, merchant);

    res.json({
      success: true,
      merchantId: merchant.id,
      merchantName: merchant.tradingName || merchant.legalName,
      ...pnlData,
      categorySplitHoldings: splitCategories
    });
  } catch (err) {
    console.error('[Merchant PnL Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// GET /api/merchant/autoswap/config - Single Merchant Auto-Swap Configuration
router.get('/autoswap/config', (req, res) => {
  try {
    const config = getAutoSwapConfig();
    res.json({ success: true, config });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/merchant/autoswap/config - Update Single Merchant Auto-Swap Configuration
router.post('/autoswap/config', (req, res) => {
  try {
    const updated = updateAutoSwapConfig(req.body || {});
    res.json({ success: true, config: updated });
  } catch (err) {
    res.status(400).json({ error: 'UPDATE_FAILED', message: err.message });
  }
});

// POST /api/merchant/swap - Convert single token holding or ALL holdings to USDC
router.post('/swap', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) {
      return res.status(404).json({ error: 'MERCHANT_NOT_FOUND', message: 'No merchant found.' });
    }

    const { symbol } = req.body || {};
    const result = await executeMerchantSwap(merchant.id, symbol || 'ALL');

    // Record audit log
    try {
      await prisma.auditLog.create({
        data: {
          merchantId: merchant.id,
          action: 'MERCHANT_SWAP_TO_USDC',
          resource: 'HOLDINGS_PNL',
          metadata: {
            symbol: symbol || 'ALL',
            summary: result.summary,
            swaps: result.executedSwaps
          }
        }
      });
    } catch (auditErr) {}

    res.json(result);
  } catch (err) {
    console.error('[Merchant Swap Error]:', err);
    res.status(400).json({ error: 'SWAP_ERROR', message: err.message });
  }
});

// POST /api/merchant/pnl/reset - Reseeds the demo holdings ledger
router.post('/pnl/reset', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    resetPnlLedger(merchant.id);
    const pnlData = await getMerchantPnlData(merchant.id);
    const splitCategories = buildSplitCategories(pnlData, merchant);
    res.json({
      success: true,
      merchantId: merchant?.id,
      merchantName: merchant?.tradingName || merchant?.legalName,
      ...pnlData,
      categorySplitHoldings: splitCategories
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// PUT /api/merchant/industry - change the kind of business (used for suggestions)
router.put('/industry', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const key = String(req.body.industry || '');
    if (!/^[a-z]{2,20}$/.test(key)) return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Choose a type of business.' });
    await prisma.merchant.update({ where: { id: merchant.id }, data: { industry: key } });
    res.json({ success: true, industry: key });
  } catch (err) {
    res.status(500).json({ error: 'SAVE_INDUSTRY_FAILED', message: err.message });
  }
});

// GET/PUT /api/merchant/categories - the merchant's own category tree (list of paths)
router.get('/categories', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    res.json({ success: true, categories: Array.isArray(merchant.catalogCategories) ? merchant.catalogCategories : [] });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});
router.put('/categories', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const list = Array.isArray(req.body.categories) ? req.body.categories : [];
    const paths = [...new Set(list.map(cleanCategoryPath).filter(Boolean))].slice(0, 500);
    await prisma.merchant.update({ where: { id: merchant.id }, data: { catalogCategories: paths } });
    res.json({ success: true, categories: paths });
  } catch (err) {
    res.status(500).json({ error: 'SAVE_CATEGORIES_FAILED', message: err.message });
  }
});

// GET /api/merchant/products - List merchant products
router.get('/products', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const products = await prisma.product.findMany({
      where: { merchantId: merchant.id, active: true },
      orderBy: { createdAt: 'asc' }
    });

    res.json({
      success: true,
      products: products.map(mapProduct)
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/merchant/products - Create a new product
router.post('/products', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { name, category, cat, price, description, currency = 'AUD' } = req.body;

    if (!name || price === undefined) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Product name and price are required.' });
    }
    const parsedPrice = parseFloat(price);
    if (!Number.isFinite(parsedPrice) || parsedPrice < 0) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Price must be a non-negative number.' });
    }

    const product = await prisma.product.create({
      data: {
        merchantId: merchant.id,
        name: name.trim(),
        category: cleanCategoryPath(category || cat) || 'General',
        description: description || null,
        price: parseFloat(price),
        currency,
        meta: productMeta(req.body),
        active: true
      }
    });

    res.status(201).json({
      success: true,
      product: mapProduct(product)
    });
  } catch (err) {
    res.status(500).json({ error: 'CREATE_PRODUCT_FAILED', message: err.message });
  }
});

// POST /api/merchant/products/bulk - Bulk create or replace products
router.post('/products/bulk', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { products, replace = false } = req.body;
    if (!Array.isArray(products)) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Products array is required.' });
    }

    // Validate every row up front and report which were skipped and why —
    // this used to silently `continue` past malformed rows with zero signal
    // to the caller about which of their N products didn't make it in.
    const skipped = [];
    const validRows = [];
    products.forEach((p, index) => {
      if (!p.name || p.price === undefined) {
        skipped.push({ index, reason: 'MISSING_NAME_OR_PRICE' });
        return;
      }
      const parsedPrice = parseFloat(p.price);
      if (!Number.isFinite(parsedPrice) || parsedPrice < 0) {
        skipped.push({ index, name: p.name, reason: 'INVALID_PRICE' });
        return;
      }
      validRows.push({ ...p, price: parsedPrice });
    });

    // Replace if explicitly requested, then create all valid rows, atomically —
    // previously this looped with sequential creates outside any transaction,
    // so an exception partway (e.g. a bad Decimal cast) left whatever had
    // already been created committed, with no rollback and no report.
    const ops = [];
    if (replace === true) {
      ops.push(prisma.product.deleteMany({ where: { merchantId: merchant.id } }));
    }
    for (const p of validRows) {
      ops.push(prisma.product.create({
        data: {
          merchantId: merchant.id,
          name: p.name.trim(),
          category: (p.category || p.cat || 'General').trim(),
          description: p.description || null,
          price: p.price,
          currency: p.currency || 'AUD',
          active: true
        }
      }));
    }

    const results = ops.length ? await prisma.$transaction(ops) : [];
    const createdRows = replace === true ? results.slice(1) : results;
    const created = createdRows.map(prod => ({
      id: prod.id,
      name: prod.name,
      category: prod.category,
      cat: prod.category,
      price: parseFloat(prod.price.toString()),
      currency: prod.currency
    }));

    // Fetch all current active products for the merchant
    const allProducts = await prisma.product.findMany({
      where: { merchantId: merchant.id, active: true },
      orderBy: { createdAt: 'asc' }
    });

    res.status(201).json({
      success: true,
      count: created.length,
      skipped,
      products: created,
      allProducts: allProducts.map(p => ({
        id: p.id,
        name: p.name,
        category: p.category,
        cat: p.category,
        price: parseFloat(p.price.toString()),
        currency: p.currency
      }))
    });
  } catch (err) {
    res.status(500).json({ error: 'BULK_CREATE_FAILED', message: err.message });
  }
});

// PUT /api/merchant/products/:id - Update product
router.put('/products/:id', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { name, category, cat, price, description, active } = req.body;

    if (price !== undefined) {
      const parsedPrice = parseFloat(price);
      if (!Number.isFinite(parsedPrice) || parsedPrice < 0) {
        return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Price must be a non-negative number.' });
      }
    }

    // Scoping by merchantId as well as id closes a cross-tenant edit hole:
    // without it, any caller who knows/guesses another merchant's product id
    // could rewrite its name/price/category.
    const { count } = await prisma.product.updateMany({
      where: { id: req.params.id, merchantId: merchant.id },
      data: {
        name: name !== undefined ? name.trim() : undefined,
        category: (category !== undefined || cat !== undefined) ? (cleanCategoryPath(category ?? cat) || 'General') : undefined,
        price: price !== undefined ? parseFloat(price) : undefined,
        description: description !== undefined ? description : undefined,
        meta: Object.keys(productMeta(req.body)).length ? productMeta(req.body) : undefined,
        active: active !== undefined ? Boolean(active) : undefined
      }
    });

    if (count === 0) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Product not found for this merchant.' });
    }

    const updated = await prisma.product.findUnique({ where: { id: req.params.id } });

    res.json({
      success: true,
      product: mapProduct(updated)
    });
  } catch (err) {
    res.status(500).json({ error: 'UPDATE_PRODUCT_FAILED', message: err.message });
  }
});

// DELETE /api/merchant/products/:id - Soft-delete or remove product
router.delete('/products/:id', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { count } = await prisma.product.deleteMany({
      where: { id: req.params.id, merchantId: merchant.id }
    });
    if (count === 0) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Product not found for this merchant.' });
    }
    res.json({ success: true, message: 'Product removed successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'DELETE_PRODUCT_FAILED', message: err.message });
  }
});

// POST /api/merchant/wallets - Update revenue split rules with STRICT 100% (10,000 bps) validation
router.post('/wallets', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { wallets } = req.body;

    if (!Array.isArray(wallets) || wallets.length === 0) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Wallets array is required.' });
    }

    // Calculate total basis points
    let totalBps = 0;
    const validatedRules = [];

    for (let i = 0; i < wallets.length; i++) {
      const w = wallets[i];
      const bps = w.basisPoints !== undefined ? parseInt(w.basisPoints) : Math.round(parseFloat(w.percent || w.pct || w.split || 0) * 100);
      totalBps += bps;
      const rawName = (w.name || w.label || `Split Category ${i + 1}`).trim();
      const bucketCode = w.bucket || rawName.toUpperCase().replace(/[^A-Z0-9]/g, '_').substring(0, 30);
      let destinationAddress = w.address || '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH';

      // An address that isn't a real Solana public key would only surface as
      // a crash inside buildSolanaTransaction at settlement time — after the
      // merchant is already live and a customer has already paid. Reject it
      // here instead, before it's ever persisted.
      //
      // DEV BYPASS: rather than skip this check outright (which would just
      // move the same crash to settlement time), silently swap in the valid
      // default address so a tester's placeholder input never blocks saving.
      try {
        new PublicKey(destinationAddress);
      } catch {
        if (DEMO_MODE) {
          destinationAddress = '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH';
        } else {
          return res.status(400).json({
            error: 'INVALID_WALLET_ADDRESS',
            message: `"${destinationAddress}" (${rawName}) is not a valid Solana address.`
          });
        }
      }

      validatedRules.push({
        bucket: bucketCode,
        basisPoints: bps,
        destinationAddress,
        label: rawName,
        settlementMode: (w.mode === 'CRYPTO' || w.settle === 'Hold' || w.settleMode === 'Hold') ? 'CRYPTO' : 'STABLE'
      });
    }

    // STRICT 10,000 BPS (100.00%) VALIDATION
    if (totalBps !== 10000) {
      return res.status(400).json({
        error: 'INVALID_SPLIT_TOTAL',
        message: `Total revenue split must equal exactly 100.00% (10,000 basis points). Provided total: ${(totalBps / 100).toFixed(2)}% (${totalBps} bps).`
      });
    }

    // Update in database transaction
    await prisma.$transaction(async (tx) => {
      // Remove old rules
      await tx.revenueSplitRule.deleteMany({ where: { merchantId: merchant.id } });

      for (const rule of validatedRules) {
        // Find or create wallet by merchantId and label
        let wallet = await tx.wallet.findFirst({
          where: { merchantId: merchant.id, label: rule.label }
        });

        if (!wallet) {
          wallet = await tx.wallet.create({
            data: {
              merchantId: merchant.id,
              label: rule.label,
              address: rule.destinationAddress,
              blockchain: 'solana'
            }
          });
        }

        await tx.revenueSplitRule.create({
          data: {
            merchantId: merchant.id,
            bucket: rule.bucket,
            basisPoints: rule.basisPoints,
            settlementMode: rule.settlementMode,
            destinationWalletId: wallet.id
          }
        });
      }
    });

    try {
      const formattedForStore = validatedRules.map((r, i) => ({
        id: (wallets[i] && wallets[i].id) || `w_${r.bucket.toLowerCase()}`,
        name: r.label,
        bucket: r.bucket,
        pct: r.basisPoints / 100,
        settle: r.settlementMode === 'STABLE' ? 'USDC' : 'Hold',
        mode: r.settlementMode,
        color: (wallets[i] && wallets[i].color) || ['#4C7DF5', '#8B7CF6', '#3DD68C', '#FF7A29'][i % 4],
        address: r.destinationAddress,
        balance: (wallets[i] && wallets[i].balance) || 0
      }));
      setMerchantWallets(formattedForStore);
    } catch (e) {
      console.warn('[Sync Merchant Wallets Warn]:', e.message);
    }

    res.json({
      success: true,
      message: 'Revenue split rules updated and 100.00% allocation strictly verified.',
      totalBasisPoints: totalBps
    });
  } catch (err) {
    console.error('[Update Wallets Error]:', err);
    res.status(500).json({ error: 'UPDATE_WALLETS_FAILED', message: err.message });
  }
});

// GET /api/merchant/currencies - Matrix of currencies
router.get('/currencies', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const currencies = await getMerchantCurrencies(merchant.id);
    res.json({ success: true, currencies });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/merchant/currencies - Add currency to matrix
router.post('/currencies', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { symbol, name, chain, icon, direct, fee, solver } = req.body;
    if (!symbol || !name) {
      return res.status(400).json({ error: 'Symbol and Name are required.' });
    }

    const cleanSymbol = symbol.toUpperCase().trim();
    const isSolana = (chain || '').toLowerCase().includes('solana') || ['SOL', 'DYNK', 'BONK'].includes(cleanSymbol);
    const isTron = (chain || '').toLowerCase().includes('tron') || cleanSymbol === 'TRX';
    const isBtc = (chain || '').toLowerCase().includes('bitcoin') || cleanSymbol === 'BTC';
    const blockchain = isSolana ? 'solana' : (isTron ? 'tron' : (isBtc ? 'bitcoin' : 'evm'));

    if (direct) {
      await prisma.acceptedToken.upsert({
        where: {
          merchantId_tokenSymbol_blockchain: {
            merchantId: merchant.id,
            tokenSymbol: cleanSymbol,
            blockchain
          }
        },
        update: { enabled: true },
        create: {
          merchantId: merchant.id,
          tokenSymbol: cleanSymbol,
          blockchain,
          enabled: true,
          customerFeeType: 'percentage',
          customerFeeValue: 0.01
        }
      });
    } else {
      const swapAndSendList = getSwapAndSendList(merchant.id);
      if (!swapAndSendList.some(c => c.symbol === cleanSymbol)) {
        swapAndSendList.push({
          symbol: cleanSymbol,
          name,
          chain: chain || 'Cross-Chain',
          fee: fee || 'Swap 0.5% (Payer)',
          direct: false,
          solver: solver || 'deBridge Solver',
          icon: icon || '🪙',
          priceAUD: 1.00,
          speed: '~2.5s',
          payout: '100% USDC'
        });
      }
    }

    const currencies = await getMerchantCurrencies(merchant.id);
    res.json({ success: true, currencies });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/merchant/currencies/toggle - Switch currency between direct and swap
router.post('/currencies/toggle', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { symbol } = req.body;
    if (!symbol) {
      return res.status(400).json({ error: 'Symbol is required.' });
    }
    const cleanSymbol = symbol.toUpperCase().trim();

    const existingToken = await prisma.acceptedToken.findFirst({
      where: { merchantId: merchant.id, tokenSymbol: cleanSymbol, enabled: true }
    });

    let movedTo = 'accepted';
    if (existingToken) {
      await prisma.acceptedToken.update({
        where: { id: existingToken.id },
        data: { enabled: false }
      });
      const swapAndSendList = getSwapAndSendList(merchant.id);
      if (!swapAndSendList.some(c => c.symbol === cleanSymbol)) {
        swapAndSendList.push({
          symbol: cleanSymbol,
          name: cleanSymbol,
          chain: existingToken.blockchain === 'solana' ? 'Solana L1' : 'EVM',
          fee: 'Swap 0.5% (Payer)',
          direct: false,
          solver: 'deBridge Solver',
          icon: '🪙',
          priceAUD: 1.00,
          speed: '~2.0s',
          payout: '100% USDC'
        });
      }
      movedTo = 'swapAndSend';
    } else {
      const isSolana = cleanSymbol === 'SOL' || cleanSymbol === 'DYNK' || cleanSymbol === 'BONK';
      const isTron = cleanSymbol === 'TRX';
      const isBtc = cleanSymbol === 'BTC';
      const blockchain = isSolana ? 'solana' : (isTron ? 'tron' : (isBtc ? 'bitcoin' : 'evm'));
      await prisma.acceptedToken.upsert({
        where: {
          merchantId_tokenSymbol_blockchain: {
            merchantId: merchant.id,
            tokenSymbol: cleanSymbol,
            blockchain
          }
        },
        update: { enabled: true },
        create: {
          merchantId: merchant.id,
          tokenSymbol: cleanSymbol,
          blockchain,
          enabled: true,
          customerFeeType: 'percentage',
          customerFeeValue: 0.01
        }
      });
      movedTo = 'accepted';
    }

    const currencies = await getMerchantCurrencies(merchant.id);
    res.json({ success: true, movedTo, currencies });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// DELETE /api/merchant/currencies/:symbol - Remove currency
router.delete('/currencies/:symbol', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const cleanSymbol = req.params.symbol.toUpperCase().trim();

    await prisma.acceptedToken.updateMany({
      where: { merchantId: merchant.id, tokenSymbol: cleanSymbol },
      data: { enabled: false }
    });

    const swapAndSendList = getSwapAndSendList(merchant.id);
    const idx = swapAndSendList.findIndex(c => c.symbol === cleanSymbol);
    if (idx !== -1) {
      swapAndSendList.splice(idx, 1);
    }

    const currencies = await getMerchantCurrencies(merchant.id);
    res.json({ success: true, currencies });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/merchant/tokens - Bulk configure/customize accepted tokens during onboarding
router.post('/tokens', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { tokens } = req.body;
    if (!Array.isArray(tokens)) {
      return res.status(400).json({ error: 'Tokens array is required.' });
    }

    for (const t of tokens) {
      if (!t.symbol || t.symbol === 'SWAP') continue;
      const cleanSymbol = t.symbol.toUpperCase().trim();
      const isSolana = (t.blockchain || t.chain || '').toLowerCase().includes('solana') || cleanSymbol === 'SOL' || cleanSymbol === 'DYNK' || cleanSymbol === 'USDC' || cleanSymbol === 'BONK';
      const blockchain = isSolana ? 'solana' : 'evm';
      const isEnabled = t.enabled !== undefined ? Boolean(t.enabled) : (t.active !== undefined ? Boolean(t.active) : true);

      await prisma.acceptedToken.upsert({
        where: {
          merchantId_tokenSymbol_blockchain: {
            merchantId: merchant.id,
            tokenSymbol: cleanSymbol,
            blockchain
          }
        },
        update: {
          enabled: isEnabled,
          customerFeeType: t.customerFeeType || (cleanSymbol === 'DYNK' ? 'flat' : 'percentage'),
          customerFeeValue: t.customerFeeValue !== undefined ? t.customerFeeValue : 0.01
        },
        create: {
          merchantId: merchant.id,
          tokenSymbol: cleanSymbol,
          blockchain,
          enabled: isEnabled,
          customerFeeType: t.customerFeeType || (cleanSymbol === 'DYNK' ? 'flat' : 'percentage'),
          customerFeeValue: t.customerFeeValue !== undefined ? t.customerFeeValue : 0.01
        }
      });
    }

    const currencies = await getMerchantCurrencies(merchant.id);
    res.json({ success: true, currencies, tokens: currencies.accepted, message: 'Accepted tokens configured successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'CONFIG_TOKENS_FAILED', message: err.message });
  }
});

// POST /api/merchant/kit/checkout - Create $199 checkout session
router.post('/kit/checkout', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { email } = req.body;
    const session = await createKitPaymentIntent(merchant.id, email);
    res.json({ success: true, session });
  } catch (err) {
    res.status(500).json({ error: 'CHECKOUT_FAILED', message: err.message });
  }
});

// POST /api/merchant/kit/confirm - Confirm $199 kit payment & trigger shipping
router.post('/kit/confirm', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { intentId, shippingAddress } = req.body;

    const result = await processKitPaymentSuccess(merchant.id, intentId, shippingAddress);
    res.json(result);
  } catch (err) {
    const status = err.code?.startsWith('KIT_PAYMENT_INTENT') ? 400 : 500;
    res.status(status).json({ error: err.code || 'KIT_PAYMENT_FAILED', message: err.message });
  }
});

// GET /api/merchant/kit/shipping - Real shipping status
router.get('/kit/shipping', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const shipment = await getShipmentStatus(merchant.id);
    res.json({ success: true, shipment });
  } catch (err) {
    res.status(500).json({ error: 'SHIPPING_FETCH_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/go-live - Strict Prerequisite Verification
router.post('/onboarding/go-live', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) {
      return res.status(404).json({ error: 'MERCHANT_NOT_FOUND' });
    }

    const [
      profile,
      terminals,
      splitRules,
      acceptedTokens,
      owner
    ] = await Promise.all([
      prisma.businessProfile.findUnique({ where: { merchantId: merchant.id } }),
      prisma.terminal.findMany({ where: { merchantId: merchant.id } }),
      prisma.revenueSplitRule.findMany({ where: { merchantId: merchant.id } }),
      prisma.acceptedToken.findMany({ where: { merchantId: merchant.id, enabled: true } }),
      prisma.merchantUser.findFirst({
        where: { merchantId: merchant.id, role: 'OWNER' },
        include: { user: true },
        orderBy: { createdAt: 'asc' }
      })
    ]);

    const missing = [];

    // 0. Owner contact verification. register() no longer marks an account
    // verified on its own — this is the point where that verification is
    // actually required to mean something: a merchant cannot start taking
    // real customer payments on an unverified email.
    if (!owner?.user?.emailVerified) {
      missing.push('Owner email must be verified (check your inbox for a verification code, or resend one).');
    }

    // 1. Business Profile Check (Legal Name, Trading Name, ABN)
    if (!merchant.legalName || !merchant.tradingName || !merchant.abn) {
      missing.push('Business profile must be completed (legal name, customer trading name, and ABN).');
    }

    // 2. Kit Payment Check ($199 Starter Kit)
    if (!merchant.kitPaid) {
      missing.push('Hardware Starter Kit ($199) must be ordered and paid.');
    }

    // 3. Countertop Terminal Pairing Check
    const hasReadyTerminal = terminals.some(t => t.pairedAt !== null || t.status === 'READY' || t.status === 'CONNECTED');
    if (!hasReadyTerminal) {
      missing.push('DYNKLE Countertop Terminal (#DY-009) must be connected and paired.');
    }

    // 4. 100% Split Rule Check
    const totalBps = splitRules.reduce((sum, r) => sum + r.basisPoints, 0);
    if (totalBps !== 10000) {
      missing.push(`Revenue split rules must sum to exactly 100.00% (10,000 basis points). Current sum: ${(totalBps / 100).toFixed(2)}%.`);
    }

    // 5. Currency Acceptance Check
    if (acceptedTokens.length === 0) {
      missing.push('At least one cryptocurrency (e.g. SOL or DYNK) must be enabled.');
    }

    // ENFORCE PREREQUISITES
    if (missing.length > 0) {
      if (DEMO_MODE) {
        // In Fake/Dev Onboarding Mode: auto-fulfill any missing items so tester is never blocked!
        console.log('[Dev Mode Go-Live]: Auto-fulfilling missing prerequisites:', missing);
        if (!merchant.kitPaid) {
          await prisma.merchant.update({ where: { id: merchant.id }, data: { kitPaid: true } });
        }
        if (!hasReadyTerminal) {
          await prisma.terminal.upsert({
            where: { terminalId: 'POS_001' },
            update: { merchantId: merchant.id, status: 'READY', pairedAt: new Date() },
            create: { merchantId: merchant.id, terminalId: 'POS_001', label: 'Main Counter', serialNumber: 'SN-POS_001-9001', status: 'READY', pairedAt: new Date() }
          });
        }
        if (totalBps !== 10000) {
          const defaultBuckets = [
            { bucket: 'TAX', label: 'Tax Reserves (ATO)', basisPoints: 1500, settlementMode: 'STABLE' },
            { bucket: 'EXPENSES', label: 'Operating Expenses', basisPoints: 2000, settlementMode: 'STABLE' },
            { bucket: 'OWNER_PAY', label: 'Owner Drawings', basisPoints: 2000, settlementMode: 'CRYPTO' },
            { bucket: 'PROFIT', label: 'Retained Profit', basisPoints: 4500, settlementMode: 'CRYPTO' }
          ];

          await prisma.revenueSplitRule.deleteMany({ where: { merchantId: merchant.id } });
          for (const b of defaultBuckets) {
            let wallet = await prisma.wallet.findFirst({
              where: { merchantId: merchant.id, label: b.label }
            });
            if (!wallet) {
              wallet = await prisma.wallet.create({
                data: {
                  merchantId: merchant.id,
                  label: b.label,
                  address: merchant.solanaAddress || '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH',
                  blockchain: 'solana'
                }
              });
            }
            await prisma.revenueSplitRule.create({
              data: {
                merchantId: merchant.id,
                bucket: b.bucket,
                basisPoints: b.basisPoints,
                settlementMode: b.settlementMode,
                destinationWalletId: wallet.id
              }
            });
          }
        }
        if (acceptedTokens.length === 0) {
          await prisma.acceptedToken.createMany({
            data: [
              { merchantId: merchant.id, tokenSymbol: 'DYNK', blockchain: 'solana', enabled: true, customerFeeType: 'flat', customerFeeValue: 0.01 },
              { merchantId: merchant.id, tokenSymbol: 'SOL', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 },
              { merchantId: merchant.id, tokenSymbol: 'USDC', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 }
            ]
          });
        }
      } else {
        return res.status(422).json({
          success: false,
          error: 'PREREQUISITES_NOT_MET',
          message: 'Cannot activate live payment processing until all onboarding requirements are satisfied.',
          missing
        });
      }
    }

    // All requirements satisfied: transition to live!
    const updated = await prisma.merchant.update({
      where: { id: merchant.id },
      data: {
        status: 'live',
        onboardingStep: 7
      }
    });

    res.json({
      success: true,
      message: 'Congratulations! All compliance and hardware verifications passed. Merchant is now LIVE!',
      status: updated.status,
      merchantId: updated.id
    });
  } catch (err) {
    console.error('[Go Live Error]:', err);
    res.status(500).json({ error: 'GO_LIVE_FAILED', message: err.message });
  }
});

// GET /api/merchant/list - List all registered merchants for multi-tenant switcher
router.get('/list', async (req, res) => {
  try {
    const merchants = await prisma.merchant.findMany({
      orderBy: { updatedAt: 'desc' },
      select: {
        id: true,
        legalName: true,
        tradingName: true,
        businessType: true,
        abn: true,
        status: true,
        onboardingStep: true,
        kitPaid: true,
        createdAt: true,
        updatedAt: true
      }
    });
    res.json({ success: true, merchants });
  } catch (err) {
    res.status(500).json({ error: 'LIST_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/account - Stage 1: Account & Contact
router.post('/onboarding/account', async (req, res) => {
  try {
    const { email, phone, signatoryName, isNew } = req.body;
    let merchant = null;
    const reqMerchantId = req.headers['x-merchant-id'] || req.query?.merchantId || req.body?.merchantId;
    if (reqMerchantId && !isNew) {
      merchant = await prisma.merchant.findUnique({ where: { id: reqMerchantId } });
    }
    if (!merchant && !isNew) {
      merchant = await getActiveMerchant(req);
    }

    if (!merchant || isNew) {
      merchant = await prisma.merchant.create({
        data: {
          legalName: signatoryName ? `${signatoryName} Pty Ltd` : 'New Business Pty Ltd',
          tradingName: signatoryName ? `${signatoryName} Store` : 'New Store',
          businessType: 'company',
          status: 'setup',
          onboardingStep: 2,
          kybStatus: 'DRAFT',
          kitPaid: false
        }
      });
      // Pre-seed default accepted tokens
      await prisma.acceptedToken.createMany({
        data: [
          { merchantId: merchant.id, tokenSymbol: 'DYNK', blockchain: 'solana', enabled: true, customerFeeType: 'flat', customerFeeValue: 0.01 },
          { merchantId: merchant.id, tokenSymbol: 'SOL', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 },
          { merchantId: merchant.id, tokenSymbol: 'USDC', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 }
        ],
        skipDuplicates: true
      });
      // New businesses start with an empty catalogue: Dynkle serves any kind of shop.
    } else {
      merchant = await prisma.merchant.update({
        where: { id: merchant.id },
        data: { onboardingStep: Math.max(merchant.onboardingStep, 2) }
      });
    }

    if (email) {
      await prisma.user.updateMany({
        where: { merchants: { some: { merchantId: merchant.id } } },
        data: { email: email.trim().toLowerCase(), phone: phone || null }
      });
    }

    res.json({
      success: true,
      merchantId: merchant.id,
      message: 'Account verified successfully.',
      onboarding: {
        step: merchant.onboardingStep,
        account: { email, phone, signatoryName, verified: true }
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'ACCOUNT_SAVE_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/business - Stage 2: Business Profile & KYB + Counter Architecture
router.post('/onboarding/business', async (req, res) => {
  try {
    const { legalName, tradingName, businessType, abn, address, isNew, counterMode, counters, industry } = req.body;
    const industryKey = typeof industry === 'string' && /^[a-z]{2,20}$/.test(industry) ? industry : undefined;
    let merchant = null;
    const reqMerchantId = req.headers['x-merchant-id'] || req.query?.merchantId || req.body?.merchantId;
    if (reqMerchantId && !isNew) {
      merchant = await prisma.merchant.findUnique({ where: { id: reqMerchantId } });
    }

    const finalCounterMode = counterMode === 'MULTIPLE' ? 'MULTIPLE' : 'SINGLE';

    if (!merchant || isNew) {
      // If creating a brand new merchant at Step 2
      merchant = await prisma.merchant.create({
        data: {
          legalName: legalName || 'New Business Pty Ltd',
          tradingName: tradingName || 'New Business',
          businessType: businessType || 'company',
          industry: industryKey || null,
          abn: abn ? abn.replace(/\s+/g, '') : '51824753556',
          registeredAddress: address || '123 Collins Street, Melbourne VIC 3000',
          counterMode: finalCounterMode,
          kybStatus: 'APPROVED',
          onboardingStep: 3,
          status: 'setup',
          kitPaid: false
        }
      });
      // Pre-seed default accepted tokens
      await prisma.acceptedToken.createMany({
        data: [
          { merchantId: merchant.id, tokenSymbol: 'DYNK', blockchain: 'solana', enabled: true, customerFeeType: 'flat', customerFeeValue: 0.01 },
          { merchantId: merchant.id, tokenSymbol: 'SOL', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 },
          { merchantId: merchant.id, tokenSymbol: 'USDC', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 }
        ],
        skipDuplicates: true
      });
      // New businesses start with an empty catalogue: Dynkle serves any kind of shop.
    } else {
      merchant = await prisma.merchant.update({
        where: { id: merchant.id },
        data: {
          legalName: legalName || merchant.legalName,
          tradingName: tradingName || merchant.tradingName,
          businessType: businessType || merchant.businessType,
          industry: industryKey ?? merchant.industry,
          abn: abn ? abn.replace(/\s+/g, '') : merchant.abn,
          registeredAddress: address || merchant.registeredAddress,
          counterMode: finalCounterMode,
          kybStatus: 'APPROVED',
          onboardingStep: Math.max(merchant.onboardingStep, 3)
        }
      });
    }

    // Configure Terminals based on Counter Architecture
    const targetCounters = (counters && Array.isArray(counters) && counters.length > 0)
      ? counters
      : (finalCounterMode === 'SINGLE' 
          ? [{ terminalId: 'POS_001', label: 'Main Counter' }]
          : [
              { terminalId: 'POS_001', label: 'Counter 1 (Main Till)' },
              { terminalId: 'POS_002', label: 'Counter 2 (Bar Till)' },
              { terminalId: 'POS_003', label: 'Counter 3 (Patio / Dining)' }
            ]
        );

    for (let i = 0; i < targetCounters.length; i++) {
      const c = targetCounters[i];
      const tid = c.terminalId || `POS_${String(i + 1).padStart(3, '0')}`;
      const label = c.label || (finalCounterMode === 'SINGLE' ? 'Main Counter' : `Counter ${i + 1}`);

      await prisma.terminal.upsert({
        where: { terminalId: tid },
        update: {
          merchantId: merchant.id,
          label,
          status: 'READY',
          lastSeenAt: new Date()
        },
        create: {
          merchantId: merchant.id,
          terminalId: tid,
          label,
          serialNumber: `SN-${tid}-${Date.now().toString().slice(-4)}`,
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        }
      });
    }

    const terminals = await prisma.terminal.findMany({ where: { merchantId: merchant.id } });

    res.json({
      success: true,
      merchantId: merchant.id,
      message: `Business details and ${finalCounterMode} counter architecture saved ✓`,
      counterMode: finalCounterMode,
      terminals: terminals.map(t => ({ ...t, staticUrl: `/t/${merchant.id}/${t.terminalId}` })),
      onboarding: {
        step: merchant.onboardingStep,
        counterMode: finalCounterMode,
        business: {
          legalName: merchant.legalName,
          tradingName: merchant.tradingName,
          abn: merchant.abn
        }
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'BUSINESS_SAVE_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/counters - Dedicated Counter Configuration
router.post('/onboarding/counters', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) return res.status(404).json({ error: 'MERCHANT_NOT_FOUND' });

    const { counterMode, counters } = req.body;
    const mode = counterMode === 'MULTIPLE' ? 'MULTIPLE' : 'SINGLE';

    await prisma.merchant.update({
      where: { id: merchant.id },
      data: { counterMode: mode }
    });

    const targetCounters = (counters && Array.isArray(counters) && counters.length > 0)
      ? counters
      : (mode === 'SINGLE' 
          ? [{ terminalId: 'POS_001', label: 'Main Counter' }]
          : [
              { terminalId: 'POS_001', label: 'Counter 1 (Main Till)' },
              { terminalId: 'POS_002', label: 'Counter 2 (Bar Till)' },
              { terminalId: 'POS_003', label: 'Counter 3 (Patio / Dining)' }
            ]
        );

    const createdTerminals = [];
    for (let i = 0; i < targetCounters.length; i++) {
      const c = targetCounters[i];
      const tid = c.terminalId || `POS_${String(i + 1).padStart(3, '0')}`;
      const label = c.label || (mode === 'SINGLE' ? 'Main Counter' : `Counter ${i + 1}`);

      const term = await prisma.terminal.upsert({
        where: { terminalId: tid },
        update: {
          merchantId: merchant.id,
          label,
          status: 'READY',
          lastSeenAt: new Date()
        },
        create: {
          merchantId: merchant.id,
          terminalId: tid,
          label,
          serialNumber: `SN-${tid}-${Date.now().toString().slice(-4)}`,
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        }
      });
      createdTerminals.push({
        ...term,
        staticUrl: `/t/${merchant.id}/${term.terminalId}`
      });
    }

    res.json({
      success: true,
      message: `Counters configured successfully (${mode} mode).`,
      counterMode: mode,
      terminals: createdTerminals
    });
  } catch (err) {
    res.status(500).json({ error: 'COUNTERS_SAVE_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/kit-order - Stage 3: Order Starter Kit ($199)
router.post('/onboarding/kit-order', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { shippingAddress, intentId } = req.body;

    const result = await processKitPaymentSuccess(
      merchant.id,
      intentId,
      shippingAddress || merchant.registeredAddress || '123 Collins Street, Melbourne VIC 3000'
    );

    res.json({
      success: true,
      message: 'Starter kit ordered and $199 payment recorded. Hardware dispatched via Australia Post.',
      orderNumber: `KIT-${result.intentId.slice(-8).toUpperCase()}`,
      trackingNumber: result.trackingNumber,
      onboarding: {
        step: 4,
        kit: { paid: true, trackingNumber: result.trackingNumber }
      }
    });
  } catch (err) {
    const status = err.code?.startsWith('KIT_PAYMENT_INTENT') ? 400 : 500;
    res.status(status).json({ error: err.code || 'KIT_ORDER_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/pair-device - Connect Hardware Terminal(s)
router.post('/onboarding/pair-device', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { terminalId, serialNumber, pairAll = false } = req.body;

    if (pairAll) {
      await prisma.terminal.updateMany({
        where: { merchantId: merchant.id },
        data: {
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        }
      });
    } else {
      const tid = terminalId || 'POS_001';
      await prisma.terminal.upsert({
        where: { terminalId: tid },
        update: {
          merchantId: merchant.id,
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        },
        create: {
          merchantId: merchant.id,
          terminalId: tid,
          label: 'Main Counter',
          serialNumber: serialNumber || `SN-${tid}-9001`,
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        }
      });
    }

    await prisma.merchant.update({
      where: { id: merchant.id },
      data: { onboardingStep: Math.max(merchant.onboardingStep, 5) }
    });

    const terminals = await prisma.terminal.findMany({ where: { merchantId: merchant.id } });

    res.json({
      success: true,
      message: pairAll ? 'All configured terminals paired and ready.' : `Terminal paired and ready.`,
      terminals: terminals.map(t => ({
        ...t,
        staticUrl: `/t/${merchant.id}/${t.terminalId}`
      })),
      onboarding: {
        step: 5,
        device: { paired: true }
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'PAIR_DEVICE_FAILED', message: err.message });
  }
});

// POST /api/merchant/pair-tag - Bind a physical NTAG 424 DNA tag to merchant
router.post('/pair-tag', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const { tagId, terminalId, label, picc, cmac } = req.body;
    const tid = tagId || terminalId;
    if (!tid) {
      return res.status(400).json({ error: 'TAG_ID_REQUIRED', message: 'tagId or terminalId is required.' });
    }

    if (picc || cmac) {
      const validation = await validateNtag424Tap({ tagId: tid, picc, cmac });
      if (!validation.valid) {
        return res.status(400).json({ error: 'INVALID_TAG_SIGNATURE', message: validation.error });
      }
    }

    const existingTerminal = await prisma.terminal.findUnique({ where: { terminalId: tid } });
    if (existingTerminal && existingTerminal.merchantId !== merchant.id && existingTerminal.status === 'READY') {
      return res.status(403).json({
        error: 'TAG_ALREADY_PAIRED',
        message: 'This tag is already paired to another merchant. Unlink it from the existing POS before re-pairing.'
      });
    }

    const terminal = await prisma.terminal.upsert({
      where: { terminalId: tid },
      update: {
        merchantId: merchant.id,
        label: label || `Counter (${tid})`,
        status: 'READY',
        pairedAt: new Date(),
        lastSeenAt: new Date()
      },
      create: {
        merchantId: merchant.id,
        terminalId: tid,
        label: label || `Counter (${tid})`,
        serialNumber: `SN-${tid}-${Date.now().toString().slice(-4)}`,
        status: 'READY',
        pairedAt: new Date(),
        lastSeenAt: new Date()
      }
    });

    res.json({
      success: true,
      message: `NFC Tag ${tid} paired successfully to ${merchant.tradingName || merchant.legalName}`,
      terminal: {
        ...terminal,
        staticUrl: `/t/${tid}`,
        directNfcUrl: `/t/${merchant.id}/${tid}`
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'PAIR_TAG_FAILED', message: err.message });
  }
});

// GET /api/merchant/terminals - List all paired terminals / tags for active merchant
router.get('/terminals', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    const terminals = await prisma.terminal.findMany({
      where: { merchantId: merchant.id },
      orderBy: { createdAt: 'asc' }
    });
    res.json({
      success: true,
      terminals: terminals.map(t => ({
        ...t,
        staticUrl: `/t/${t.terminalId}`,
        directNfcUrl: `/t/${merchant.id}/${t.terminalId}`
      }))
    });
  } catch (err) {
    res.status(500).json({ error: 'LIST_TERMINALS_FAILED', message: err.message });
  }
});

// POST /api/merchant/onboarding/reset - Reset onboarding for testing from scratch
router.post('/onboarding/reset', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);

    // Previously this only touched 4 fields on the merchant row and claimed
    // `device: {paired: false}` in the response while leaving every Terminal
    // still READY/paired, every RevenueSplitRule still summing to 100%, and
    // every Wallet/AcceptedToken/Product intact. A subsequent /onboarding/
    // go-live would pass immediately post-"reset" because none of its actual
    // prerequisites had been touched — the reset was cosmetic, and its own
    // response was lying about device pairing state.
    await prisma.$transaction([
      prisma.revenueSplitRule.deleteMany({ where: { merchantId: merchant.id } }),
      prisma.wallet.deleteMany({ where: { merchantId: merchant.id } }),
      prisma.acceptedToken.deleteMany({ where: { merchantId: merchant.id } }),
      prisma.product.deleteMany({ where: { merchantId: merchant.id } }),
      prisma.terminal.deleteMany({ where: { merchantId: merchant.id } }),
      prisma.merchant.update({
        where: { id: merchant.id },
        data: {
          status: 'setup',
          onboardingStep: 1,
          kybStatus: 'DRAFT',
          kitPaid: false,
          kitPaymentId: null
        }
      })
    ]);
    merchantSwapAndSendLists.delete(merchant.id);

    const updated = await prisma.merchant.findUnique({ where: { id: merchant.id } });

    res.json({
      success: true,
      message: 'Onboarding reset to Step 1.',
      onboarding: {
        step: 1,
        isLive: false,
        account: { verified: false },
        business: { kybStatus: 'DRAFT' },
        kit: { paid: false },
        device: { paired: false }
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'RESET_FAILED', message: err.message });
  }
});

// GET /api/merchant/onboarding - Return full status
router.get('/onboarding', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) return res.json({ success: false });

    const terminal = await prisma.terminal.findFirst({
      where: { merchantId: merchant.id, status: 'READY' }
    });

    res.json({
      success: true,
      onboarding: {
        step: merchant.onboardingStep,
        isLive: merchant.status === 'live',
        account: { verified: true },
        business: { legalName: merchant.legalName, tradingName: merchant.tradingName, abn: merchant.abn, kybStatus: merchant.kybStatus },
        kit: { paid: merchant.kitPaid },
        device: { paired: !!terminal, deviceId: terminal?.terminalId || 'DY-009' }
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/merchant/onboarding/fake-complete - 1-Click Fast-Track Fake Onboarding
router.post('/onboarding/fake-complete', async (req, res) => {
  try {
    let merchant = await getActiveMerchant(req);
    if (!merchant) {
      merchant = await prisma.merchant.create({
        data: {
          legalName: 'Bean & Brew Pty Ltd',
          tradingName: 'Bean & Brew Café',
          businessType: 'company',
          abn: '51824753556',
          registeredAddress: '123 Collins Street, Melbourne VIC 3000',
          counterMode: 'SINGLE',
          kybStatus: 'APPROVED',
          onboardingStep: 8,
          status: 'live',
          kitPaid: true
        }
      });
    } else {
      merchant = await prisma.merchant.update({
        where: { id: merchant.id },
        data: {
          legalName: merchant.legalName || 'Bean & Brew Pty Ltd',
          tradingName: merchant.tradingName || 'Bean & Brew Café',
          businessType: merchant.businessType || 'company',
          abn: merchant.abn || '51824753556',
          registeredAddress: merchant.registeredAddress || '123 Collins Street, Melbourne VIC 3000',
          kybStatus: 'APPROVED',
          onboardingStep: 8,
          status: 'live',
          kitPaid: true
        }
      });
    }

    // Terminal
    await prisma.terminal.upsert({
      where: { terminalId: 'POS_001' },
      update: { merchantId: merchant.id, status: 'READY', pairedAt: new Date() },
      create: { merchantId: merchant.id, terminalId: 'POS_001', label: 'Main Register', serialNumber: 'SN-POS_001-9001', status: 'READY', pairedAt: new Date() }
    });

    // Split rules
    const existingRules = await prisma.revenueSplitRule.findMany({ where: { merchantId: merchant.id } });
    const totalBps = existingRules.reduce((sum, r) => sum + r.basisPoints, 0);
    if (totalBps !== 10000) {
      const defaultBuckets = [
        { bucket: 'TAX', label: 'Tax Reserves (ATO)', basisPoints: 1500, settlementMode: 'STABLE' },
        { bucket: 'EXPENSES', label: 'Operating Expenses', basisPoints: 2000, settlementMode: 'STABLE' },
        { bucket: 'OWNER_PAY', label: 'Owner Drawings', basisPoints: 2000, settlementMode: 'CRYPTO' },
        { bucket: 'PROFIT', label: 'Retained Profit', basisPoints: 4500, settlementMode: 'CRYPTO' }
      ];

      await prisma.revenueSplitRule.deleteMany({ where: { merchantId: merchant.id } });
      for (const b of defaultBuckets) {
        let wallet = await prisma.wallet.findFirst({
          where: { merchantId: merchant.id, label: b.label }
        });
        if (!wallet) {
          wallet = await prisma.wallet.create({
            data: {
              merchantId: merchant.id,
              label: b.label,
              address: merchant.solanaAddress || '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH',
              blockchain: 'solana'
            }
          });
        }
        await prisma.revenueSplitRule.create({
          data: {
            merchantId: merchant.id,
            bucket: b.bucket,
            basisPoints: b.basisPoints,
            settlementMode: b.settlementMode,
            destinationWalletId: wallet.id
          }
        });
      }
    }

    // Accepted tokens
    const existingTokens = await prisma.acceptedToken.findMany({ where: { merchantId: merchant.id } });
    if (existingTokens.length === 0) {
      await prisma.acceptedToken.createMany({
        data: [
          { merchantId: merchant.id, tokenSymbol: 'DYNK', blockchain: 'solana', enabled: true, customerFeeType: 'flat', customerFeeValue: 0.01 },
          { merchantId: merchant.id, tokenSymbol: 'SOL', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 },
          { merchantId: merchant.id, tokenSymbol: 'USDC', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.01 }
        ]
      });
    }

    // Products
    const existingProducts = await prisma.product.findMany({ where: { merchantId: merchant.id } });
    if (existingProducts.length === 0) {
      // New businesses start with an empty catalogue: Dynkle serves any kind of shop.
    }

    res.json({
      success: true,
      message: 'Fast-track onboarding complete! Merchant is now LIVE.',
      merchantId: merchant.id,
      merchant
    });
  } catch (err) {
    res.status(500).json({ error: 'FAKE_COMPLETE_FAILED', message: err.message });
  }
});

export default router;


