import express from 'express';
import QRCode from 'qrcode';
import crypto from 'crypto';
import prisma from '../db.js';
import { ipLimiter } from '../middleware/rateLimit.js';
import { MERCHANT, PUBLIC_BASE_URL, ORDER_TTL_SECONDS, MAX_ORDER_AUD, LARGE_AMOUNT_WARNING_AUD, VAPID_PUBLIC_KEY, DEMO_MODE } from '../config.js';
import { getLivePrice, calculateCustomerFee, checkVolatilityThreshold } from '../services/priceService.js';
import { generateReference, confirmSolanaPayment, checkSolanaPayment, fetchSolanaBlockhash, executeSolanaRefund } from '../services/solana.js';
import { terminalGateway } from '../gateway/terminalGateway.js';
import { FLOWS, sendFlow, flowResponse, classifyError, SETTLED_STATUSES, IN_FLIGHT_STATUSES, NON_TERMINAL_STATUSES } from '../services/paymentFlows.js';
import { preflight, getPreflightResult, recordPreflightResult } from '../services/preflight.js';
import { saveSubscription, sendInsufficientFundsPush } from '../services/pushService.js';
import { customerBaseUrl } from '../services/publicUrl.js';
import { confirmWebSignature } from '../tappay/service.js';
import { pollSepoliaPayment, forgetOrder } from '../services/evmWatch.js';

const router = express.Router();

// GET /api/orders/flows - Canonical flow catalogue, so pay.html renders the same
// copy the API returns instead of keeping its own divergent strings.
router.get('/flows', (req, res) => res.json({ flows: FLOWS }));

// GET /api/orders/push/vapid-public-key - Lets the customer's browser create
// a push subscription bound to this server's identity.
router.get('/push/vapid-public-key', (req, res) => res.json({ publicKey: VAPID_PUBLIC_KEY }));

// POST /api/orders/:id/push-subscribe - Registers the customer's browser
// push subscription for this specific checkout. No auth beyond knowing the
// orderId — the same access boundary the rest of the customer-facing
// checkout endpoints already use.
router.post('/:id/push-subscribe', async (req, res) => {
  try {
    const { subscription } = req.body || {};
    if (!subscription?.endpoint) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'A valid push subscription is required.' });
    }
    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) return sendFlow(res, 'ORDER_NOT_FOUND');

    saveSubscription(order.id, subscription);
    res.json({ success: true });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// GET /api/orders/solana-blockhash - Provides latest cluster blockhash for client wallet signing
router.get('/solana-blockhash', async (req, res) => {
  try {
    const data = await fetchSolanaBlockhash();
    res.json(data);
  } catch (err) {
    res.status(503).json({ error: 'BLOCKHASH_UNAVAILABLE', message: 'Could not reach Solana. Try again.' });
  }
});

// Active terminal tap sessions (for NFC countertop tap-to-pay concurrency & locking)
export const terminalSessions = new Map();

// POST /api/orders - Creates a new order with an ORDER_TTL_SECONDS rate lock and arms the terminal
router.post('/', async (req, res) => {
  try {
    const {
      terminalId = 'DY-009',
      amountAUD = '10.00',
      items = [],
      tokenSymbol: explicitToken,
      currency: altCurrency,
      token: altToken,
      merchantId: requestedMerchantId,
      publicBaseUrl
    } = req.body;
    const tokenSymbol = explicitToken || altCurrency || (typeof altToken === 'object' ? altToken?.symbol : altToken) || null;

    // 1. Resolve Merchant
    const targetMerchantId = requestedMerchantId || req.headers['x-merchant-id'] || req.query?.merchantId;
    let merchant;
    if (targetMerchantId) {
      merchant = await prisma.merchant.findUnique({ where: { id: targetMerchantId } });
    }
    if (!merchant) {
      merchant = await prisma.merchant.findFirst({ orderBy: { updatedAt: 'desc' } }) || await prisma.merchant.findFirst({ orderBy: { createdAt: 'asc' } });
    }

    if (!merchant) {
      return res.status(400).json({ error: 'MERCHANT_NOT_FOUND', message: 'No merchant found in system.' });
    }

    // 1b. Ensure terminal is registered and bound to this merchant
    if (terminalId) {
      try {
        await prisma.terminal.upsert({
          where: { terminalId },
          update: { merchantId: merchant.id, lastSeenAt: new Date() },
          create: {
            merchantId: merchant.id,
            terminalId,
            serialNumber: `SN-${terminalId}-${Date.now().toString().slice(-4)}`,
            status: 'CONNECTED',
            pairedAt: new Date()
          }
        });
      } catch (termErr) {
        // Fallback gracefully
      }
    }

    // 2. Calculate Subtotal, Fees, GST, and Crypto Amount
    let subtotal = parseFloat(amountAUD);
    if (items && items.length > 0) {
      // The web register sends `qty`, devices send both; reading only `quantity`
      // billed a 2× line as one.
      const itemsSum = items.reduce((sum, item) => sum + (parseFloat(item.price || 0) * (Number(item.quantity || item.qty) || 1)), 0);
      if (itemsSum > 0) subtotal = itemsSum;
    }

    // Refuse outright before a QR/link is ever generated. A bill like
    // $99,999,999 is a fat-fingered extra digit or a bad caller, not a real
    // in-person sale — catch it here rather than let a customer discover it
    // by opening their wallet to a life-changing charge.
    if (!Number.isFinite(subtotal) || subtotal <= 0) {
      return res.status(400).json({
        error: 'INVALID_AMOUNT',
        message: 'The bill amount must be a positive number.'
      });
    }
    // DEV BYPASS: lets a tester try large test amounts without hitting the
    // production ceiling. INVALID_AMOUNT (negative/NaN) above still applies —
    // that's basic input sanity, not a friction point worth skipping.
    if (subtotal > MAX_ORDER_AUD && !DEMO_MODE) {
      return res.status(400).json({
        error: 'AMOUNT_EXCEEDS_LIMIT',
        message: `$${subtotal.toFixed(2)} AUD exceeds the maximum single-bill limit of $${MAX_ORDER_AUD.toFixed(2)} AUD. Check the amount entered, or split into smaller bills.`,
        maxAllowedAUD: MAX_ORDER_AUD
      });
    }

    // 2b. Enforce Merchant Accepted Currencies
    const merchantAcceptedTokens = await prisma.acceptedToken.findMany({
      where: { merchantId: merchant.id, enabled: true }
    });

    let sym = tokenSymbol ? tokenSymbol.toUpperCase().trim() : null;
    if (merchantAcceptedTokens.length > 0) {
      if (sym) {
        const isAllowed = merchantAcceptedTokens.some(t => t.tokenSymbol.toUpperCase() === sym);
        if (!isAllowed) {
          return res.status(400).json({
            error: 'CURRENCY_NOT_ACCEPTED',
            message: `Currency ${sym} is not accepted by this merchant. Accepted: ${merchantAcceptedTokens.map(t => t.tokenSymbol).join(', ')}`
          });
        }
      } else {
        sym = merchantAcceptedTokens[0].tokenSymbol.toUpperCase();
      }
    } else {
      sym = sym || 'SOL';
    }

    const feeAUD = calculateCustomerFee(sym, subtotal);
    const totalAUD = parseFloat((subtotal + feeAUD).toFixed(2));
    const gstAUD = parseFloat((subtotal / 11).toFixed(2)); // ATO 10% GST included

    // 3. Real-time Price Oracle
    const oracle = await getLivePrice(sym);
    const quotePrice = oracle.priceAUD;
    const cryptoDecimals = sym === 'BTC' ? 8 : (['SOL', 'ETH'].includes(sym) ? 6 : (sym === 'TRX' ? 4 : 2));
    const cryptoAmount = parseFloat((totalAUD / quotePrice).toFixed(cryptoDecimals));

    // 4. Strict rate lock window (ORDER_TTL_SECONDS)
    const quoteCreatedAt = new Date();
    const quoteExpiresAt = new Date(quoteCreatedAt.getTime() + (ORDER_TTL_SECONDS * 1000));

    // 5. Generate Solana Pay Reference Public Key
    const referencePubkey = generateReference();
    const referenceKey = referencePubkey.toBase58();

    // 6. Generate Unique Order Number
    const orderNumber = `ORD-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;

    // Enforce strictly ONE active payment session per physical terminal at a time
    // Cancel/supersede any previous uncompleted order on this terminal
    await prisma.order.updateMany({
      where: {
        terminalId,
        merchantId: merchant.id,
        status: { in: ['QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'] }
      },
      data: {
        status: 'CANCELLED'
      }
    });

    // 7. Persist Order in PostgreSQL Database
    const order = await prisma.order.create({
      data: {
        merchantId: merchant.id,
        orderNumber,
        subtotalAUD: subtotal,
        customerFeeAUD: feeAUD,
        totalAUD,
        gstAUD,
        tokenSymbol: sym,
        cryptoAmount,
        quotePrice,
        quoteCreatedAt,
        quoteExpiresAt,
        status: 'QUOTED',
        terminalId,
        referenceKey,
        items: items || []
      }
    });

    // 8. Update Terminal Session & Arm Countertop Device
    terminalSessions.set(`${merchant.id}:${terminalId}`, {
      orderId: order.id,
      state: 'DEVICE_ARMED',
      merchantId: merchant.id,
      terminalId,
      createdAt: Date.now()
    });
    terminalSessions.set(terminalId, {
      orderId: order.id,
      state: 'DEVICE_ARMED',
      merchantId: merchant.id,
      terminalId,
      createdAt: Date.now()
    });

    terminalGateway.arm(terminalId, {
      orderId: order.id,
      amountAUD: totalAUD,
      cryptoAmount,
      tokenSymbol: sym,
      quoteExpiresAt
    }).catch(e => console.warn('[Terminal Arm Warning]:', e.message));

    // 9. Generate Solana Pay URL, Web Checkout URL & QR Codes
    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const proto = req.headers['x-forwarded-proto'] || (req.secure ? 'https' : 'http');
    const headerBaseUrl = host ? `${proto}://${host}` : null;
    // The customer's phone and wallet open these links, so use the public
    // address (tunnel or domain) even when the merchant opened the POS at
    // localhost or a LAN IP. See services/publicUrl.js.
    const activeBaseUrl = customerBaseUrl(req, headerBaseUrl || publicBaseUrl || PUBLIC_BASE_URL);
    // Must be this order's merchant, not the process-wide env default, or a
    // multi-merchant deployment routes funds to whoever is configured in .env.
    const merchantSolanaWallet = await prisma.wallet.findFirst({
      where: { merchantId: merchant.id, blockchain: 'solana', status: 'active' },
      orderBy: { createdAt: 'asc' }
    });
    const receivingAddress = merchantSolanaWallet?.address || MERCHANT.solanaAddress;
    
    // Web Checkout URL (for phone camera scan)
    const payUrl = `${activeBaseUrl}/pay.html?orderId=${order.id}&ngrok-skip-browser-warning=true`;

    // Solana Pay Transaction Request URL (for wallet app scan)
    const solanaPayTxUrl = `${activeBaseUrl}/api/solana-pay/order/${order.id}`;
    const cleanTxUrlWithCluster = `${solanaPayTxUrl}?cluster=devnet&ngrok-skip-browser-warning=true`;
    const solanaPayTxUri = `solana:${encodeURIComponent(cleanTxUrlWithCluster)}`;
    
    // Standard Direct Transfer URL for Phantom / Solflare Native Scan (Natively parsed in Phantom, prefilled amount)
    const merchantLabel = merchant.tradingName || merchant.legalName || 'DYNKLE Merchant';
    const directSolanaUrl = `solana:${receivingAddress}?amount=${cryptoAmount}&reference=${referenceKey}&label=${encodeURIComponent(merchantLabel)}&message=${encodeURIComponent(`Order ${orderNumber}`)}`;

    // Standard EIP-681 Transfer URL for MetaMask Native Scan
    const weiAmount = BigInt(Math.max(1, Math.round(cryptoAmount * 1e18))).toString();
    const directEvmUrl = `ethereum:${MERCHANT.evmAddress}@11155111?value=${weiAmount}`;

    const [webQrDataUrl, solanaQrDataUrl, evmQrDataUrl] = await Promise.all([
      QRCode.toDataURL(payUrl, {
        errorCorrectionLevel: 'M',
        margin: 2,
        width: 380,
        color: { dark: '#000000', light: '#FFFFFF' }
      }),
      QRCode.toDataURL(solanaPayTxUri, {
        errorCorrectionLevel: 'M',
        margin: 2,
        width: 380,
        color: { dark: '#000000', light: '#FFFFFF' }
      }),
      QRCode.toDataURL(directEvmUrl, {
        errorCorrectionLevel: 'M',
        margin: 2,
        width: 380,
        color: { dark: '#000000', light: '#FFFFFF' }
      })
    ]);

    let liveBh = null;
    try {
      const bhObj = await fetchSolanaBlockhash();
      liveBh = bhObj.blockhash;
    } catch (e) {}

    res.status(201).json({
      success: true,
      id: order.id,
      orderId: order.id,
      blockhash: liveBh,
      orderNumber: order.orderNumber,
      status: order.status,
      sessionState: 'DEVICE_ARMED',
      terminalId,
      acceptedTokens: merchantAcceptedTokens.map(t => {
        const sym = t.tokenSymbol.toUpperCase();
        let icon = '🪙';
        if (sym === 'SOL') icon = '◎';
        else if (sym === 'DYNK') icon = '⚡';
        else if (sym === 'USDC') icon = '💵';
        else if (sym === 'ETH') icon = '⟠';
        else if (sym === 'BTC') icon = '₿';
        else if (sym === 'TRX') icon = '🔴';
        let name = sym;
        if (sym === 'SOL') name = 'Solana';
        else if (sym === 'DYNK') name = 'DYNK Token';
        else if (sym === 'USDC') name = 'USD Coin';
        else if (sym === 'ETH') name = 'Ethereum';
        else if (sym === 'BTC') name = 'Bitcoin';
        else if (sym === 'TRX') name = 'TRON Native';
        return {
          symbol: sym,
          name,
          icon,
          blockchain: t.blockchain,
          customerFeeType: t.customerFeeType,
          customerFeeValue: parseFloat(t.customerFeeValue || 0)
        };
      }),
      subtotalAUD: order.subtotalAUD.toString(),
      customerFeeAUD: order.customerFeeAUD.toString(),
      totalAUD: order.totalAUD.toString(),
      finalTotalAUD: order.totalAUD.toString(),
      amountUSD: order.totalAUD.toString(),
      gstAUD: order.gstAUD.toString(),
      // Tells pay.html whether to gate the pay button behind an explicit
      // "yes, this amount is correct" confirmation before it's usable.
      largeAmountWarning: parseFloat(order.totalAUD.toString()) >= LARGE_AMOUNT_WARNING_AUD,
      tokenSymbol: order.tokenSymbol,
      cryptoAmount: order.cryptoAmount.toString(),
      amount: order.cryptoAmount.toString(),
      quotePrice: order.quotePrice.toString(),
      quoteExpiresAt: order.quoteExpiresAt,
      reference: order.referenceKey,
      referenceKey: order.referenceKey,
      payUrl,
      qrPayload: solanaPayTxUri,
      solanaPayTxUrl,
      solanaPayTxUri,
      solanaPayUri: solanaPayTxUri,
      directSolanaUrl,
      directEvmUrl,
      webQrDataUrl,
      solanaQrDataUrl,
      evmQrDataUrl,
      items: order.items,
      merchantName: merchantLabel,
      merchantAddress: receivingAddress
    });
  } catch (err) {
    console.error('[Create Order Error]:', err);
    res.status(500).json({ error: 'CREATE_ORDER_FAILED', message: err.message });
  }
});

// GET /api/orders/:id - Get order details with live expiry calculation
router.get('/:id', async (req, res) => {
  try {
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: {
        transaction: {
          include: {
            settlementTransactions: true
          }
        },
        merchant: {
          select: {
            id: true,
            tradingName: true,
            legalName: true,
            abn: true
          }
        }
      }
    });

    if (!order) {
      if (DEMO_MODE) { // demo ids only on the local demo (spec D12)
        const activeSession = terminalSessions.get('POS_001') || Array.from(terminalSessions.values())[0];
        if (activeSession && activeSession.orderId) {
          const linkedOrder = await prisma.order.findUnique({
            where: { id: activeSession.orderId },
            include: {
              transaction: { include: { settlementTransactions: true } },
              merchant: { select: { id: true, tradingName: true, legalName: true, abn: true } }
            }
          });
          if (linkedOrder) return res.json(linkedOrder);
        }
        return res.json({
          id: req.params.id,
          orderNumber: 'DY-009',
          status: 'QUOTED',
          sessionState: 'ARMED',
          amountUSD: '10.10',
          totalAUD: '10.10',
          cryptoAmount: '0.0459',
          tokenSymbol: 'SOL',
          quoteExpiresAt: new Date(Date.now() + ORDER_TTL_SECONDS * 1000),
          merchantName: 'Bean & Brew Café',
          merchantAddress: '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH'
        });
      }
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Order not found.' });
    }

    // Check on-chain reference key if order is not yet marked paid
    let currentStatus = order.status;
    let settledResult = null;
    if (currentStatus !== 'PAID' && currentStatus !== 'SETTLED') {
      try {
        const settled = await checkSolanaPayment(order);
        if (settled) {
          settledResult = settled;
          currentStatus = 'PAID';
          order.status = 'PAID';
          order.paidAt = new Date();
          order.customerWallet = settled.recordedTx?.senderAddress || settled.customerWallet || order.customerWallet;
        }
      } catch (err) {
        // Silently continue
      }
    }

    // Customer is paying from an EVM wallet app (MetaMask/Trust payment link): look for
    // the tagged Sepolia transfer. Only when the pay page asks, so SOL orders never hit the RPC.
    if (currentStatus !== 'PAID' && currentStatus !== 'SETTLED' && req.query.watch === 'evm') {
      try {
        const evmTx = pollSepoliaPayment(order);
        if (evmTx) {
          await confirmSolanaPayment(order.id, evmTx.txHash, evmTx.from, {
            blockchain: 'ethereum', token: 'ETH', receiverAddress: MERCHANT.evmAddress, verified: true
          });
          forgetOrder(order.id);
          currentStatus = 'PAID';
          order.status = 'PAID';
          order.paidAt = new Date();
          order.txHash = evmTx.txHash;
          order.paidCurrency = 'ETH';
          order.paidVia = 'Ethereum wallet (Sepolia)';
          order.customerWallet = evmTx.from;
          console.log(`[EVM] Order ${order.orderNumber} paid on Sepolia: ${evmTx.txHash}`);
        }
      } catch (err) {
        console.warn('[EVM] Sepolia check failed:', err.message);
      }
    }

    // Check expiry strictly: Expired quotes transition to EXPIRED and disarm till
    const now = Date.now();
    const expiresAt = new Date(order.quoteExpiresAt).getTime();

    if (['QUOTED', 'CUSTOMER_DETECTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'].includes(currentStatus) && now > expiresAt) {
      await prisma.order.update({
        where: { id: order.id },
        data: { status: 'EXPIRED' }
      });
      terminalGateway.disarm(order.terminalId).catch(() => {});
      currentStatus = 'EXPIRED';
    }

    // Surfaces a dead register to the customer immediately rather than making
    // them wait out the sweeper's 30s grace window or the full quote expiry
    // with no explanation of what's actually wrong.
    let terminalOffline = false;
    if (NON_TERMINAL_STATUSES.includes(currentStatus) && order.terminalId) {
      const terminal = await prisma.terminal.findUnique({ where: { terminalId: order.terminalId } });
      terminalOffline = terminal?.status === 'OFFLINE';
    }

    const host = req.headers['x-forwarded-host'] || req.headers.host;
    const proto = req.headers['x-forwarded-proto'] || (req.secure ? 'https' : 'http');
    const activeBaseUrl = customerBaseUrl(req, host ? `${proto}://${host}` : PUBLIC_BASE_URL);
    const payUrl = `${activeBaseUrl}/pay.html?orderId=${order.id}`;
    const solanaPayTxUrl = `${activeBaseUrl}/api/solana-pay/order/${order.id}`;
    const cleanTxUrlWithCluster = `${solanaPayTxUrl}?cluster=devnet`;
    const solanaPayTxUri = `solana:${encodeURIComponent(cleanTxUrlWithCluster)}`;
    
    // Direct Transfer URL (Zero ngrok reliance, natively processed in Phantom mobile with prefilled amount)
    const merchantLabel = order.merchant?.tradingName || order.merchant?.legalName || MERCHANT.name;
    const orderMerchantWallet = await prisma.wallet.findFirst({
      where: { merchantId: order.merchantId, blockchain: 'solana', status: 'active' },
      orderBy: { createdAt: 'asc' }
    });
    const receivingAddress = orderMerchantWallet?.address || MERCHANT.solanaAddress;
    const directSolanaUrl = `solana:${receivingAddress}?amount=${order.cryptoAmount.toString()}&reference=${order.referenceKey}&label=${encodeURIComponent(merchantLabel)}&message=${encodeURIComponent(`Order ${order.orderNumber}`)}`;
    const solanaPayUri = solanaPayTxUri;

    const merchantAccepted = await prisma.acceptedToken.findMany({
      where: { merchantId: order.merchantId, enabled: true }
    });

    const acceptedTokens = merchantAccepted.map(t => {
      const sym = t.tokenSymbol.toUpperCase();
      let icon = '🪙';
      if (sym === 'SOL') icon = '◎';
      else if (sym === 'DYNK') icon = '⚡';
      else if (sym === 'USDC') icon = '💵';
      else if (sym === 'ETH') icon = '⟠';
      else if (sym === 'BTC') icon = '₿';
      else if (sym === 'TRX') icon = '🔴';
      
      let name = sym;
      if (sym === 'SOL') name = 'Solana';
      else if (sym === 'DYNK') name = 'DYNK Token';
      else if (sym === 'USDC') name = 'USD Coin';
      else if (sym === 'ETH') name = 'Ethereum';
      else if (sym === 'BTC') name = 'Bitcoin';
      else if (sym === 'TRX') name = 'TRON Native';

      return {
        symbol: sym,
        name,
        icon,
        blockchain: t.blockchain,
        customerFeeType: t.customerFeeType,
        customerFeeValue: parseFloat(t.customerFeeValue || 0)
      };
    });

    res.json({
      success: true,
      id: order.id,
      orderNumber: order.orderNumber,
      status: currentStatus,
      acceptedTokens,
      sessionState: currentStatus === 'PAID' ? 'PAID' : (currentStatus === 'EXPIRED' ? 'EXPIRED' : 'DEVICE_ARMED'),
      terminalId: order.terminalId,
      terminalOffline,
      subtotalAUD: order.subtotalAUD.toString(),
      customerFeeAUD: order.customerFeeAUD.toString(),
      totalAUD: order.totalAUD.toString(),
      finalTotalAUD: order.totalAUD.toString(),
      largeAmountWarning: parseFloat(order.totalAUD.toString()) >= LARGE_AMOUNT_WARNING_AUD,
      amountUSD: order.totalAUD.toString(),
      gstAUD: order.gstAUD.toString(),
      tokenSymbol: order.tokenSymbol,
      cryptoAmount: order.cryptoAmount.toString(),
      amount: order.cryptoAmount.toString(),
      quotePrice: order.quotePrice.toString(),
      quoteCreatedAt: order.quoteCreatedAt,
      quoteExpiresAt: order.quoteExpiresAt,
      // Authoritative countdown. The UI must render this rather than its own
      // hardcoded duration, so the timer can never disagree with the server.
      secondsRemaining: Math.max(0, Math.ceil((new Date(order.quoteExpiresAt).getTime() - Date.now()) / 1000)),
      reference: order.referenceKey,
      referenceKey: order.referenceKey,
      blockhash: (await fetchSolanaBlockhash().catch(() => ({}))).blockhash || null,
      customerWallet: order.customerWallet,
      preflight: getPreflightResult(order.id) || null,
      paidAt: order.paidAt,
      items: order.items,
      payUrl,
      directSolanaUrl,
      solanaPayTxUrl,
      solanaPayTxUri,
      solanaPayUri,
      merchantName: order.merchant?.tradingName || MERCHANT.name,
      merchantAddress: receivingAddress,
      merchant: order.merchant,
      txHash: settledResult?.txHash || order.transaction?.txHash || null,
      transaction: (order.transaction || settledResult) ? {
        txHash: settledResult?.txHash || order.transaction?.txHash,
        senderAddress: settledResult?.recordedTx?.senderAddress || order.transaction?.senderAddress || order.customerWallet,
        blockchain: 'solana',
        confirmedAt: order.transaction?.confirmedAt || order.paidAt || new Date(),
        settlements: settledResult?.settlements || (order.transaction?.settlementTransactions ? order.transaction.settlementTransactions.map(s => ({
          bucket: s.bucket,
          basisPoints: s.basisPoints,
          amountAUD: s.amountAUD.toString(),
          tokenAmount: s.tokenAmount.toString(),
          destinationWallet: s.destinationWallet
        })) : [])
      } : null
    });
  } catch (err) {
    console.error('[Get Order Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/confirm & /submit - Confirms payment and triggers atomic revenue split
router.post(['/:id/confirm', '/:id/submit'], ipLimiter(20), async (req, res) => {
  try {
    const { txHash, senderAddress, payerAddress, currency, paidVia, demoMode, isDemo } = req.body;
    let effectiveTxHash = txHash || req.body.signature;

    // Enforce valid on-chain transaction hash for settlement.
    // Legacy demo only (DEMO_MODE=true and an explicit demo submit) may use a
    // fake hash; every other submit is verified on-chain.
    const demoSubmit = DEMO_MODE && Boolean(demoMode || isDemo);
    if (!effectiveTxHash) {
      if (demoSubmit) {
        effectiveTxHash = 'sol_test_' + Math.random().toString(36).substring(2, 14);
      } else {
        return res.status(400).json({
          error: 'MISSING_TRANSACTION_HASH',
          message: 'A valid on-chain transaction hash or wallet signature is required for settlement.'
        });
      }
    }

    const effectiveSender = payerAddress || senderAddress || 'Phantom Wallet';

    let targetOrderId = req.params.id;
    let existingOrder = await prisma.order.findUnique({ where: { id: targetOrderId } });

    // Legacy demo only: an unknown id borrows the open session on a counter.
    // Outside DEMO_MODE that could attach a payment to someone else's order.
    if (!existingOrder && DEMO_MODE) {
      const activeSession = terminalSessions.get('POS_001') || Array.from(terminalSessions.values())[0];
      if (activeSession && activeSession.orderId) {
        const found = await prisma.order.findUnique({ where: { id: activeSession.orderId } });
        if (found) {
          existingOrder = found;
          targetOrderId = found.id;
        }
      }
    }

    if (!existingOrder && demoSubmit) {
      const m = await prisma.merchant.findFirst();
      const mId = m ? m.id : 'demo-merchant';
      return res.json({
        success: true,
        orderId: targetOrderId,
        status: 'PAID',
        txHash: effectiveTxHash,
        amount: '10.10',
        token: currency || 'SOL',
        paidVia: paidVia || 'Phantom Wallet (SOL)',
        order: {
          id: targetOrderId,
          merchantId: mId,
          orderNumber: 'DY-009',
          status: 'PAID',
          sessionState: 'SETTLED',
          amountUSD: '10.10',
          totalAUD: '10.10',
          txHash: effectiveTxHash,
          paidAt: new Date(),
          paidCurrency: currency || 'SOL',
          paidVia: paidVia || 'Phantom Wallet (SOL)',
          splits: [
            { name: 'Tax Reserves (ATO)', pct: 10, settleMode: 'USDC', shareAUD: '1.01' },
            { name: 'Operating Expenses', pct: 20, settleMode: 'USDC', shareAUD: '2.02' },
            { name: "Owner's Pay", pct: 30, settleMode: 'SOL', shareAUD: '3.03' },
            { name: 'Net Profit', pct: 40, settleMode: 'SOL', shareAUD: '4.04' }
          ]
        }
      });
    }

    if (!existingOrder) return res.status(404).json({ error: 'ORDER_NOT_FOUND', message: 'Order not found.' });
    if (existingOrder.tapPayAmount != null) {
      // Website wallet paid a tap-and-pay order: the chain decides (src/tappay).
      if (!/^[1-9A-HJ-NP-Za-km-z]{64,90}$/.test(String(effectiveTxHash))) {
        return res.status(400).json({ error: 'INVALID_TRANSACTION_SIGNATURE', message: 'A real Solana transaction signature is required.' });
      }
      const r = await confirmWebSignature(existingOrder, effectiveTxHash);
      return res.status(r.status === 'CONFIRMED' ? 200 : 202).json({ success: r.status === 'CONFIRMED', status: r.status, orderId: existingOrder.id });
    }
    const receipt = await confirmSolanaPayment(targetOrderId, effectiveTxHash, effectiveSender, { allowDemoHash: demoSubmit });

    // Dynkle No-Device lifecycle: Once settled, session clears back to IDLE straight away.
    // Next customer to tap the tag gets IDLE/nothing to pay.
    try {
      const settledOrd = await prisma.order.findUnique({ where: { id: targetOrderId } });
      if (settledOrd) {
        terminalSessions.delete(settledOrd.terminalId);
        terminalSessions.delete(`${settledOrd.merchantId}:${settledOrd.terminalId}`);
      }
    } catch (e) {}

    // A stray payment (order was cancelled/expired before this landed) is real
    // money that needs cashier attention, not a normal happy-path receipt.
    if (receipt.strayPayment) {
      return sendFlow(res, 'STRAY_PAYMENT_RECEIVED', {
        orderId: receipt.orderId,
        orderNumber: receipt.orderNumber,
        txHash: receipt.txHash
      });
    }

    res.json({
      success: true,
      ...receipt,
      order: {
        id: req.params.id,
        status: 'PAID',
        sessionState: 'SETTLED',
        txHash: receipt.txHash || effectiveTxHash,
        paidAt: new Date(),
        paidCurrency: currency || 'SOL',
        paidVia: paidVia || 'Phantom Wallet (SOL)'
      }
    });
  } catch (err) {
    console.error('[Confirm Payment Error]:', err.message);

    const code = classifyError(err);

    // Raw chain/RPC text never reaches the customer — it goes to the log above
    // and into `detail` for the cashier's screen only.
    return sendFlow(res, code, {
      orderId: req.params.id,
      txHash: req.body?.txHash || req.body?.signature || null,
      originalTxHash: err.originalTxHash || null,
      duplicateTxHash: err.duplicateTxHash || null,
      internal: err.message
    });
  }
});

// GET /api/orders - List orders with pagination
router.get('/', async (req, res) => {
  try {
    const limit = Math.min(parseInt(req.query.limit || '100'), 100);
    const merchantId = req.headers['x-merchant-id'] || req.query?.merchantId;

    const where = {};
    if (merchantId) {
      where.merchantId = merchantId;
    } else {
      const active = await prisma.merchant.findFirst({ orderBy: { updatedAt: 'desc' } }) || await prisma.merchant.findFirst({ orderBy: { createdAt: 'asc' } });
      if (active) where.merchantId = active.id;
    }

    if (req.query.status) {
      where.status = req.query.status;
    } else if (req.query.settled === 'true') {
      where.status = { in: ['PAID', 'SETTLED', 'RECEIPT_READY', 'REFUNDED'] };
    }

    const orders = await prisma.order.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      take: limit,
      include: {
        transaction: {
          select: { txHash: true, confirmedAt: true }
        },
        // The attempt that paid (UI spec §C channel badge); never duplicates.
        paymentAttempts: {
          where: { status: 'CONFIRMED', failureCode: null },
          select: { channel: true, option: true },
          take: 1,
        },
      }
    });

    res.json({
      success: true,
      orders: orders.map(o => ({
        id: o.id,
        orderNumber: o.orderNumber,
        status: o.status,
        totalAUD: o.totalAUD.toString(),
        tokenSymbol: o.tokenSymbol,
        cryptoAmount: o.cryptoAmount.toString(),
        createdAt: o.createdAt,
        paidAt: o.paidAt,
        txHash: o.transaction?.txHash || null,
        customerWallet: o.customerWallet || o.transaction?.senderAddress || null,
        channel: o.paymentAttempts?.[0]?.channel || null,
        swapAndPay: o.paymentAttempts?.[0]?.option === 'SWAP',
      }))
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/claim - Claims active payment session when customer taps NFC or scans QR (ATOMIC LOCK)
router.post('/:id/claim', async (req, res) => {
  try {
    const now = new Date();
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: { merchant: true }
    });

    if (!order) {
      if (DEMO_MODE) { // demo ids only on the local demo (spec D12)
        return res.status(200).json({ success: true, status: 'CUSTOMER_DETECTED', sessionState: 'CLAIMED' });
      }
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Order not found.' });
    }

    if (['PAID', 'SETTLED', 'RECEIPT_READY'].includes(order.status)) {
      return res.status(200).json({ success: true, status: order.status, message: 'Order is already paid.' });
    }

    if (now > new Date(order.quoteExpiresAt)) {
      await prisma.order.update({
        where: { id: order.id },
        data: { status: 'EXPIRED' }
      });
      return res.status(400).json({ error: 'EXPIRED', message: 'Payment session has expired.' });
    }

    // Atomic check: Allow claiming if status is CREATED, QUOTED, DEVICE_ARMED, WAITING_FOR_CUSTOMER, or CUSTOMER_DETECTED
    const claimResult = await prisma.order.updateMany({
      where: {
        id: order.id,
        status: { in: ['CREATED', 'QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER', 'CUSTOMER_DETECTED'] },
        quoteExpiresAt: { gt: now }
      },
      data: { status: 'CUSTOMER_DETECTED' }
    });

    if (claimResult.count === 0) {
      if (['CONFIRMING', 'SUBMITTED'].includes(order.status)) {
        return res.status(409).json({
          error: 'SESSION_LOCKED',
          message: 'Payment is currently broadcasting and confirming on-chain.'
        });
      }
      return res.status(400).json({ error: 'INVALID_STATE', message: 'Cannot claim order in state: ' + order.status });
    }

    const updated = await prisma.order.findUnique({ where: { id: order.id } });

    if (order.terminalId) {
      terminalSessions.set(`${order.merchantId}:${order.terminalId}`, {
        orderId: order.id,
        state: 'CLAIMED',
        merchantId: order.merchantId,
        terminalId: order.terminalId,
        updatedAt: Date.now()
      });
      terminalSessions.set(order.terminalId, {
        orderId: order.id,
        state: 'CLAIMED',
        merchantId: order.merchantId,
        terminalId: order.terminalId,
        updatedAt: Date.now()
      });
    }

    res.json({
      success: true,
      orderId: updated.id,
      orderNumber: updated.orderNumber,
      status: updated.status,
      sessionState: 'CLAIMED',
      terminalId: order.terminalId
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/preflight - Checks the payer can actually fund this bill
// BEFORE handing off to their wallet, so shortfalls are explained on our screen.
// Avoids re-pushing the same alert to the register every time a customer's
// page retries the same preflight check for the same order.
const notifiedInsufficientOrders = new Set();

export async function pushInsufficientFundsAlert(order, { walletKey, result }) {
  if (notifiedInsufficientOrders.has(order.id)) return;
  notifiedInsufficientOrders.add(order.id);

  terminalGateway.notifyInsufficientFunds(order.terminalId, {
    orderId: order.id,
    walletKey: walletKey || null,
    symbol: result.symbol,
    have: result.have,
    need: result.need,
    shortfall: result.shortfall
  }).catch(e => console.warn('[Insufficient Funds Push Warning]:', e.message));

  // Reaches the CUSTOMER'S OWN phone — this matters most on the mobile
  // deep-link path, where by the time this fires they've already switched
  // out of our tab and into the wallet app, so an in-page message on our
  // page is invisible to them until they switch back on their own.
  sendInsufficientFundsPush(order.id, {
    symbol: result.symbol,
    have: result.have,
    need: result.need,
    walletKey
  }).catch(e => console.warn('[Customer Push Warning]:', e.message));

  // Backed by the same AuditLog the persistent /api/merchant/alerts banner
  // already polls every 20s, so the cashier still sees this even if the
  // register's WebSocket happened to be disconnected the instant it fired.
  await prisma.auditLog.create({
    data: {
      merchantId: order.merchantId,
      action: 'INSUFFICIENT_FUNDS_DETECTED',
      resource: 'ORDER',
      resourceId: order.id,
      metadata: {
        orderNumber: order.orderNumber,
        walletKey: walletKey || null,
        tokenSymbol: result.symbol,
        have: result.have,
        need: result.need,
        shortfall: result.shortfall,
        detectedAt: new Date().toISOString()
      }
    }
  }).catch(e => console.warn('[Insufficient Funds Audit Warning]:', e.message));
}

router.post('/:id/preflight', async (req, res) => {
  try {
    const { account, chain = 'solana', chainId, walletKey } = req.body || {};
    if (!account) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Missing payer account.' });
    }

    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) {
      if (DEMO_MODE) { // demo ids only on the local demo (spec D12)
        return res.json({ ok: true, code: 'OK' });
      }
      return sendFlow(res, 'ORDER_NOT_FOUND');
    }

    if (SETTLED_STATUSES.includes(order.status)) return sendFlow(res, 'ORDER_ALREADY_PAID');
    if (order.status === 'CANCELLED') return sendFlow(res, 'ORDER_CANCELLED');
    if (Date.now() > new Date(order.quoteExpiresAt).getTime()) return sendFlow(res, 'QUOTE_EXPIRED');

    const result = await preflight(order, account, { chain, chainId });
    // Populates the same `order.preflight` field the deep-link path
    // (solanaPay.js) already writes, so GET /api/orders/:id surfaces this
    // result regardless of which wallet-launch path the customer took —
    // and the cashier's own per-order poll can now show it too.
    recordPreflightResult(order.id, { wallet: account, walletKey, ...result });

    if (result.code === 'OK') {
      return res.json({ ok: true, code: 'OK', ...result });
    }
    if (result.code === 'INVALID_ACCOUNT') {
      return res.status(400).json({ error: 'INVALID_ACCOUNT', message: 'That wallet address is not valid for this network.' });
    }

    // The moment DYNKLE's own real balance check confirms this — not just
    // when the customer sees the popup — push it to the register.
    if (result.code === 'INSUFFICIENT_BALANCE' || result.code === 'INSUFFICIENT_GAS') {
      await pushInsufficientFundsAlert(order, { walletKey, result });
    }

    return sendFlow(res, result.code, result);
  } catch (err) {
    return sendFlow(res, 'RPC_DEGRADED', { reason: err.message });
  }
});

// POST /api/orders/:id/abandon - Customer backs out. Frees the counter immediately
// instead of leaving the bill locked until the quote expires.
router.post('/:id/abandon', async (req, res) => {
  try {
    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) return sendFlow(res, 'ORDER_NOT_FOUND');

    if (SETTLED_STATUSES.includes(order.status)) return sendFlow(res, 'ORDER_ALREADY_PAID');

    // Never release a bill whose funds may already be in flight — that would
    // re-arm the counter while a payment is still landing.
    if (IN_FLIGHT_STATUSES.includes(order.status)) {
      return sendFlow(res, 'TX_CONFIRMING', { orderId: order.id });
    }

    // Hand the bill back to the armed state so the next tap can claim it.
    await prisma.order.updateMany({
      where: { id: order.id, status: { in: ['CUSTOMER_DETECTED', 'AWAITING_APPROVAL'] } },
      data: { status: 'QUOTED' }
    });

    terminalSessions.delete(order.terminalId);
    terminalSessions.delete(`${order.merchantId}:${order.terminalId}`);

    return res.json(flowResponse('ABANDONED', { orderId: order.id, terminalId: order.terminalId }));
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/processing - Customer initiates signing in wallet
router.post('/:id/processing', async (req, res) => {
  try {
    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) return sendFlow(res, 'ORDER_NOT_FOUND');

    if (SETTLED_STATUSES.includes(order.status)) return sendFlow(res, 'ORDER_ALREADY_PAID');
    if (order.status === 'CANCELLED') return sendFlow(res, 'ORDER_CANCELLED');
    if (order.status === 'EXPIRED') return sendFlow(res, 'QUOTE_EXPIRED');

    // Idempotent: a retry from the same customer must not error.
    if (IN_FLIGHT_STATUSES.includes(order.status)) {
      return res.json({ success: true, orderId: order.id, status: order.status, sessionState: 'PROCESSING' });
    }

    if (Date.now() > new Date(order.quoteExpiresAt).getTime()) {
      await prisma.order.update({ where: { id: order.id }, data: { status: 'EXPIRED' } });
      return sendFlow(res, 'QUOTE_EXPIRED');
    }

    const updated = await prisma.order.update({
      where: { id: order.id },
      data: { status: 'CONFIRMING' }
    });

    res.json({ success: true, orderId: updated.id, status: updated.status, sessionState: 'PROCESSING' });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/currency-choice - Updates order currency when customer selects on phone (LIVE ORACLE)
router.post('/:id/currency-choice', async (req, res) => {
  try {
    const { tokenSymbol } = req.body;
    if (!tokenSymbol) return res.status(400).json({ error: 'Missing tokenSymbol' });

    const sym = tokenSymbol.toUpperCase();
    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) return res.status(404).json({ error: 'NOT_FOUND' });

    if (['PAID', 'SETTLED'].includes(order.status)) {
      return res.status(400).json({ error: 'ALREADY_PAID' });
    }

    // STRICT VALIDATION: Only allow currencies explicitly accepted by this merchant
    const isAccepted = await prisma.acceptedToken.findFirst({
      where: {
        merchantId: order.merchantId,
        tokenSymbol: sym,
        enabled: true
      }
    });

    if (!isAccepted) {
      const allowed = await prisma.acceptedToken.findMany({
        where: { merchantId: order.merchantId, enabled: true },
        select: { tokenSymbol: true }
      });
      return res.status(400).json({
        error: 'CURRENCY_NOT_ACCEPTED',
        message: `Currency ${sym} is not accepted by this merchant. Allowed currencies: ${allowed.map(a => a.tokenSymbol).join(', ')}`
      });
    }

    // Dynamic price from live oracle
    let price = 1.0;
    try {
      const oracle = await getLivePrice(sym);
      if (oracle && oracle.priceAUD) {
        price = oracle.priceAUD;
      }
    } catch (e) {
      price = sym === 'SOL' ? 228.45 : (sym === 'ETH' ? 4120.50 : (sym === 'BTC' ? 104500 : (sym === 'TRX' ? 0.35 : 1.0)));
    }

    const subtotalAUD = parseFloat(order.subtotalAUD);
    const feeAUD = calculateCustomerFee(sym, subtotalAUD);
    const totalAUD = parseFloat((subtotalAUD + feeAUD).toFixed(2));
    const cryptoDecimals = sym === 'BTC' ? 8 : (['SOL', 'ETH'].includes(sym) ? 6 : (sym === 'TRX' ? 4 : 2));
    const cryptoAmount = (totalAUD / price).toFixed(cryptoDecimals);

    const updated = await prisma.order.update({
      where: { id: order.id },
      data: {
        tokenSymbol: sym,
        cryptoAmount,
        customerFeeAUD: feeAUD,
        totalAUD,
        quotePrice: price
      }
    });

    res.json({ success: true, tokenSymbol: sym, cryptoAmount, totalAUD, customerFeeAUD: feeAUD, quotePrice: price });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/cancel - Cancels active order and disarms terminal (PROTECTED)
router.post('/:id/cancel', async (req, res) => {
  try {
    const callerMerchantId = req.headers['x-merchant-id'] || req.body?.merchantId || req.query?.merchantId;
    const order = await prisma.order.findUnique({ where: { id: req.params.id } });
    if (!order) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Order not found.' });
    }

    if (callerMerchantId && order.merchantId !== callerMerchantId) {
      return res.status(403).json({ error: 'FORBIDDEN', message: 'Unauthorized: Merchant mismatch.' });
    }

    if (order.status === 'PAID') {
      return res.status(400).json({ error: 'ALREADY_PAID', message: 'Cannot cancel an already paid order.' });
    }

    const updated = await prisma.order.update({
      where: { id: order.id },
      data: { status: 'CANCELLED' }
    });

    terminalSessions.delete(order.terminalId);
    terminalGateway.disarm(order.terminalId).catch(() => {});

    res.json({ success: true, message: 'Order cancelled.', orderId: updated.id, status: updated.status });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/orders/:id/refund - Processes merchant refund returned in identical cryptocurrency (ON-CHAIN & PROTECTED)
router.post('/:id/refund', async (req, res) => {
  try {
    const orderId = req.params.id;
    const callerMerchantId = req.headers['x-merchant-id'] || req.body?.merchantId || req.query?.merchantId;
    const { reason = 'Customer Return', notes = '' } = req.body || {};

    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        transaction: {
          include: {
            settlementTransactions: true
          }
        },
        merchant: true
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Order not found.' });
    }

    // Verify merchant authorization
    if (callerMerchantId && order.merchantId !== callerMerchantId) {
      return res.status(403).json({ error: 'FORBIDDEN', message: 'Unauthorized: Merchant mismatch.' });
    }

    if (order.status === 'REFUNDED') {
      return res.status(400).json({ error: 'ALREADY_REFUNDED', message: 'Order has already been refunded.' });
    }

    const isSettled = order.status === 'PAID' || order.status === 'SETTLED' || order.status === 'RECEIPT_READY';
    if (!isSettled) {
      return res.status(400).json({ error: 'INVALID_STATUS', message: 'Only paid or settled orders can be refunded.' });
    }

    // Determine refund destination (customer's original address)
    const customerAddress = order.customerWallet || 
                            order.transaction?.senderAddress || 
                            '9WzDXwBbmkg8ZTbNMqUxvQRAyrZzDsGYdLVL9zYtAWWM';

    // Execute real cryptocurrency refund on Solana blockchain.
    // executeSolanaRefund now throws rather than fabricating a fake txHash when
    // no signing key is configured or the broadcast fails — so reaching the
    // success path below means funds genuinely moved on-chain.
    let onChainRefund = null;
    let refundError = null;
    if (order.tokenSymbol === 'SOL' || order.tokenSymbol === 'USDC' || order.tokenSymbol === 'DYNK') {
      try {
        onChainRefund = await executeSolanaRefund(order, customerAddress, order.tokenSymbol, order.cryptoAmount);
      } catch (refErr) {
        console.error('[Refund Failed]:', refErr.message);
        refundError = refErr;
      }
    } else {
      refundError = new Error(`REFUND_UNSUPPORTED_TOKEN: No refund path implemented for ${order.tokenSymbol}.`);
    }

    if (!onChainRefund || !onChainRefund.onChain) {
      // Log the attempt so it's visible for manual follow-up, but do NOT mark
      // the order REFUNDED or tell the customer money moved when it didn't.
      await prisma.auditLog.create({
        data: {
          merchantId: order.merchantId,
          action: 'MERCHANT_REFUND_FAILED',
          resource: 'ORDER',
          resourceId: order.id,
          metadata: {
            orderNumber: order.orderNumber,
            attemptedAmountAUD: order.totalAUD.toString(),
            attemptedCurrency: order.tokenSymbol,
            customerWallet: customerAddress,
            reason: refundError?.code || refundError?.message || 'UNKNOWN',
            attemptedAt: new Date().toISOString()
          }
        }
      });

      return sendFlow(res, 'REFUND_FAILED', {
        orderId: order.id,
        reason: refundError?.code || 'REFUND_FAILED',
        message: refundError?.message
      });
    }

    const refundHash = onChainRefund.txHash;
    const refundedAt = new Date();

    // Atomic update: Order status -> REFUNDED, update transaction status
    const updated = await prisma.$transaction(async (tx) => {
      const ord = await tx.order.update({
        where: { id: order.id },
        data: {
          status: 'REFUNDED'
        }
      });

      if (order.transaction) {
        await tx.transaction.update({
          where: { id: order.transaction.id },
          data: {
            status: 'refunded'
          }
        });
      }

      // Record audit log
      await tx.auditLog.create({
        data: {
          merchantId: order.merchantId,
          action: 'MERCHANT_REFUND_PROCESSED',
          resource: 'ORDER',
          resourceId: order.id,
          metadata: {
            orderNumber: order.orderNumber,
            refundedAmountAUD: order.totalAUD.toString(),
            refundedCurrency: order.tokenSymbol,
            refundedCryptoAmount: order.cryptoAmount.toString(),
            customerWallet: customerAddress,
            reason,
            notes,
            refundTxHash: refundHash,
            originalTxHash: order.transaction?.txHash || null,
            refundedAt: refundedAt.toISOString(),
            onChain: onChainRefund?.onChain || false
          }
        }
      });

      return ord;
    });

    res.json({
      success: true,
      message: `Refund of ${order.cryptoAmount} ${order.tokenSymbol} processed successfully to customer wallet.`,
      orderId: updated.id,
      orderNumber: updated.orderNumber,
      status: 'REFUNDED',
      refundDetails: {
        refundTxHash: refundHash,
        refundedAmountAUD: order.totalAUD.toString(),
        refundedCurrency: order.tokenSymbol,
        refundedCryptoAmount: order.cryptoAmount.toString(),
        customerWallet: customerAddress,
        reason,
        refundedAt: refundedAt.toISOString(),
        currencyMatched: true,
        onChain: onChainRefund?.onChain || false
      }
    });

  } catch (err) {
    console.error('[Refund Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// GET /api/orders/:id/refund-receipt - Returns credit note / refund receipt metadata
router.get('/:id/refund-receipt', async (req, res) => {
  try {
    const order = await prisma.order.findUnique({
      where: { id: req.params.id },
      include: {
        merchant: true,
        transaction: true
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Order not found.' });
    }

    const log = await prisma.auditLog.findFirst({
      where: {
        resourceId: order.id,
        action: 'MERCHANT_REFUND_PROCESSED'
      },
      orderBy: { createdAt: 'desc' }
    });

    const meta = log?.metadata || {};
    res.json({
      creditNoteNumber: `CN-${order.orderNumber}`,
      originalOrderNumber: order.orderNumber,
      merchantName: order.merchant?.tradingName || order.merchant?.legalName || 'DYNKLE Merchant',
      merchantABN: order.merchant?.abn || '45 123 456 789',
      refundedAmountAUD: meta.refundedAmountAUD || order.totalAUD.toString(),
      refundedCurrency: meta.refundedCurrency || order.tokenSymbol,
      refundedCryptoAmount: meta.refundedCryptoAmount || order.cryptoAmount.toString(),
      customerWallet: meta.customerWallet || order.customerWallet,
      reason: meta.reason || 'Customer Return',
      refundTxHash: meta.refundTxHash || ('ref_' + order.orderNumber),
      originalTxHash: meta.originalTxHash || order.transaction?.txHash,
      refundedAt: meta.refundedAt || order.updatedAt,
      currencyMatched: true
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

export default router;
