import express from 'express';
import { DEMO_MODE } from '../config.js';
import { autoSwapKeeper } from '../services/autoSwapKeeperService.js';
import { audToUsdc } from '../services/priceService.js';

const router = express.Router();

/**
 * GET /api/auto-swap/policies
 * Returns active policies, live holdings, gas reserve warnings, and next scheduled check
 */
router.get('/policies', async (req, res) => {
  try {
    const data = await autoSwapKeeper.getPolicies();
    res.json({
      success: true,
      ...data
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/auto-swap/policy
 * One-time setup / update of a bucket's auto-swap policy.
 * Body: { bucketId, enabled, dustFloorAUD, maxSlippageBps, whitelistedRouter, signatureInfo }
 */
router.post('/policy', async (req, res) => {
  try {
    const { bucketId, enabled, dustFloorAUD, maxSlippageBps, whitelistedRouter, bucketName, chain, destinationAddress, signatureInfo } = req.body;
    if (!bucketId) {
      return res.status(400).json({ success: false, error: 'bucketId is required' });
    }

    const updated = await autoSwapKeeper.updatePolicy(
      bucketId,
      { enabled, dustFloorAUD, maxSlippageBps, whitelistedRouter, bucketName, chain, destinationAddress },
      signatureInfo
    );

    res.json({
      success: true,
      policy: updated,
      message: `Policy successfully saved for ${updated.bucketName}`
    });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/auto-swap/revoke
 * Bucket owner revokes auto-swap authorization immediately.
 * Body: { bucketId, signatureInfo }
 */
router.post('/revoke', async (req, res) => {
  try {
    const { bucketId, signatureInfo } = req.body;
    if (!bucketId) {
      return res.status(400).json({ success: false, error: 'bucketId is required' });
    }

    const revoked = await autoSwapKeeper.revokePolicy(bucketId, signatureInfo);
    res.json({
      success: true,
      policy: revoked,
      message: `Auto-swap revoked for ${revoked.bucketName}`
    });
  } catch (err) {
    res.status(400).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/auto-swap/trigger
 * Manual keeper trigger (for testing / on-demand settlement)
 */
router.post('/trigger', async (req, res) => {
  try {
    const result = await autoSwapKeeper.runKeeperCycle();
    res.json({
      success: true,
      result
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * POST /api/auto-swap/simulate-payment
 * Live simulation and settlement of customer multi-chain payment with 4-bucket split & netting
 */
router.post('/simulate-payment', async (req, res) => {
  // A simulation with invented hashes: the local demo only (spec D12).
  if (!DEMO_MODE) return res.status(404).json({ success: false, error: 'DEMO_ONLY' });
  try {
    const { amountAUD = 100, currency = 'ETH', buckets = [] } = req.body;
    
    // Spot prices in AUD
    const prices = {
      ETH: 3800.00,
      SOL: 218.00,
      BTC: 92000.00,
      DYNK: 0.15
    };
    
    const token = (currency || 'ETH').toUpperCase();
    const spotPrice = prices[token] || 3800.00;
    const totalCrypto = Number((amountAUD / spotPrice).toFixed(6));

    // Validate 100% invariant
    const totalPct = buckets.reduce((acc, b) => acc + Number(b.pct || 0), 0);
    if (Math.abs(totalPct - 100) > 0.01) {
      return res.status(400).json({ success: false, error: `Splits must total exactly 100% (currently ${totalPct}%)` });
    }

    const txHashPayment = token === 'ETH' 
      ? `0x7b1a${Date.now().toString(16)}${Math.random().toString(16).substring(2, 6)}`
      : `5SolPay${Date.now()}${Math.random().toString(36).substring(2, 6)}`;

    // Calculate split for each bucket
    const splitDetails = buckets.map(b => {
      const shareAUD = Number((amountAUD * (b.pct / 100)).toFixed(2));
      const shareCrypto = Number((totalCrypto * (b.pct / 100)).toFixed(6));
      // 'AUDC' was the stable target before USDC; older clients may still send it.
      const isAutoSwap = ['USDC', 'AUDC'].includes((b.target || '').toUpperCase());
      return {
        bucketId: b.id,
        bucketName: b.name,
        pct: b.pct,
        target: isAutoSwap ? 'USDC' : (b.target || token),
        shareAUD,
        shareCrypto,
        action: isAutoSwap ? 'AUTO_SWAP' : 'HOLD',
        settledAmount: isAutoSwap ? 0 : shareCrypto,
        settledUnit: isAutoSwap ? 'USDC' : token
      };
    });

    const holdBuckets = splitDetails.filter(b => b.action === 'HOLD');
    const swapBuckets = splitDetails.filter(b => b.action === 'AUTO_SWAP');

    let swapResult = null;

    if (swapBuckets.length > 0) {
      const nettedGrossAUD = Number(swapBuckets.reduce((sum, b) => sum + b.shareAUD, 0).toFixed(2));
      const nettedCrypto = Number(swapBuckets.reduce((sum, b) => sum + b.shareCrypto, 0).toFixed(6));
      const dexFeeAUD = Number((nettedGrossAUD * 0.005).toFixed(2)); // 0.5% DEX fee
      // Swap value is in AUD; USDC (1 USD) is converted at the live USDC/AUD price.
      const netReceivedAUD = Number((nettedGrossAUD - dexFeeAUD).toFixed(2));
      const usdcReceived = audToUsdc(netReceivedAUD);
      const txHashSwap = token === 'ETH'
        ? `0x9c4f${Date.now().toString(16)}${Math.random().toString(16).substring(2, 6)}`
        : `5SolSwap${Date.now()}${Math.random().toString(36).substring(2, 6)}`;

      // Pro-rata credit
      let runningUsdc = 0;
      swapBuckets.forEach((b, idx) => {
        if (idx === swapBuckets.length - 1) {
          b.settledAmount = Number((usdcReceived - runningUsdc).toFixed(2));
        } else {
          const share = Number(((b.shareAUD / nettedGrossAUD) * usdcReceived).toFixed(2));
          b.settledAmount = share;
          runningUsdc += share;
        }
      });

      swapResult = {
        inputToken: token,
        nettedGrossAUD,
        nettedCrypto,
        dustFloorAUD: 15.00,
        dustPassed: nettedGrossAUD >= 15.00,
        dexFeeAUD,
        netReceivedAUD,
        usdcReceived,
        whitelistedRouter: token === 'ETH' ? 'uniswap-v3-evm-vault' : 'jupiter-v6-solana-pda',
        routerName: token === 'ETH' ? 'Uniswap V3 Auto-Router' : 'Jupiter v6 Ultra-Router',
        oracleType: token === 'ETH' ? 'Chainlink EVM Data Feed' : 'Pyth Network Real-Time Oracle',
        slippageBps: 15,
        txHashSwap,
        contributingBuckets: swapBuckets.map(b => ({
          bucketId: b.bucketId,
          bucketName: b.bucketName,
          usdcCredited: b.settledAmount
        }))
      };

      // Record to keeper ledger
      await autoSwapKeeper.logLedgerEvent({
        action: 'NETTED_AUTO_SWAP_SETTLEMENT',
        status: 'CONFIRMED',
        inputToken: token,
        outputToken: 'USDC',
        chain: token === 'ETH' ? 'ethereum' : 'solana',
        nettedGrossAUD,
        nettedAmountIn: nettedCrypto,
        usdcReceived,
        netValueAUD: netReceivedAUD,
        feeAUD: dexFeeAUD,
        txHash: txHashSwap,
        router: swapResult.routerName,
        message: `Multi-bucket swap confirmed: Swapped ${nettedCrypto} ${token} ($${nettedGrossAUD} AUD) → ${usdcReceived} USDC via ${swapResult.routerName}`,
        settlements: swapBuckets.map(b => ({
          bucketId: b.bucketId,
          bucketName: b.bucketName,
          usdcCredited: b.settledAmount
        }))
      });
    }

    res.json({
      success: true,
      timestamp: new Date().toISOString(),
      order: {
        amountAUD,
        currency: token,
        totalCrypto,
        spotPrice,
        txHashPayment,
        referenceKey: `REF_${Date.now().toString(36).toUpperCase()}`
      },
      splitDetails,
      holdSummary: {
        bucketCount: holdBuckets.length,
        totalAUD: Number(holdBuckets.reduce((sum, b) => sum + b.shareAUD, 0).toFixed(2)),
        buckets: holdBuckets
      },
      swapSummary: swapResult
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/auto-swap/ledger
 * Returns execution ledger entries with optional filtering by bucketId, status, or token
 */
router.get('/ledger', (req, res) => {
  try {
    const { bucketId, status, token, limit } = req.query;
    let entries = autoSwapKeeper.ledger;

    if (bucketId) {
      entries = entries.filter(e => e.bucketId === bucketId || (e.settlements && e.settlements.some(s => s.bucketId === bucketId)));
    }
    if (status) {
      entries = entries.filter(e => e.status === status);
    }
    if (token) {
      entries = entries.filter(e => e.inputToken === token);
    }

    const max = parseInt(limit, 10) || 50;
    res.json({
      success: true,
      total: entries.length,
      entries: entries.slice(0, max)
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/auto-swap/ledger/export
 * Downloads the execution ledger as a CSV file
 */
router.get('/ledger/export', (req, res) => {
  try {
    const csv = autoSwapKeeper.exportLedgerCsv();
    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename="dynkle_auto_swap_ledger_${Date.now()}.csv"`);
    res.send(csv);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

/**
 * GET /api/auto-swap/notifications
 * In-app notifications feed
 */
router.get('/notifications', (req, res) => {
  try {
    res.json({
      success: true,
      notifications: autoSwapKeeper.notifications
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

export default router;
