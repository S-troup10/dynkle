import express from 'express';
import { PublicKey } from '@solana/web3.js';
import prisma from '../db.js';
import { buildSolanaTransaction } from '../services/solana.js';
import { preflightSolana, recordPreflightResult } from '../services/preflight.js';
import { pushInsufficientFundsAlert } from './orders.js';
import { MERCHANT } from '../config.js';
import { buildForWebWallet } from '../tappay/service.js';
import { ipLimiter } from '../middleware/rateLimit.js';

const router = express.Router();

router.use((req, res, next) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', '*');
  res.setHeader('ngrok-skip-browser-warning', 'true');
  if (req.method === 'OPTIONS') return res.sendStatus(200);
  // No customer wallet or balances in logs (spec 02 §11-§12).
  console.log(`[Solana Pay Request]: ${req.method} ${req.path}`);
  next();
});

// GET /api/solana-pay/:orderId or /order/:orderId
async function handleGetOrderMetadata(req, res) {
  try {
    const orderId = req.params.orderId;
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: {
        merchant: {
          include: { profile: true }
        }
      }
    });

    if (!order) {
      return res.status(404).json({ error: 'ORDER_NOT_FOUND', message: 'Order not found' });
    }

    const merchantName = order.merchant?.tradingName || MERCHANT.name;
    const logoUrl = order.merchant?.profile?.logoUrl || 'https://raw.githubusercontent.com/solana-labs/token-list/main/assets/mainnet/So11111111111111111111111111111111111111112/logo.png';

    res.json({
      label: merchantName,
      icon: logoUrl
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
}

// POST /api/solana-pay/:orderId or /order/:orderId
async function handleBuildTransaction(req, res) {
  try {
    const orderId = req.params.orderId;
    const order = await prisma.order.findUnique({
      where: { id: orderId },
      include: { merchant: true }
    });

    if (!order) {
      return res.status(404).json({ error: 'ORDER_NOT_FOUND', message: 'Order not found' });
    }

    // Strict rate lock check (ORDER_TTL_SECONDS): reject expired quotes
    const now = Date.now();
    const expiresAt = order.quoteExpiresAt ? new Date(order.quoteExpiresAt).getTime() : 0;
    if (expiresAt && now > expiresAt) {
      if (order.status !== 'PAID' && order.status !== 'SETTLED') {
        await prisma.order.update({
          where: { id: order.id },
          data: { status: 'EXPIRED' }
        });
      }
      return res.status(410).json({
        error: 'QUOTE_EXPIRED',
        message: 'This payment has expired. Ask the merchant for a new bill.'
      });
    }

    if (order.status === 'EXPIRED') {
      return res.status(410).json({
        error: 'QUOTE_EXPIRED',
        message: 'This payment has expired. Ask the merchant for a new bill.'
      });
    }

    if (order.status === 'PAID' || order.status === 'SETTLED') {
      return res.status(409).json({ error: 'ALREADY_PAID', message: 'Order has already been settled.' });
    }

    if (order.tapPayAmount != null) {
      try {
        return res.json(await buildForWebWallet({ orderId: order.id, account: req.body?.account }));
      } catch (e) {
        return res.status(e.status || 500).json({ error: e.code || 'BUILD_TRANSACTION_FAILED', message: e.message });
      }
    }

    const { account } = req.body;
    if (!account) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Missing payer account public key in request body.' });
    }

    try {
      new PublicKey(account);
    } catch {
      return res.status(400).json({ error: 'INVALID_PUBKEY', message: 'Payer account is not a valid Solana public key.' });
    }

    // Proactive balance check: Record preflight and customer wallet
    let isInsufficient = false;
    let balanceNote = '';
    try {
      const pre = await preflightSolana(order, account);
      recordPreflightResult(order.id, { wallet: account, ...pre });

      if (pre.code === 'INSUFFICIENT_BALANCE' || pre.code === 'INSUFFICIENT_GAS') {
        isInsufficient = true;
        const symbol = pre.symbol || order.tokenSymbol || 'SOL';
        const have = Number(pre.have || 0).toFixed(4);
        const need = Number(pre.need || order.cryptoAmount).toFixed(4);
        balanceNote = `(Low Balance: ${have} of ${need} ${symbol})`;

        console.log(`[Solana Pay Preflight]: insufficient funds for order ${order.id} (${pre.code})`);

        // Persist customer wallet on order
        await prisma.order.update({
          where: { id: order.id },
          data: { customerWallet: account, status: 'CUSTOMER_DETECTED' }
        }).catch(() => {});

        // This is the moment DYNKLE's own real balance check confirms it —
        // for the mobile deep-link flow, this fires before Phantom has even
        // shown the customer anything. Push it to the register now rather
        // than waiting for the customer to say something.
        pushInsufficientFundsAlert(order, { walletKey: 'phantom', result: pre }).catch(() => {});

        // NOTE: We do NOT return HTTP 400 here!
        // When a Solana Pay endpoint returns 400, Phantom displays:
        // "We could not load this transaction request. The QR code may be expired, invalid, or the server is unavailable."
        // Returning HTTP 200 with the serialized transaction allows Phantom to load the transaction sheet
        // and show its clean native warning ("Insufficient SOL balance" / "Insufficient funds") directly on screen!
      }
    } catch (preErr) {
      console.warn('[Solana Pay Preflight Warning]:', preErr.message);
      // RPC error / degraded: do not block, allow transaction build to proceed
    }

    // Build atomic transaction with on-chain split instructions
    const transaction = await buildSolanaTransaction(order, account);
    const serialized = transaction.serialize({
      requireAllSignatures: false,
      verifySignatures: false
    });

    // Mark order as CONFIRMING (or keep CUSTOMER_DETECTED if insufficient) and persist customer wallet
    await prisma.order.update({
      where: { id: order.id },
      data: {
        customerWallet: account,
        status: isInsufficient ? 'CUSTOMER_DETECTED' : 'CONFIRMING'
      }
    }).catch(() => {});
    console.log(`[Solana Pay]: handed transaction for order ${order.id} (${isInsufficient ? 'low balance' : 'confirming'})`);

    const merchantName = order.merchant?.tradingName || MERCHANT.name;
    const msg = isInsufficient
      ? `Pay $${order.totalAUD} AUD (${order.cryptoAmount} ${order.tokenSymbol}) to ${merchantName} ${balanceNote}`
      : `Pay $${order.totalAUD} AUD (${order.cryptoAmount} ${order.tokenSymbol}) to ${merchantName}`;

    res.json({
      transaction: serialized.toString('base64'),
      message: msg
    });
  } catch (err) {
    console.error('[Solana Pay Build Error]:', err);
    res.status(500).json({ error: 'BUILD_TRANSACTION_FAILED', message: err.message });
  }
}

const metadataLimit = ipLimiter(120);
const buildLimit = ipLimiter(30);
router.get('/:orderId', metadataLimit, handleGetOrderMetadata);
router.get('/order/:orderId', metadataLimit, handleGetOrderMetadata);

router.post('/:orderId', buildLimit, handleBuildTransaction);
router.post('/order/:orderId', buildLimit, handleBuildTransaction);

export default router;
