// Table payments: floor plans, tables, tags, table bills.
//
// Portal (merchant dashboard, same trust model as /api/merchant):
//   GET    /api/merchant/floor                      venue: plans, zones, tables
//   POST   /api/merchant/floor/plans                {name, zones?}
//   PATCH  /api/merchant/floor/plans/:id            {name?, zones?:[{id?,name}]}
//   DELETE /api/merchant/floor/plans/:id
//   PATCH  /api/merchant/floor/settings             {autoClearMinutes: 1-240 | null, serviceMode: 'TABLES'|'COUNTER'|null}
//   POST   /api/merchant/floor/tables/:id/assign    {to: deviceId | 'merchant' | null}  hand a table to a waiter's POS
//   POST   /api/merchant/floor/tables/:id/charge-counter {terminalId}  collect the table's bill on a counter POS
//   POST   /api/merchant/floor/groups              {tableIds:[...], name?}  connect tables: one bill (on the first), first tag tapped holds it
//   DELETE /api/merchant/floor/groups/:id          disconnect (id = any table in the group)
//   POST   /api/merchant/floor/groups/:id/release  let another tag in the group pay
//   POST   /api/merchant/floor/tables/bulk          {floorPlanId, zoneId?, count, seats?, shape?, columns?, prefix?, x?, y?}
//   PATCH  /api/merchant/floor/tables/layout        {updates:[{id, x?, y?, w?, h?}]}  (align / distribute)
//   POST   /api/merchant/floor/tables               {floorPlanId, zoneId?, name?, seats?, shape?, x,y,w,h}
//   PATCH  /api/merchant/floor/tables/:id           layout fields, floorPlanId, zoneId
//   DELETE /api/merchant/floor/tables/:id           refused while the table has an open bill
//   POST   /api/merchant/floor/tables/:id/tag       {tagCode?} assign / reassign / replace
//   DELETE /api/merchant/floor/tables/:id/tag
//   + the bill actions below
//
// Bill actions (portal under /api/merchant/floor, terminal under /api/terminals/me/floor):
//   POST   /tables/:id/lock | DELETE /tables/:id/lock    edit lease (60 s, renew while open)
//   PUT    /tables/:id/items      {items:[{productId, variants?, qty}], version?}
//   POST   /tables/:id/send       send bill to tag
//   POST   /tables/:id/cancel-send
//   POST   /tables/:id/clear
//   POST   /tables/:id/move       {toTableId}
//   POST   /tables/:id/join       {intoTableId}
//   POST   /api/terminals/me/floor/tables/:id/charge {terminalEphemeralPub, bleSessionId}  "Generate bill → Pay here" (terminal only)
// Ownership: the POS that opens a table owns it; other POS devices get 403 TABLE_OWNED
// on changes (they can still view). The portal (merchant) can change every table.
//
// Customer (public):
//   GET    /tb/:tagCode                  what a tag URL opens without the DYNK app
//   GET    /api/pay/tables/:tagCode      state + (when READY) order id and signed intent

import { Router } from 'express';
import { requireDevice } from '../devices/deviceAuth.js';
import { getActiveMerchant } from './merchant.js';
import { ipLimiter } from '../middleware/rateLimit.js';
import * as tables from '../tables/service.js';

const wrap = (fn) => async (req, res) => {
  try {
    res.json(await fn(req, res));
  } catch (e) {
    if (e instanceof tables.TableError) {
      const { status, code, message, ...extra } = e;
      delete extra.stack;
      return res.status(status).json({ error: code, message, ...extra });
    }
    console.error('[tables] route error:', e.message);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Something went wrong. Try again.' });
  }
};

async function merchantIdOf(req) {
  const m = await getActiveMerchant(req);
  if (!m) throw new tables.TableError(404, 'MERCHANT_NOT_FOUND', 'Set up the business first.');
  return m.id;
}

// The merchant (portal) can change any table; tables it opens are owned by "merchant".
const portalActor = (req) => {
  const client = String(req.headers['x-dynkle-client'] || '').replace(/[^A-Za-z0-9_-]/g, '').slice(0, 40);
  return {
    kind: 'portal',
    key: `portal:${client || req.ip}`,
    label: String(req.headers['x-dynkle-client-label'] || 'Merchant portal').slice(0, 40),
    ownerKey: 'merchant',
    ownerLabel: 'Merchant',
  };
};
// A waiter's POS: owns the tables it opens; other waiters' tables are read-only to it.
const deviceActor = (req) => {
  const label = (req.device.label || `POS ${req.device.terminalId || ''}`).trim().slice(0, 40);
  return { kind: 'device', key: `device:${req.device.id}`, label, ownerKey: `device:${req.device.id}`, ownerLabel: label, device: req.device };
};

/** The bill actions, mounted once for the portal and once for terminals. */
function billRoutes(router, merchantOf, actorOf, auth = []) {
  // Connected tables share one bill: an action on any of them goes to the group's first table.
  const act = (fn) => wrap(async (req) => {
    const merchantId = await merchantOf(req);
    return fn(merchantId, await tables.billTableId(merchantId, req.params.id), actorOf(req), req.body || {});
  });
  router.post('/tables/:id/lock', ...auth, act(tables.lockTable));
  router.delete('/tables/:id/lock', ...auth, act(tables.unlockTable));
  router.put('/tables/:id/items', ...auth, act(tables.setItems));
  router.post('/tables/:id/send', ...auth, act(tables.sendBill));
  router.post('/tables/:id/cancel-send', ...auth, act(tables.cancelSend));
  router.post('/tables/:id/clear', ...auth, act(tables.clearTable));
  router.post('/tables/:id/move', ...auth, act(tables.moveTable));
  router.post('/tables/:id/join', ...auth, act(tables.joinTables));
}

// ── Portal ─────────────────────────────────────────────────────────────

export const portalFloorRouter = Router();
portalFloorRouter.get('/', wrap(async (req) => tables.getFloor(await merchantIdOf(req), portalActor(req))));
portalFloorRouter.post('/plans', wrap(async (req) => tables.createPlan(await merchantIdOf(req), req.body || {})));
portalFloorRouter.patch('/plans/:id', wrap(async (req) => tables.updatePlan(await merchantIdOf(req), req.params.id, req.body || {})));
portalFloorRouter.delete('/plans/:id', wrap(async (req) => tables.deletePlan(await merchantIdOf(req), req.params.id)));
portalFloorRouter.patch('/settings', wrap(async (req) => tables.updateSettings(await merchantIdOf(req), req.body || {})));
portalFloorRouter.post('/tables/bulk', wrap(async (req) => tables.createTablesBulk(await merchantIdOf(req), req.body || {})));
portalFloorRouter.patch('/tables/layout', wrap(async (req) => tables.updateLayoutBatch(await merchantIdOf(req), req.body || {})));
portalFloorRouter.post('/tables', wrap(async (req) => tables.createTable(await merchantIdOf(req), req.body || {})));
portalFloorRouter.patch('/tables/:id', wrap(async (req) => tables.updateTable(await merchantIdOf(req), req.params.id, req.body || {})));
portalFloorRouter.delete('/tables/:id', wrap(async (req) => tables.deleteTable(await merchantIdOf(req), req.params.id)));
portalFloorRouter.post('/tables/:id/tag', wrap(async (req) => tables.assignTag(await merchantIdOf(req), req.params.id, req.body || {})));
portalFloorRouter.delete('/tables/:id/tag', wrap(async (req) => tables.removeTag(await merchantIdOf(req), req.params.id)));
billRoutes(portalFloorRouter, merchantIdOf, portalActor);
portalFloorRouter.post('/tables/:id/assign', wrap(async (req) => { const m = await merchantIdOf(req); return tables.assignOwner(m, await tables.billTableId(m, req.params.id), req.body || {}); }));
portalFloorRouter.post('/groups', wrap(async (req) => tables.connectTables(await merchantIdOf(req), req.body || {})));
portalFloorRouter.delete('/groups/:id', wrap(async (req) => tables.disconnectTables(await merchantIdOf(req), req.params.id)));
portalFloorRouter.post('/groups/:id/release', wrap(async (req) => tables.releaseGroupClaim(await merchantIdOf(req), req.params.id)));
portalFloorRouter.post('/tables/:id/charge-counter', wrap(async (req) => { const m = await merchantIdOf(req); return tables.chargeOnCounter(m, await tables.billTableId(m, req.params.id), portalActor(req), req.body || {}); }));

// ── Terminal (read-only layout, bill actions) ───────────────────────────

export const deviceFloorRouter = Router();
deviceFloorRouter.get('/', requireDevice, wrap(async (req) => tables.getFloor(req.device.merchantId, deviceActor(req))));
billRoutes(deviceFloorRouter, async (req) => req.device.merchantId, deviceActor, [requireDevice]);
deviceFloorRouter.post('/tables/:id/charge', requireDevice, wrap(async (req) => tables.chargeOnTerminal(req.device.merchantId, await tables.billTableId(req.device.merchantId, req.params.id), deviceActor(req), req.body || {})));

// ── Customer ──────────────────────────────────────────────────────────

export const publicTableRouter = Router();
const tagLimiter = ipLimiter(60);

publicTableRouter.get('/api/pay/tables/:code', tagLimiter, wrap(async (req) => tables.resolveTag(req.params.code)));

// Without the DYNK app the tag URL opens in the browser: a sent bill goes to the
// web checkout; anything else shows the view-only table page.
publicTableRouter.get('/tb/:code', tagLimiter, async (req, res) => {
  try {
    const r = await tables.resolveTag(req.params.code);
    if (r.state === 'READY') {
      return res.redirect(302, `/pay.html?orderId=${encodeURIComponent(r.order.id)}&via=nfc`);
    }
    res.redirect(302, `/table.html?tag=${encodeURIComponent(String(req.params.code).toLowerCase())}`);
  } catch (e) {
    console.error('[tables] tag open:', e.message);
    res.redirect(302, `/table.html?tag=${encodeURIComponent(String(req.params.code).toLowerCase())}`);
  }
});
