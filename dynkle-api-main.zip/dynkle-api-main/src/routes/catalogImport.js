// Catalogue import (Products → Import):
//   GET  /api/merchant/catalog-import/config    which import paths are available
//   POST /api/merchant/catalog-import/extract   multipart "files": menu photos / PDFs → rows to review
//   POST /api/merchant/catalog-import/commit    {rows:[{name, price, category, gst, icon?, sku?, description?}], source?}
//   GET  /api/merchant/catalog-import/last      the import that can still be undone (or null)
//   POST /api/merchant/catalog-import/:id/undo  undo it (most recent import, within 24 h)
// Nothing is saved until commit, which the portal sends only after the merchant
// has reviewed the rows.

import { Router } from 'express';
import multer from 'multer';
import { getActiveMerchant } from './merchant.js';
import { ipLimiter } from '../middleware/rateLimit.js';
import { extractMenu, extractionConfig, sniffType, ExtractError, ACCEPTED_TYPES, MAX_FILES, MAX_FILE_BYTES, UNCERTAIN_BELOW } from '../catalog/extract.js';
import { commitImport, lastImport, undoImport, MAX_IMPORT_ROWS } from '../catalog/importService.js';

const router = Router();

const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: MAX_FILE_BYTES, files: MAX_FILES },
});

function fail(res, status, code, message) {
  return res.status(status).json({ error: code, message });
}

router.get('/config', (req, res) => {
  const cfg = extractionConfig();
  res.json({
    imageImport: cfg.available,
    demo: cfg.primary === 'demo',
    provider: cfg.primary,
    acceptedTypes: ACCEPTED_TYPES,
    maxFiles: MAX_FILES,
    maxFileMb: MAX_FILE_BYTES / 1024 / 1024,
    maxRows: MAX_IMPORT_ROWS,
    uncertainBelow: UNCERTAIN_BELOW,
  });
});

router.post('/extract', ipLimiter(10), (req, res) => {
  upload.array('files', MAX_FILES)(req, res, async (err) => {
    if (err) {
      if (err.code === 'LIMIT_FILE_SIZE') return fail(res, 413, 'FILE_TOO_LARGE', `Each file can be up to ${MAX_FILE_BYTES / 1024 / 1024} MB.`);
      if (err.code === 'LIMIT_FILE_COUNT' || err.code === 'LIMIT_UNEXPECTED_FILE') return fail(res, 400, 'TOO_MANY_FILES', `Upload up to ${MAX_FILES} files at once.`);
      return fail(res, 400, 'UPLOAD_FAILED', 'The upload did not go through. Try again.');
    }
    try {
      const merchant = await getActiveMerchant(req);
      if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'Set up the business first.');
      const files = (req.files || []).map((f) => ({ buffer: f.buffer, type: sniffType(f.buffer), name: f.originalname }));
      if (!files.length) return fail(res, 400, 'NO_FILES', 'Choose a photo or PDF of your menu.');
      const bad = files.find((f) => !f.type);
      if (bad) return fail(res, 415, 'UNSUPPORTED_FILE', `${bad.name} is not a JPEG, PNG, WebP or PDF file.`);
      const result = await extractMenu(files);
      res.json({
        rows: result.rows,
        notes: result.notes,
        provider: result.provider,
        model: result.model,
        demo: !!result.demo,
        escalated: result.escalated,
        uncertain: result.uncertain,
      });
    } catch (e) {
      if (e instanceof ExtractError) return fail(res, e.status, e.code, e.message);
      console.error('[catalog] extract:', e.message);
      fail(res, 500, 'INTERNAL_ERROR', 'Something went wrong reading the menu. Try again.');
    }
  });
});

router.post('/commit', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'Set up the business first.');
    res.json({ success: true, ...(await commitImport(merchant.id, req.body?.rows, { source: req.body?.source })) });
  } catch (e) {
    if (e.status && e.code) return fail(res, e.status, e.code, e.message);
    console.error('[catalog] commit:', e.message);
    fail(res, 500, 'IMPORT_FAILED', 'The products could not be saved. Try again.');
  }
});

router.get('/last', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    res.json({ last: merchant ? await lastImport(merchant.id) : null });
  } catch (e) {
    console.error('[catalog] last:', e.message);
    fail(res, 500, 'INTERNAL_ERROR', 'Something went wrong. Try again.');
  }
});

router.post('/:id/undo', async (req, res) => {
  try {
    const merchant = await getActiveMerchant(req);
    if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'Set up the business first.');
    res.json({ success: true, ...(await undoImport(merchant.id, String(req.params.id))) });
  } catch (e) {
    if (e.status && e.code) return fail(res, e.status, e.code, e.message);
    console.error('[catalog] undo:', e.message);
    fail(res, 500, 'UNDO_FAILED', 'The import could not be undone. Try again.');
  }
});

export default router;
