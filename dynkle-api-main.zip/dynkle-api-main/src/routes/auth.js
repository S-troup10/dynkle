import { Router } from 'express';
import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import crypto from 'crypto';
import prisma from '../db.js';
import { JWT_SECRET, JWT_REFRESH_SECRET, DEMO_MODE } from '../config.js';
import { requireAuth } from '../middleware/auth.js';
import { generateOtp, verifyOtp, canSendOtp } from '../services/otpService.js';

const router = Router();

function hashToken(token) {
  return crypto.createHash('sha256').update(token).digest('hex');
}

function generateTokens(userId) {
  const accessToken = jwt.sign(
    { sub: userId },
    JWT_SECRET,
    { expiresIn: '15m' }
  );

  const refreshToken = jwt.sign(
    { sub: userId, jti: crypto.randomUUID() },
    JWT_REFRESH_SECRET,
    { expiresIn: '7d' }
  );

  return { accessToken, refreshToken };
}

// POST /api/auth/register
router.post('/register', async (req, res) => {
  try {
    const {
      email,
      password,
      legalName,
      tradingName,
      businessType = 'company',
      abn,
      phone,
      solanaAddress = '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH'
    } = req.body;

    if (!email || !password) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Email and password are required.' });
    }

    if (password.length < 8) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Password must be at least 8 characters long.' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const existingUser = await prisma.user.findUnique({ where: { email: normalizedEmail } });
    if (existingUser) {
      return res.status(409).json({ error: 'EMAIL_EXISTS', message: 'An account with this email already exists.' });
    }

    const salt = await bcrypt.genSalt(10);
    const passwordHash = await bcrypt.hash(password, salt);

    const result = await prisma.$transaction(async (tx) => {
      // 1. Create User
      // emailVerified/status used to be set true/ACTIVE unconditionally here
      // ("auto-verified on explicit registration") — meaning no OTP was ever
      // actually required to get a fully working account: register alone
      // handed back real, usable access+refresh tokens. The send-otp/
      // verify-otp round trip that runs afterward only flips a flag on an
      // account that already exists and already works either way, so it
      // verified nothing. PENDING/unverified is the honest starting state;
      // /onboarding/go-live below now refuses to go live until it's real.
      const user = await tx.user.create({
        data: {
          email: normalizedEmail,
          passwordHash,
          phone: phone || null,
          emailVerified: false,
          status: 'PENDING'
        }
      });

      // 2. Create Merchant
      const merchant = await tx.merchant.create({
        data: {
          legalName: legalName || tradingName || 'DYNKLE Merchant Ltd',
          tradingName: tradingName || legalName || 'DYNKLE Store',
          businessType,
          abn: abn ? abn.replace(/\s+/g, '') : null,
          status: 'setup',
          onboardingStep: 1,
          kybStatus: 'DRAFT',
          kitPaid: false
        }
      });

      // 3. Link Owner
      await tx.merchantUser.create({
        data: {
          merchantId: merchant.id,
          userId: user.id,
          role: 'OWNER'
        }
      });

      // 4. Create Business Profile
      await tx.businessProfile.create({
        data: {
          merchantId: merchant.id,
          brandingColor: '#FF7A29',
          operatingHours: { monday: '07:00-17:00', tuesday: '07:00-17:00', wednesday: '07:00-17:00', thursday: '07:00-17:00', friday: '07:00-17:00' }
        }
      });

      // 5. Create Wallets
      const taxWallet = await tx.wallet.create({
        data: { merchantId: merchant.id, label: 'Tax Reserves (ATO)', blockchain: 'solana', address: solanaAddress }
      });
      const opexWallet = await tx.wallet.create({
        data: { merchantId: merchant.id, label: 'Operating Expenses', blockchain: 'solana', address: solanaAddress }
      });
      const ownerWallet = await tx.wallet.create({
        data: { merchantId: merchant.id, label: 'Owner Drawings', blockchain: 'solana', address: solanaAddress }
      });
      const profitWallet = await tx.wallet.create({
        data: { merchantId: merchant.id, label: 'Retained Profit', blockchain: 'solana', address: solanaAddress }
      });

      // 6. Create Revenue Split Rules (sum = 10,000 bps = 100%)
      await tx.revenueSplitRule.createMany({
        data: [
          { merchantId: merchant.id, bucket: 'TAX', basisPoints: 1500, destinationWalletId: taxWallet.id },
          { merchantId: merchant.id, bucket: 'EXPENSES', basisPoints: 2000, destinationWalletId: opexWallet.id },
          { merchantId: merchant.id, bucket: 'OWNER_PAY', basisPoints: 2000, destinationWalletId: ownerWallet.id },
          { merchantId: merchant.id, bucket: 'PROFIT', basisPoints: 4500, destinationWalletId: profitWallet.id },
        ]
      });

      // 7. Create Default Accepted Tokens
      await tx.acceptedToken.createMany({
        data: [
          { merchantId: merchant.id, tokenSymbol: 'SOL', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.0100 },
          { merchantId: merchant.id, tokenSymbol: 'DYNK', blockchain: 'solana', enabled: true, customerFeeType: 'flat', customerFeeValue: 0.0100 },
          { merchantId: merchant.id, tokenSymbol: 'USDC', blockchain: 'solana', enabled: true, customerFeeType: 'percentage', customerFeeValue: 0.0050 },
        ]
      });

      // 8. Create Default Products
      // New businesses start with an empty catalogue: Dynkle serves any kind of shop.

      return { user, merchant };
    });

    const { accessToken, refreshToken } = generateTokens(result.user.id);
    const refreshExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await prisma.refreshToken.create({
      data: {
        userId: result.user.id,
        tokenHash: hashToken(refreshToken),
        expiresAt: refreshExpiresAt
      }
    });

    res.status(201).json({
      success: true,
      accessToken,
      refreshToken,
      user: {
        id: result.user.id,
        email: result.user.email,
        status: result.user.status
      },
      merchant: {
        id: result.merchant.id,
        legalName: result.merchant.legalName,
        tradingName: result.merchant.tradingName,
        status: result.merchant.status,
        onboardingStep: result.merchant.onboardingStep
      }
    });
  } catch (err) {
    // Two concurrent registrations with the same email can both pass the
    // findUnique check above before either has committed, then race into
    // the transaction — the loser hits this unique constraint. Without this
    // check it fell into a raw 500 leaking Prisma's constraint error text.
    if (err.code === 'P2002') {
      return res.status(409).json({ error: 'EMAIL_EXISTS', message: 'An account with this email already exists.' });
    }
    console.error('[Auth Register Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Registration failed. Please try again.' });
  }
});

// POST /api/auth/login
router.post('/login', async (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Email and password are required.' });
    }

    const normalizedEmail = email.trim().toLowerCase();
    const user = await prisma.user.findUnique({
      where: { email: normalizedEmail },
      include: {
        merchants: {
          include: {
            merchant: true
          }
        }
      }
    });

    if (!user) {
      return res.status(401).json({ error: 'INVALID_CREDENTIALS', message: 'Invalid email or password.' });
    }

    const passwordMatch = await bcrypt.compare(password, user.passwordHash);
    if (!passwordMatch) {
      return res.status(401).json({ error: 'INVALID_CREDENTIALS', message: 'Invalid email or password.' });
    }

    const { accessToken, refreshToken } = generateTokens(user.id);
    const refreshExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await prisma.refreshToken.create({
      data: {
        userId: user.id,
        tokenHash: hashToken(refreshToken),
        expiresAt: refreshExpiresAt
      }
    });

    const primaryMerchant = user.merchants[0]?.merchant || null;
    const role = user.merchants[0]?.role || 'CASHIER';

    res.json({
      success: true,
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        email: user.email,
        status: user.status
      },
      merchant: primaryMerchant ? {
        id: primaryMerchant.id,
        legalName: primaryMerchant.legalName,
        tradingName: primaryMerchant.tradingName,
        status: primaryMerchant.status,
        onboardingStep: primaryMerchant.onboardingStep,
        role
      } : null
    });
  } catch (err) {
    console.error('[Auth Login Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/auth/refresh
router.post('/refresh', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (!refreshToken) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Refresh token is required.' });
    }

    let payload;
    try {
      payload = jwt.verify(refreshToken, JWT_REFRESH_SECRET);
    } catch {
      return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Refresh token is invalid or expired.' });
    }

    const hashed = hashToken(refreshToken);
    const storedToken = await prisma.refreshToken.findUnique({
      where: { tokenHash: hashed }
    });

    if (!storedToken) {
      return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Refresh token is invalid.' });
    }

    // A token that exists AND is already revoked means this exact token was
    // already used once to rotate — this is a replay, not just an expired
    // session. It could be the legitimate device retrying, but it could also
    // mean this token leaked and an attacker is racing the real owner. There
    // is no way to tell which from here, so the safe response is to kill
    // every refresh token for this user (not just report an error and let
    // the stolen-and-reused token's session chain continue undisturbed).
    if (storedToken.revoked) {
      await prisma.refreshToken.updateMany({
        where: { userId: payload.sub, revoked: false },
        data: { revoked: true }
      });
      return res.status(401).json({
        error: 'TOKEN_REUSE_DETECTED',
        message: 'This refresh token was already used. All sessions for this account have been signed out as a precaution — please log in again.'
      });
    }

    if (new Date() > storedToken.expiresAt) {
      return res.status(401).json({ error: 'TOKEN_EXPIRED', message: 'Refresh token has expired.' });
    }

    // Revoke current refresh token (Token rotation)
    await prisma.refreshToken.update({
      where: { id: storedToken.id },
      data: { revoked: true }
    });

    // Issue new token pair
    const tokens = generateTokens(payload.sub);
    const refreshExpiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);

    await prisma.refreshToken.create({
      data: {
        userId: payload.sub,
        tokenHash: hashToken(tokens.refreshToken),
        expiresAt: refreshExpiresAt
      }
    });

    res.json({
      success: true,
      accessToken: tokens.accessToken,
      refreshToken: tokens.refreshToken
    });
  } catch (err) {
    console.error('[Auth Refresh Error]:', err);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/auth/logout
router.post('/logout', async (req, res) => {
  try {
    const { refreshToken } = req.body;
    if (refreshToken) {
      const hashed = hashToken(refreshToken);
      await prisma.refreshToken.updateMany({
        where: { tokenHash: hashed },
        data: { revoked: true }
      });
    }
    res.json({ success: true, message: 'Logged out successfully.' });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// GET /api/auth/me
router.get('/me', requireAuth, async (req, res) => {
  try {
    const user = await prisma.user.findUnique({
      where: { id: req.user.id },
      include: {
        merchants: {
          include: {
            merchant: {
              include: {
                profile: true
              }
            }
          }
        }
      }
    });

    res.json({
      success: true,
      user: {
        id: user.id,
        email: user.email,
        phone: user.phone,
        status: user.status,
        emailVerified: user.emailVerified,
        phoneVerified: user.phoneVerified,
        merchants: user.merchants.map(m => ({
          merchantId: m.merchant.id,
          legalName: m.merchant.legalName,
          tradingName: m.merchant.tradingName,
          status: m.merchant.status,
          role: m.role,
          brandingColor: m.merchant.profile?.brandingColor || '#FF7A29'
        }))
      }
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/auth/send-otp
router.post('/send-otp', async (req, res) => {
  try {
    const { identifier } = req.body;
    if (!identifier) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Identifier (email or phone) is required.' });
    }

    const throttle = canSendOtp(identifier);
    if (!throttle.allowed) {
      return res.status(429).json({
        error: 'OTP_RATE_LIMITED',
        message: `Please wait ${throttle.retryAfterSeconds}s before requesting another code.`,
        retryAfterSeconds: throttle.retryAfterSeconds
      });
    }

    const code = generateOtp(identifier);
    // A code that is echoed in the response is not a secret anymore — the
    // entire point of the OTP step is defeated the moment that happens.
    // This must go to a real SMS/email gateway in production.
    // TODO(production): wire `code` to the actual SMS/email provider here.
    if (process.env.OTP_DEV_LOG === 'true') {
      // Explicit opt-in only, off by default, console only — for local
      // testing when no real gateway is configured. Never in the HTTP response.
      console.log(`[OTP Gateway — DEV LOGGING ENABLED] ${identifier}: ${code}`);
    }

    // DEV BYPASS: return code directly in response so testers don't need a real gateway
    if (DEMO_MODE) {
      return res.json({
        success: true,
        message: `[DEV MODE] Verification code for ${identifier}: ${code}`,
        devCode: code   // shown in response — remove in production
      });
    }

    res.json({
      success: true,
      message: `Verification code sent to ${identifier}.`
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});


// POST /api/auth/verify-otp
router.post('/verify-otp', async (req, res) => {
  try {
    const { identifier, code } = req.body;
    if (!identifier || !code) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'Identifier and code are required.' });
    }

    const verification = verifyOtp(identifier, code);
    if (!verification.valid) {
      return res.status(400).json({ error: 'INVALID_OTP', message: verification.reason, remainingAttempts: verification.remainingAttempts });
    }

    // If user exists, mark verified
    const user = await prisma.user.findFirst({
      where: {
        OR: [
          { email: identifier.trim().toLowerCase() },
          { phone: identifier.trim() }
        ]
      }
    });

    if (user) {
      const isEmail = identifier.includes('@');
      await prisma.user.update({
        where: { id: user.id },
        data: {
          ...(isEmail ? { emailVerified: true } : { phoneVerified: true }),
          // This is the actual activation point now that register() no
          // longer marks the account verified/active on its own.
          ...(user.status === 'PENDING' ? { status: 'ACTIVE' } : {})
        }
      });
    }

    res.json({ success: true, verified: true });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

export default router;
