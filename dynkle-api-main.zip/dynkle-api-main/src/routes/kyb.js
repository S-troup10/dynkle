import { Router } from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import prisma from '../db.js';
import { requireAuth, requireMerchant, requireRole } from '../middleware/auth.js';
import { validateABN } from '../services/kybService.js';

const router = Router();

// Ensure upload directory exists
const uploadDir = path.resolve('uploads/kyb');
if (!fs.existsSync(uploadDir)) {
  fs.mkdirSync(uploadDir, { recursive: true });
}

// Multer storage setup
const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadDir),
  filename: (req, file, cb) => {
    const ext = path.extname(file.originalname);
    const uniqueName = `${req.merchant ? req.merchant.id : 'unknown'}-${Date.now()}-${Math.round(Math.random() * 1E9)}${ext}`;
    cb(null, uniqueName);
  }
});

const fileFilter = (req, file, cb) => {
  const allowed = ['application/pdf', 'image/png', 'image/jpeg', 'image/jpg'];
  if (allowed.includes(file.mimetype)) {
    cb(null, true);
  } else {
    cb(new Error('INVALID_FILE_TYPE: Only PDF, PNG, and JPEG documents are accepted.'));
  }
};

const upload = multer({
  storage,
  fileFilter,
  limits: { fileSize: 10 * 1024 * 1024 } // 10MB limit
});

// GET /api/kyb/abn/:abn - Public or authenticated ABN verification
router.get('/abn/:abn', (req, res) => {
  const result = validateABN(req.params.abn);
  if (!result.valid) {
    return res.status(400).json(result);
  }
  res.json(result);
});

// POST /api/kyb/documents - Upload verification document
router.post('/documents', requireAuth, requireMerchant, requireRole('OWNER', 'ADMIN'), upload.single('document'), async (req, res) => {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'FILE_REQUIRED', message: 'Document file is required.' });
    }

    const { docType } = req.body;
    const validDocTypes = ['REGISTRATION_CERT', 'DIRECTOR_ID', 'PROOF_OF_ADDRESS', 'BANK_STATEMENT'];
    if (!docType || !validDocTypes.includes(docType)) {
      // Remove uploaded file on validation error
      fs.unlinkSync(req.file.path);
      return res.status(400).json({
        error: 'INVALID_DOC_TYPE',
        message: `docType must be one of: ${validDocTypes.join(', ')}`
      });
    }

    const document = await prisma.kybDocument.create({
      data: {
        merchantId: req.merchant.id,
        docType,
        storageKey: req.file.path,
        filename: req.file.originalname,
        mimeType: req.file.mimetype,
        fileSize: req.file.size,
        status: 'uploaded'
      }
    });

    res.status(201).json({
      success: true,
      document: {
        id: document.id,
        docType: document.docType,
        filename: document.filename,
        fileSize: document.fileSize,
        mimeType: document.mimeType,
        uploadedAt: document.uploadedAt
      }
    });
  } catch (err) {
    console.error('[KYB Upload Error]:', err);
    res.status(500).json({ error: 'UPLOAD_FAILED', message: err.message });
  }
});

// GET /api/kyb/documents/:id/download - Authenticated, ownership-checked file
// download. KYB documents (registration certs, director ID, bank statements)
// were previously served by a blanket unauthenticated `express.static` mount
// on `/uploads`. Filenames follow a guessable `{merchantId}-{timestamp}-
// {random}.{ext}` pattern, so anyone who ever saw a URL (server logs,
// referrer headers, a shared screen) could download another merchant's
// compliance documents with zero auth. This checks the caller's own merchant
// actually owns the document before streaming anything.
router.get('/documents/:id/download', requireAuth, requireMerchant, async (req, res) => {
  try {
    const doc = await prisma.kybDocument.findUnique({ where: { id: req.params.id } });
    if (!doc || doc.merchantId !== req.merchant.id) {
      return res.status(404).json({ error: 'NOT_FOUND', message: 'Document not found.' });
    }
    if (!fs.existsSync(doc.storageKey)) {
      return res.status(404).json({ error: 'FILE_MISSING', message: 'Document file is no longer available.' });
    }
    res.download(doc.storageKey, doc.filename);
  } catch (err) {
    res.status(500).json({ error: 'DOWNLOAD_FAILED', message: err.message });
  }
});

// GET /api/kyb/documents - List merchant's uploaded documents
router.get('/documents', requireAuth, requireMerchant, async (req, res) => {
  try {
    const docs = await prisma.kybDocument.findMany({
      where: { merchantId: req.merchant.id },
      select: {
        id: true,
        docType: true,
        filename: true,
        fileSize: true,
        mimeType: true,
        status: true,
        uploadedAt: true
      },
      orderBy: { uploadedAt: 'desc' }
    });

    res.json({ success: true, documents: docs });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/kyb/submit - Submit KYB application for review
router.post('/submit', requireAuth, requireMerchant, requireRole('OWNER', 'ADMIN'), async (req, res) => {
  try {
    const { abn, legalName } = req.body;

    // Without this guard, submitting again after already being APPROVED (or
    // while a review is already PENDING) silently reverted kybStatus back to
    // PENDING and created a duplicate KybVerification row — an approved
    // merchant could accidentally un-approve themselves by re-submitting.
    if (req.merchant.kybStatus === 'APPROVED') {
      return res.status(409).json({ error: 'ALREADY_APPROVED', message: 'This business is already verified.' });
    }
    if (req.merchant.kybStatus === 'PENDING') {
      return res.status(409).json({ error: 'REVIEW_ALREADY_PENDING', message: 'A verification is already pending review.' });
    }

    // Check that merchant has required documents uploaded
    const docs = await prisma.kybDocument.findMany({
      where: { merchantId: req.merchant.id }
    });

    if (docs.length === 0) {
      return res.status(400).json({
        error: 'DOCUMENTS_REQUIRED',
        message: 'Please upload at least one verification document (e.g. Business Registration Certificate) before submitting.'
      });
    }

    let cleanedAbn = req.merchant.abn;
    if (abn) {
      const abnCheck = validateABN(abn);
      if (!abnCheck.valid) {
        return res.status(400).json({ error: 'INVALID_ABN', message: abnCheck.error });
      }
      cleanedAbn = abnCheck.clean;
    }

    const verification = await prisma.kybVerification.create({
      data: {
        merchantId: req.merchant.id,
        verificationProvider: 'internal_abr',
        status: 'PENDING',
        metadata: {
          submittedByUserId: req.user.id,
          docCount: docs.length,
          abn: cleanedAbn
        }
      }
    });

    await prisma.merchant.update({
      where: { id: req.merchant.id },
      data: {
        kybStatus: 'PENDING',
        abn: cleanedAbn || req.merchant.abn,
        legalName: legalName || req.merchant.legalName
      }
    });

    res.json({
      success: true,
      message: 'KYB verification submitted successfully and is pending review.',
      verificationId: verification.id,
      kybStatus: 'PENDING'
    });
  } catch (err) {
    res.status(500).json({ error: 'SUBMIT_FAILED', message: err.message });
  }
});

// GET /api/kyb/status - Get current KYB status
router.get('/status', requireAuth, requireMerchant, async (req, res) => {
  try {
    const merchant = await prisma.merchant.findUnique({
      where: { id: req.merchant.id },
      select: {
        id: true,
        legalName: true,
        abn: true,
        kybStatus: true,
        kybVerifications: {
          orderBy: { submittedAt: 'desc' },
          take: 1
        }
      }
    });

    const latest = merchant.kybVerifications[0] || null;

    res.json({
      success: true,
      kybStatus: merchant.kybStatus,
      abn: merchant.abn,
      latestVerification: latest ? {
        id: latest.id,
        status: latest.status,
        submittedAt: latest.submittedAt,
        reviewedAt: latest.reviewedAt,
        rejectionReason: latest.rejectionReason
      } : null
    });
  } catch (err) {
    res.status(500).json({ error: 'INTERNAL_ERROR', message: err.message });
  }
});

// POST /api/kyb/review - Compliance review endpoint (Approves or rejects KYB)
//
// This previously used `requireMerchant` + `requireRole('OWNER','ADMIN')`,
// which resolves to the CALLER'S OWN merchant — meaning any merchant's own
// owner/admin could call this and approve their own business verification.
// There is no separate compliance-staff role anywhere in this codebase, so
// the only honest fix without inventing a full staff-role system is to gate
// this behind a platform-level secret that a merchant's own credentials
// cannot satisfy, and to require the target merchant explicitly rather than
// resolving it from the caller's own session.
router.post('/review', requireAuth, async (req, res) => {
  try {
    const adminKey = process.env.KYB_REVIEWER_API_KEY;
    if (!adminKey) {
      return res.status(503).json({
        error: 'REVIEW_NOT_CONFIGURED',
        message: 'KYB review is not available — no compliance reviewer key is configured on this server.'
      });
    }
    if (req.headers['x-admin-key'] !== adminKey) {
      return res.status(403).json({ error: 'FORBIDDEN', message: 'This action requires platform compliance-reviewer credentials.' });
    }

    const { merchantId, status, rejectionReason } = req.body;
    if (!merchantId) {
      return res.status(400).json({ error: 'VALIDATION_ERROR', message: 'merchantId is required.' });
    }
    if (!['APPROVED', 'REJECTED', 'REQUIRES_INFORMATION'].includes(status)) {
      return res.status(400).json({ error: 'INVALID_STATUS', message: 'Status must be APPROVED, REJECTED, or REQUIRES_INFORMATION' });
    }

    const verification = await prisma.kybVerification.findFirst({
      where: { merchantId },
      orderBy: { submittedAt: 'desc' }
    });

    if (verification) {
      await prisma.kybVerification.update({
        where: { id: verification.id },
        data: {
          status,
          reviewedAt: new Date(),
          rejectionReason: status === 'REJECTED' ? (rejectionReason || 'Documents did not meet compliance requirements.') : null
        }
      });
    }

    await prisma.merchant.update({
      where: { id: merchantId },
      data: { kybStatus: status }
    });

    await prisma.auditLog.create({
      data: {
        merchantId,
        action: 'KYB_REVIEWED',
        resource: 'KYB_VERIFICATION',
        resourceId: verification?.id || null,
        metadata: { status, rejectionReason: rejectionReason || null }
      }
    });

    res.json({
      success: true,
      kybStatus: status,
      reviewedAt: new Date(),
      rejectionReason: status === 'REJECTED' ? rejectionReason : null
    });
  } catch (err) {
    res.status(500).json({ error: 'REVIEW_FAILED', message: err.message });
  }
});

export default router;
