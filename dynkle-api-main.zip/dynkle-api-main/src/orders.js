import { v4 as uuidv4 } from 'uuid';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { ORDER_TTL_SECONDS } from './config.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = path.join(__dirname, '..', 'orders_store.json');

const orders = new Map();

// Load persisted orders on startup
try {
  if (fs.existsSync(DATA_FILE)) {
    const raw = fs.readFileSync(DATA_FILE, 'utf8');
    const arr = JSON.parse(raw);
    arr.forEach(o => orders.set(o.id, o));
    console.log(`[Orders Store] Restored ${orders.size} persisted orders.`);
  }
} catch (e) {
  console.warn('[Orders Store] Warning loading persisted orders:', e.message);
}

function persistOrders() {
  try {
    const arr = Array.from(orders.values()).slice(0, 100);
    fs.writeFileSync(DATA_FILE, JSON.stringify(arr, null, 2));
  } catch (e) {}
}

export function createOrder(data) {
  const id = uuidv4();
  const now = Date.now();
  const order = {
    id,
    status: 'pending',
    createdAt: now,
    expiresAt: now + ORDER_TTL_SECONDS * 1000,
    txHash: null,
    payerAddress: null,
    ...data
  };
  orders.set(id, order);
  persistOrders();
  return order;
}

export function getOrder(id) {
  const order = orders.get(id);
  if (order && order.status === 'pending' && Date.now() > order.expiresAt) {
    order.status = 'expired';
  }
  return order || null;
}

export function updateOrder(id, patch) {
  const order = orders.get(id);
  if (!order) return null;
  Object.assign(order, patch);
  persistOrders();
  return order;
}

export function listOrders() {
  return Array.from(orders.values()).sort((a, b) => b.createdAt - a.createdAt);
}
