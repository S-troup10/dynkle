import WebSocket from 'ws';
const WebSocketServer = WebSocket.Server;
import prisma from '../db.js';
import { deviceHub } from '../devices/deviceHub.js';

class TerminalGateway {
  constructor() {
    this.wss = null;
    // Map of terminalId -> WebSocket connection
    this.connections = new Map();
    // Map of terminalId -> active order details
    this.activeOrders = new Map();
    // Map of terminalId -> last critical message (PAYMENT_SUCCESS/PAYMENT_ERROR)
    // sent while the socket may have been down. sendMessage() firing "true"
    // only means a TCP write happened, not that the physical terminal read
    // it — a drop between signing and this message meant the register never
    // learned a sale succeeded. Replayed once on the next (re)connection and
    // cleared by an explicit ACK or by the next ARM.
    this.pendingCritical = new Map();
  }

  /**
   * Initializes the WebSocket server attached to the existing HTTP server.
   * @param {import('http').Server} httpServer 
   */
  initialize(httpServer) {
    this.wss = new WebSocketServer({
      server: httpServer,
      path: '/ws/terminal'
    });

    this.wss.on('connection', (ws, req) => {
      this.handleConnection(ws, req);
    });

    // Start periodic heartbeat checker every 15 seconds
    setInterval(() => this.checkHeartbeats(), 15000);

    console.log('[Terminal Gateway] WebSocket server mounted on /ws/terminal');
  }

  async handleConnection(ws, req) {
    const url = new URL(req.url, 'http://localhost');
    const terminalId = url.searchParams.get('terminalId');
    const token = url.searchParams.get('token');

    // Counter devices page listening for live device events.
    if (url.searchParams.get('role') === 'dashboard') {
      deviceHub.attachDashboard(ws, url.searchParams.get('merchantId'));
      return;
    }
    // Paired Dynkle terminal app (protocol v2): device JWT, no terminalId.
    if (!terminalId && token) {
      await deviceHub.attachDevice(ws, req, token);
      return;
    }

    if (!terminalId) {
      ws.close(4001, 'Missing terminalId query parameter');
      return;
    }

    try {
      // Find terminal in database
      const terminal = await prisma.terminal.findUnique({
        where: { terminalId }
      });

      if (!terminal) {
        ws.close(4004, 'Terminal not found in registry');
        return;
      }

      // Check pairing token if un-paired or pairing
      if (terminal.status === 'PAIRING' && token) {
        if (terminal.pairingToken !== token) {
          ws.close(4003, 'Invalid pairing token');
          return;
        }
        // Promote to READY
        await prisma.terminal.update({
          where: { terminalId },
          data: {
            status: 'READY',
            pairedAt: new Date(),
            lastSeenAt: new Date(),
            pairingToken: null
          }
        });
      } else {
        // pairingToken is cleared to null once pairing completes, so it can't
        // serve as an ongoing secret. Without checking anything else here,
        // any client that merely knows/guesses a terminalId ('POS_001' etc.)
        // could open a socket claiming to BE that terminal — no pairing
        // token, no serial number, nothing — and receive every ARM message
        // (live order amounts) meant for the real device. The serial number
        // is persistent (survives pairing) and not returned by any public,
        // unauthenticated route, so require it here as a standing credential.
        if (terminal.status !== 'PAIRING' && terminal.serialNumber && token !== terminal.serialNumber) {
          ws.close(4003, 'Missing or invalid terminal credential');
          return;
        }
        await prisma.terminal.update({
          where: { terminalId },
          data: {
            status: 'READY',
            lastSeenAt: new Date()
          }
        });
      }

      ws.terminalId = terminalId;
      ws.isAlive = true;
      this.connections.set(terminalId, ws);

      console.log(`[Terminal Gateway] Terminal ${terminalId} connected and authenticated.`);

      // Send initial STATUS message
      this.sendMessage(terminalId, {
        type: 'DEVICE_READY',
        terminalId,
        timestamp: Date.now(),
        firmware: terminal.firmwareVersion
      });

      // Replay any success/error event this terminal may have missed while
      // disconnected, so a dropped socket never silently loses "you got paid."
      const pending = this.pendingCritical.get(terminalId);
      if (pending) {
        this.sendMessage(terminalId, { ...pending, replay: true });
      }

      ws.on('pong', () => {
        ws.isAlive = true;
      });

      ws.on('message', async (data) => {
        try {
          const message = JSON.parse(data.toString());
          await this.handleDeviceMessage(terminalId, message);
        } catch (err) {
          console.error(`[Terminal Gateway] Error parsing message from ${terminalId}:`, err);
        }
      });

      ws.on('close', async () => {
        // If a second connection for this terminalId has already replaced
        // this one in the map (stale reconnect race, or the impersonation
        // this function now blocks above), deleting unconditionally here
        // would drop the NEW, live connection out of `connections` the
        // moment the OLD, already-dead one finishes closing — silently
        // making isOnline() report false and heartbeats stop tracking a
        // socket that is still open.
        if (this.connections.get(terminalId) !== ws) return;
        this.connections.delete(terminalId);
        try {
          await prisma.terminal.update({
            where: { terminalId },
            data: { status: 'OFFLINE', lastSeenAt: new Date() }
          });
        } catch (e) {
          // ignore cleanup error
        }
        console.log(`[Terminal Gateway] Terminal ${terminalId} disconnected.`);
      });

    } catch (err) {
      console.error(`[Terminal Gateway] Auth failed for ${terminalId}:`, err);
      ws.close(4500, 'Internal Gateway Error');
    }
  }

  async handleDeviceMessage(terminalId, message) {
    const { type, payload } = message;
    switch (type) {
      case 'HEARTBEAT':
        await prisma.terminal.update({
          where: { terminalId },
          data: { lastSeenAt: new Date() }
        });
        this.sendMessage(terminalId, { type: 'HEARTBEAT_ACK', timestamp: Date.now() });
        break;

      case 'CUSTOMER_TAP_DETECTED':
        console.log(`[Terminal Gateway] Customer tapped on ${terminalId}`);
        // Can trigger order state progression: CUSTOMER_DETECTED
        break;

      case 'HARDWARE_STATUS':
        console.log(`[Terminal Gateway] Hardware report from ${terminalId}:`, payload);
        break;

      case 'ACK':
        // Device confirms it displayed the critical event; stop replaying it.
        this.pendingCritical.delete(terminalId);
        break;

      default:
        console.log(`[Terminal Gateway] Unknown message type ${type} from ${terminalId}`);
    }
  }

  checkHeartbeats() {
    deviceHub.heartbeat();
    for (const [terminalId, ws] of this.connections.entries()) {
      if (!ws.isAlive) {
        console.log(`[Terminal Gateway] Heartbeat lost for ${terminalId}, terminating connection.`);
        ws.terminate();
        this.connections.delete(terminalId);
        prisma.terminal.update({
          where: { terminalId },
          data: { status: 'OFFLINE', lastSeenAt: new Date() }
        }).catch(() => {});
        continue;
      }
      ws.isAlive = false;
      ws.ping();
    }
  }

  sendMessage(terminalId, message) {
    const ws = this.connections.get(terminalId);
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(message));
      return true;
    }
    return false;
  }

  /**
   * Arms the screenless countertop device for payment.
   * Actuates LED pulsing and starts the rate lock indicator (ORDER_TTL_SECONDS).
   */
  async arm(terminalId, { orderId, amountAUD, cryptoAmount, tokenSymbol, quoteExpiresAt }) {
    this.activeOrders.set(terminalId, { orderId, amountAUD, cryptoAmount, tokenSymbol, quoteExpiresAt });
    // A new sale starting means any stale success/error replay from a prior
    // order is no longer relevant to what's on screen now.
    this.pendingCritical.delete(terminalId);

    try {
      await prisma.terminal.update({
        where: { terminalId },
        data: { status: 'ARMED' }
      });
    } catch (e) {
      // Virtual/demo terminal or not yet seeded
    }

    const deviceArmed = await deviceHub.onArm(terminalId, orderId).catch(() => false);

    const legacyArmed = this.sendMessage(terminalId, {
      type: 'ARM',
      orderId,
      amountAUD,
      cryptoAmount,
      tokenSymbol,
      quoteExpiresAt,
      ttlSeconds: Math.max(0, Math.round((new Date(quoteExpiresAt).getTime() - Date.now()) / 1000)),
      ledMode: 'PULSE_BLUE',
      chime: 'ARM'
    });
    return legacyArmed || deviceArmed;
  }

  /**
   * Disarms the device and returns to ready state.
   */
  async disarm(terminalId) {
    this.activeOrders.delete(terminalId);
    try {
      await prisma.terminal.update({
        where: { terminalId },
        data: { status: 'READY' }
      });
    } catch (e) {
      // Virtual/demo terminal
    }

    await deviceHub.onDisarm(terminalId).catch(() => {});

    return this.sendMessage(terminalId, {
      type: 'DISARM',
      ledMode: 'SOLID_GREEN_IDLE',
      chime: 'NONE'
    });
  }

  /**
   * Triggers hardware payment success event: plays chime and illuminates solid green.
   */
  async setSuccess(terminalId, { orderId, txHash, tokenSymbol, amount, receipt = null }) {
    this.activeOrders.delete(terminalId);
    try {
      await prisma.terminal.update({
        where: { terminalId },
        data: { status: 'READY' }
      });
    } catch (e) {
      // Virtual/demo terminal
    }

    const message = {
      type: 'PAYMENT_SUCCESS',
      orderId,
      txHash,
      tokenSymbol,
      amount,
      ledMode: 'SOLID_GREEN_SUCCESS',
      chime: 'SUCCESS'
    };
    // Hold this until the device ACKs it or a new sale is armed — a socket
    // write returning true only means it left this process, not that the
    // physical register displayed it.
    this.pendingCritical.set(terminalId, message);
    await deviceHub.onSuccess(terminalId, { orderId, tokenSymbol, txHash, receipt }).catch(() => {});
    return this.sendMessage(terminalId, message);
  }

  /**
   * Triggers hardware error buzzer and red LED.
   */
  async setError(terminalId, { orderId, error }) {
    try {
      await prisma.terminal.update({
        where: { terminalId },
        data: { status: 'ERROR' }
      });
    } catch (e) {
      // Virtual/demo terminal
    }

    const message = {
      type: 'PAYMENT_ERROR',
      orderId,
      error,
      ledMode: 'PULSE_RED_ERROR',
      chime: 'ERROR'
    };
    this.pendingCritical.set(terminalId, message);
    await deviceHub.onError(terminalId, { orderId }).catch(() => {});
    return this.sendMessage(terminalId, message);
  }

  /**
   * Pushed the instant DYNKLE's own preflight check confirms a customer's
   * chosen wallet can't cover the bill — before they ever see a wallet's own
   * confirm screen. Uses the same reliable-delivery queue as
   * setSuccess/setError so a register that's briefly disconnected still
   * gets it on reconnect, rather than the cashier only learning about it
   * because the customer tells them.
   */
  async notifyInsufficientFunds(terminalId, { orderId, walletKey, symbol, have, need, shortfall }) {
    const message = {
      type: 'INSUFFICIENT_FUNDS',
      orderId,
      walletKey,
      symbol,
      have,
      need,
      shortfall,
      ledMode: 'PULSE_AMBER',
      chime: 'ALERT'
    };
    this.pendingCritical.set(terminalId, message);
    return this.sendMessage(terminalId, message);
  }

  isOnline(terminalId) {
    const ws = this.connections.get(terminalId);
    return !!(ws && ws.readyState === WebSocket.OPEN) || deviceHub.isCounterOnline(terminalId);
  }
}

export const terminalGateway = new TerminalGateway();
export default terminalGateway;
