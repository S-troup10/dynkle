// Tap-and-pay service: create payment -> intent -> precheck + build (QR) or
// tap prepare (tap) -> submit -> confirm -> verify on-chain -> PAID -> receipt.
// Spec v6: the backend builds every transaction, in parallel with the balance
// check; the phone checks it and partially signs.
//
// Rules that hold everywhere in this file:
//  - The server decides every amount (integer base units) once, at creation.
//  - PAID is set only after the backend itself saw the transaction confirmed
//    AND verified amount, mint, recipient, reference and signer on-chain.
//  - One attempt per order may be submitted (Order.paymentLock, atomic).
//  - What the customer signed is exactly what is sent (stored message bytes).
//  - Balances are never logged and never returned in clear to the terminal.

import crypto from 'crypto';
import { Connection, Keypair, PublicKey, VersionedTransaction } from '@solana/web3.js';
import { getAccount, getAssociatedTokenAddressSync, TOKEN_PROGRAM_ID, TokenAccountNotFoundError, TokenInvalidAccountOwnerError } from '@solana/spl-token';
import prisma from '../db.js';
import { SOLANA_CLUSTER_URL, ORDER_TTL_SECONDS } from '../config.js';
import { terminalGateway } from '../gateway/terminalGateway.js';
import { recordCryptoReceipt } from '../services/pnlService.js';
import { customerBaseUrl } from '../services/publicUrl.js';
import { readTapPayConfig, loadTapPayKeys, checkDynkMint } from './config.js';
import { signIntent, toBase64Url } from './intent.js';
import { quoteDynk, formatUnits } from './pricing.js';
import {
  buildDirectTransaction, ensureFeeCollectorAta, signMessage, assembleSignedTransaction,
  verifyEd25519, verifyTapPayTransaction, transferAuthority, sha256Hex,
} from './chain.js';
import { sealForPhone, signReceipt, signDecline, signTapQuote } from './crypto.js';
import { encodeTapRequest, encodeDecline } from './tapRequest.js';
import { publishOrderEvent } from './events.js';
import { swapService, pushService, dynkServiceConfigured, swapServiceAvailable } from './dynkService.js';
import { setDemoSwapContext } from './demoSwap.js';
import { resilientFetch, failureReason } from '../services/resilientFetch.js';

export const OPEN_STATUSES = ['QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER', 'CUSTOMER_DETECTED', 'AWAITING_APPROVAL'];
const ATTEMPT_ABANDON_MS = 10 * 60 * 1000;
const CONFIRM_POLL_MS = 1000;

export class TapPayError extends Error {
  constructor(status, code, message) { super(message); this.status = status; this.code = code; }
}

export const tapPay = { ready: false, reason: 'NOT_STARTED', missing: [], cfg: null, keys: null, mint: null, connection: null };
setDemoSwapContext(() => tapPay);
const confirming = new Map(); // attemptId -> promise (one loop per attempt)

const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
export function base58(bytes) {
  let n = BigInt('0x' + (Buffer.from(bytes).toString('hex') || '0'));
  let out = '';
  while (n > 0n) { out = B58[Number(n % 58n)] + out; n /= 58n; }
  for (const b of Buffer.from(bytes)) { if (b === 0) out = '1' + out; else break; }
  return out;
}

// ── Startup ─────────────────────────────────────────────────────────────

/**
 * Reads config, decrypts keys and checks the DYNK mint on-chain.
 * Throws (so the server refuses to start) only on MINT_MISMATCH. Missing
 * config or an unreachable RPC leaves tap-and-pay off with a loud log.
 */
export async function initTapPay({ env = process.env, connection = null, log = console } = {}) {
  Object.assign(tapPay, { ready: false, reason: 'NOT_CONFIGURED', missing: [] });
  const cfg = readTapPayConfig(env);
  tapPay.cfg = cfg;
  if (cfg.missing.length) {
    tapPay.missing = cfg.missing;
    log.warn(`[tappay] OFF: missing ${cfg.missing.join(', ')}`);
    return tapPay;
  }
  try {
    tapPay.keys = loadTapPayKeys(cfg);
  } catch (e) {
    tapPay.reason = 'KEYSTORE_ERROR';
    log.error(`[tappay] OFF: ${e.message}`);
    return tapPay;
  }
  tapPay.connection = connection || new Connection(env.SOLANA_RPC || SOLANA_CLUSTER_URL, {
    commitment: 'confirmed',
    // Short attempts with retries ride out network blips; our 429 handling replaces the
    // library's multi-second backoff (public devnet rate limits).
    disableRetryOnRateLimit: true,
    fetch: resilientFetch({ attemptTimeoutMs: 6_000, retries: 2, label: 'solana' }),
  });
  try {
    tapPay.mint = await checkDynkMint(tapPay.connection, cfg);
  } catch (e) {
    if (String(e.message).startsWith('MINT_MISMATCH')) throw e; // fail loudly: never run on the wrong mint
    tapPay.reason = 'RPC_UNREACHABLE';
    log.error(`[tappay] OFF until Solana answers: ${e.message}`);
    return tapPay;
  }
  if (cfg.platformFeeMicroUsd > 0n) {
    try {
      const r = await ensureFeeCollectorAta({ connection: tapPay.connection, sponsor: tapPay.keys.sponsor, feeCollector: cfg.feeCollector, mint: cfg.mint, tokenProgram: tapPay.mint.programId });
      if (r === 'CREATED') log.log(`[tappay] created the fee collector's DYNK account (paid by the gas sponsor)`);
    } catch (e) {
      // The tap builder never creates it, so taps would fail on-chain without it.
      tapPay.reason = 'FEE_COLLECTOR_ACCOUNT_MISSING';
      log.error(`[tappay] OFF: could not create the fee collector's DYNK account (fund the gas sponsor): ${e.message}`);
      return tapPay;
    }
  }
  Object.assign(tapPay, { ready: true, reason: 'READY' });
  log.log(`[tappay] ready: mint ${cfg.mint.toBase58()} (${tapPay.mint.tokenProgram}, ${tapPay.mint.decimals} decimals), sponsor ${tapPay.keys.sponsor.publicKey.toBase58()}, kid ${tapPay.keys.activeKid}`);
  return tapPay;
}

export function requireReady() {
  if (!tapPay.ready) {
    const err = new TapPayError(503, 'TAPPAY_NOT_CONFIGURED', tapPay.missing.length ? `Tap and pay is off. Missing: ${tapPay.missing.join(', ')}` : `Tap and pay is off (${tapPay.reason}).`);
    err.missing = tapPay.missing;
    throw err;
  }
}

// ── Helpers ─────────────────────────────────────────────────────────────

const centsOf = (decimal) => Math.round(parseFloat(String(decimal)) * 100);
/** The network fee in cents as shown everywhere: rounded UP, like the order total. */
export const feeCentsOf = (order) => Math.ceil(Math.round(parseFloat(String(order.customerFeeAUD)) * 1e6) / 1e4);
const isOpen = (order, now = Date.now()) => OPEN_STATUSES.includes(order.status) && new Date(order.quoteExpiresAt).getTime() > now;

export function payBase() {
  const domain = tapPay.cfg?.publicPayDomain;
  return domain ? `https://${domain.replace(/^https?:\/\//, '').replace(/\/$/, '')}` : customerBaseUrl(null, null);
}

export function paymentLink(orderId, intentBytes) {
  return `${payBase()}/o/${orderId}#${toBase64Url(intentBytes)}`;
}

/**
 * Push backup to the customer's phone (06 §A3) when the DYNK app is closed.
 * Best effort and never blocking: the live status (SSE / Bluetooth) is primary.
 */
function pushOutcome(order, customerPubkey, status) {
  if (!customerPubkey || !dynkServiceConfigured()) return;
  pushService.paymentStatus({
    customerPubkey, orderId: order.id, status,
    amountFiat: `$${order.totalAUD} AUD`, merchantName: order.merchant?.tradingName || '',
  }).catch((e) => console.warn(`[tappay] push ${status} for ${order.id}: ${e.code || e.message}`));
}

/**
 * ORDER_STATUS to the counter's terminal (WebSocket), and ORDER_UPDATED to the
 * merchant's open dashboards (UI spec §C live status). Never carries balances.
 */
async function notifyTerminal(order, status, extra = {}) {
  try {
    const { deviceHub } = await import('../devices/deviceHub.js');
    deviceHub.sendToCounter(order.merchantId, order.terminalId, 'ORDER_STATUS', { orderId: order.id, status, ...extra });
    deviceHub.broadcast(order.merchantId, { type: 'ORDER_UPDATED', orderId: order.id, status });
  } catch (e) {
    console.warn('[tappay] terminal notify:', e.message);
  }
}

function parsePubkey(v, code = 'BAD_PUBKEY') {
  try { return new PublicKey(String(v)); } catch { throw new TapPayError(400, code, 'Not a valid Solana public key.'); }
}

function parseBytes(v, len, code) {
  const b = Buffer.from(String(v || ''), 'base64');
  if (b.length !== len) throw new TapPayError(400, code, `Expected ${len} bytes (base64).`);
  return b;
}

async function merchantWallet(merchantId) {
  const w = await prisma.wallet.findFirst({ where: { merchantId, blockchain: 'solana', status: 'active' }, orderBy: { createdAt: 'asc' } });
  if (!w) throw new TapPayError(409, 'MERCHANT_WALLET_MISSING', 'Add a Solana wallet for this merchant before taking DYNK payments.');
  return parsePubkey(w.address, 'MERCHANT_WALLET_INVALID').toBase58();
}

function itemCountOf(items) {
  return (Array.isArray(items) ? items : []).filter((i) => i && !i.isTip).reduce((n, i) => n + (Number(i.quantity || i.qty) || 1), 0);
}

async function loadOrderForDevice(orderId, device) {
  const order = await prisma.order.findUnique({ where: { id: String(orderId) } });
  if (!order || order.merchantId !== device.merchantId || order.terminalId !== device.terminalId) {
    throw new TapPayError(404, 'ORDER_NOT_FOUND', 'Order not found.');
  }
  return order;
}

/** Sets the tap-and-pay terms on an order that has none yet (e.g. charged from the dashboard). */
export async function ensureTerms(order, { deviceId = null } = {}) {
  if (order.tapPayAmount != null) return order;
  const billCents = centsOf(order.subtotalAUD);
  const q = await quoteDynk({ billCents, decimals: tapPay.mint.decimals, platformFeeMicroUsd: tapPay.cfg.platformFeeMicroUsd });
  const recipient = await merchantWallet(order.merchantId);
  await prisma.order.updateMany({
    where: { id: order.id, tapPayAmount: null },
    data: {
      tapPayMint: tapPay.cfg.mint.toBase58(), tapPayAmount: q.amount, tapPayFee: q.fee, tapPayRecipient: recipient,
      tapPayDeviceId: deviceId, itemCount: itemCountOf(order.items),
    },
  });
  return prisma.order.findUnique({ where: { id: order.id } });
}

// ── Payments and intents ────────────────────────────────────────────────

/** Creates the order (amounts fixed here, in base units) and its first intent. */
export async function createPayment({ device, billCents, items = [], terminalEphemeralPub, bleSessionId, ttlSeconds = ORDER_TTL_SECONDS, arm = true }) {
  requireReady();
  if (!Number.isInteger(billCents) || billCents <= 0) throw new TapPayError(400, 'INVALID_AMOUNT', 'Enter an amount above zero.');
  const eph = parseBytes(terminalEphemeralPub, 32, 'BAD_TERMINAL_EPHEMERAL_PUB');
  const session = parseBytes(bleSessionId, 8, 'BAD_BLE_SESSION_ID');
  const recipient = await merchantWallet(device.merchantId);
  const q = await quoteDynk({ billCents, decimals: tapPay.mint.decimals, platformFeeMicroUsd: tapPay.cfg.platformFeeMicroUsd });
  // Fee in AUD at 4 decimals, rounded up; every displayed cent amount derives from this.
  const feeAud4 = (q.feeFiatMicro + 99n) / 100n;
  const customerFeeAUD = (Number(feeAud4) / 1e4).toFixed(4);
  const feeCents = feeCentsOf({ customerFeeAUD });
  const now = new Date();

  // One payment per counter at a time (same rule as the register).
  await prisma.order.updateMany({
    where: { merchantId: device.merchantId, terminalId: device.terminalId, status: { in: ['QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'] }, paymentLock: null },
    data: { status: 'CANCELLED' },
  });

  const totalBase = q.amount + q.fee;
  const order = await prisma.order.create({
    data: {
      merchantId: device.merchantId,
      orderNumber: `ORD-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`,
      subtotalAUD: (billCents / 100).toFixed(2),
      customerFeeAUD,
      totalAUD: ((billCents + feeCents) / 100).toFixed(2),
      gstAUD: (billCents / 1100).toFixed(2),
      tokenSymbol: 'DYNK',
      // Display copy of the DYNK total; tapPayAmount/tapPayFee are the truth.
      cryptoAmount: formatUnits(totalBase, tapPay.mint.decimals).replace(/^(\d+\.\d{6})\d+$/, '$1'),
      quotePrice: (Number(q.priceMicro) / 1e6).toFixed(4),
      quoteCreatedAt: now,
      quoteExpiresAt: new Date(now.getTime() + ttlSeconds * 1000),
      status: 'QUOTED',
      terminalId: device.terminalId,
      referenceKey: Keypair.generate().publicKey.toBase58(),
      items,
      itemCount: itemCountOf(items),
      tapPayMint: tapPay.cfg.mint.toBase58(),
      tapPayAmount: q.amount,
      tapPayFee: q.fee,
      tapPayRecipient: recipient,
      tapPayDeviceId: device.id,
    },
  });
  const intent = await issueIntent(order, { device, terminalEphemeralPub: eph, bleSessionId: session });

  // Same bookkeeping as a register charge (dashboard state, terminal ARM).
  // Table bills have no counter device to arm.
  if (arm) terminalGateway.arm(device.terminalId, {
    orderId: order.id, amountAUD: order.totalAUD.toString(), cryptoAmount: order.cryptoAmount.toString(), tokenSymbol: 'DYNK', quoteExpiresAt: order.quoteExpiresAt,
  }).catch((e) => console.warn('[tappay] arm:', e.message));

  return { order, ...intent, priceSource: q.priceSource };
}

/**
 * Signs a new intent for an open order. Spec v6: one intent for QR and tap
 * (the terminal sends it over NFC with the backend-built transaction). Never
 * extends the order's expiry.
 */
export async function issueIntent(order, { device, terminalEphemeralPub, bleSessionId }) {
  requireReady();
  const o = await ensureTerms(order, { deviceId: device.id });
  if (!isOpen(o)) throw new TapPayError(409, 'ORDER_NOT_OPEN', 'This payment is no longer open.');
  const merchant = await prisma.merchant.findUnique({ where: { id: o.merchantId } });
  const kid = tapPay.keys.activeKid;
  const key = tapPay.keys.intentKeys.get(kid).privateKey;
  const base = {
    kid,
    orderId: o.id,
    orderNumber: o.displayNumber,
    itemCount: o.itemCount,
    terminalId: device.id,
    merchantWallet: o.tapPayRecipient,
    mint: o.tapPayMint,
    amount: o.tapPayAmount,
    decimals: tapPay.mint.decimals,
    fiatAmount: BigInt(centsOf(o.subtotalAUD)),
    currency: 'AUD',
    reference: o.referenceKey,
    expiresAt: Math.floor(new Date(o.quoteExpiresAt).getTime() / 1000),
    bleSessionId,
    terminalEphemeralPub,
    merchantName: merchant?.tradingName || 'Merchant',
  };
  const qr = signIntent(base, key);

  const now = new Date();
  const common = { orderId: o.id, version: 1, kid, bleSessionId: Buffer.from(bleSessionId), terminalEphemeralPub: Buffer.from(terminalEphemeralPub), expiresAt: o.quoteExpiresAt };
  await prisma.$transaction([
    prisma.paymentIntent.updateMany({ where: { orderId: o.id, supersededAt: null }, data: { supersededAt: now } }),
    prisma.paymentIntent.create({ data: { ...common, kind: 'QR', payload: qr } }),
  ]);
  return {
    intent: toBase64Url(qr),
    link: paymentLink(o.id, qr),
    expiresAt: o.quoteExpiresAt.toISOString(),
    ttlSeconds: Math.max(0, Math.round((new Date(o.quoteExpiresAt).getTime() - Date.now()) / 1000)),
    // For the terminal's screen (UI spec B2): the server's numbers, never recomputed there.
    orderNumber: o.displayNumber,
    dynk: {
      amount: String(o.tapPayAmount), fee: String(o.tapPayFee),
      total: (BigInt(o.tapPayAmount) + BigInt(o.tapPayFee)).toString(), decimals: tapPay.mint.decimals,
    },
  };
}

/** New intent for the same order; keeps the session keys unless new ones are sent. */
export async function refreshIntent({ device, orderId, terminalEphemeralPub, bleSessionId }) {
  requireReady();
  const order = await loadOrderForDevice(orderId, device);
  const last = await prisma.paymentIntent.findFirst({ where: { orderId: order.id, kind: 'QR' }, orderBy: { createdAt: 'desc' } });
  const eph = terminalEphemeralPub ? parseBytes(terminalEphemeralPub, 32, 'BAD_TERMINAL_EPHEMERAL_PUB') : last?.terminalEphemeralPub;
  const session = bleSessionId ? parseBytes(bleSessionId, 8, 'BAD_BLE_SESSION_ID') : last?.bleSessionId;
  if (!eph || !session) throw new TapPayError(400, 'SESSION_KEYS_REQUIRED', 'Send terminalEphemeralPub and bleSessionId for the first intent.');
  return issueIntent(order, { device, terminalEphemeralPub: eph, bleSessionId: session });
}

export async function currentIntent(orderId) {
  requireReady();
  const order = await prisma.order.findUnique({ where: { id: String(orderId) } });
  if (!order || !isOpen(order)) throw new TapPayError(404, 'ORDER_NOT_OPEN', 'This payment is no longer open.');
  const last = await prisma.paymentIntent.findFirst({ where: { orderId: order.id, kind: 'QR', supersededAt: null }, orderBy: { createdAt: 'desc' } });
  if (!last) throw new TapPayError(404, 'NO_INTENT', 'The terminal has not issued a payment code yet.');
  return { intent: toBase64Url(last.payload), link: paymentLink(order.id, last.payload), expiresAt: order.quoteExpiresAt.toISOString() };
}

export async function display(orderId) {
  const order = await prisma.order.findUnique({ where: { id: String(orderId) }, include: { merchant: { include: { profile: true } } } });
  if (!order) throw new TapPayError(404, 'ORDER_NOT_FOUND', 'Order not found.');
  const logo = order.merchant.profile?.logoUrl || null;
  return {
    merchantName: order.merchant.tradingName,
    location: order.merchant.registeredAddress || null,
    logoUrl: logo && /^https?:\/\//.test(logo) ? logo : (logo ? `${payBase()}${logo.startsWith('/') ? '' : '/'}${logo}` : null),
  };
}

const PAID_ORDER_STATUSES = ['PAID', 'SETTLING', 'SETTLED', 'RECEIPT_READY'];

/**
 * The itemised bill for a paid order, for the DYNK user who paid it (so they
 * can split it with friends). Amounts are in cents of the order currency.
 * Prices include GST; the customer fee is added on top.
 */
export async function bill(orderId, payerWallets) {
  const order = await prisma.order.findUnique({
    where: { id: String(orderId) },
    include: { merchant: { include: { profile: true } }, paymentAttempts: { where: { status: 'CONFIRMED' }, take: 1 } },
  });
  if (!order) throw new TapPayError(404, 'ORDER_NOT_FOUND', 'Order not found.');
  const attempt = order.paymentAttempts[0];
  if (!PAID_ORDER_STATUSES.includes(order.status) || !attempt) {
    throw new TapPayError(409, 'ORDER_NOT_PAID', 'This bill has not been paid yet.');
  }
  if (!(payerWallets || []).includes(attempt.customerPubkey)) {
    throw new TapPayError(403, 'NOT_YOUR_BILL', 'Only the person who paid can see this bill.');
  }
  const cents = (v) => Math.round(parseFloat(String(v)) * 100);
  const items = (Array.isArray(order.items) ? order.items : [])
    .filter((i) => i && i.name)
    .map((i) => {
      const qty = Math.max(1, Number(i.quantity || i.qty) || 1);
      const unitCents = cents(i.price || 0);
      return { name: String(i.name), qty, unitCents, lineCents: unitCents * qty, isTip: Boolean(i.isTip) };
    });
  const view = await display(order.id);
  return {
    orderId: order.id,
    orderNumber: order.displayNumber,
    merchantName: view.merchantName,
    location: view.location,
    logoUrl: view.logoUrl,
    currency: 'AUD',
    items,
    subtotalCents: cents(order.subtotalAUD),
    gstIncludedCents: cents(order.gstAUD),
    feeCents: feeCentsOf(order),
    totalCents: cents(order.totalAUD),
    paidAt: (order.paidAt || attempt.updatedAt).toISOString(),
    payment: {
      tokenSymbol: 'DYNK',
      mint: order.tapPayMint || tapPay.cfg?.mint?.toBase58?.() || null,
      decimals: tapPay.mint?.decimals ?? 9,
      // Everything the payer sent (merchant amount + platform fee), in base units.
      amountBaseUnits: (BigInt(attempt.amount) + BigInt(attempt.fee)).toString(),
      txSignature: attempt.txSignature,
      customerPubkey: attempt.customerPubkey,
    },
  };
}

/** Customer-facing link for an order the terminal shows (latest intent), or null. */
export async function linkForOrder(orderId) {
  if (!tapPay.ready) return null;
  const last = await prisma.paymentIntent.findFirst({ where: { orderId, kind: 'QR', supersededAt: null }, orderBy: { createdAt: 'desc' } });
  return last ? paymentLink(orderId, last.payload) : null;
}

// ── Precheck / build / submit ───────────────────────────────────────────

async function tokenBalance(owner, mint, programId) {
  const ata = getAssociatedTokenAddressSync(mint, owner, true, programId);
  try {
    const acc = await getAccount(tapPay.connection, ata, 'confirmed', programId);
    return { exists: true, frozen: acc.isFrozen, amount: acc.amount };
  } catch (e) {
    if (e instanceof TokenAccountNotFoundError || e instanceof TokenInvalidAccountOwnerError) return { exists: false, frozen: false, amount: 0n };
    console.warn(`[tappay] balance read failed: ${failureReason(e)} ${e?.message || ''}`.trim());
    throw new TapPayError(503, 'RPC_UNAVAILABLE', 'Could not read balances from Solana. Try again.');
  }
}

async function openOrderWithTerms(orderId) {
  const order = await prisma.order.findUnique({ where: { id: String(orderId) } });
  if (!order) throw new TapPayError(404, 'ORDER_NOT_FOUND', 'Order not found.');
  if (['PAID', 'SETTLING', 'SETTLED', 'RECEIPT_READY'].includes(order.status)) throw new TapPayError(409, 'ORDER_PAID', 'This order is already paid.');
  if (order.paymentLock) throw new TapPayError(409, 'PAYMENT_IN_PROGRESS', 'A payment for this order is already being processed.');
  if (!isOpen(order)) throw new TapPayError(410, 'ORDER_EXPIRED', 'Payment expired. Tap or scan again.');
  if (order.tapPayAmount == null) throw new TapPayError(409, 'NO_INTENT', 'The terminal has not issued a payment code yet.');
  return order;
}

/**
 * Balance check. The caller (terminal or app) learns only the result code
 * and the fee; balances go to the phone inside the sealed blob.
 */
/**
 * Swap and Pay is offered ONLY in Case 1: QR entry with the phone online
 * (spec v5, D5). Over the internet the phone is online by definition; over
 * Bluetooth only when PUBKEY said `phoneOnline: true`. Never after a tap.
 */
export function swapEligible({ channel, phoneOnline }) {
  return channel === 'QR_INTERNET' || (channel === 'QR_BLE' && phoneOnline === true);
}

export async function precheck({ orderId, customerPubkey, phoneEphemeralPub, channel, phoneOnline = false }) {
  requireReady();
  const order = await openOrderWithTerms(orderId);
  const customer = parsePubkey(customerPubkey, 'BAD_CUSTOMER_PUBKEY');
  const phoneEph = parseBytes(phoneEphemeralPub, 32, 'BAD_PHONE_EPHEMERAL_PUB');
  const amount = BigInt(order.tapPayAmount);
  const fee = BigInt(order.tapPayFee);
  const need = amount + fee;

  const canSwap = swapEligible({ channel, phoneOnline });
  // The build's blockhash is fetched in parallel with the balance check (spec v6 §6.1).
  const blockhash = tapPay.connection.getLatestBlockhash('confirmed').catch(() => null);
  // DYNK and USDC are read in parallel too. USDC only matters (and is only read)
  // where Swap and Pay may be offered and the Swap and Pay service is set up.
  const noUsdc = { exists: false, frozen: false, amount: 0n };
  const readUsdc = canSwap && tapPay.cfg.usdcMint && swapServiceAvailable();
  const [dynk, usdcRead] = await Promise.all([
    tokenBalance(customer, tapPay.cfg.mint, tapPay.mint.programId),
    readUsdc ? tokenBalance(customer, tapPay.cfg.usdcMint, TOKEN_PROGRAM_ID) : noUsdc,
  ]);
  let usdc = usdcRead;
  let result = dynk.exists && !dynk.frozen && dynk.amount >= need ? 'OK' : 'INSUFFICIENT';

  // A new precheck replaces this customer's earlier unused quote on this channel.
  await releaseUnusedSwaps({ orderId: order.id, customerPubkey: customer.toBase58(), channel });

  // Swap and Pay: short on DYNK (not frozen) -> ask the DYNK backend for a
  // quote (it reserves the DYNK); offer it only if their USDC covers it.
  let swap = null;
  if (canSwap && result === 'INSUFFICIENT' && !dynk.frozen && swapServiceAvailable()) {
    swap = await quoteSwap({ order, customer, shortfall: need - dynk.amount })
      .catch((e) => { console.warn(`[tappay] Swap and Pay quote: ${e.code || e.message}`); return null; });
    if (swap) {
      result = 'SWAP_OFFER';
      usdc = swap.usdcBalance;
    }
  }

  // The terminal shows "Customer is reviewing the payment…", or "Declined – not enough funds"
  // when nothing can be paid (Cases 1–2 "not enough": nothing signed; the order stays open for
  // another try or method). Over Bluetooth the terminal reads the result itself.
  if (channel === 'QR_INTERNET') {
    if (result === 'INSUFFICIENT') notifyTerminal(order, 'DECLINED', { reason: 'INSUFFICIENT' });
    else notifyTerminal(order, 'REVIEWING');
  }

  await prisma.paymentAttempt.create({
    data: {
      orderId: order.id, channel, customerPubkey: customer.toBase58(), status: 'PRECHECKED', amount, fee,
      ...(swap ? { swapQuoteId: swap.quote.quoteId, swapQuote: swap.quote } : {}),
    },
  });

  const blob = sealForPhone({
    dynkBalance: dynk.amount.toString(),
    dynkAccountExists: dynk.exists,
    dynkFrozen: dynk.frozen,
    usdcBalance: usdc.amount.toString(),
    amount: amount.toString(),
    fee: fee.toString(),
    decimals: tapPay.mint.decimals,
    // What the Review screen shows for Swap and Pay; the phone checks the
    // built transaction against exactly these values before signing (§7).
    swap: swap ? {
      usdcMint: swap.quote.usdcMint,
      usdcAmount: swap.quote.usdcAmount,
      dynkAmount: swap.quote.dynkAmount,
      treasuryUsdcAccount: swap.quote.treasuryUsdcAccount,
      vault: swap.quote.vault,
      delegate: swap.quote.delegate,
      expiresAt: swap.quote.expiresAt,
    } : null,
  }, { phoneEphemeralPub: phoneEph, orderId: order.id });

  // The transaction goes to the phone with this answer, so it is checked before
  // the slide (spec v6 01 Case 1 step 6). Swap and Pay when offered (Case 1).
  // If building fails here the phone asks for a build at the slide instead.
  let built = null;
  if (result !== 'INSUFFICIENT') {
    built = await build({
      orderId: order.id, customerPubkey: customer.toBase58(), option: result === 'SWAP_OFFER' ? 'SWAP' : 'DIRECT', channel,
      recentBlockhash: await blockhash,
    }).catch((e) => { console.warn(`[tappay] build with precheck: ${e.code || e.message}`); return null; });
  }

  return {
    result,
    fee: { baseUnits: fee.toString(), fiatCents: feeCentsOf(order), currency: 'AUD' },
    private: blob,
    expiresAt: order.quoteExpiresAt.toISOString(),
    build: built,
  };
}

export async function build({ orderId, customerPubkey, option = 'DIRECT', channel, recentBlockhash = null }) {
  requireReady();
  if (option !== 'DIRECT' && option !== 'SWAP') throw new TapPayError(400, 'BAD_OPTION', 'option must be DIRECT or SWAP.');
  const order = await openOrderWithTerms(orderId);
  const customer = parsePubkey(customerPubkey, 'BAD_CUSTOMER_PUBKEY').toBase58();
  const prior = await prisma.paymentAttempt.findFirst({
    where: { orderId: order.id, customerPubkey: customer, channel, status: { in: ['PRECHECKED', 'BUILT'] } },
    orderBy: { createdAt: 'desc' },
  });
  let swapInstructions = null;
  if (option === 'SWAP') {
    // Only the quote this customer was offered at precheck, while it lasts.
    const q = prior?.swapQuote;
    if (!q || new Date(q.expiresAt).getTime() <= Date.now()) {
      if (q) await releaseSwap(prior.swapQuoteId);
      throw new TapPayError(409, 'SWAP_UNAVAILABLE', 'Swap and Pay unavailable. Try again.');
    }
    swapInstructions = q.instructions;
  } else if (prior?.swapQuoteId) {
    await releaseSwap(prior.swapQuoteId); // paying directly after all
  }

  const built = await buildDirectTransaction({
    connection: tapPay.connection,
    sponsor: tapPay.keys.sponsor,
    customer,
    mint: order.tapPayMint,
    tokenProgram: tapPay.mint.programId,
    decimals: tapPay.mint.decimals,
    merchant: order.tapPayRecipient,
    amount: BigInt(order.tapPayAmount),
    feeCollector: tapPay.cfg.feeCollector?.toBase58(),
    fee: BigInt(order.tapPayFee),
    reference: order.referenceKey,
    computeUnitLimit: tapPay.cfg.computeUnitLimit,
    priorityFeeMicroLamports: tapPay.cfg.priorityFeeMicroLamports,
    swapInstructions,
    recentBlockhash,
  }).catch((e) => { throw e instanceof TapPayError ? e : new TapPayError(503, 'RPC_UNAVAILABLE', 'Could not reach Solana to build the payment.'); });

  const data = {
    option,
    ...(option === 'DIRECT' ? { swapQuoteId: null, swapQuote: null } : {}),
    quoteId: crypto.randomUUID(), // every build is a new quote; older ones stop working
    messageBytes: built.messageBytes,
    messageHash: sha256Hex(built.messageBytes),
    lastValidBlockHeight: BigInt(built.lastValidBlockHeight),
    quoteExpiresAt: order.quoteExpiresAt,
    status: 'BUILT',
  };
  const attempt = prior
    ? await prisma.paymentAttempt.update({ where: { id: prior.id }, data })
    : await prisma.paymentAttempt.create({ data: { ...data, orderId: order.id, channel, customerPubkey: customer, amount: BigInt(order.tapPayAmount), fee: BigInt(order.tapPayFee) } });

  return {
    quoteId: attempt.quoteId,
    option,
    transaction: built.unsignedTx.toString('base64'),
    expiresAt: (option === 'SWAP' && new Date(attempt.swapQuote.expiresAt) < order.quoteExpiresAt ? new Date(attempt.swapQuote.expiresAt) : order.quoteExpiresAt).toISOString(),
    feePayer: tapPay.keys.sponsor.publicKey.toBase58(),
  };
}

function attemptView(a) {
  return {
    quoteId: a.quoteId,
    status: a.status,
    txSignature: a.txSignature || null,
    failureCode: a.failureCode || null,
    receipt: a.receipt || null,
    ...(a.status === 'DECLINED' ? { reason: a.declineNotice?.reason || 'INSUFFICIENT', decline: a.declineNotice || null } : {}),
  };
}

/** Ends an attempt that will not be sent and frees the order for another try. */
async function release(attempt, code, { status = 'FAILED', declineNotice = undefined } = {}) {
  await prisma.paymentAttempt.update({ where: { id: attempt.id }, data: { status, failureCode: code, ...(declineNotice ? { declineNotice } : {}) } });
  const order = await prisma.order.findUnique({ where: { id: attempt.orderId } });
  const stillOpen = order && new Date(order.quoteExpiresAt).getTime() > Date.now();
  await prisma.order.updateMany({
    where: { id: attempt.orderId, paymentLock: attempt.id },
    data: { paymentLock: null, status: stillOpen ? 'CUSTOMER_DETECTED' : 'EXPIRED' },
  });
  return order;
}

function simulationCode(sim) {
  const logs = (sim.value.logs || []).join('\n');
  if (/insufficient funds/i.test(logs)) return 'INSUFFICIENT_FUNDS';
  if (/frozen/i.test(logs)) return 'ACCOUNT_FROZEN';
  if (/Blockhash not found|BlockhashNotFound/i.test(JSON.stringify(sim.value.err))) return 'BLOCKHASH_EXPIRED';
  return 'SIMULATION_FAILED';
}

// ── Swap and Pay (DYNK backend service, spec §8) ───────────────────────

const mintPrograms = new Map();
async function tokenProgramOf(mint) {
  const key = String(mint);
  if (!mintPrograms.has(key)) {
    const info = await tapPay.connection.getAccountInfo(new PublicKey(key), 'confirmed');
    if (!info) throw new TapPayError(503, 'SWAP_UNAVAILABLE', 'Swap and Pay unavailable. Try again.');
    mintPrograms.set(key, info.owner);
  }
  return mintPrograms.get(key);
}

/**
 * Asks the DYNK backend for a Swap and Pay quote covering `shortfall` DYNK and
 * checks it: right DYNK mint, at least the shortfall, the two expected
 * instructions, and the customer's USDC covering it. Anything else -> null
 * (and the reservation is released).
 * @returns {Promise<{ quote: object, usdcBalance: object } | null>}
 */
async function quoteSwap({ order, customer, shortfall, dryRun = false }) {
  const q = await swapService.quote({
    customerPubkey: customer.toBase58(), dynkShortfall: shortfall.toString(), orderRef: order.id,
    expiresAt: new Date(order.quoteExpiresAt).toISOString(), ...(dryRun ? { dryRun: true } : {}),
  });
  const quote = {
    quoteId: q.quoteId || null, usdcMint: String(q.usdcMint), usdcAmount: String(q.usdcAmount), dynkMint: String(q.dynkMint),
    dynkAmount: String(q.dynkAmount), treasuryUsdcAccount: String(q.treasuryUsdcAccount), vault: String(q.vault),
    delegate: String(q.delegate), instructions: q.instructions, expiresAt: String(q.expiresAt),
  };
  const ok = quote.dynkMint === tapPay.cfg.mint.toBase58() && BigInt(quote.dynkAmount) >= shortfall
    && /^\d+$/.test(quote.usdcAmount) && Array.isArray(quote.instructions) && quote.instructions.length === 2
    && (dryRun || quote.quoteId);
  const usdcBalance = ok ? await tokenBalance(customer, new PublicKey(quote.usdcMint), await tokenProgramOf(quote.usdcMint)) : null;
  if (!ok || !usdcBalance.exists || usdcBalance.frozen || usdcBalance.amount < BigInt(quote.usdcAmount)) {
    if (quote.quoteId) await releaseSwap(quote.quoteId);
    return null;
  }
  return { quote, usdcBalance };
}

async function releaseSwap(quoteId) {
  if (!quoteId) return;
  await swapService.release({ quoteId }).catch((e) => console.warn(`[tappay] Swap and Pay release ${quoteId}: ${e.code || e.message}`));
}

/** Releases quotes held by a customer's attempts that were never submitted. */
async function releaseUnusedSwaps(where) {
  const held = await prisma.paymentAttempt.findMany({ where: { ...where, status: { in: ['PRECHECKED', 'BUILT'] }, swapQuoteId: { not: null } } });
  for (const a of held) {
    await releaseSwap(a.swapQuoteId);
    await prisma.paymentAttempt.update({ where: { id: a.id }, data: { swapQuoteId: null, swapQuote: null } });
  }
}

/** Signed decline for the phone (§11). */
function declineNotice({ orderId, customerPubkey, reason = 'INSUFFICIENT' }) {
  return signDecline(
    { orderId, customerPubkey, reason, declinedAt: new Date().toISOString() },
    { kid: tapPay.keys.activeKid, privateKey: tapPay.keys.intentKeys.get(tapPay.keys.activeKid).privateKey },
  );
}

/**
 * After a failed simulation: is the customer short of DYNK? Decided from the
 * chain (their DYNK account missing, frozen or below amount + fee), never
 * from log text, so a platform-side problem is never blamed on the customer.
 * @returns {Promise<bigint|null>} the shortfall, or null if they have enough (or it can't be read)
 */
async function customerShortfall(attempt) {
  const b = await tokenBalance(new PublicKey(attempt.customerPubkey), tapPay.cfg.mint, tapPay.mint.programId).catch(() => null);
  if (!b) return null;
  const need = BigInt(attempt.amount) + BigInt(attempt.fee);
  if (!b.exists || b.frozen) return need;
  return b.amount < need ? need - b.amount : null;
}


/**
 * Shared by every channel once the customer's signature is verified on the
 * exact message: take the order lock, add the sponsor signature, simulate
 * (classifying failures), persist, send, and watch until confirmed.
 */
async function lockSimulateSend(attempt, customerSig) {
  // Atomic lock: only one attempt per order gets past this line.
  const locked = await prisma.order.updateMany({
    where: { id: attempt.orderId, paymentLock: null, status: { in: OPEN_STATUSES }, quoteExpiresAt: { gt: new Date() } },
    data: { paymentLock: attempt.id, status: 'SUBMITTED' },
  });
  if (locked.count !== 1) {
    const order = await prisma.order.findUnique({ where: { id: attempt.orderId } });
    await prisma.paymentAttempt.update({ where: { id: attempt.id }, data: { status: 'FAILED', failureCode: order?.paymentLock ? 'PAYMENT_IN_PROGRESS' : 'ORDER_EXPIRED' } });
    if (order?.paymentLock) throw new TapPayError(409, 'PAYMENT_IN_PROGRESS', 'A payment for this order is already being processed.');
    throw new TapPayError(410, 'ORDER_EXPIRED', 'Payment expired. Tap or scan again.');
  }

  const sponsorSig = signMessage(tapPay.keys.sponsor, attempt.messageBytes);
  const signatures = new Map([
    [attempt.customerPubkey, customerSig],
    [tapPay.keys.sponsor.publicKey.toBase58(), sponsorSig],
  ]);
  let wire;
  try {
    if (attempt.option === 'SWAP') {
      // The delegate signs only this exact message, once (DYNK backend). The
      // fee payer's signature (= tx id) lets it check the chain before ever
      // releasing the reservation.
      const c = await swapService.cosign({
        quoteId: attempt.swapQuoteId, message: Buffer.from(attempt.messageBytes).toString('base64'), feePayerSignature: sponsorSig.toString('base64'),
      });
      if (c.delegate !== attempt.swapQuote?.delegate) throw new Error('SWAP_DELEGATE_MISMATCH');
      signatures.set(c.delegate, Buffer.from(String(c.signature), 'base64'));
    }
    wire = assembleSignedTransaction(attempt.messageBytes, signatures);
  } catch (e) {
    console.warn(`[tappay] Swap and Pay cosign for ${attempt.orderId}: ${e.code || e.message}`);
    return failBeforeSend(attempt, 'SWAP_UNAVAILABLE');
  }

  let sim;
  try {
    sim = await tapPay.connection.simulateTransaction(VersionedTransaction.deserialize(wire), { sigVerify: true, commitment: 'confirmed' });
  } catch {
    await release(attempt, 'RPC_UNAVAILABLE');
    throw new TapPayError(503, 'RPC_UNAVAILABLE', 'Could not reach Solana. Try again.');
  }
  if (sim.value.err) {
    let code = simulationCode(sim);
    if (attempt.option === 'SWAP') {
      // The quote was for the balances at precheck; something changed. Start again.
      console.warn(`[tappay] Swap and Pay simulation failed for ${attempt.orderId}: ${JSON.stringify(sim.value.err)}`);
      return failBeforeSend(attempt, code === 'BLOCKHASH_EXPIRED' ? code : 'SWAP_UNAVAILABLE');
    }
    const order = await prisma.order.findUnique({ where: { id: attempt.orderId } });
    const shortfall = code === 'BLOCKHASH_EXPIRED' ? null : await customerShortfall(attempt);
    if (shortfall != null) {
      // Not enough DYNK: DECLINED {reason: INSUFFICIENT}. Never a Swap and Pay
      // offer here (spec v5 §6.3); the order stays open for another method.
      code = 'INSUFFICIENT_FUNDS';
      const notice = declineNotice({ orderId: order.id, customerPubkey: attempt.customerPubkey });
      await release(attempt, code, { status: 'DECLINED', declineNotice: notice });
      notifyTerminal(order, 'DECLINED', { reason: 'INSUFFICIENT' });
      publishOrderEvent(order.id, { status: 'DECLINED', customerPubkey: attempt.customerPubkey, reason: 'INSUFFICIENT', decline: notice });
      pushOutcome(await withMerchant(order), attempt.customerPubkey, 'DECLINED');
      return attemptView({ ...attempt, status: 'DECLINED', failureCode: code, declineNotice: notice });
    }
    // Enough DYNK but it still fails: not the customer's funds.
    if (code === 'INSUFFICIENT_FUNDS') code = 'SIMULATION_FAILED';
    console.warn(`[tappay] simulation failed (${code}) for order ${order.orderNumber}: ${JSON.stringify(sim.value.err)}`);
    await release(attempt, code);
    notifyTerminal(order, 'FAILED', { code });
    publishOrderEvent(order.id, { status: 'FAILED', customerPubkey: attempt.customerPubkey, code });
    pushOutcome(await withMerchant(order), attempt.customerPubkey, 'FAILED');
    return attemptView({ ...attempt, status: 'FAILED', failureCode: code });
  }

  // The fee payer's signature is the transaction id. Persist it BEFORE sending.
  const txSignature = base58(wire.subarray(1, 65));
  const submitted = await prisma.paymentAttempt.update({
    where: { id: attempt.id },
    data: { status: 'SUBMITTED', txSignature, signedTx: wire },
  });
  // Not awaited: the attempt is already saved, and the confirm loop rebroadcasts the same bytes.
  tapPay.connection.sendRawTransaction(wire, { skipPreflight: true, maxRetries: 0 }).catch((e) => console.warn('[tappay] send:', e.message));
  publishOrderEvent(attempt.orderId, { status: 'PROCESSING', customerPubkey: attempt.customerPubkey, txSignature });
  watchAttempt(submitted.id);
  return attemptView(submitted);
}

async function withMerchant(order) {
  if (order.merchant) return order;
  return prisma.order.findUnique({ where: { id: order.id }, include: { merchant: true } });
}

/** Ends a locked attempt that was never sent: FAILED, lock and any Swap and Pay quote released. */
async function failBeforeSend(attempt, code) {
  const order = await release(attempt, code);
  if (order) pushOutcome(await withMerchant(order), attempt.customerPubkey, 'FAILED');
  if (attempt.swapQuoteId) await releaseSwap(attempt.swapQuoteId);
  if (order) notifyTerminal(order, 'FAILED', { code });
  publishOrderEvent(attempt.orderId, { status: 'FAILED', customerPubkey: attempt.customerPubkey, code });
  return attemptView({ ...attempt, status: 'FAILED', failureCode: code });
}

/** Verifies the customer's signature on the stored message, then locks, simulates and sends. */
export async function submit({ orderId, quoteId, customerPubkey, signature, channel }) {
  requireReady();
  const channels = Array.isArray(channel) ? channel : [channel];
  const attempt = await prisma.paymentAttempt.findUnique({ where: { quoteId: String(quoteId || '') } });
  if (!attempt || attempt.orderId !== String(orderId) || attempt.customerPubkey !== String(customerPubkey) || !channels.includes(attempt.channel)) {
    throw new TapPayError(404, 'QUOTE_NOT_FOUND', 'This payment quote was not found. Start again.');
  }
  if (['SUBMITTED', 'CONFIRMED'].includes(attempt.status)) return attemptView(attempt); // idempotent
  if (attempt.status !== 'BUILT') throw new TapPayError(409, 'QUOTE_NOT_SUBMITTABLE', `This quote is ${attempt.status.toLowerCase()}.`);

  const sig = Buffer.from(String(signature || ''), 'base64');
  if (sig.length !== 64 || !verifyEd25519(attempt.customerPubkey, attempt.messageBytes, sig)) {
    await prisma.paymentAttempt.update({ where: { id: attempt.id }, data: { status: 'FAILED', failureCode: 'BAD_SIGNATURE' } });
    throw new TapPayError(400, 'BAD_SIGNATURE', 'The signature does not match this payment.');
  }
  return lockSimulateSend(attempt, sig);
}

// ── Tap and Pay (Cases 3 and 4), spec v6 ────────────────────────────────

export const TAP_CHANNELS = ['TAP_ONLINE', 'TAP_OFFLINE'];

/**
 * During the tap, the phone on the reader (02 §4.4): the phone sent its public
 * key over NFC; check its DYNK balance and build the transaction in parallel.
 *   - not enough DYNK: a signed decline goes back over NFC and NOTHING is signed
 *     (Cases 3 and 4 alike; no Swap and Pay in Tap and Pay);
 *   - enough: the backend-built transaction plus a signed tap quote (message
 *     hash + fee), which the phone checks before it partially signs.
 * phoneOnline only labels the channel and picks the phone's result channel.
 */
export async function tapPrepare({ orderId, customerPubkey, phoneOnline = false }) {
  requireReady();
  const order = await openOrderWithTerms(orderId);
  const customer = parsePubkey(customerPubkey, 'BAD_CUSTOMER_PUBKEY');
  const c58 = customer.toBase58();
  const channel = phoneOnline === true ? 'TAP_ONLINE' : 'TAP_OFFLINE';
  const amount = BigInt(order.tapPayAmount);
  const fee = BigInt(order.tapPayFee);

  const [dynk, recentBlockhash] = await Promise.all([
    tokenBalance(customer, tapPay.cfg.mint, tapPay.mint.programId),
    tapPay.connection.getLatestBlockhash('confirmed'),
  ]).catch(() => { throw new TapPayError(503, 'RPC_UNAVAILABLE', 'Could not reach Solana. Tap again.'); });

  // A new tap replaces this customer's unsent tap quotes for the order.
  await prisma.paymentAttempt.updateMany({
    where: { orderId: order.id, customerPubkey: c58, channel: { in: TAP_CHANNELS }, status: 'BUILT' },
    data: { status: 'EXPIRED' },
  });

  if (!(dynk.exists && !dynk.frozen && dynk.amount >= amount + fee)) {
    const notice = declineNotice({ orderId: order.id, customerPubkey: c58 });
    await prisma.paymentAttempt.create({ data: { orderId: order.id, channel, customerPubkey: c58, status: 'DECLINED', failureCode: 'INSUFFICIENT_FUNDS', declineNotice: notice, amount, fee } });
    notifyTerminal(order, 'DECLINED', { reason: 'INSUFFICIENT' });
    publishOrderEvent(order.id, { status: 'DECLINED', customerPubkey: c58, reason: 'INSUFFICIENT', decline: notice });
    // PUT_DECLINE payload: the terminal relays these bytes as they are.
    return { result: 'INSUFFICIENT', decline: notice, declineBytes: encodeDecline(notice).toString('base64') };
  }

  // The intent the phone verifies: the order's current one (QR and tap share it).
  const intentRow = await prisma.paymentIntent.findFirst({ where: { orderId: order.id, kind: 'QR', supersededAt: null }, orderBy: { createdAt: 'desc' } });
  if (!intentRow) throw new TapPayError(409, 'NO_INTENT', 'The terminal has not issued a payment code yet.');

  const built = await buildDirectTransaction({
    connection: tapPay.connection,
    sponsor: tapPay.keys.sponsor,
    customer: c58,
    mint: order.tapPayMint,
    tokenProgram: tapPay.mint.programId,
    decimals: tapPay.mint.decimals,
    merchant: order.tapPayRecipient,
    amount,
    feeCollector: tapPay.cfg.feeCollector?.toBase58(),
    fee,
    reference: order.referenceKey,
    computeUnitLimit: tapPay.cfg.computeUnitLimit,
    priorityFeeMicroLamports: tapPay.cfg.priorityFeeMicroLamports,
    recentBlockhash,
  });
  const quoteId = crypto.randomUUID();
  const messageHash = sha256Hex(built.messageBytes);
  await prisma.paymentAttempt.create({
    data: {
      orderId: order.id, channel, customerPubkey: c58, option: 'DIRECT', quoteId, status: 'BUILT',
      messageBytes: built.messageBytes, messageHash, lastValidBlockHeight: BigInt(built.lastValidBlockHeight),
      quoteExpiresAt: order.quoteExpiresAt, amount, fee,
    },
  });
  const tapQuote = signTapQuote(
    { orderId: order.id, quoteId, messageHash, fee: fee.toString(), expiresAt: order.quoteExpiresAt.toISOString() },
    { kid: tapPay.keys.activeKid, privateKey: tapPay.keys.intentKeys.get(tapPay.keys.activeKid).privateKey },
  );
  return {
    result: 'OK', quoteId, tapQuote, expiresAt: order.quoteExpiresAt.toISOString(),
    // PUT_REQUEST payload (02 §4.2), relayed by the terminal as it is.
    request: encodeTapRequest({ intent: intentRow.payload, tapQuote, transaction: built.unsignedTx }).toString('base64'),
  };
}

/**
 * The phone's partial signature on a tap quote: from the terminal (read during
 * the tap, or relayed over Bluetooth) or the phone itself (late submit). Same
 * pipeline as every channel: verify on the stored message, lock, simulate, send.
 */
export function tapSubmit({ orderId, quoteId, customerPubkey, signature }) {
  return submit({ orderId, quoteId, customerPubkey, signature, channel: TAP_CHANNELS });
}

/** Fresh DYNK balance for "Ready to pay" (Case 3; no Swap and Pay, so no USDC). The phone's own wallet only. */
export async function balances({ customerPubkey }) {
  requireReady();
  const customer = parsePubkey(customerPubkey, 'BAD_CUSTOMER_PUBKEY');
  const dynk = await tokenBalance(customer, tapPay.cfg.mint, tapPay.mint.programId);
  return {
    dynk: { mint: tapPay.cfg.mint.toBase58(), decimals: tapPay.mint.decimals, amount: dynk.amount.toString(), exists: dynk.exists, frozen: dynk.frozen },
    at: new Date().toISOString(),
  };
}

/**
 * Where this customer's payment on the order stands, as the live-status event
 * it last produced (spec v5: the internet is the BACKUP result channel, so a
 * phone may subscribe after the result was already published). Only the
 * signed-in user's own wallets; null if there is nothing to tell yet.
 */
export async function latestOutcome(orderId, wallets) {
  if (!wallets?.length) return null;
  const a = await prisma.paymentAttempt.findFirst({
    where: { orderId, customerPubkey: { in: wallets }, status: { in: ['SUBMITTED', 'CONFIRMED', 'DECLINED', 'FAILED'] } },
    orderBy: { updatedAt: 'desc' },
  });
  if (!a) return null;
  const base = { customerPubkey: a.customerPubkey, orderId, at: a.updatedAt.toISOString() };
  if (a.status === 'CONFIRMED') return a.receipt ? { ...base, status: 'CONFIRMED', txSignature: a.txSignature, receipt: a.receipt } : { ...base, status: 'PROCESSING', txSignature: a.txSignature };
  if (a.status === 'DECLINED') return { ...base, status: 'DECLINED', reason: a.declineNotice?.reason || 'INSUFFICIENT', decline: a.declineNotice || null };
  if (a.status === 'FAILED') return { ...base, status: 'FAILED', code: a.failureCode || 'FAILED' };
  return { ...base, status: 'PROCESSING', txSignature: a.txSignature || undefined };
}

export async function attemptStatus({ quoteId, orderId }) {
  const a = await prisma.paymentAttempt.findUnique({ where: { quoteId: String(quoteId || '') } });
  if (!a || a.orderId !== String(orderId)) throw new TapPayError(404, 'QUOTE_NOT_FOUND', 'Not found.');
  return attemptView(a);
}

export async function decline({ orderId, customerPubkey, channel, notifyTerminal = true }) {
  const order = await prisma.order.findUnique({ where: { id: String(orderId) } });
  if (!order) throw new TapPayError(404, 'ORDER_NOT_FOUND', 'Order not found.');
  await releaseUnusedSwaps({ orderId: order.id, channel, ...(customerPubkey ? { customerPubkey: String(customerPubkey) } : {}) });
  await prisma.paymentAttempt.updateMany({
    where: { orderId: order.id, channel, ...(customerPubkey ? { customerPubkey: String(customerPubkey) } : {}), status: { in: ['PRECHECKED', 'BUILT'] } },
    data: { status: 'CUSTOMER_DECLINED' },
  });
  publishOrderEvent(order.id, { status: 'CUSTOMER_DECLINED', customerPubkey: customerPubkey ? String(customerPubkey) : null });
  if (notifyTerminal) {
    const { deviceHub } = await import('../devices/deviceHub.js');
    deviceHub.sendToCounter(order.merchantId, order.terminalId, 'CUSTOMER_DECLINED', { orderId: order.id });
  }
  return { declined: true }; // the order stays open until it expires
}

// ── Confirmation ────────────────────────────────────────────────────────

export function watchAttempt(attemptId) {
  if (confirming.has(attemptId)) return confirming.get(attemptId);
  const p = confirmLoop(attemptId).catch((e) => console.error(`[tappay] confirm ${attemptId}:`, e.message)).finally(() => confirming.delete(attemptId));
  confirming.set(attemptId, p);
  return p;
}

async function confirmLoop(attemptId) {
  const conn = tapPay.connection;
  for (;;) {
    const a = await prisma.paymentAttempt.findUnique({ where: { id: attemptId } });
    if (!a || a.status !== 'SUBMITTED') return;
    const st = (await conn.getSignatureStatuses([a.txSignature], { searchTransactionHistory: true }).catch(() => ({ value: [null] }))).value[0];
    if (st?.err) return failAfterSend(a, 'FAILED_ON_CHAIN');
    if (st && ['confirmed', 'finalized'].includes(st.confirmationStatus)) {
      if ((await finalize(a)) !== 'RETRY') return;
      await new Promise((r) => setTimeout(r, CONFIRM_POLL_MS));
      continue;
    }
    const height = await conn.getBlockHeight('confirmed').catch(() => null);
    if (height != null && BigInt(height) > BigInt(a.lastValidBlockHeight)) {
      // One last look: it may have landed between the two calls.
      const last = (await conn.getSignatureStatuses([a.txSignature], { searchTransactionHistory: true }).catch(() => ({ value: [null] }))).value[0];
      if (last && !last.err) {
        if ((await finalize(a)) !== 'RETRY') return;
        continue;
      }
      return failAfterSend(a, 'BLOCKHASH_EXPIRED');
    }
    // Rebroadcast the exact same bytes. Never rebuild.
    if (a.signedTx) await conn.sendRawTransaction(Buffer.from(a.signedTx), { skipPreflight: true, maxRetries: 0 }).catch(() => {});
    await new Promise((r) => setTimeout(r, CONFIRM_POLL_MS));
  }
}

async function confirmSwap(attempt, tries = 5) {
  for (let i = 0; i < tries; i++) {
    try {
      await swapService.confirm({ quoteId: attempt.swapQuoteId, txSignature: attempt.txSignature });
      return;
    } catch (e) {
      if (e.status && e.status < 500) { console.error(`[tappay] Swap and Pay confirm ${attempt.swapQuoteId}: ${e.code}`); return; }
      await new Promise((r) => setTimeout(r, 2000 * (i + 1)));
    }
  }
  // The DYNK backend's own expiry job checks the chain (it knows the tx id from cosign).
  console.error(`[tappay] Swap and Pay confirm ${attempt.swapQuoteId} not delivered; the DYNK backend will reconcile from the chain.`);
}

async function failAfterSend(attempt, code) {
  const order = await release(attempt, code);
  if (order) pushOutcome(await withMerchant(order), attempt.customerPubkey, 'FAILED');
  // Failed on-chain or never landed: no tokens moved, the reservation can go.
  if (attempt.swapQuoteId) await releaseSwap(attempt.swapQuoteId);
  if (order) notifyTerminal(order, 'FAILED', { code });
  publishOrderEvent(attempt.orderId, { status: 'FAILED', customerPubkey: attempt.customerPubkey, code });
}

async function finalize(attempt) {
  const order = await prisma.order.findUnique({ where: { id: attempt.orderId }, include: { merchant: { include: { revenueSplitRules: { include: { destinationWallet: true } } } } } });
  let parsed = null;
  for (let i = 0; i < 10 && !parsed; i++) {
    parsed = await tapPay.connection.getParsedTransaction(attempt.txSignature, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 }).catch(() => null);
    if (!parsed) await new Promise((r) => setTimeout(r, 1000));
  }
  // Confirmed but not readable yet: try again later, never decide without it.
  if (!parsed) return 'RETRY';
  // The transaction landed, so the DYNK top-up moved: the DYNK backend checks
  // its own leg on-chain and records the direct-buy sale.
  if (attempt.option === 'SWAP') confirmSwap(attempt);
  const mint = new PublicKey(order.tapPayMint);
  const ata = (owner) => getAssociatedTokenAddressSync(mint, new PublicKey(owner), true, tapPay.mint.programId).toBase58();
  try {
    verifyTapPayTransaction(parsed, {
      mint: order.tapPayMint,
      customer: attempt.customerPubkey,
      customerAta: ata(attempt.customerPubkey),
      merchantAta: ata(order.tapPayRecipient),
      amount: attempt.amount,
      feeCollectorAta: BigInt(attempt.fee) > 0n ? ata(tapPay.cfg.feeCollector.toBase58()) : null,
      fee: attempt.fee,
      reference: order.referenceKey,
    });
  } catch (e) {
    // The transaction landed but does not prove this payment. Never PAID;
    // keep the lock and flag it for a person to review.
    await prisma.paymentAttempt.update({ where: { id: attempt.id }, data: { status: 'FAILED', failureCode: `VERIFY_FAILED:${e.message}` } });
    await prisma.order.updateMany({ where: { id: order.id, paymentLock: attempt.id }, data: { status: 'PAYMENT_FAILED' } });
    await prisma.auditLog.create({ data: { merchantId: order.merchantId, action: 'TAPPAY_VERIFY_FAILED', resource: 'ORDER', resourceId: order.id, metadata: { txSignature: attempt.txSignature, reason: e.message } } }).catch(() => {});
    console.error(`[tappay] ${attempt.txSignature} confirmed but failed verification: ${e.message}`);
    publishOrderEvent(order.id, { status: 'FAILED', customerPubkey: attempt.customerPubkey, code: 'VERIFY_FAILED' });
    return;
  }

  await bookPaid(order, attempt);
}

/**
 * Books a verified, confirmed payment: PAID (only while this attempt holds the
 * lock), Transaction + settlement rows, signed receipt, P&L, terminal notify.
 * Anything else that lands for the order becomes a DuplicatePayment.
 */
async function bookPaid(order, attempt) {
  const confirmedAt = new Date();
  const receipt = signReceipt({
    orderId: order.id,
    txSignature: attempt.txSignature,
    amount: attempt.amount,
    mint: order.tapPayMint,
    merchantWallet: order.tapPayRecipient,
    merchantName: order.merchant.tradingName,
    confirmedAt: confirmedAt.toISOString(),
  }, { kid: tapPay.keys.activeKid, privateKey: tapPay.keys.intentKeys.get(tapPay.keys.activeKid).privateKey });

  const decimals = tapPay.mint.decimals;
  const totalAUD = parseFloat(order.subtotalAUD.toString());
  const tokenAmount = formatUnits(attempt.amount, decimals).replace(/^(\d+\.\d{6})\d+$/, '$1');
  const booked = await prisma.$transaction(async (tx) => {
    const paid = await tx.order.updateMany({
      where: { id: order.id, paymentLock: attempt.id, status: 'SUBMITTED' },
      data: { status: 'PAID', paidAt: confirmedAt, customerWallet: attempt.customerPubkey },
    });
    if (paid.count !== 1) {
      await tx.duplicatePayment.create({ data: { orderId: order.id, txSignature: attempt.txSignature, note: `Order was ${order.status} when this payment confirmed.` } });
      return false;
    }
    const recorded = await tx.transaction.create({
      data: {
        merchantId: order.merchantId, orderId: order.id, blockchain: 'solana', token: 'DYNK', amount: tokenAmount,
        senderAddress: attempt.customerPubkey, receiverAddress: order.tapPayRecipient, txHash: attempt.txSignature, status: 'confirmed',
      },
    });
    for (const rule of order.merchant.revenueSplitRules) {
      const share = rule.basisPoints / 10000;
      await tx.settlementTransaction.create({
        data: {
          transactionId: recorded.id, bucket: rule.bucket, basisPoints: rule.basisPoints, amountAUD: totalAUD * share,
          tokenAmount: Number(tokenAmount) * share, tokenSymbol: 'DYNK', destinationWallet: rule.destinationWallet.address,
          settlementTxHash: attempt.txSignature, status: 'settled',
        },
      });
    }
    await tx.paymentAttempt.update({ where: { id: attempt.id }, data: { status: 'CONFIRMED', receipt } });
    return true;
  });
  if (!booked) {
    await prisma.paymentAttempt.update({ where: { id: attempt.id }, data: { status: 'CONFIRMED', receipt, failureCode: 'DUPLICATE_PAYMENT' } });
    console.warn(`[tappay] duplicate payment ${attempt.txSignature} on order ${order.orderNumber}: flagged for refund`);
    return;
  }
  publishOrderEvent(order.id, { status: 'CONFIRMED', customerPubkey: attempt.customerPubkey, txSignature: attempt.txSignature, receipt });
  pushOutcome(order, attempt.customerPubkey, 'CONFIRMED');
  import('../devices/deviceHub.js').then(({ deviceHub }) => deviceHub.broadcast(order.merchantId, { type: 'ORDER_UPDATED', orderId: order.id, status: 'PAID' })).catch(() => {});
  try { recordCryptoReceipt(order.merchantId, 'DYNK', Number(tokenAmount), parseFloat(order.quotePrice.toString()), order.orderNumber); } catch { /* P&L is best effort */ }
  terminalGateway.setSuccess(order.terminalId, { orderId: order.id, txHash: attempt.txSignature, tokenSymbol: 'DYNK', amount: tokenAmount, receipt })
    .catch((e) => console.warn('[tappay] terminal notify:', e.message));
}

// ── Website wallets (phones without DYNK) ───────────────────────────

/**
 * Solana Pay transaction request for a tap-and-pay order: the same strict
 * transaction (transferChecked to the merchant with the reference, the
 * network fee), but the customer's wallet pays the Solana fee and rent,
 * because a browser wallet can't take a sponsor co-signature.
 */
export async function buildForWebWallet({ orderId, account }) {
  requireReady();
  const order = await openOrderWithTerms(orderId);
  const customer = parsePubkey(account, 'BAD_CUSTOMER_PUBKEY').toBase58();
  const built = await buildDirectTransaction({
    connection: tapPay.connection, sponsor: tapPay.keys.sponsor, feePayer: customer, customer,
    mint: order.tapPayMint, tokenProgram: tapPay.mint.programId, decimals: tapPay.mint.decimals,
    merchant: order.tapPayRecipient, amount: BigInt(order.tapPayAmount),
    feeCollector: tapPay.cfg.feeCollector?.toBase58(), fee: BigInt(order.tapPayFee), reference: order.referenceKey,
    computeUnitLimit: tapPay.cfg.computeUnitLimit, priorityFeeMicroLamports: tapPay.cfg.priorityFeeMicroLamports,
  }).catch(() => { throw new TapPayError(503, 'RPC_UNAVAILABLE', 'Could not reach Solana to build the payment.'); });
  const merchant = await prisma.merchant.findUnique({ where: { id: order.merchantId } });
  return { transaction: built.unsignedTx.toString('base64'), message: `Pay ${merchant?.tradingName || 'merchant'} · Order #${order.displayNumber}` };
}

const PAID_STATUSES = ['PAID', 'SETTLING', 'SETTLED', 'RECEIPT_READY', 'REFUNDED'];

/**
 * Checks one transaction that carries a tap-and-pay order's reference (a
 * website wallet paid it). Books it only if the chain proves it paid this
 * order: authority, amounts, mint, recipient, reference. Late but real
 * payments are booked too (the money moved); a second one becomes a
 * DuplicatePayment.
 */
export async function confirmWebSignature(order, txSignature) {
  if (!tapPay.ready) return { status: 'NOT_READY' };
  const known = await prisma.paymentAttempt.findUnique({ where: { txSignature: String(txSignature) } });
  if (known) return { status: known.status };
  const parsed = await tapPay.connection.getParsedTransaction(String(txSignature), { commitment: 'confirmed', maxSupportedTransactionVersion: 0 }).catch(() => null);
  if (!parsed) return { status: 'PENDING' };
  if (parsed.meta?.err) return { status: 'FAILED_ON_CHAIN' };

  const mint = new PublicKey(order.tapPayMint);
  const ata = (owner) => getAssociatedTokenAddressSync(mint, new PublicKey(owner), true, tapPay.mint.programId).toBase58();
  const merchantAta = ata(order.tapPayRecipient);
  const customer = transferAuthority(parsed, merchantAta);
  if (!customer) return { status: 'NOT_A_PAYMENT' };
  try {
    verifyTapPayTransaction(parsed, {
      mint: order.tapPayMint, customer, customerAta: ata(customer), merchantAta,
      amount: order.tapPayAmount,
      feeCollectorAta: BigInt(order.tapPayFee) > 0n ? ata(tapPay.cfg.feeCollector.toBase58()) : null,
      fee: order.tapPayFee, reference: order.referenceKey,
    });
  } catch (e) {
    return { status: 'NOT_A_PAYMENT', reason: e.message };
  }

  let attempt;
  try {
    attempt = await prisma.paymentAttempt.create({
      data: { orderId: order.id, channel: 'WEBSITE', customerPubkey: customer, status: 'SUBMITTED', amount: BigInt(order.tapPayAmount), fee: BigInt(order.tapPayFee), txSignature: String(txSignature) },
    });
  } catch {
    const again = await prisma.paymentAttempt.findUnique({ where: { txSignature: String(txSignature) } });
    return { status: again?.status || 'PENDING' }; // another check got here first
  }
  const locked = await prisma.order.updateMany({
    where: { id: order.id, paymentLock: null, status: { notIn: PAID_STATUSES } },
    data: { paymentLock: attempt.id, status: 'SUBMITTED' },
  });
  if (locked.count !== 1) {
    await prisma.duplicatePayment.create({ data: { orderId: order.id, txSignature: String(txSignature), note: 'Website wallet payment for an order that was already paid or being paid.' } }).catch(() => {});
    await prisma.paymentAttempt.update({ where: { id: attempt.id }, data: { status: 'CONFIRMED', failureCode: 'DUPLICATE_PAYMENT' } });
    return { status: 'DUPLICATE' };
  }
  const full = await prisma.order.findUnique({ where: { id: order.id }, include: { merchant: { include: { revenueSplitRules: { include: { destinationWallet: true } } } } } });
  await bookPaid(full, attempt);
  return { status: 'CONFIRMED' };
}

/** Looks up references of recent tap-and-pay orders for website wallet payments. */
export async function watchWebPayments() {
  if (!tapPay.ready) return 0;
  const orders = await prisma.order.findMany({
    where: {
      tapPayAmount: { not: null }, paymentLock: null, status: { notIn: PAID_STATUSES },
      quoteExpiresAt: { gt: new Date(Date.now() - 10 * 60 * 1000) }, // late payments still count
    },
    take: 50,
    orderBy: { createdAt: 'desc' },
  });
  let booked = 0;
  for (const o of orders) {
    const sigs = await tapPay.connection.getSignaturesForAddress(new PublicKey(o.referenceKey), { limit: 5 }, 'confirmed').catch(() => []);
    for (const sig of sigs.filter((x) => !x.err)) {
      const r = await confirmWebSignature(o, sig.signature);
      if (r.status === 'CONFIRMED') booked += 1;
    }
  }
  return booked;
}

// ── Housekeeping ────────────────────────────────────────────────────────

/** Resumes confirmation for attempts that were in flight when the server stopped. */
export async function resumeInFlight() {
  if (!tapPay.ready) return;
  const inFlight = await prisma.paymentAttempt.findMany({ where: { status: 'SUBMITTED' }, select: { id: true } });
  for (const a of inFlight) watchAttempt(a.id);
}

/** Drops attempts that never reached submit (keeps no pubkeys from abandoned payments). */
export async function sweepAbandoned(now = Date.now()) {
  const where = { status: { in: ['PRECHECKED', 'BUILT', 'DECLINED', 'CUSTOMER_DECLINED'] }, createdAt: { lt: new Date(now - ATTEMPT_ABANDON_MS) } };
  for (const a of await prisma.paymentAttempt.findMany({ where: { ...where, swapQuoteId: { not: null } }, select: { swapQuoteId: true } })) {
    await releaseSwap(a.swapQuoteId);
  }
  const r = await prisma.paymentAttempt.deleteMany({ where });
  return r.count;
}

/** Looks for a second on-chain payment carrying a paid order's reference. */
export async function scanDuplicates({ sinceMs = 30 * 60 * 1000 } = {}) {
  if (!tapPay.ready) return 0;
  const orders = await prisma.order.findMany({
    where: { status: 'PAID', tapPayAmount: { not: null }, paidAt: { gt: new Date(Date.now() - sinceMs) } },
    include: { transaction: true },
  });
  let found = 0;
  for (const o of orders) {
    const sigs = await tapPay.connection.getSignaturesForAddress(new PublicKey(o.referenceKey), { limit: 10 }, 'confirmed').catch(() => []);
    for (const s of sigs) {
      if (s.err || s.signature === o.transaction?.txHash) continue;
      const known = await prisma.duplicatePayment.findUnique({ where: { txSignature: s.signature } });
      if (known) continue;
      await prisma.duplicatePayment.create({ data: { orderId: o.id, txSignature: s.signature, note: 'Another transaction carries this paid order\'s reference.' } });
      console.warn(`[tappay] second payment ${s.signature} for paid order ${o.orderNumber}: flagged for refund`);
      found += 1;
    }
  }
  return found;
}

export async function checkSponsorBalance() {
  if (!tapPay.ready) return null;
  const lamports = await tapPay.connection.getBalance(tapPay.keys.sponsor.publicKey, 'confirmed').catch(() => null);
  if (lamports != null && lamports < tapPay.cfg.sponsorMinLamports) {
    console.error(`[tappay] ALERT gas sponsor ${tapPay.keys.sponsor.publicKey.toBase58()} is low: ${lamports} lamports (min ${tapPay.cfg.sponsorMinLamports}).`);
  }
  return lamports;
}
