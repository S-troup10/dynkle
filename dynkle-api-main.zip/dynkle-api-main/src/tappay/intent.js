// Payment intent v1: the signed, compact description of one payment that the
// terminal shows as QR / NFC and the DYNK app verifies (online or offline).
//
// Layout (all integers little-endian), then an Ed25519 signature over every
// preceding byte. The whole thing travels as base64url after '#' in the link.
//
//   version u8 (=1) | kid u8 | orderId 16 | orderNumber u32 | itemCount u16 |
//   terminalId 16 | merchantWallet 32 | mint 32 | amount u64 (base units) |
//   decimals u8 | fiatAmount u64 (cents) | currency 3 (ASCII) | reference 32 |
//   expiresAt u32 (unix s) | bleSessionId 8 | terminalEphemeralPub 32 (X25519) |
//   merchantNameLen u8 | merchantName (UTF-8, <= 24 B) | signature 64
//
// No blockhash, location or logo: every transaction is built server-side
// (spec v6, also for a tap, where the terminal sends this same intent over
// NFC together with the backend-built transaction). Max 289 B.

import crypto from 'crypto';
import { PublicKey } from '@solana/web3.js';

export const INTENT_VERSION = 1;
export const MAX_MERCHANT_NAME_BYTES = 24;
const SIG_LEN = 64;
const FIXED_LEN = 1 + 1 + 16 + 4 + 2 + 16 + 32 + 32 + 8 + 1 + 8 + 3 + 32 + 4 + 8 + 32 + 1;

export function uuidToBytes(uuid) {
  const hex = String(uuid).replace(/-/g, '');
  if (!/^[0-9a-fA-F]{32}$/.test(hex)) throw new Error(`INTENT_BAD_UUID: ${uuid}`);
  return Buffer.from(hex, 'hex');
}

export function bytesToUuid(b) {
  const h = Buffer.from(b).toString('hex');
  return `${h.slice(0, 8)}-${h.slice(8, 12)}-${h.slice(12, 16)}-${h.slice(16, 20)}-${h.slice(20)}`;
}

/** UTF-8 name cut to at most 24 bytes without splitting a character. */
export function clampName(name) {
  let out = '';
  for (const ch of String(name || '')) {
    if (Buffer.byteLength(out + ch, 'utf8') > MAX_MERCHANT_NAME_BYTES) break;
    out += ch;
  }
  return out;
}

function u64(v, field) {
  const n = BigInt(v);
  if (n < 0n || n > 0xFFFFFFFFFFFFFFFFn) throw new Error(`INTENT_RANGE: ${field}`);
  return n;
}

function fixed(buf, len, field) {
  const b = Buffer.from(buf);
  if (b.length !== len) throw new Error(`INTENT_LENGTH: ${field} must be ${len} bytes`);
  return b;
}

/** Serialises the unsigned body. */
export function encodeIntentBody(f) {
  const name = Buffer.from(clampName(f.merchantName), 'utf8');
  const currency = String(f.currency || '');
  if (!/^[A-Z]{3}$/.test(currency)) throw new Error('INTENT_BAD_CURRENCY');
  const b = Buffer.alloc(FIXED_LEN + name.length);
  let o = 0;
  o = b.writeUInt8(INTENT_VERSION, o);
  o = b.writeUInt8(f.kid, o);
  uuidToBytes(f.orderId).copy(b, o); o += 16;
  o = b.writeUInt32LE(f.orderNumber >>> 0, o);
  o = b.writeUInt16LE(Math.min(0xFFFF, f.itemCount >>> 0), o);
  uuidToBytes(f.terminalId).copy(b, o); o += 16;
  new PublicKey(f.merchantWallet).toBuffer().copy(b, o); o += 32;
  new PublicKey(f.mint).toBuffer().copy(b, o); o += 32;
  o = b.writeBigUInt64LE(u64(f.amount, 'amount'), o);
  o = b.writeUInt8(f.decimals, o);
  o = b.writeBigUInt64LE(u64(f.fiatAmount, 'fiatAmount'), o);
  b.write(currency, o, 3, 'ascii'); o += 3;
  new PublicKey(f.reference).toBuffer().copy(b, o); o += 32;
  o = b.writeUInt32LE(f.expiresAt >>> 0, o);
  fixed(f.bleSessionId, 8, 'bleSessionId').copy(b, o); o += 8;
  fixed(f.terminalEphemeralPub, 32, 'terminalEphemeralPub').copy(b, o); o += 32;
  o = b.writeUInt8(name.length, o);
  name.copy(b, o); o += name.length;
  return b;
}

/** Signs and returns the full intent bytes (body + signature). */
export function signIntent(fields, privateKey) {
  const body = encodeIntentBody(fields);
  const sig = crypto.sign(null, body, privateKey);
  return Buffer.concat([body, sig]);
}

/** Parses intent bytes. Does not verify; see verifyIntent. */
export function decodeIntent(bytes) {
  const b = Buffer.from(bytes);
  if (b.length < FIXED_LEN + SIG_LEN) throw new Error('INTENT_TOO_SHORT');
  let o = 0;
  const version = b.readUInt8(o); o += 1;
  if (version !== INTENT_VERSION) throw new Error(`INTENT_VERSION_UNSUPPORTED: ${version}`);
  const kid = b.readUInt8(o); o += 1;
  const orderId = bytesToUuid(b.subarray(o, o + 16)); o += 16;
  const orderNumber = b.readUInt32LE(o); o += 4;
  const itemCount = b.readUInt16LE(o); o += 2;
  const terminalId = bytesToUuid(b.subarray(o, o + 16)); o += 16;
  const merchantWallet = new PublicKey(b.subarray(o, o + 32)).toBase58(); o += 32;
  const mint = new PublicKey(b.subarray(o, o + 32)).toBase58(); o += 32;
  const amount = b.readBigUInt64LE(o); o += 8;
  const decimals = b.readUInt8(o); o += 1;
  const fiatAmount = b.readBigUInt64LE(o); o += 8;
  const currency = b.subarray(o, o + 3).toString('ascii'); o += 3;
  const reference = new PublicKey(b.subarray(o, o + 32)).toBase58(); o += 32;
  const expiresAt = b.readUInt32LE(o); o += 4;
  const bleSessionId = Buffer.from(b.subarray(o, o + 8)); o += 8;
  const terminalEphemeralPub = Buffer.from(b.subarray(o, o + 32)); o += 32;
  const nameLen = b.readUInt8(o); o += 1;
  if (nameLen > MAX_MERCHANT_NAME_BYTES) throw new Error('INTENT_LENGTH_MISMATCH');
  const rest = b.length - (o + nameLen);
  if (rest !== SIG_LEN) throw new Error('INTENT_LENGTH_MISMATCH');
  const merchantName = b.subarray(o, o + nameLen).toString('utf8'); o += nameLen;
  return {
    version, kid, orderId, orderNumber, itemCount, terminalId, merchantWallet, mint, amount, decimals,
    fiatAmount, currency, reference, expiresAt, bleSessionId, terminalEphemeralPub, merchantName,
    body: b.subarray(0, o), signature: b.subarray(o),
  };
}

/**
 * Verifies the signature with the public key for its kid.
 * @param {Map<number, import('crypto').KeyObject>} publicKeys kid -> Ed25519 public key
 */
export function verifyIntent(bytes, publicKeys, { now = Date.now() } = {}) {
  const intent = decodeIntent(bytes);
  const key = publicKeys.get(intent.kid);
  if (!key) throw new Error(`INTENT_UNKNOWN_KID: ${intent.kid}`);
  if (!crypto.verify(null, intent.body, key, intent.signature)) throw new Error('INTENT_BAD_SIGNATURE');
  if (intent.expiresAt * 1000 <= now) throw new Error('INTENT_EXPIRED');
  return intent;
}

export const toBase64Url = (bytes) => Buffer.from(bytes).toString('base64url');
export const fromBase64Url = (s) => Buffer.from(String(s), 'base64url');
