// Integer money for tap-and-pay. Prices arrive as decimals from the price
// service; they are converted ONCE into integer micro-units, and every amount
// after that is BigInt. Amounts the customer pays are rounded UP to the base
// unit, so the merchant never receives less than the bill.

import { getLivePrice } from '../services/priceService.js';

const MICRO = 1_000_000n;

/** Decimal number/string -> integer micro units (1e-6), rounded half up. */
export function toMicro(value) {
  const s = typeof value === 'number' ? value.toFixed(9) : String(value).trim();
  if (!/^\d+(\.\d+)?$/.test(s)) throw new Error(`PRICE_INVALID: ${value}`);
  const [w, f = ''] = s.split('.');
  const frac = (f + '0000000').slice(0, 7); // one extra digit for rounding
  let micro = BigInt(w) * MICRO + BigInt(frac.slice(0, 6));
  if (Number(frac[6]) >= 5) micro += 1n;
  return micro;
}

const ceilDiv = (a, b) => (a + b - 1n) / b;

/**
 * Fiat cents -> token base units at `priceMicro` (fiat micro-units per whole token).
 * base = cents * 10^decimals * 10^4 / priceMicro, rounded up.
 */
export function centsToBaseUnits(cents, priceMicro, decimals) {
  const c = BigInt(cents);
  const p = BigInt(priceMicro);
  if (c < 0n) throw new Error('AMOUNT_NEGATIVE');
  if (p <= 0n) throw new Error('PRICE_INVALID: zero');
  return ceilDiv(c * 10n ** BigInt(decimals) * 10_000n, p);
}

/** Fee in micro-USD -> fiat micro-units at `usdInFiatMicro` (fiat micro per 1 USD), rounded up. */
export function microUsdToFiatMicro(microUsd, usdInFiatMicro) {
  return ceilDiv(BigInt(microUsd) * BigInt(usdInFiatMicro), MICRO);
}

/** Fiat micro-units -> token base units, rounded up. */
export function fiatMicroToBaseUnits(fiatMicro, priceMicro, decimals) {
  if (BigInt(fiatMicro) === 0n) return 0n;
  return ceilDiv(BigInt(fiatMicro) * 10n ** BigInt(decimals), BigInt(priceMicro));
}

/** Base units -> fixed decimal string (display only). */
export function formatUnits(base, decimals) {
  const b = BigInt(base);
  const d = BigInt(10) ** BigInt(decimals);
  const frac = (b % d).toString().padStart(decimals, '0').replace(/0+$/, '');
  return frac ? `${b / d}.${frac}` : `${b / d}`;
}

/**
 * The server's decision on what this bill costs in DYNK.
 * @returns {{ amount: bigint, fee: bigint, priceMicro: bigint, feeFiatMicro: bigint, priceSource: string }}
 */
export async function quoteDynk({ billCents, decimals, platformFeeMicroUsd, prices = getLivePrice }) {
  const dynk = await prices('DYNK');
  const priceMicro = toMicro(dynk.priceAUD);
  const amount = centsToBaseUnits(billCents, priceMicro, decimals);
  let fee = 0n;
  let feeFiatMicro = 0n;
  if (BigInt(platformFeeMicroUsd) > 0n) {
    // USDC tracks USD; its AUD price converts the USD fee into AUD.
    const usd = await prices('USDC');
    feeFiatMicro = microUsdToFiatMicro(platformFeeMicroUsd, toMicro(usd.priceAUD));
    fee = fiatMicroToBaseUnits(feeFiatMicro, priceMicro, decimals);
  }
  return { amount, fee, priceMicro, feeFiatMicro, priceSource: dynk.source || 'unknown' };
}
