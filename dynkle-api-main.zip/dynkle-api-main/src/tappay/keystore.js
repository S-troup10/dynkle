// Encrypted keystore for the tap-and-pay platform keys:
//  - intent-signing keys (Ed25519, one per kid; signs intents and receipts)
//  - the gas sponsor key (Solana fee payer; holds a little SOL, moves no customer funds)
//
// File format (JSON): { v:1, kdf:{salt,N,r,p}, iv, tag, data } with data being
// AES-256-GCM over the plaintext JSON { activeKid, intentKeys:[{kid, seed}], sponsorSecretKey }.
// The passphrase comes from TAP_PAY_KEYSTORE_PASSPHRASE; the key material is
// never written in clear and never logged. Create or rotate with
// scripts/tappay-keygen.js.

import crypto from 'crypto';
import fs from 'fs';

const KDF = { N: 2 ** 15, r: 8, p: 1, keyLen: 32 };
// PKCS#8 DER prefix for an Ed25519 private key wrapping a 32-byte seed.
const ED25519_PKCS8_PREFIX = Buffer.from('302e020100300506032b657004220420', 'hex');

function deriveKey(passphrase, salt, kdf = KDF) {
  return crypto.scryptSync(passphrase, salt, kdf.keyLen ?? 32, { N: kdf.N, r: kdf.r, p: kdf.p, maxmem: 64 * 1024 * 1024 });
}

export function encryptKeystore(plain, passphrase) {
  if (!passphrase || passphrase.length < 12) throw new Error('KEYSTORE_PASSPHRASE_TOO_SHORT: use at least 12 characters.');
  const salt = crypto.randomBytes(16);
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', deriveKey(passphrase, salt), iv);
  const data = Buffer.concat([cipher.update(JSON.stringify(plain), 'utf8'), cipher.final()]);
  return {
    v: 1,
    kdf: { alg: 'scrypt', salt: salt.toString('base64'), N: KDF.N, r: KDF.r, p: KDF.p },
    iv: iv.toString('base64'),
    tag: cipher.getAuthTag().toString('base64'),
    data: data.toString('base64'),
  };
}

export function decryptKeystore(file, passphrase) {
  if (file?.v !== 1) throw new Error('KEYSTORE_VERSION: unsupported keystore file.');
  const key = deriveKey(passphrase, Buffer.from(file.kdf.salt, 'base64'), file.kdf);
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, Buffer.from(file.iv, 'base64'));
  decipher.setAuthTag(Buffer.from(file.tag, 'base64'));
  try {
    const plain = Buffer.concat([decipher.update(Buffer.from(file.data, 'base64')), decipher.final()]);
    return JSON.parse(plain.toString('utf8'));
  } catch {
    throw new Error('KEYSTORE_DECRYPT_FAILED: wrong passphrase or corrupted keystore.');
  }
}

export function ed25519FromSeed(seed) {
  const s = Buffer.from(seed);
  if (s.length !== 32) throw new Error('KEYSTORE_BAD_SEED: Ed25519 seeds are 32 bytes.');
  const privateKey = crypto.createPrivateKey({ key: Buffer.concat([ED25519_PKCS8_PREFIX, s]), format: 'der', type: 'pkcs8' });
  const publicKey = crypto.createPublicKey(privateKey);
  const raw = publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  return { privateKey, publicKey, publicKeyRaw: Buffer.from(raw) };
}

/**
 * Loads and validates the keystore.
 * @returns {{ activeKid:number, intentKeys:Map<number,{privateKey,publicKey,publicKeyRaw}>, sponsorSecretKey:Uint8Array }}
 */
export function loadKeystore(path, passphrase) {
  const plain = decryptKeystore(JSON.parse(fs.readFileSync(path, 'utf8')), passphrase);
  const intentKeys = new Map();
  for (const k of plain.intentKeys || []) {
    if (!Number.isInteger(k.kid) || k.kid < 0 || k.kid > 255) throw new Error('KEYSTORE_BAD_KID: kid must be 0-255.');
    intentKeys.set(k.kid, ed25519FromSeed(Buffer.from(k.seed, 'base64')));
  }
  if (!intentKeys.has(plain.activeKid)) throw new Error('KEYSTORE_NO_ACTIVE_KID: the active intent key is missing.');
  const sponsorSecretKey = Uint8Array.from(Buffer.from(plain.sponsorSecretKey || '', 'base64'));
  if (sponsorSecretKey.length !== 64) throw new Error('KEYSTORE_NO_SPONSOR: the gas sponsor key is missing.');
  return { activeKid: plain.activeKid, intentKeys, sponsorSecretKey };
}
