// Solana side of tap-and-pay: the single transaction builder, signature
// handling on the STORED message, and the on-chain check after confirmation.

import crypto from 'crypto';
import {
  ComputeBudgetProgram,
  Message,
  PublicKey,
  Transaction,
  TransactionInstruction,
} from '@solana/web3.js';
import {
  createAssociatedTokenAccountIdempotentInstruction,
  createTransferCheckedInstruction,
  getAssociatedTokenAddressSync,
} from '@solana/spl-token';

const ED25519_SPKI_PREFIX = Buffer.from('302a300506032b6570032100', 'hex');

/** Verifies a raw 64-byte Ed25519 signature by a Solana public key. */
export function verifyEd25519(pubkey, message, signature) {
  const raw = new PublicKey(pubkey).toBuffer();
  const key = crypto.createPublicKey({ key: Buffer.concat([ED25519_SPKI_PREFIX, raw]), format: 'der', type: 'spki' });
  const sig = Buffer.from(signature);
  return sig.length === 64 && crypto.verify(null, Buffer.from(message), key, sig);
}

export const sha256Hex = (bytes) => crypto.createHash('sha256').update(Buffer.from(bytes)).digest('hex');

/**
 * Builds the DIRECT payment (spec §6.1): compute budget, the merchant's ATA
 * created idempotently (sponsor pays rent), transferChecked customer ->
 * merchant with the reference, and the platform fee. The fee collector's ATA
 * is NOT created here: ensureFeeCollectorAta() makes sure it exists at
 * startup. Fee payer = gas sponsor. Used for QR and, since v6, for taps.
 *
 * Swap and Pay (`swapInstructions`): the DYNK backend's quoted instructions
 * (USDC customer -> treasury; DYNK vault -> customer, delegate as authority)
 * go between the account creation and the payment, so the customer holds the
 * topped-up DYNK before paying. The customer's own DYNK account is created
 * first (idempotent, sponsor pays) in case they never held DYNK.
 */
export async function buildDirectTransaction({
  connection, sponsor, customer, mint, tokenProgram, decimals,
  merchant, amount, feeCollector, fee, reference, computeUnitLimit, priorityFeeMicroLamports,
  feePayer = null, swapInstructions = null, recentBlockhash = null,
}) {
  const customerPk = new PublicKey(customer);
  // Fee payer and rent payer: the gas sponsor, or (website wallets, which can't
  // take a co-signature) the customer.
  const payerPk = feePayer ? new PublicKey(feePayer) : sponsor.publicKey;
  const mintPk = new PublicKey(mint);
  const merchantPk = new PublicKey(merchant);
  const customerAta = getAssociatedTokenAddressSync(mintPk, customerPk, false, tokenProgram);
  const merchantAta = getAssociatedTokenAddressSync(mintPk, merchantPk, true, tokenProgram);

  const tx = new Transaction();
  tx.add(ComputeBudgetProgram.setComputeUnitLimit({ units: computeUnitLimit }));
  if (priorityFeeMicroLamports > 0) tx.add(ComputeBudgetProgram.setComputeUnitPrice({ microLamports: priorityFeeMicroLamports }));
  tx.add(createAssociatedTokenAccountIdempotentInstruction(payerPk, merchantAta, merchantPk, mintPk, tokenProgram));
  if (swapInstructions?.length) {
    tx.add(createAssociatedTokenAccountIdempotentInstruction(payerPk, customerAta, customerPk, mintPk, tokenProgram));
    for (const ix of swapInstructions) tx.add(instructionFromJson(ix));
  }

  const pay = createTransferCheckedInstruction(customerAta, mintPk, merchantAta, customerPk, BigInt(amount), decimals, [], tokenProgram);
  pay.keys.push({ pubkey: new PublicKey(reference), isSigner: false, isWritable: false });
  tx.add(pay);

  let feeCollectorAta = null;
  if (BigInt(fee) > 0n) {
    const collectorPk = new PublicKey(feeCollector);
    feeCollectorAta = getAssociatedTokenAddressSync(mintPk, collectorPk, true, tokenProgram);
    tx.add(createTransferCheckedInstruction(customerAta, mintPk, feeCollectorAta, customerPk, BigInt(fee), decimals, [], tokenProgram));
  }

  // A blockhash fetched in parallel with the balance check (spec v6 §6.1), or a fresh one.
  const { blockhash, lastValidBlockHeight } = recentBlockhash || await connection.getLatestBlockhash('confirmed');
  tx.recentBlockhash = blockhash;
  tx.feePayer = payerPk;
  const messageBytes = Buffer.from(tx.serializeMessage());
  return {
    messageBytes,
    // Unsigned wire transaction for the phone (it signs messageBytes).
    unsignedTx: Buffer.from(tx.serialize({ requireAllSignatures: false, verifySignatures: false })),
    blockhash,
    lastValidBlockHeight,
    customerAta: customerAta.toBase58(),
    merchantAta: merchantAta.toBase58(),
    feeCollectorAta: feeCollectorAta?.toBase58() || null,
  };
}

export async function ensureFeeCollectorAta({ connection, sponsor, feeCollector, mint, tokenProgram }) {
  const mintPk = new PublicKey(mint);
  const owner = new PublicKey(feeCollector);
  const ata = getAssociatedTokenAddressSync(mintPk, owner, true, tokenProgram);
  if (await connection.getAccountInfo(ata, 'confirmed')) return 'EXISTS';
  const tx = new Transaction().add(createAssociatedTokenAccountIdempotentInstruction(sponsor.publicKey, ata, owner, mintPk, tokenProgram));
  const { blockhash, lastValidBlockHeight } = await connection.getLatestBlockhash('confirmed');
  tx.recentBlockhash = blockhash;
  tx.feePayer = sponsor.publicKey;
  tx.sign(sponsor);
  const sig = await connection.sendRawTransaction(tx.serialize());
  await connection.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, 'confirmed');
  return 'CREATED';
}

/** `{ programId, keys: [{ pubkey, isSigner, isWritable }], data (base64) }` -> instruction. */
export function instructionFromJson(ix) {
  return new TransactionInstruction({
    programId: new PublicKey(ix.programId),
    keys: ix.keys.map((k) => ({ pubkey: new PublicKey(k.pubkey), isSigner: Boolean(k.isSigner), isWritable: Boolean(k.isWritable) })),
    data: Buffer.from(String(ix.data || ''), 'base64'),
  });
}

/** The signer public keys a message needs, in order. */
export function requiredSigners(messageBytes) {
  const msg = Message.from(Buffer.from(messageBytes));
  return msg.accountKeys.slice(0, msg.header.numRequiredSignatures).map((k) => k.toBase58());
}

function shortvec(n) {
  const out = [];
  let v = n;
  for (;;) {
    let b = v & 0x7f;
    v >>= 7;
    if (v === 0) { out.push(b); break; }
    out.push(b | 0x80);
  }
  return Buffer.from(out);
}

/**
 * Builds the wire transaction from the STORED message and signatures, without
 * recompiling anything: what was signed is exactly what is sent.
 * @param {Map<string, Buffer>} signatures signer base58 -> 64-byte signature
 */
export function assembleSignedTransaction(messageBytes, signatures) {
  const signers = requiredSigners(messageBytes);
  const sigs = signers.map((s) => {
    const sig = signatures.get(s);
    if (!sig || Buffer.from(sig).length !== 64) throw new Error(`MISSING_SIGNATURE: ${s}`);
    if (!verifyEd25519(s, messageBytes, sig)) throw new Error(`BAD_SIGNATURE: ${s}`);
    return Buffer.from(sig);
  });
  return Buffer.concat([shortvec(sigs.length), ...sigs, Buffer.from(messageBytes)]);
}

/** Signs the stored message with a Keypair (the gas sponsor). */
export function signMessage(keypair, messageBytes) {
  const pkcs8 = Buffer.concat([Buffer.from('302e020100300506032b657004220420', 'hex'), Buffer.from(keypair.secretKey.subarray(0, 32))]);
  const key = crypto.createPrivateKey({ key: pkcs8, format: 'der', type: 'pkcs8' });
  return crypto.sign(null, Buffer.from(messageBytes), key);
}

/** Who authorised the transfer into merchantAta (the paying wallet), or null. */
export function transferAuthority(parsedTx, merchantAta) {
  const ixs = [
    ...(parsedTx?.transaction?.message?.instructions || []),
    ...((parsedTx?.meta?.innerInstructions || []).flatMap((i) => i.instructions)),
  ];
  const t = ixs.find((ix) => ['spl-token', 'spl-token-2022'].includes(ix.program) && ix.parsed?.type === 'transferChecked' && ix.parsed.info?.destination === merchantAta);
  return t ? (t.parsed.info.authority || t.parsed.info.multisigAuthority || null) : null;
}

/**
 * After confirmation: proves on-chain that this transaction paid this order.
 * Integer amounts from the token balance deltas (raw `amount` strings).
 */
export function verifyTapPayTransaction(parsedTx, { mint, customer, customerAta, merchantAta, amount, feeCollectorAta, fee, reference }) {
  if (!parsedTx) throw new Error('TX_NOT_FOUND');
  if (parsedTx.meta?.err) throw new Error(`TX_FAILED_ON_CHAIN: ${JSON.stringify(parsedTx.meta.err)}`);
  const keys = (parsedTx.transaction?.message?.accountKeys || []).map((k) => ({
    pubkey: typeof k === 'string' ? k : (k.pubkey?.toBase58?.() || String(k.pubkey)),
    signer: Boolean(k.signer),
  }));
  if (!keys.some((k) => k.pubkey === reference)) throw new Error('MISSING_REFERENCE');
  if (!keys.some((k) => k.pubkey === customer && k.signer)) throw new Error('WRONG_SIGNER');

  // The customer must be the authority of the exact transfers (being a signer
  // is not enough: the gas sponsor signs too).
  const ixs = [
    ...(parsedTx.transaction?.message?.instructions || []),
    ...((parsedTx.meta?.innerInstructions || []).flatMap((i) => i.instructions)),
  ];
  // The reference rides after the authority, so the RPC parser shows the
  // authority as `multisigAuthority` (the token program ignores extra accounts
  // for a plain wallet authority).
  const authorityOf = (i) => i.authority || i.multisigAuthority;
  const transfers = ixs.filter((ix) => ['spl-token', 'spl-token-2022'].includes(ix.program) && ix.parsed?.type === 'transferChecked');
  const paid = (dest, amt) => transfers.some((ix) => {
    const i = ix.parsed.info || {};
    return i.destination === dest && i.mint === mint && authorityOf(i) === customer
      && (!customerAta || i.source === customerAta) && BigInt(i.tokenAmount?.amount || '-1') === BigInt(amt);
  });
  if (!transfers.some((ix) => ix.parsed.info?.destination === merchantAta && authorityOf(ix.parsed.info) === customer)) throw new Error('WRONG_SIGNER');
  if (!transfers.some((ix) => ix.parsed.info?.destination === merchantAta && ix.parsed.info?.mint === mint)) throw new Error('WRONG_MINT');
  if (!paid(merchantAta, amount)) throw new Error('WRONG_AMOUNT');
  if (BigInt(fee) > 0n && !paid(feeCollectorAta, fee)) throw new Error('WRONG_FEE');

  const delta = (account) => {
    const idx = keys.findIndex((k) => k.pubkey === account);
    if (idx < 0) return 0n;
    const pre = (parsedTx.meta?.preTokenBalances || []).find((b) => b.accountIndex === idx);
    const post = (parsedTx.meta?.postTokenBalances || []).find((b) => b.accountIndex === idx);
    if (post && post.mint !== mint) throw new Error('WRONG_MINT');
    return BigInt(post?.uiTokenAmount?.amount || '0') - BigInt(pre?.uiTokenAmount?.amount || '0');
  };
  if (delta(merchantAta) !== BigInt(amount)) throw new Error('WRONG_AMOUNT');
  if (BigInt(fee) > 0n && delta(feeCollectorAta) !== BigInt(fee)) throw new Error('WRONG_FEE');
  return true;
}
