// Client for the DYNK backend's internal endpoints (session check, Swap and
// Pay service). Every request is HMAC-signed:
//
//   x-dynkle-ts:        unix milliseconds
//   x-dynkle-nonce:     16 random bytes, hex (single use on the receiving side)
//   x-dynkle-signature: hex HMAC-SHA256(DYNKLE_SERVICE_SECRET,
//                         ts + "." + nonce + "." + METHOD + "." + path + "." + sha256hex(body))
//
// The receiver accepts a 60 s window and rejects a repeated nonce.

import crypto from 'crypto';
import { demoSwapActive, demoSwapService } from './demoSwap.js';
import { resilientFetch, failureReason } from '../services/resilientFetch.js';

export function signServiceRequest({ secret, method, path, body = '', ts = Date.now(), nonce = crypto.randomBytes(16).toString('hex') }) {
  const bodyHash = crypto.createHash('sha256').update(body).digest('hex');
  const signature = crypto.createHmac('sha256', secret).update(`${ts}.${nonce}.${method.toUpperCase()}.${path}.${bodyHash}`).digest('hex');
  return { 'x-dynkle-ts': String(ts), 'x-dynkle-nonce': nonce, 'x-dynkle-signature': signature };
}

export class DynkServiceError extends Error {
  constructor(code, message, status = 502) { super(message); this.code = code; this.status = status; }
}

function settings(env = process.env) {
  const base = String(env.DYNK_INTERNAL_BASE_URL || '').replace(/\/$/, '');
  const secret = env.DYNKLE_SERVICE_SECRET || '';
  return { base, secret, configured: Boolean(base && secret.length >= 32) };
}

export function dynkServiceConfigured(env) { return settings(env).configured; }

export async function callDynk(method, path, payload, { env = process.env, timeoutMs = 5000, fetchImpl = fetch } = {}) {
  const s = settings(env);
  if (!s.configured) throw new DynkServiceError('DYNK_SERVICE_NOT_CONFIGURED', 'DYNK_INTERNAL_BASE_URL and DYNKLE_SERVICE_SECRET (32+ chars) are required.', 503);
  const body = payload === undefined ? '' : JSON.stringify(payload);
  const headers = { 'content-type': 'application/json', ...signServiceRequest({ secret: s.secret, method, path, body }) };
  let res;
  try {
    res = await fetchImpl(`${s.base}${path}`, { method, headers, body: body || undefined, signal: AbortSignal.timeout(timeoutMs) });
  } catch (e) {
    throw new DynkServiceError('DYNK_SERVICE_UNREACHABLE', 'The DYNK backend did not answer.', 503);
  }
  const json = await res.json().catch(() => ({}));
  if (!res.ok) throw new DynkServiceError(json.error || 'DYNK_SERVICE_ERROR', json.message || `DYNK backend returned ${res.status}.`, res.status >= 500 ? 502 : res.status);
  return json;
}

/**
 * Test mode (DYNK_SESSION_CHECK=profile): verify the session with the HOSTED DYNK
 * API's existing GET /api/auth/profile (same auth middleware as the internal
 * check: valid token, active user, session version), using the user's own
 * token, and take the Solana wallets from it. For local testing against
 * api.dynk.io, which doesn't have /internal yet. Production uses the HMAC call.
 */
const profileCache = new Map(); // sha256(token) -> { at, value }
const PROFILE_CACHE_MS = 2 * 60 * 60_000; // hosted profile is slow (it reads the DYNK balance on-chain); test mode only

// The hosted profile can take several seconds (it reads balances on-chain): keep its whole
// time limit, but try again at once when the connection itself failed (network blip).
const profileFetch = resilientFetch({ attemptTimeoutMs: 20_000, retries: 1, retryOnTimeout: false, label: 'dynk-login' });

async function verifyViaProfile(token, { env = process.env, fetchImpl = profileFetch } = {}) {
  const base = String(env.DYNK_API_BASE_URL || '').replace(/\/$/, '');
  if (!base) throw new DynkServiceError('DYNK_SERVICE_NOT_CONFIGURED', 'DYNK_API_BASE_URL is required for DYNK_SESSION_CHECK=profile.', 503);
  const key = crypto.createHash('sha256').update(token).digest('hex');
  const hit = profileCache.get(key);
  if (hit && Date.now() - hit.at < PROFILE_CACHE_MS) return hit.value;
  let res;
  try {
    res = await fetchImpl(`${base}/api/auth/profile`, { headers: { authorization: `Bearer ${token}`, accept: 'application/json' } });
  } catch (e) {
    console.warn(`[dynk] login check failed: ${failureReason(e)}`);
    throw new DynkServiceError('DYNK_SERVICE_UNREACHABLE', 'The DYNK backend did not answer.', 503);
  }
  if (res.status === 401 || res.status === 403) throw new DynkServiceError('UNAUTHENTICATED', 'The DYNK session is not valid.', 401);
  if (!res.ok) throw new DynkServiceError('DYNK_SERVICE_ERROR', `DYNK backend returned ${res.status}.`, 502);
  const json = await res.json().catch(() => ({}));
  const user = json?.data?.user;
  if (!user?.id) throw new DynkServiceError('UNAUTHENTICATED', 'The DYNK session is not valid.', 401);
  const wallets = new Set();
  if (user.primary_wallet_address) wallets.add(String(user.primary_wallet_address));
  for (const a of json?.data?.wallet_accounts || []) {
    if (String(a?.chain_code || '').toLowerCase() === 'solana' && a.address) wallets.add(String(a.address));
  }
  const value = { userId: user.id, wallets: [...wallets] };
  profileCache.set(key, { at: Date.now(), value });
  if (profileCache.size > 1000) profileCache.delete(profileCache.keys().next().value);
  return value;
}

/**
 * Verifies a DYNK user session token with the DYNK backend.
 * @returns {Promise<{ userId: string|number, wallets: string[] }>} Solana wallets of that user
 */
export async function verifyDynkSession(token, opts = {}) {
  if (!token) throw new DynkServiceError('UNAUTHENTICATED', 'Sign in to DYNK first.', 401);
  if ((opts.env || process.env).DYNK_SESSION_CHECK === 'profile') return verifyViaProfile(token, opts);
  const r = await callDynk('POST', '/internal/session/verify', { token }, opts);
  if (!r?.userId || !Array.isArray(r.wallets)) throw new DynkServiceError('UNAUTHENTICATED', 'The DYNK session is not valid.', 401);
  return { userId: r.userId, wallets: r.wallets.map(String) };
}

// ── Swap and Pay (DYNK backend, spec §8) ───────────────────────────────
//
// quote   { customerPubkey, dynkShortfall, orderRef, expiresAt, dryRun? }
//      -> { quoteId (null on dryRun), usdcMint, usdcAmount, dynkMint, dynkAmount,
//           treasuryUsdcAccount, vault, delegate, instructions: [ix, ix], expiresAt }
//         instructions = [USDC customer -> treasury, DYNK vault -> customer (delegate signs)]
//         ix = { programId, keys: [{ pubkey, isSigner, isWritable }], data (base64) }
// cosign  { quoteId, message (base64) } -> { signature (base64), delegate }   exact match, single use
// confirm { quoteId, txSignature }      -> { status }                        verified on-chain, sale recorded
// release { quoteId }                   -> { released }
// Amounts are integer strings in base units.

/** Push backup for payment outcomes (DYNK backend sends it via Firebase). */
export const pushService = {
  paymentStatus: (body, opts) => callDynk('POST', '/internal/push/payment-status', body, opts),
};

// The DYNK backend when configured; otherwise, only with DEMO_MODE, the local demo stand-in (demoSwap.js).
const useDemoSwap = (opts) => {
  const env = opts?.env || process.env;
  return !dynkServiceConfigured(env) && demoSwapActive(env);
};

export const swapService = {
  quote: (body, opts) => (useDemoSwap(opts) ? demoSwapService.quote(body, opts) : callDynk('POST', '/internal/swap/quote', body, opts)),
  cosign: (body, opts) => (useDemoSwap(opts) ? demoSwapService.cosign(body, opts) : callDynk('POST', '/internal/swap/cosign', body, opts)),
  confirm: (body, opts) => (useDemoSwap(opts) ? demoSwapService.confirm(body, opts) : callDynk('POST', '/internal/swap/confirm', body, opts)),
  release: (body, opts) => (useDemoSwap(opts) ? demoSwapService.release(body, opts) : callDynk('POST', '/internal/swap/release', body, opts)),
};

/** Can Swap and Pay be offered at all (DYNK backend, or the demo stand-in)? */
export function swapServiceAvailable(env = process.env) {
  return dynkServiceConfigured(env) || demoSwapActive(env);
}
