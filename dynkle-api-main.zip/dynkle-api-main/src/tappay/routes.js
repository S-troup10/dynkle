// Tap-and-pay HTTP endpoints.
//
//   Terminal (device JWT)             /api/terminals/me/payments..., /api/terminals/me/tap/...
//   Terminal relaying the phone (BLE) /api/pay/relay/...
//   DYNK app (DYNK user session)      /api/pay/orders/..., /api/pay/online/..., /api/pay/balances,
//                                     /api/pay/tap/late-submit
//   Public                            /api/pay/status, /api/pay/intent-keys, /o/:orderId
//
// Every route is rate limited. Errors are { error, message }.

import { Router } from 'express';
import { rateLimit, ipKeyGenerator } from 'express-rate-limit';
import prisma from '../db.js';
import { requireDevice } from '../devices/deviceAuth.js';
import { priceCart, CartPricingError } from '../devices/pricing.js';
import { verifyDynkSession, DynkServiceError } from './dynkService.js';
import {
  tapPay, TapPayError, requireReady, createPayment, refreshIntent, currentIntent, display, bill,
  precheck, build, submit, attemptStatus, decline, feeCentsOf, tapPrepare, tapSubmit, balances, latestOutcome,
} from './service.js';
import { subscribeOrderEvents } from './events.js';

const UUID = /^[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}$/i;

function limiter(limit, windowMs = 60_000) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    // Per device or per DYNK user when known, otherwise per IP.
    keyGenerator: (req) => (req.device?.id ? `d:${req.device.id}` : req.dynkUser ? `u:${req.dynkUser.userId}` : ipKeyGenerator(req.ip)),
    handler: (req, res) => res.status(429).json({ error: 'RATE_LIMITED', message: 'Too many requests. Wait a moment and try again.' }),
  });
}

const wrap = (fn) => async (req, res) => {
  try {
    res.json(await fn(req, res));
  } catch (e) {
    if (e instanceof TapPayError || e instanceof DynkServiceError) {
      return res.status(e.status).json({ error: e.code, message: e.message, ...(e.missing?.length ? { missing: e.missing } : {}) });
    }
    console.error('[tappay] route error:', e.message);
    res.status(500).json({ error: 'INTERNAL_ERROR', message: 'Something went wrong. Try again.' });
  }
};

function orderIdFrom(v) {
  const id = String(v || '');
  if (!UUID.test(id)) throw new TapPayError(400, 'BAD_ORDER_ID', 'orderId must be a UUID.');
  return id;
}

/** The terminal may only relay for orders on its own counter. */
async function assertDeviceOrder(req, orderId) {
  const o = await prisma.order.findUnique({ where: { id: orderId }, select: { merchantId: true, terminalId: true } });
  if (!o || o.merchantId !== req.device.merchantId || o.terminalId !== req.device.terminalId) {
    throw new TapPayError(404, 'ORDER_NOT_FOUND', 'Order not found.');
  }
}

/** DYNK user session, verified by the DYNK backend (no shared signing secret). */
async function requireDynkUser(req, res, next) {
  try {
    const h = req.headers.authorization || '';
    req.dynkUser = await verifyDynkSession(h.startsWith('Bearer ') ? h.slice(7) : '');
    next();
  } catch (e) {
    const status = e.status || 401;
    res.status(status).json({ error: e.code || 'UNAUTHENTICATED', message: e.message });
  }
}

function assertOwnWallet(req, customerPubkey) {
  if (!req.dynkUser.wallets.includes(String(customerPubkey))) {
    throw new TapPayError(403, 'WALLET_NOT_YOURS', 'That wallet is not linked to your DYNK account.');
  }
}

const router = Router();

// One line per payment request, for diagnosing device tests:
//   [pay] POST /api/terminals/me/tap/prepare order=1b9d6bcd 200 result=OK 812ms
// Never the body: no wallets, signatures, balances or tokens.
router.use((req, res, next) => {
  if (!/^\/(api\/pay|api\/terminals\/me\/(tap|payments)|o\/)/.test(req.path)) return next();
  const started = Date.now();
  const json = res.json.bind(res);
  let outcome = '';
  res.json = (body) => {
    if (body && typeof body === 'object') outcome = body.error ? `error=${body.error}` : [body.result && `result=${body.result}`, body.status && `status=${body.status}`].filter(Boolean).join(' ');
    return json(body);
  };
  res.on('finish', () => {
    const order = String(req.body?.orderId || req.params?.orderId || (req.path.match(/[0-9a-f]{8}-[0-9a-f-]{27}/i) || [''])[0]).slice(0, 8);
    const path = req.path.replace(/[0-9a-f]{8}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{4}-[0-9a-f]{12}/gi, ':id');
    console.log(`[pay] ${req.method} ${path}${order ? ` order=${order}` : ''} ${res.statusCode}${outcome ? ` ${outcome}` : ''} ${Date.now() - started}ms`);
  });
  next();
});

// Session checks call the DYNK backend: limit by IP before that happens.
router.use(['/api/pay/online', '/api/pay/orders', '/api/pay/balances', '/api/pay/tap'], limiter(120));

// ── Public ──────────────────────────────────────────────────────────────

router.get('/api/pay/status', limiter(60), (req, res) => {
  res.json({ ready: tapPay.ready, reason: tapPay.reason, missing: tapPay.missing });
});

// Website checkout settings: "Get DYNK" store links (from env, https only).
router.get('/api/pay/config', limiter(60), (req, res) => {
  const https = (v) => (typeof v === 'string' && /^https:\/\//.test(v) ? v : null);
  res.json({
    iosStoreUrl: https(process.env.DYNK_IOS_STORE_URL),
    androidStoreUrl: https(process.env.DYNK_ANDROID_STORE_URL),
    // Pages show demo-only controls (simulate buttons) only when this is true (spec D12).
    demoMode: process.env.DEMO_MODE === 'true',
  });
});

router.get('/api/pay/intent-keys', limiter(60), wrap(async () => {
  requireReady();
  return {
    activeKid: tapPay.keys.activeKid,
    keys: [...tapPay.keys.intentKeys].map(([kid, k]) => ({ kid, alg: 'Ed25519', publicKey: k.publicKeyRaw.toString('base64') })),
  };
}));

// Website checkout for phones without DYNK. The '#intent' never reaches the
// server; the browser keeps it across this redirect and pay.html strips it.
router.get('/o/:orderId', limiter(120), (req, res) => {
  const id = String(req.params.orderId || '');
  if (!UUID.test(id)) return res.status(404).send('Not found');
  res.redirect(302, `/pay.html?orderId=${encodeURIComponent(id)}&via=link`);
});

// ── Terminal ────────────────────────────────────────────────────────────

router.post('/api/terminals/me/payments', requireDevice, limiter(30), wrap(async (req) => {
  const body = req.body || {};
  let billCents = Number(body.totalCents);
  let items = [];
  const tipCents = Math.max(0, Math.round(Number(body.tipCents) || 0));
  if (Array.isArray(body.items) && body.items.length) {
    // Register sale: priced from the catalog, never from the device.
    const products = await prisma.product.findMany({ where: { merchantId: req.device.merchantId, active: true } });
    try {
      const priced = priceCart(products, body.items);
      billCents = priced.subtotalCents;
      items = priced.lines.map((l) => ({ name: l.name, price: l.unitCents / 100, quantity: l.qty, qty: l.qty, productId: l.productId }));
    } catch (e) {
      if (e instanceof CartPricingError) throw new TapPayError(409, e.code, e.message);
      throw e;
    }
    if (tipCents > 0) items.push({ name: 'Tip', price: tipCents / 100, quantity: 1, qty: 1, isTip: true });
  }
  if (!Number.isInteger(billCents) || billCents <= 0) throw new TapPayError(400, 'INVALID_AMOUNT', 'Enter an amount above zero.');
  const created = await createPayment({
    device: req.device, billCents: billCents + tipCents, items,
    terminalEphemeralPub: body.terminalEphemeralPub, bleSessionId: body.bleSessionId,
  });
  return {
    orderId: created.order.id,
    orderNumber: created.order.displayNumber,
    totalCents: billCents + tipCents,
    feeCents: feeCentsOf(created.order),
    currency: 'AUD',
    intent: created.intent, // QR and tap (spec v6)
    link: created.link,
    expiresAt: created.expiresAt,
    ttlSeconds: created.ttlSeconds,
    dynk: created.dynk,
  };
}));

router.post('/api/terminals/me/payments/:orderId/intent', requireDevice, limiter(30), wrap(async (req) =>
  refreshIntent({ device: req.device, orderId: orderIdFrom(req.params.orderId), terminalEphemeralPub: req.body?.terminalEphemeralPub, bleSessionId: req.body?.bleSessionId })));

router.get('/api/terminals/me/payments/:orderId/display', requireDevice, limiter(60), wrap(async (req) => {
  const orderId = orderIdFrom(req.params.orderId);
  await assertDeviceOrder(req, orderId);
  const d = await display(orderId);
  return { merchantName: d.merchantName, location: d.location }; // MERCHANT_DISPLAY: text only (no logo over BLE)
}));

// ── Terminal: Tap and Pay (Cases 3 and 4), spec v6 ─────────────────────

// During the tap: the phone's public key (GET_IDENTITY) -> balance check and
// build in parallel -> OK {quoteId, transaction, tapQuote} or INSUFFICIENT {decline}.
// phoneOnline is the GET_IDENTITY flag (labels the channel: Tap · Online / Offline).
router.post('/api/terminals/me/tap/prepare', requireDevice, limiter(30), wrap(async (req) => {
  const orderId = orderIdFrom(req.body?.orderId);
  await assertDeviceOrder(req, orderId);
  return tapPrepare({ orderId, customerPubkey: req.body.customerPubkey, phoneOnline: req.body.phoneOnline === true });
}));

// The phone's partial signature on that quote (read during the tap, or relayed over Bluetooth).
router.post('/api/terminals/me/tap/submit', requireDevice, limiter(20), wrap(async (req) => {
  const orderId = orderIdFrom(req.body?.orderId);
  await assertDeviceOrder(req, orderId);
  return tapSubmit({ orderId, quoteId: req.body.quoteId, customerPubkey: req.body.customerPubkey, signature: req.body.signature });
}));

// ── Terminal relaying the phone over Bluetooth (Cases 1-2) ──

router.post('/api/pay/relay/precheck', requireDevice, limiter(30), wrap(async (req) => {
  const orderId = orderIdFrom(req.body?.orderId);
  await assertDeviceOrder(req, orderId);
  // phoneOnline comes from the phone's PUBKEY message; only `true` makes Swap and Pay possible (Case 1).
  return precheck({ orderId, customerPubkey: req.body.customerPubkey, phoneEphemeralPub: req.body.phoneEphemeralPub, channel: 'QR_BLE', phoneOnline: req.body.phoneOnline === true });
}));

router.post('/api/pay/relay/build', requireDevice, limiter(30), wrap(async (req) => {
  const orderId = orderIdFrom(req.body?.orderId);
  await assertDeviceOrder(req, orderId);
  return build({ orderId, customerPubkey: req.body.customerPubkey, option: req.body.option || 'DIRECT', channel: 'QR_BLE' });
}));

router.post('/api/pay/relay/submit', requireDevice, limiter(20), wrap(async (req) => {
  const orderId = orderIdFrom(req.body?.orderId);
  await assertDeviceOrder(req, orderId);
  return submit({ orderId, quoteId: req.body.quoteId, customerPubkey: req.body.customerPubkey, signature: req.body.signature, channel: 'QR_BLE' });
}));

router.get('/api/pay/relay/attempts/:quoteId', requireDevice, limiter(120), wrap(async (req) => {
  const orderId = orderIdFrom(req.query.orderId);
  await assertDeviceOrder(req, orderId);
  return attemptStatus({ quoteId: req.params.quoteId, orderId });
}));

router.post('/api/pay/relay/decline', requireDevice, limiter(30), wrap(async (req) => {
  const orderId = orderIdFrom(req.body?.orderId);
  await assertDeviceOrder(req, orderId);
  // The terminal already knows (BYE DECLINED); just record it.
  return decline({ orderId, customerPubkey: req.body.customerPubkey, channel: 'QR_BLE', notifyTerminal: false });
}));

// ── DYNK app (online path) ──────────────────────────────────────────────

router.get('/api/pay/orders/:orderId/intent', requireDynkUser, limiter(60), wrap(async (req) => currentIntent(orderIdFrom(req.params.orderId))));
router.get('/api/pay/orders/:orderId/display', requireDynkUser, limiter(60), wrap(async (req) => display(orderIdFrom(req.params.orderId))));
// Itemised bill of a paid order, for the payer only (bill split in the DYNK app).
router.get('/api/pay/orders/:orderId/bill', requireDynkUser, limiter(60), wrap(async (req) => bill(orderIdFrom(req.params.orderId), req.dynkUser.wallets)));

router.post('/api/pay/online/precheck', requireDynkUser, limiter(30), wrap(async (req) => {
  assertOwnWallet(req, req.body?.customerPubkey);
  return precheck({ orderId: orderIdFrom(req.body.orderId), customerPubkey: req.body.customerPubkey, phoneEphemeralPub: req.body.phoneEphemeralPub, channel: 'QR_INTERNET' });
}));

router.post('/api/pay/online/build', requireDynkUser, limiter(30), wrap(async (req) => {
  assertOwnWallet(req, req.body?.customerPubkey);
  return build({ orderId: orderIdFrom(req.body.orderId), customerPubkey: req.body.customerPubkey, option: req.body.option || 'DIRECT', channel: 'QR_INTERNET' });
}));

router.post('/api/pay/online/submit', requireDynkUser, limiter(20), wrap(async (req) => {
  assertOwnWallet(req, req.body?.customerPubkey);
  return submit({ orderId: orderIdFrom(req.body.orderId), quoteId: req.body.quoteId, customerPubkey: req.body.customerPubkey, signature: req.body.signature, channel: 'QR_INTERNET' });
}));

router.get('/api/pay/online/attempts/:quoteId', requireDynkUser, limiter(120), wrap(async (req) =>
  attemptStatus({ quoteId: req.params.quoteId, orderId: orderIdFrom(req.query.orderId) })));

router.post('/api/pay/online/decline', requireDynkUser, limiter(30), wrap(async (req) => {
  if (req.body?.customerPubkey) assertOwnWallet(req, req.body.customerPubkey);
  return decline({ orderId: orderIdFrom(req.body?.orderId), customerPubkey: req.body?.customerPubkey, channel: 'QR_INTERNET' });
}));

// "Ready to pay" (Case 3): fresh balances of the user's own wallet.
router.get('/api/pay/balances', requireDynkUser, limiter(30), wrap(async (req) => {
  assertOwnWallet(req, req.query.customerPubkey);
  return balances({ customerPubkey: req.query.customerPubkey });
}));

// The tap signature did not reach the terminal (phone pulled away): the phone sends it.
router.post('/api/pay/tap/late-submit', requireDynkUser, limiter(20), wrap(async (req) => {
  assertOwnWallet(req, req.body?.customerPubkey);
  return tapSubmit({ orderId: orderIdFrom(req.body.orderId), quoteId: req.body.quoteId, customerPubkey: req.body.customerPubkey, signature: req.body.signature });
}));

// Live status for the phone (SSE). Only events about the user's own wallets,
// plus EXPIRED for the order. Push notifications are the backup (DYNK backend).
router.get('/api/pay/orders/:orderId/events', requireDynkUser, limiter(30), async (req, res) => {
  let orderId;
  try { orderId = orderIdFrom(req.params.orderId); } catch (e) { return res.status(400).json({ error: e.code, message: e.message }); }
  const order = await prisma.order.findUnique({ where: { id: orderId }, select: { quoteExpiresAt: true, status: true } }).catch(() => null);
  if (!order) return res.status(404).json({ error: 'ORDER_NOT_FOUND', message: 'Order not found.' });
  const mine = new Set(req.dynkUser.wallets);
  res.writeHead(200, { 'content-type': 'text/event-stream', 'cache-control': 'no-store', connection: 'keep-alive', 'x-accel-buffering': 'no' });
  const send = (event) => {
    const { customerPubkey, ...rest } = event;
    if (customerPubkey && !mine.has(customerPubkey)) return;
    res.write(`event: status\ndata: ${JSON.stringify(rest)}\n\n`);
  };
  const unsubscribe = subscribeOrderEvents(orderId, send);
  // The internet is the backup channel (spec v5): start with where this
  // user's payment already stands, so a late subscriber misses nothing.
  latestOutcome(orderId, [...mine]).then((e) => { if (e) send(e); }).catch(() => {});
  const ping = setInterval(() => res.write(': ping\n\n'), 15_000);
  const left = new Date(order.quoteExpiresAt).getTime() - Date.now();
  const expiry = setTimeout(async () => {
    const now = await prisma.order.findUnique({ where: { id: orderId }, select: { status: true, paymentLock: true } }).catch(() => null);
    if (now && !now.paymentLock && !['PAID', 'SETTLING', 'SETTLED', 'RECEIPT_READY'].includes(now.status)) send({ status: 'EXPIRED', orderId });
  }, Math.max(0, left) + 500);
  req.on('close', () => { unsubscribe(); clearInterval(ping); clearTimeout(expiry); });
});

export default router;
