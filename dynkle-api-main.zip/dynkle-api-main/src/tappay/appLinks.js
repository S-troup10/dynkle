// App association files for the payment link https://<PUBLIC_PAY_DOMAIN>/o/<orderId>
// and the table tag link https://<PUBLIC_PAY_DOMAIN>/tb/<tagCode>.
// Built only from env; with values missing they list no apps (never placeholder
// IDs). Only /o/* and /tb/* open DYNK, so every other page stays in the browser.

export function appleAppSiteAssociation(env = process.env) {
  const appID = env.APPLE_TEAM_ID && env.IOS_BUNDLE_ID ? `${env.APPLE_TEAM_ID}.${env.IOS_BUNDLE_ID}` : null;
  return {
    applinks: {
      apps: [],
      details: appID ? [{ appIDs: [appID], appID, components: [{ '/': '/o/*', comment: 'Dynkle payment links' }, { '/': '/tb/*', comment: 'Dynkle table tags' }], paths: ['/o/*', '/tb/*'] }] : [],
    },
  };
}

export function androidAssetLinks(env = process.env) {
  const fingerprints = String(env.ANDROID_CERT_SHA256 || '').split(',').map((s) => s.trim().toUpperCase()).filter(Boolean);
  if (!fingerprints.length) return [];
  return [{
    relation: ['delegate_permission/common.handle_all_urls'],
    target: { namespace: 'android_app', package_name: env.ANDROID_PACKAGE || 'io.dynk.www', sha256_cert_fingerprints: fingerprints },
  }];
}
