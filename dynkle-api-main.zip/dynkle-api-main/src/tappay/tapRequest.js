// The NFC payloads of a tap (spec v6 02 §4.2), built here so the terminal only
// chunks and relays bytes it is given:
//
//   PUT_REQUEST data = u16 LE intentLen | intent | u16 LE quoteLen | tap quote (UTF-8 JSON) |
//                      transaction (serialized, unsigned)
//   PUT_DECLINE data = signed decline (UTF-8 JSON)
//
// The phone verifies the intent, the tap quote (message hash + fee, signed by
// Dynkle) and the transaction itself before it partially signs.

export function encodeTapRequest({ intent, tapQuote, transaction }) {
  const i = Buffer.from(intent);
  const q = Buffer.from(JSON.stringify(tapQuote), 'utf8');
  if (i.length > 0xFFFF || q.length > 0xFFFF) throw new Error('TAP_REQUEST_TOO_LARGE');
  const head = Buffer.alloc(2);
  head.writeUInt16LE(i.length);
  const mid = Buffer.alloc(2);
  mid.writeUInt16LE(q.length);
  return Buffer.concat([head, i, mid, q, Buffer.from(transaction)]);
}

export function decodeTapRequest(bytes) {
  const b = Buffer.from(bytes);
  let o = 0;
  const need = (n) => { if (o + n > b.length) throw new Error('TAP_REQUEST_TRUNCATED'); };
  need(2); const il = b.readUInt16LE(o); o += 2;
  need(il); const intent = b.subarray(o, o + il); o += il;
  need(2); const ql = b.readUInt16LE(o); o += 2;
  need(ql); const tapQuote = JSON.parse(b.subarray(o, o + ql).toString('utf8')); o += ql;
  if (o >= b.length) throw new Error('TAP_REQUEST_TRUNCATED');
  return { intent, tapQuote, transaction: b.subarray(o) };
}

export const encodeDecline = (notice) => Buffer.from(JSON.stringify(notice), 'utf8');
