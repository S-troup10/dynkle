// Tap-and-pay configuration. Everything comes from env; nothing has a fake
// default. When something required is missing the feature reports
// "not configured" (with the env var NAMES only) instead of guessing.

import { Keypair, PublicKey } from '@solana/web3.js';
import { getMint, TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID } from '@solana/spl-token';
import { loadKeystore } from './keystore.js';

const USDC_DEFAULT = {
  devnet: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
  mainnet: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
};

function pubkeyOrNull(v) {
  try { return v ? new PublicKey(String(v).trim()) : null; } catch { return null; }
}

function intEnv(env, name, def, min, max) {
  const n = env[name] === undefined || env[name] === '' ? def : Number(env[name]);
  if (!Number.isInteger(n) || n < min || n > max) throw new Error(`TAPPAY_CONFIG: ${name} must be an integer ${min}-${max}.`);
  return n;
}

/**
 * Reads the configuration. Never throws for missing values; collects them in
 * `missing`. Throws only for values that are present but malformed.
 */
export function readTapPayConfig(env = process.env) {
  const missing = [];
  const need = (name) => { if (!env[name] || !String(env[name]).trim()) missing.push(name); return env[name]; };

  const cluster = String(env.SOLANA_RPC || 'https://api.devnet.solana.com').includes('devnet') ? 'devnet' : 'mainnet';
  const mint = pubkeyOrNull(need('DYNK_MINT_ADDRESS'));
  if (env.DYNK_MINT_ADDRESS && !mint) throw new Error('TAPPAY_CONFIG: DYNK_MINT_ADDRESS is not a valid public key.');

  const feeCollector = pubkeyOrNull(env.TAP_PAY_FEE_COLLECTOR);
  if (env.TAP_PAY_FEE_COLLECTOR && !feeCollector) throw new Error('TAPPAY_CONFIG: TAP_PAY_FEE_COLLECTOR is not a valid public key.');

  const feeUsd = env.TAP_PAY_PLATFORM_FEE_USD === undefined || env.TAP_PAY_PLATFORM_FEE_USD === '' ? '0.01' : String(env.TAP_PAY_PLATFORM_FEE_USD);
  if (!/^\d+(\.\d{1,6})?$/.test(feeUsd)) throw new Error('TAPPAY_CONFIG: TAP_PAY_PLATFORM_FEE_USD must be a decimal like 0.01.');
  // Integer micro-USD: no float money.
  const [whole, frac = ''] = feeUsd.split('.');
  const platformFeeMicroUsd = BigInt(whole) * 1_000_000n + BigInt((frac + '000000').slice(0, 6));
  if (platformFeeMicroUsd > 0n && !feeCollector) missing.push('TAP_PAY_FEE_COLLECTOR');

  need('TAP_PAY_KEYSTORE_FILE');
  need('TAP_PAY_KEYSTORE_PASSPHRASE');

  const usdcMint = pubkeyOrNull(env.USDC_MINT_ADDRESS || USDC_DEFAULT[cluster]);

  return {
    cluster,
    mint,
    expectedDecimals: intEnv(env, 'DYNK_MINT_DECIMALS', 9, 0, 18),
    usdcMint,
    feeCollector,
    platformFeeMicroUsd,
    keystoreFile: env.TAP_PAY_KEYSTORE_FILE || null,
    keystorePassphrase: env.TAP_PAY_KEYSTORE_PASSPHRASE || null,
    computeUnitLimit: intEnv(env, 'TAP_PAY_COMPUTE_UNIT_LIMIT', 120_000, 20_000, 1_400_000),
    priorityFeeMicroLamports: intEnv(env, 'TAP_PAY_PRIORITY_FEE_MICROLAMPORTS', 1_000, 0, 10_000_000),
    sponsorMinLamports: intEnv(env, 'TAP_PAY_SPONSOR_MIN_LAMPORTS', 50_000_000, 0, Number.MAX_SAFE_INTEGER),
    // App identity for the app-association files.
    publicPayDomain: env.PUBLIC_PAY_DOMAIN || null,
    appleTeamId: env.APPLE_TEAM_ID || null,
    iosBundleId: env.IOS_BUNDLE_ID || null,
    androidPackage: env.ANDROID_PACKAGE || 'io.dynk.www',
    androidCertSha256: String(env.ANDROID_CERT_SHA256 || '').split(',').map((s) => s.trim()).filter(Boolean),
    missing,
  };
}

/** Decrypts the keystore (intent keys + gas sponsor). */
export function loadTapPayKeys(cfg) {
  const ks = loadKeystore(cfg.keystoreFile, cfg.keystorePassphrase);
  return {
    activeKid: ks.activeKid,
    intentKeys: ks.intentKeys,
    publicKeys: new Map([...ks.intentKeys].map(([kid, k]) => [kid, k.publicKey])),
    sponsor: Keypair.fromSecretKey(ks.sponsorSecretKey),
  };
}

/**
 * Fetches the DYNK mint from chain and asserts it matches the configuration.
 * Throws MINT_MISMATCH on a wrong decimals or a non-token account: the caller
 * must refuse to run tap-and-pay (and fail loudly) in that case.
 */
export async function checkDynkMint(connection, cfg) {
  const info = await connection.getAccountInfo(cfg.mint, 'confirmed');
  if (!info) throw new Error(`MINT_MISMATCH: DYNK_MINT_ADDRESS ${cfg.mint.toBase58()} does not exist on this cluster.`);
  let programId;
  if (info.owner.equals(TOKEN_PROGRAM_ID)) programId = TOKEN_PROGRAM_ID;
  else if (info.owner.equals(TOKEN_2022_PROGRAM_ID)) programId = TOKEN_2022_PROGRAM_ID;
  else throw new Error(`MINT_MISMATCH: ${cfg.mint.toBase58()} is not an SPL Token or Token-2022 mint.`);
  const mint = await getMint(connection, cfg.mint, 'confirmed', programId);
  if (mint.decimals !== cfg.expectedDecimals) {
    throw new Error(`MINT_MISMATCH: DYNK mint has ${mint.decimals} decimals; DYNK_MINT_DECIMALS says ${cfg.expectedDecimals}.`);
  }
  if (!mint.isInitialized) throw new Error('MINT_MISMATCH: the DYNK mint is not initialised.');
  return { programId, decimals: mint.decimals, tokenProgram: programId.equals(TOKEN_2022_PROGRAM_ID) ? 'token-2022' : 'spl-token' };
}
