// Live payment status for the DYNK app (GET /api/pay/orders/:id/events, SSE).
//
// In-process only: one Node process serves both the pipeline and the stream.
// Each event names the customer wallet it concerns (or none, for order-wide
// events like EXPIRED); the stream only forwards events for the signed-in
// user's own wallets, and never sends the wallet itself.

import { EventEmitter } from 'events';

const bus = new EventEmitter();
bus.setMaxListeners(0);

/**
 * @param {string} orderId
 * @param {{ status: string, customerPubkey?: string|null } & Record<string, unknown>} event
 */
export function publishOrderEvent(orderId, event) {
  bus.emit(`order:${orderId}`, { ...event, orderId, at: new Date().toISOString() });
}

/** @returns {() => void} unsubscribe */
export function subscribeOrderEvents(orderId, listener) {
  const name = `order:${orderId}`;
  bus.on(name, listener);
  return () => bus.off(name, listener);
}
