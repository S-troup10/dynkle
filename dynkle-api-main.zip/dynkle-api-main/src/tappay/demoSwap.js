// Local stand-in for the DYNK backend's Swap and Pay service (dynkService.js
// swapService), for the POC demo only. Active when DEMO_MODE=true, the DYNK
// backend isn't configured, and `scripts/demo-swap.js init` has been run.
//
// It is not a fake payment: the transaction is real and checked on-chain like
// any other. Only the counterparty differs. Instead of the DYNK backend's vault
// and capped delegate, a local demo wallet owns the DYNK vault and the USDC
// treasury, and the USDC is a demo mint on devnet (6 decimals).
//
// Same contract as the real service (see dynkService.js):
//   quote   -> { quoteId, usdcMint, usdcAmount, dynkMint, dynkAmount, treasuryUsdcAccount, vault, delegate, instructions, expiresAt }
//   cosign  -> { signature, delegate }   only for the exact quoted instructions, once
//   confirm -> { status }
//   release -> { released }
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';
import { Keypair, Message, PublicKey } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, createTransferCheckedInstruction, getAssociatedTokenAddressSync } from '@solana/spl-token';
import { getLivePrice } from '../services/priceService.js';
import { signMessage } from './chain.js';

const BACKEND_ROOT = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '../..');
export const DEMO_USDC_DECIMALS = 6;
/** Charged on top of the market rate, like a real swap spread. */
const SPREAD_PERCENT = 1n;

export function demoSwapKeyPath(env = process.env) {
  return path.resolve(BACKEND_ROOT, env.DEMO_SWAP_KEYPAIR || 'keys/demo-swap.json');
}

export function demoSwapActive(env = process.env) {
  return env.DEMO_MODE === 'true' && Boolean(env.DEMO_SWAP_USDC_MINT) && fs.existsSync(demoSwapKeyPath(env));
}

let ctx = () => null;
/** service.js hands over its live state (connection, mint) without a circular import. */
export function setDemoSwapContext(fn) { ctx = fn; }

let wallet = null;
function delegate(env) {
  if (!wallet) {
    const raw = JSON.parse(fs.readFileSync(demoSwapKeyPath(env), 'utf8'));
    wallet = Keypair.fromSecretKey(Uint8Array.from(raw));
  }
  return wallet;
}

class DemoSwapError extends Error {
  constructor(code) { super(code); this.code = code; this.status = 409; }
}

const quotes = new Map(); // quoteId -> { customer, usdcAmount, dynkAmount, expiresAt, ixs, used }

const micro = (n) => BigInt(Math.round(Number(n) * 1e6));
const ceilDiv = (a, b) => (a + b - 1n) / b;

function ixJson(ix) {
  return {
    programId: ix.programId.toBase58(),
    keys: ix.keys.map((k) => ({ pubkey: k.pubkey.toBase58(), isSigner: k.isSigner, isWritable: k.isWritable })),
    data: Buffer.from(ix.data).toString('base64'),
  };
}

function reservedDynk() {
  let sum = 0n;
  const now = Date.now();
  for (const [id, q] of quotes) {
    if (q.used) continue;
    if (q.expiresAt < now) { quotes.delete(id); continue; }
    sum += q.dynkAmount;
  }
  return sum;
}

async function quote({ customerPubkey, dynkShortfall, expiresAt, dryRun }, env) {
  const tp = ctx();
  if (!tp?.ready) throw new DemoSwapError('NOT_READY');
  const owner = delegate(env);
  const customer = new PublicKey(customerPubkey);
  const usdcMint = new PublicKey(env.DEMO_SWAP_USDC_MINT);
  const dynkMint = tp.cfg.mint;
  const dynkProgram = tp.mint.programId;
  const decimals = tp.mint.decimals;
  const dynkAmount = BigInt(dynkShortfall);
  if (dynkAmount <= 0n) throw new DemoSwapError('BAD_SHORTFALL');

  const vault = getAssociatedTokenAddressSync(dynkMint, owner.publicKey, false, dynkProgram);
  const treasury = getAssociatedTokenAddressSync(usdcMint, owner.publicKey, false, TOKEN_PROGRAM_ID);
  const vaultBalance = await tp.connection.getTokenAccountBalance(vault, 'confirmed').then((r) => BigInt(r.value.amount)).catch(() => 0n);
  if (vaultBalance - reservedDynk() < dynkAmount) {
    console.warn('[demo-swap] the demo vault is short of DYNK: send DYNK to it (node scripts/demo-swap.js status)');
    throw new DemoSwapError('VAULT_EMPTY');
  }

  // USDC for the shortfall at the live DYNK/USDC rate (both priced in AUD), plus the spread, rounded up.
  const [dynkPrice, usdcPrice] = await Promise.all([getLivePrice('DYNK'), getLivePrice('USDC')]);
  const num = dynkAmount * micro(dynkPrice.priceAUD) * 10n ** BigInt(DEMO_USDC_DECIMALS) * (100n + SPREAD_PERCENT);
  const den = 10n ** BigInt(decimals) * micro(usdcPrice.priceAUD) * 100n;
  const usdcAmount = ceilDiv(num, den) || 1n;

  const ixs = [
    createTransferCheckedInstruction(
      getAssociatedTokenAddressSync(usdcMint, customer, false, TOKEN_PROGRAM_ID), usdcMint, treasury, customer,
      usdcAmount, DEMO_USDC_DECIMALS, [], TOKEN_PROGRAM_ID,
    ),
    createTransferCheckedInstruction(
      vault, dynkMint, getAssociatedTokenAddressSync(dynkMint, customer, false, dynkProgram), owner.publicKey,
      dynkAmount, decimals, [], dynkProgram,
    ),
  ];
  const expires = Math.min(new Date(expiresAt).getTime() || Infinity, Date.now() + 5 * 60_000);
  const quoteId = dryRun ? null : `demo-${crypto.randomUUID()}`;
  if (quoteId) quotes.set(quoteId, { customer: customer.toBase58(), usdcAmount, dynkAmount, expiresAt: expires, ixs, used: false });
  console.log(`[demo-swap] quote ${quoteId || '(dry run)'}: ${dynkAmount} DYNK base units for ${usdcAmount} demo USDC base units`);
  return {
    quoteId, usdcMint: usdcMint.toBase58(), usdcAmount: usdcAmount.toString(), dynkMint: dynkMint.toBase58(),
    dynkAmount: dynkAmount.toString(), treasuryUsdcAccount: treasury.toBase58(), vault: vault.toBase58(),
    delegate: owner.publicKey.toBase58(), instructions: ixs.map(ixJson), expiresAt: new Date(expires).toISOString(),
  };
}

/** Does compiled instruction `ci` of `msg` equal `ix` exactly (program, accounts in order, data)? */
function sameInstruction(msg, ci, ix) {
  const keys = msg.accountKeys;
  if (!keys[ci.programIdIndex].equals(ix.programId)) return false;
  if (ci.accountKeyIndexes.length !== ix.keys.length) return false;
  if (!ci.accountKeyIndexes.every((k, i) => keys[k].equals(ix.keys[i].pubkey))) return false;
  return Buffer.from(ci.data).equals(Buffer.from(ix.data));
}

/** Signs only a message that contains exactly the quoted swap, where the demo wallet appears in nothing else. */
async function cosign({ quoteId, message }, env) {
  const q = quotes.get(quoteId);
  if (!q) throw new DemoSwapError('QUOTE_NOT_FOUND');
  if (q.used) throw new DemoSwapError('QUOTE_USED');
  if (q.expiresAt < Date.now()) { quotes.delete(quoteId); throw new DemoSwapError('QUOTE_EXPIRED'); }
  const owner = delegate(env);
  const bytes = Buffer.from(String(message), 'base64');
  const msg = Message.from(bytes);
  const signers = msg.accountKeys.slice(0, msg.header.numRequiredSignatures);
  if (msg.accountKeys[0].equals(owner.publicKey)) throw new DemoSwapError('WRONG_FEE_PAYER');
  if (!signers.some((k) => k.equals(owner.publicKey)) || !signers.some((k) => k.toBase58() === q.customer)) throw new DemoSwapError('WRONG_SIGNERS');
  const ownerIndex = msg.accountKeys.findIndex((k) => k.equals(owner.publicKey));
  let usdcLeg = 0;
  let topUp = 0;
  for (const ci of msg.compiledInstructions) {
    if (sameInstruction(msg, ci, q.ixs[0])) { usdcLeg++; continue; }
    if (sameInstruction(msg, ci, q.ixs[1])) { topUp++; continue; }
    if (ci.accountKeyIndexes.includes(ownerIndex) || ci.programIdIndex === ownerIndex) throw new DemoSwapError('UNEXPECTED_INSTRUCTION');
  }
  if (usdcLeg !== 1 || topUp !== 1) throw new DemoSwapError('SWAP_MISMATCH');
  q.used = true;
  return { signature: signMessage(owner, bytes).toString('base64'), delegate: owner.publicKey.toBase58() };
}

export const demoSwapService = {
  quote: (body, opts = {}) => quote(body, opts.env || process.env),
  cosign: (body, opts = {}) => cosign(body, opts.env || process.env),
  confirm: async ({ quoteId }) => { quotes.delete(quoteId); return { status: 'CONFIRMED' }; },
  release: async ({ quoteId }) => {
    const q = quotes.get(quoteId);
    if (q && !q.used) quotes.delete(quoteId);
    return { released: Boolean(q && !q.used) };
  },
};
