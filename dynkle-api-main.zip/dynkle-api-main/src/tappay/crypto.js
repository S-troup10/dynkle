// Tap-and-pay crypto helpers.
//
// Private precheck blob (backend -> phone, relayed by the terminal unread):
//   key   = HKDF-SHA256(X25519(backendEphemeral, phoneEphemeralPub),
//                       salt = orderId (16 bytes), info = "dynkle-precheck-v1", 32 bytes)
//   seal  = ChaCha20-Poly1305(key, nonce 12 random bytes, aad = orderId bytes)
//   blob  = { v:1, epk:<backend eph pub, 32 B b64>, nonce:<b64>, ct:<ciphertext||tag b64> }
// The plaintext is JSON with integer strings (balances in base units).
//
// Receipt (signed by the intent key, verified offline by DYNK):
//   message = "dynkle-receipt-v1\n" + orderId + "\n" + txSignature + "\n" + amount + "\n" +
//             mint + "\n" + merchantWallet + "\n" + merchantName + "\n" + confirmedAt
//   (UTF-8; amount in base units; confirmedAt ISO-8601 UTC), Ed25519, base64.
//
// Tap quote (same key; spec v6 §4.2): binds the backend-built transaction and
// its fee to the order, so the phone signs during a tap without a Review screen
// and the terminal can't change either:
//   message = "dynkle-tapquote-v1\n" + orderId + "\n" + quoteId + "\n" + messageHash + "\n" +
//             fee + "\n" + expiresAt          (messageHash = sha256 hex of the message bytes)
//
// Decline (same key; tells the phone a payment was refused; spec v5: never a
// Swap and Pay offer, so there is no swap flag):
//   message = "dynkle-decline-v2\n" + orderId + "\n" + customerPubkey + "\n" + reason + "\n" + declinedAt

import crypto from 'crypto';
import { uuidToBytes } from './intent.js';

const X25519_SPKI_PREFIX = Buffer.from('302a300506032b656e032100', 'hex');
const PRECHECK_INFO = Buffer.from('dynkle-precheck-v1');

export function x25519PublicFromRaw(raw) {
  const b = Buffer.from(raw);
  if (b.length !== 32) throw new Error('BAD_X25519_KEY');
  return crypto.createPublicKey({ key: Buffer.concat([X25519_SPKI_PREFIX, b]), format: 'der', type: 'spki' });
}

export function x25519RawPublic(publicKey) {
  return Buffer.from(publicKey.export({ format: 'der', type: 'spki' }).subarray(-32));
}

function deriveKey(sharedSecret, salt, info) {
  return Buffer.from(crypto.hkdfSync('sha256', sharedSecret, salt, info, 32));
}

/** Encrypts `payload` so only the holder of phoneEphemeralPub's private key can read it. */
export function sealForPhone(payload, { phoneEphemeralPub, orderId }) {
  const eph = crypto.generateKeyPairSync('x25519');
  const shared = crypto.diffieHellman({ privateKey: eph.privateKey, publicKey: x25519PublicFromRaw(phoneEphemeralPub) });
  const salt = uuidToBytes(orderId);
  const key = deriveKey(shared, salt, PRECHECK_INFO);
  const nonce = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('chacha20-poly1305', key, nonce, { authTagLength: 16 });
  cipher.setAAD(salt, { plaintextLength: Buffer.byteLength(JSON.stringify(payload)) });
  const ct = Buffer.concat([cipher.update(JSON.stringify(payload), 'utf8'), cipher.final(), cipher.getAuthTag()]);
  return { v: 1, epk: x25519RawPublic(eph.publicKey).toString('base64'), nonce: nonce.toString('base64'), ct: ct.toString('base64') };
}

/** The phone side (used by tests and as the reference for the DYNK app). */
export function openFromBackend(blob, { phonePrivateKey, orderId }) {
  const shared = crypto.diffieHellman({ privateKey: phonePrivateKey, publicKey: x25519PublicFromRaw(Buffer.from(blob.epk, 'base64')) });
  const salt = uuidToBytes(orderId);
  const key = deriveKey(shared, salt, PRECHECK_INFO);
  const all = Buffer.from(blob.ct, 'base64');
  const decipher = crypto.createDecipheriv('chacha20-poly1305', key, Buffer.from(blob.nonce, 'base64'), { authTagLength: 16 });
  decipher.setAAD(salt, { plaintextLength: all.length - 16 });
  decipher.setAuthTag(all.subarray(all.length - 16));
  const plain = Buffer.concat([decipher.update(all.subarray(0, all.length - 16)), decipher.final()]);
  return JSON.parse(plain.toString('utf8'));
}

export function receiptMessage(r) {
  return Buffer.from([
    'dynkle-receipt-v1', r.orderId, r.txSignature, String(r.amount), r.mint, r.merchantWallet, r.merchantName, r.confirmedAt,
  ].join('\n'), 'utf8');
}

export function signReceipt(fields, { kid, privateKey }) {
  const r = { ...fields, amount: String(fields.amount), kid };
  return { ...r, signature: crypto.sign(null, receiptMessage(r), privateKey).toString('base64') };
}

export function verifyReceipt(receipt, publicKeys) {
  const key = publicKeys.get(receipt.kid);
  if (!key) throw new Error('RECEIPT_UNKNOWN_KID');
  if (!crypto.verify(null, receiptMessage(receipt), key, Buffer.from(receipt.signature, 'base64'))) throw new Error('RECEIPT_BAD_SIGNATURE');
  return true;
}

export function declineMessage(d) {
  return Buffer.from([
    'dynkle-decline-v2', d.orderId, d.customerPubkey, d.reason, d.declinedAt,
  ].join('\n'), 'utf8');
}

export function signDecline(fields, { kid, privateKey }) {
  const d = { orderId: fields.orderId, customerPubkey: fields.customerPubkey, reason: fields.reason, declinedAt: fields.declinedAt, kid };
  return { ...d, signature: crypto.sign(null, declineMessage(d), privateKey).toString('base64') };
}

export function verifyDecline(notice, publicKeys) {
  const key = publicKeys.get(notice.kid);
  if (!key) throw new Error('DECLINE_UNKNOWN_KID');
  if (!crypto.verify(null, declineMessage(notice), key, Buffer.from(notice.signature, 'base64'))) throw new Error('DECLINE_BAD_SIGNATURE');
  return true;
}

export function tapQuoteMessage(q) {
  return Buffer.from(['dynkle-tapquote-v1', q.orderId, q.quoteId, q.messageHash, String(q.fee), q.expiresAt].join('\n'), 'utf8');
}

export function signTapQuote(fields, { kid, privateKey }) {
  const q = { orderId: fields.orderId, quoteId: fields.quoteId, messageHash: fields.messageHash, fee: String(fields.fee), expiresAt: fields.expiresAt, kid };
  return { ...q, signature: crypto.sign(null, tapQuoteMessage(q), privateKey).toString('base64') };
}

export function verifyTapQuote(q, publicKeys) {
  const key = publicKeys.get(q.kid);
  if (!key) throw new Error('TAPQUOTE_UNKNOWN_KID');
  if (!crypto.verify(null, tapQuoteMessage(q), key, Buffer.from(q.signature, 'base64'))) throw new Error('TAPQUOTE_BAD_SIGNATURE');
  return true;
}
