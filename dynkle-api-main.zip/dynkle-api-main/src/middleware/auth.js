import jwt from 'jsonwebtoken';
import { JWT_SECRET } from '../config.js';
import prisma from '../db.js';

/**
 * Validates JWT Bearer token on request headers.
 */
export async function requireAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Missing or malformed Authorization header.' });
  }

  const token = authHeader.split(' ')[1];
  try {
    const payload = jwt.verify(token, JWT_SECRET);
    const user = await prisma.user.findUnique({
      where: { id: payload.sub },
      select: {
        id: true,
        email: true,
        phone: true,
        status: true,
        emailVerified: true,
        phoneVerified: true
      }
    });

    if (!user || user.status === 'SUSPENDED') {
      return res.status(403).json({ error: 'FORBIDDEN', message: 'User account is inactive or suspended.' });
    }

    req.user = user;
    next();
  } catch (err) {
    if (err.name === 'TokenExpiredError') {
      return res.status(401).json({ error: 'TOKEN_EXPIRED', message: 'Access token has expired.' });
    }
    return res.status(401).json({ error: 'INVALID_TOKEN', message: 'Invalid access token.' });
  }
}

/**
 * Ensures the authenticated user has an active membership for the target merchant.
 */
export async function requireMerchant(req, res, next) {
  if (!req.user) {
    return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Authentication required.' });
  }

  // Get merchantId from header, query, or body
  const merchantId = req.headers['x-merchant-id'] || req.query.merchantId || req.body.merchantId;

  let membership;
  if (merchantId) {
    membership = await prisma.merchantUser.findUnique({
      where: {
        merchantId_userId: {
          merchantId: String(merchantId),
          userId: req.user.id
        }
      },
      include: {
        merchant: true
      }
    });
  } else {
    // If not specified, look for primary merchant membership
    membership = await prisma.merchantUser.findFirst({
      where: { userId: req.user.id },
      include: { merchant: true },
      orderBy: { createdAt: 'asc' }
    });
  }

  if (!membership) {
    return res.status(403).json({ error: 'FORBIDDEN', message: 'Access to this merchant is unauthorized.' });
  }

  req.merchant = membership.merchant;
  req.merchantRole = membership.role;
  next();
}

/**
 * Enforces role-based permissions (e.g. ['OWNER', 'ADMIN'])
 */
export function requireRole(...allowedRoles) {
  return (req, res, next) => {
    if (!req.merchantRole) {
      return res.status(403).json({ error: 'FORBIDDEN', message: 'No merchant role found.' });
    }

    if (!allowedRoles.includes(req.merchantRole)) {
      return res.status(403).json({
        error: 'INSUFFICIENT_PERMISSIONS',
        message: `Action requires one of: ${allowedRoles.join(', ')}. Current role: ${req.merchantRole}`
      });
    }

    next();
  };
}
