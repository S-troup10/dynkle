// Per-IP rate limit for public payment endpoints (spec 02 §9: rate limits on
// all public endpoints). Tap-and-pay routes have their own keyed limiter in
// src/tappay/routes.js; this one covers the website checkout routes.
import { rateLimit } from 'express-rate-limit';

export function ipLimiter(limit, windowMs = 60_000) {
  return rateLimit({
    windowMs,
    limit,
    standardHeaders: 'draft-7',
    legacyHeaders: false,
    handler: (req, res) => res.status(429).json({ error: 'RATE_LIMITED', message: 'Too many requests. Wait a moment and try again.' }),
  });
}
