import 'dotenv/config';

// One entry per EVM chain you want to accept. Add/remove freely.
// `rpcUrl` is used only to VERIFY a payment landed on-chain after the wallet
// broadcasts it — it is never used to move funds.
export const EVM_CHAINS = {
  1: {
    name: 'Ethereum Mainnet',
    rpcUrl: process.env.RPC_ETHEREUM || 'https://ethereum-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    nativeDecimals: 18
  },
  137: {
    name: 'Polygon',
    rpcUrl: process.env.RPC_POLYGON || 'https://polygon-bor-rpc.publicnode.com',
    nativeSymbol: 'POL',
    nativeDecimals: 18
  },
  8453: {
    name: 'Base',
    rpcUrl: process.env.RPC_BASE || 'https://base-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    nativeDecimals: 18
  },
  42161: {
    name: 'Arbitrum One',
    rpcUrl: process.env.RPC_ARBITRUM || 'https://arbitrum-one-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    nativeDecimals: 18
  },
  10: {
    name: 'Optimism',
    rpcUrl: process.env.RPC_OPTIMISM || 'https://optimism-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    nativeDecimals: 18
  },
  56: {
    name: 'BNB Chain',
    rpcUrl: process.env.RPC_BSC || 'https://bsc-rpc.publicnode.com',
    nativeSymbol: 'BNB',
    nativeDecimals: 18
  },
  // Testnet — use this to test the full flow with free faucet funds before
  // touching any of the mainnet chains above.
  11155111: {
    name: 'Ethereum Sepolia (testnet)',
    rpcUrl: process.env.RPC_SEPOLIA || 'https://ethereum-sepolia-rpc.publicnode.com',
    nativeSymbol: 'ETH',
    nativeDecimals: 18
  }
};

export const SOLANA_CLUSTER_URL =
  process.env.SOLANA_RPC || 'https://api.devnet.solana.com';

export const MERCHANT = {
  name: process.env.MERCHANT_NAME || 'Bean & Brew Café',
  // Receiving addresses per chain family. Set these in .env for production.
  evmAddress: process.env.MERCHANT_EVM_ADDRESS || '0x0000000000000000000000000000000000dEaD',
  solanaAddress: process.env.MERCHANT_SOLANA_ADDRESS || '11111111111111111111111111111111'
};

// WalletConnect (Reown) Cloud project ID — required for the EVM flow.
// Free at https://cloud.reown.com
export const WALLETCONNECT_PROJECT_ID = process.env.WALLETCONNECT_PROJECT_ID || '';

export const PORT = process.env.PORT || 4000;

// Legacy demo flows (fixed OTP code, fake KYB, demo order ids, explicit demo
// submits) run only when DEMO_MODE=true. Tap-and-pay channels never consult it.
export const DEMO_MODE = process.env.DEMO_MODE === 'true';

// OTP_DEV_BYPASS used to switch on fake payment verification. It is retired:
// refuse to start with it on, so a stale .env can never fake a payment.
export function assertNoPaymentBypass(env = process.env) {
  if (env.OTP_DEV_BYPASS === 'true' && env.NODE_ENV !== 'test') {
    throw new Error('OTP_DEV_BYPASS=true is no longer allowed. Remove it (use DEMO_MODE=true for legacy demo flows).');
  }
}
export const PUBLIC_BASE_URL = process.env.PUBLIC_BASE_URL || `http://localhost:${PORT}`;

// Payment window: how long a bill (and its locked rate) can be paid. Default 120
// seconds (2 minutes), ORDER_TTL_SECONDS to change it. The register, checkout
// page and terminal all count down from the server's quoteExpiresAt.
export const ORDER_TTL_SECONDS = (() => {
  const v = process.env.ORDER_TTL_SECONDS;
  if (v === undefined || v === '') return 120;
  const n = Number(v);
  if (!Number.isInteger(n) || n < 60 || n > 600) throw new Error('ORDER_TTL_SECONDS must be an integer from 60 to 600.');
  return n;
})();

// Table payments: how long a bill sent to a table's tag holds its price before
// it is re-quoted automatically. Default 10 minutes, TABLE_HOLD_MINUTES (1-60).
export const TABLE_HOLD_MINUTES = (() => {
  const v = process.env.TABLE_HOLD_MINUTES;
  if (v === undefined || v === '') return 10;
  const n = Number(v);
  if (!Number.isInteger(n) || n < 1 || n > 60) throw new Error('TABLE_HOLD_MINUTES must be an integer from 1 to 60.');
  return n;
})();

// Hard ceiling on a single bill. Nothing rings up an in-person coffee-shop
// sale for six or seven figures — a value above this is treated as a
// fat-fingered digit (e.g. "99999999" instead of "9.99") or a compromised
// caller, and the order is refused outright before any QR/link is ever
// generated for a customer to see.
export const MAX_ORDER_AUD = parseFloat(process.env.MAX_ORDER_AUD || '10000');

// Below the hard ceiling but still unusual for this kind of counter sale.
// Orders at or above this are still created normally, but the customer's
// checkout screen must show an unmissable "confirm this amount" gate before
// the pay button is usable, so an honest mistake gets caught by the person
// about to pay, not just trusted on faith.
export const LARGE_AMOUNT_WARNING_AUD = parseFloat(process.env.LARGE_AMOUNT_WARNING_AUD || '500');

export const JWT_SECRET = process.env.JWT_SECRET || 'dynkle_pos_jwt_secret_production_key_938174981';
export const JWT_REFRESH_SECRET = process.env.JWT_REFRESH_SECRET || 'dynkle_pos_refresh_jwt_secret_production_key_481029482';

// Web Push (VAPID) keys — identify this server to push services (FCM/Mozilla
// autopush/etc.) when sending a browser push notification. A subscription a
// customer's phone creates is bound to the PUBLIC key it subscribed with, so
// this pair must stay stable across restarts or every existing subscription
// silently breaks. Set your own in .env for a real deployment — these
// fallbacks are a fixed pair generated once for this demo, the same pattern
// JWT_SECRET above already uses.
export const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY || 'BMdudOf17K54Wr06oyK-CBhWr0npecEeH29X2U9xwqMt8LDttxwRrFFS80ZibQyJ3ZEni7mCRuhX-BGVnBL8vj4';
export const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY || 'lX_rKq5hA8Xn8B96oJvyzT2K_cIByUwBwhIPZ2sKfzE';
export const VAPID_CONTACT_EMAIL = process.env.VAPID_CONTACT_EMAIL || 'mailto:admin@dynkle.example.com';

