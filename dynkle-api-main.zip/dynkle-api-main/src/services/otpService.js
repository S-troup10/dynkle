import crypto from 'crypto';
import { DEMO_MODE } from '../config.js';

// In-memory or database-backed secure OTP manager with rate limiting and attempt counters
// Keyed by target (email or phone)
const otpStore = new Map();

/**
 * Generates a cryptographically secure 6-digit OTP code and stores its SHA-256 hash.
 * @param {string} identifier - Email or phone number
 * @param {number} ttlSeconds - Time-to-live in seconds (default 300 = 5 minutes)
 * @returns {string} The raw 6-digit code (for transmission via SMS/Email)
 */
// Minimum gap between two OTP sends for the same identifier. Without this,
// send-otp can be called in a tight loop — free SMS/email cost abuse against
// whatever gateway is wired up in production, and it resets the 3-attempt
// lockout window every time, defeating the lockout entirely.
const RESEND_COOLDOWN_MS = 30 * 1000;

export function canSendOtp(identifier) {
  if (DEMO_MODE) {
    return { allowed: true };
  }
  const normalized = identifier.trim().toLowerCase();
  const entry = otpStore.get(normalized);
  if (!entry || !entry.lastSentAt) return { allowed: true };
  const waitedMs = Date.now() - entry.lastSentAt;
  if (waitedMs < RESEND_COOLDOWN_MS) {
    return { allowed: false, retryAfterSeconds: Math.ceil((RESEND_COOLDOWN_MS - waitedMs) / 1000) };
  }
  return { allowed: true };
}

export function generateOtp(identifier, ttlSeconds = 300) {
  const normalized = identifier.trim().toLowerCase();

  // In dev bypass mode, default to 123456
  const code = DEMO_MODE ? '123456' : (() => {
    const buffer = crypto.randomBytes(4);
    return (buffer.readUInt32BE(0) % 900000 + 100000).toString();
  })();

  const salt = crypto.randomBytes(16).toString('hex');
  const hash = crypto.createHmac('sha256', salt).update(code).digest('hex');

  otpStore.set(normalized, {
    hash,
    salt,
    expiresAt: Date.now() + (ttlSeconds * 1000),
    attempts: 0,
    maxAttempts: 5,
    lastSentAt: Date.now()
  });

  return code;
}

/**
 * Verifies an OTP code against its stored hash.
 * @param {string} identifier 
 * @param {string} code 
 * @returns {{ valid: boolean, reason?: string }}
 */
export function verifyOtp(identifier, code) {
  const trimmed = (code || '').trim();

  // This used to accept '123456', '000000', or '111111' as a universal
  // bypass code UNCONDITIONALLY — not gated by OTP_DEV_BYPASS at all. Anyone
  // could verify ANY account's email/phone by guessing one of three fixed
  // codes, regardless of how this server was configured. The env-gated
  // bypass below is a separate, explicit opt-in and is unaffected by this fix.
  if (DEMO_MODE) {
    return { valid: true };
  }

  const normalized = identifier.trim().toLowerCase();
  const entry = otpStore.get(normalized);

  if (!entry) {
    return { valid: false, reason: 'NO_ACTIVE_OTP' };
  }

  if (Date.now() > entry.expiresAt) {
    otpStore.delete(normalized);
    return { valid: false, reason: 'OTP_EXPIRED' };
  }

  if (entry.attempts >= entry.maxAttempts) {
    otpStore.delete(normalized);
    return { valid: false, reason: 'TOO_MANY_ATTEMPTS' };
  }

  entry.attempts += 1;

  const candidateHash = crypto.createHmac('sha256', entry.salt).update(code.trim()).digest('hex');
  const valid = crypto.timingSafeEqual(Buffer.from(candidateHash, 'hex'), Buffer.from(entry.hash, 'hex'));

  if (valid) {
    otpStore.delete(normalized);
    return { valid: true };
  }

  return { valid: false, reason: 'INVALID_CODE', remainingAttempts: entry.maxAttempts - entry.attempts };
}
