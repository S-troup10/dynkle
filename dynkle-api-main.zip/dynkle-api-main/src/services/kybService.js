import { DEMO_MODE } from '../config.js';
/**
 * Australian Business Number (ABN) Modulus-89 Validation Algorithm.
 * Defined by the Australian Taxation Office (ATO).
 * 
 * 1. Subtract 1 from the first digit
 * 2. Multiply each of the 11 digits by its assigned weight:
 *    [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19]
 * 3. Sum the 11 products
 * 4. Divide sum by 89. If remainder is 0, the ABN is valid.
 * 
 * @param {string} abn 
 * @returns {{ valid: boolean, formatted?: string, error?: string }}
 */
export function validateABN(abn) {
  if (!abn) {
    return { valid: false, error: 'ABN is required.' };
  }

  // Strip all whitespace and punctuation
  const cleanAbn = String(abn).replace(/[\s\-_]/g, '');

  if (!/^\d{11}$/.test(cleanAbn)) {
    return { valid: false, error: 'ABN must be exactly 11 digits.' };
  }

  // In dev/fake mode, accept any 11-digit ABN without requiring real ATO checksum
  if (DEMO_MODE) {
    const padded = cleanAbn.padEnd(11, '0').slice(0, 11);
    return {
      valid: true,
      clean: padded,
      formatted: `${padded.slice(0, 2)} ${padded.slice(2, 5)} ${padded.slice(5, 8)} ${padded.slice(8, 11)}`,
      entityType: 'Australian Proprietary Company (Demo / Test)',
      gstRegistered: true
    };
  }

  const weights = [10, 1, 3, 5, 7, 9, 11, 13, 15, 17, 19];
  const digits = cleanAbn.split('').map(Number);

  // Subtract 1 from first digit
  digits[0] -= 1;

  const totalSum = digits.reduce((sum, digit, index) => {
    return sum + (digit * weights[index]);
  }, 0);

  const isValid = (totalSum % 89 === 0);

  if (!isValid) {
    return { valid: false, error: 'ABN failed ATO Modulus-89 checksum verification.' };
  }

  // Standard Australian 2-3-3-3 formatting: "51 824 753 556"
  const formatted = `${cleanAbn.slice(0, 2)} ${cleanAbn.slice(2, 5)} ${cleanAbn.slice(5, 8)} ${cleanAbn.slice(8, 11)}`;

  return {
    valid: true,
    clean: cleanAbn,
    formatted,
    entityType: 'Australian Proprietary Company',
    gstRegistered: true
  };
}
