import { ethers } from 'ethers';
import { EVM_CHAINS, MERCHANT } from '../config.js';
import { updateOrder } from '../orders.js';

import { executeOrderSplitSettlement } from '../merchantStore.js';

export async function checkEvmPayment(order) {
  try {
    if (!order || order.status === 'paid') return order?.txHash || null;

    const chainId = order.chainId || 11155111;
    const chain = EVM_CHAINS[chainId];
    if (!chain) return null;

    const provider = new ethers.JsonRpcProvider(chain.rpcUrl);
    const merchantAddr = (MERCHANT.evmAddress || '').toLowerCase();
    if (!merchantAddr || merchantAddr === '0x0000000000000000000000000000000000dead') return null;

    const requiredAmount = parseFloat(order.amount);

    // Fetch the latest block and search last 10 blocks for incoming transfer
    const currentBlock = await provider.getBlockNumber();
    
    for (let b = currentBlock; b >= Math.max(0, currentBlock - 10); b--) {
      const block = await provider.getBlock(b, true);
      if (!block || !block.prefetchedTransactions) continue;

      for (const tx of block.prefetchedTransactions) {
        const toAddr = tx.to ? tx.to.toLowerCase() : '';
        const isDirect = toAddr === merchantAddr;
        const isUniswapSwap = toAddr === '0xee567fe1712faf6149d80da1e6934e354124cfe3' &&
                              tx.data && tx.data.toLowerCase().includes(merchantAddr.slice(2));

        if (isDirect || isUniswapSwap) {
          const valueEth = parseFloat(ethers.formatEther(tx.value));
          
          if (valueEth >= requiredAmount * 0.75 || valueEth >= 0.001) {
            const splitSettlement = executeOrderSplitSettlement(order, 'ETH');
            updateOrder(order.id, {
              status: 'paid',
              sessionState: 'PAID',
              txHash: tx.hash,
              payerAddress: tx.from,
              paidCurrency: 'ETH',
              paidVia: isUniswapSwap ? 'MetaMask (Uniswap V2 On-Chain Swap)' : 'MetaMask Wallet (EVM)',
              paidAt: new Date().toISOString(),
              splits: splitSettlement.splits,
              settlementReceipt: splitSettlement,
              swapExecution: splitSettlement.swapExecution,
              receivedAmount: valueEth.toFixed(4),
              explorerUrl: `https://sepolia.etherscan.io/tx/${tx.hash}`
            });
            console.log(`[EVM Verified] Order ${order.id} paid via ${isUniswapSwap ? 'Uniswap V2 Swap' : 'Direct'}: ${tx.hash}`);
            return tx.hash;
          } else if (valueEth > 0) {
            updateOrder(order.id, {
              status: 'partial_payment',
              receivedAmount: valueEth.toFixed(4),
              txHash: tx.hash
            });
          }
        }
      }
    }

    return null;
  } catch (err) {
    console.warn('EVM on-chain check error:', err.message);
    return null;
  }
}
