/**
 * DYNKLE — Off-Chain Auto-Swap Keeper Automation Engine
 *
 * Implements:
 * 1. Dust-floor evaluation per bucket/token (silently skips below floor, logs to ledger).
 * 2. Multi-bucket netting: balances holding the same token on the same chain are aggregated
 *    into a single optimal swap transaction to minimize network gas & slippage.
 * 3. Proportional contribution tracking before swap execution.
 * 4. On-chain transaction submission (`execute_swap` on Solana, `executeSwap` on EVM/TRON).
 * 5. Atomic / pro-rata distribution of returned USDC proceeds back to contributing buckets.
 *    Values are in AUD (venue currency); USDC amounts use the live USDC/AUD price.
 * 6. Idempotency & retry safety (State machine: PENDING_SUBMISSION, SUBMITTED, CONFIRMING,
 *    CONFIRMED, FAILED, DUST_SKIPPED, REVERTED, RPC_TIMEOUT).
 * 7. Comprehensive audit ledger logging of all events (successes, skips, and errors).
 * 8. Native gas reserve monitoring with warning triggers.
 */

import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import { merchantState } from '../merchantStore.js';
import { getMerchantPnlData } from './pnlService.js';
import { audToUsdc } from './priceService.js';
import prisma from '../db.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const LEDGER_FILE = path.join(__dirname, '../../auto_swap_ledger.json');
const POLICIES_FILE = path.join(__dirname, '../../auto_swap_policies.json');

// Default initial policies per bucket
const DEFAULT_POLICIES = {
  gst: {
    bucketId: 'gst',
    bucketName: 'GST / VAT (ATO)',
    chain: 'solana',
    enabled: true,
    inputToken: 'SOL',
    outputToken: 'USDC',
    whitelistedRouter: 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4', // Jupiter v6
    routerName: 'Jupiter DEX Aggregator',
    oracleType: 'Pyth Network',
    maxSlippageBps: 100, // 1.0%
    dustFloorAUD: 10.00,
    gasReserveMin: 0.005, // 0.005 SOL
    destinationAddress: '8YLL...GST1',
    status: 'ACTIVE', // ACTIVE | PAUSED | REVOKED | INACTIVE
    statusReason: 'Automation running. Pinned to USDC.',
    lastSwapAt: null,
    totalUsdcConverted: 0
  },
  exp: {
    bucketId: 'exp',
    bucketName: 'Operating Costs',
    chain: 'evm',
    enabled: true,
    inputToken: 'ETH',
    outputToken: 'USDC',
    whitelistedRouter: '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D', // Uniswap V2 Router
    routerName: 'Uniswap V2/V3',
    oracleType: 'Chainlink Price Feeds',
    maxSlippageBps: 100, // 1.0%
    dustFloorAUD: 15.00,
    gasReserveMin: 0.003, // 0.003 ETH
    destinationAddress: '0xD978167408123ca6162474A3191D198748d5C5ED',
    status: 'ACTIVE',
    statusReason: 'Automation running. Pinned to USDC.',
    lastSwapAt: null,
    totalUsdcConverted: 0
  },
  owner: {
    bucketId: 'owner',
    bucketName: "Owner's Pay",
    chain: 'solana',
    enabled: false, // Default manual hold
    inputToken: 'DYNK',
    outputToken: 'USDC',
    whitelistedRouter: 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4',
    routerName: 'Jupiter DEX Aggregator',
    oracleType: 'Pyth Network',
    maxSlippageBps: 150,
    dustFloorAUD: 25.00,
    gasReserveMin: 0.005,
    destinationAddress: '8YLL...OWN3',
    status: 'INACTIVE',
    statusReason: 'Manual hold mode. Click Configure to enable auto-swap.',
    lastSwapAt: null,
    totalUsdcConverted: 0
  },
  profit: {
    bucketId: 'profit',
    bucketName: 'Retained Profit',
    chain: 'btc',
    enabled: false,
    inputToken: 'BTC',
    outputToken: 'USDC',
    whitelistedRouter: 'thorchain-tss-vault-pool',
    routerName: 'THORChain TSS Decentralized Vaults',
    oracleType: 'THORChain Consensus Oracle',
    maxSlippageBps: 200,
    dustFloorAUD: 50.00,
    gasReserveMin: 0.0001,
    destinationAddress: 'bc1q...PRF4',
    status: 'INACTIVE',
    statusReason: 'Manual hold mode (THORChain trust model).',
    trustNotice: 'Decentralized Multi-Party Custody (THORChain TSS). Differs from EVM/Solana smart contract delegates.',
    lastSwapAt: null,
    totalUsdcConverted: 0
  }
};

/**
 * Policies saved before the switch to USDC were pinned to AUDC. Re-pin them
 * to USDC and carry the converted total over (old totals were AUD-valued).
 */
function migrateAudcPolicies(policies) {
  for (const policy of Object.values(policies || {})) {
    if (!policy || typeof policy !== 'object') continue;
    if (String(policy.outputToken || '').toUpperCase() === 'AUDC') policy.outputToken = 'USDC';
    if (policy.totalAudcConverted !== undefined) {
      policy.totalUsdcConverted = (policy.totalUsdcConverted || 0) + audToUsdc(policy.totalAudcConverted || 0);
      delete policy.totalAudcConverted;
    }
    if (typeof policy.statusReason === 'string') policy.statusReason = policy.statusReason.replace(/AUDC/g, 'USDC');
  }
  return policies;
}

/** USDC received on a ledger entry (older entries recorded AUDC). */
const receivedUsdcOf = (entry) => entry?.usdcReceived ?? entry?.audcReceived ?? '0';

class AutoSwapKeeperService {
  constructor() {
    this.policies = this.loadPolicies();
    this.ledger = this.loadLedger();
    this.notifications = [];
    this.inFlightSwaps = new Map(); // Idempotency lock: key => timestamp
    this.intervalId = null;
    this.nextScheduledCheck = Date.now() + 60000;
  }

  loadPolicies() {
    try {
      if (fs.existsSync(POLICIES_FILE)) {
        return migrateAudcPolicies(JSON.parse(fs.readFileSync(POLICIES_FILE, 'utf-8')));
      }
    } catch (e) {
      console.warn('[AutoSwapKeeper] Failed to read policies file, using defaults:', e.message);
    }
    this.savePolicies(DEFAULT_POLICIES);
    return JSON.parse(JSON.stringify(DEFAULT_POLICIES));
  }

  savePolicies(policies) {
    try {
      this.policies = policies;
      fs.writeFileSync(POLICIES_FILE, JSON.stringify(policies, null, 2));
    } catch (e) {
      console.error('[AutoSwapKeeper] Failed to save policies:', e.message);
    }
  }

  loadLedger() {
    try {
      if (fs.existsSync(LEDGER_FILE)) {
        return JSON.parse(fs.readFileSync(LEDGER_FILE, 'utf-8'));
      }
    } catch (e) {
      console.warn('[AutoSwapKeeper] Failed to read ledger file:', e.message);
    }
    return [];
  }

  saveLedger() {
    try {
      fs.writeFileSync(LEDGER_FILE, JSON.stringify(this.ledger, null, 2));
    } catch (e) {
      console.error('[AutoSwapKeeper] Failed to save ledger:', e.message);
    }
  }

  /**
   * Records an entry in the persistent audit ledger and PostgreSQL AuditLog
   */
  async logLedgerEvent(entry) {
    const record = {
      id: `as_${Date.now()}_${Math.random().toString(36).substring(2, 7)}`,
      timestamp: new Date().toISOString(),
      ...entry
    };

    this.ledger.unshift(record);
    if (this.ledger.length > 500) this.ledger.pop();
    this.saveLedger();

    // In-app notification for merchant
    if (record.status === 'CONFIRMED' || record.status === 'REVERTED' || record.status === 'LOW_GAS_WARNING') {
      this.notifications.unshift({
        id: `notif_${Date.now()}`,
        timestamp: record.timestamp,
        type: record.status,
        title: record.status === 'CONFIRMED'
          ? `Auto-Swap Completed: ${receivedUsdcOf(record)} USDC`
          : (record.status === 'LOW_GAS_WARNING' ? `Low Gas Warning on ${record.bucketName}` : `Auto-Swap Alert: ${record.bucketName}`),
        message: record.message || `Swapped ${record.amountIn} ${record.inputToken} into ${receivedUsdcOf(record)} USDC via ${record.routerName}.`,
        read: false
      });
      if (this.notifications.length > 50) this.notifications.pop();
    }

    // Try logging to database audit log
    try {
      if (prisma && prisma.auditLog) {
        await prisma.auditLog.create({
          data: {
            action: `AUTO_SWAP_${record.status}`,
            resource: 'BUCKET_AUTO_SWAP',
            resourceId: record.bucketId || 'NETTED_BATCH',
            metadata: record
          }
        });
      }
    } catch (dbErr) {
      // Non-fatal, local file ledger remains authoritative
    }

    return record;
  }

  /**
   * Helper: Resolves bucket balance and basis points / percentage
   */
  async getBucketWeightAndBalance(bucketId) {
    const memWallet = merchantState.wallets?.find(w => w.id === bucketId);
    if (memWallet) {
      return {
        pct: memWallet.pct || 25,
        balance: memWallet.balance || 0,
        name: memWallet.name,
        address: memWallet.address,
        blockchain: memWallet.blockchain
      };
    }

    try {
      if (prisma && prisma.revenueSplitRule) {
        const rule = await prisma.revenueSplitRule.findUnique({
          where: { id: bucketId },
          include: { destinationWallet: true }
        });
        if (rule) {
          const pct = (rule.basisPoints || 2500) / 100;
          // Match with in-memory balance by bucket type
          const matchMem = merchantState.wallets?.find(m => 
            m.id.toLowerCase() === rule.bucket.toLowerCase() ||
            (rule.bucket === 'TAX' && m.id === 'gst') ||
            (rule.bucket === 'EXPENSES' && m.id === 'exp') ||
            (rule.bucket === 'OWNER_PAY' && m.id === 'owner') ||
            (rule.bucket === 'PROFIT' && m.id === 'profit')
          );
          return {
            pct,
            balance: matchMem?.balance || 0,
            name: rule.destinationWallet?.label,
            address: rule.destinationWallet?.address,
            blockchain: rule.destinationWallet?.blockchain,
            bucket: rule.bucket,
            rule
          };
        }
      }
    } catch (e) {
      // ignore
    }

    return { pct: 25, balance: 0 };
  }

  /**
   * Resolves or dynamically instantiates a policy entry for any bucketId (UUID, alias, or custom)
   */
  async ensurePolicy(bucketId, overrides = {}) {
    if (!bucketId) return null;

    if (this.policies[bucketId]) {
      const existing = this.policies[bucketId];
      if (overrides.bucketName && (!existing.bucketName || existing.bucketName === existing.bucketId)) {
        existing.bucketName = overrides.bucketName;
      }
      if (overrides.destinationAddress && (!existing.destinationAddress || existing.destinationAddress === 'Vault')) {
        existing.destinationAddress = overrides.destinationAddress;
      }
      if (overrides.chain && !existing.chain) {
        existing.chain = overrides.chain;
      }
      return existing;
    }

    // Check alias mappings
    const aliasMap = {
      tax: 'gst',
      TAX: 'gst',
      gst: 'gst',
      expenses: 'exp',
      EXPENSES: 'exp',
      exp: 'exp',
      owner_pay: 'owner',
      OWNER_PAY: 'owner',
      owner: 'owner',
      profit: 'profit',
      PROFIT: 'profit'
    };

    let baseTemplate = null;
    if (aliasMap[bucketId] && this.policies[aliasMap[bucketId]]) {
      baseTemplate = this.policies[aliasMap[bucketId]];
    }

    // Look up in database (RevenueSplitRule / Wallet)
    let dbRule = null;
    try {
      if (prisma && prisma.revenueSplitRule) {
        dbRule = await prisma.revenueSplitRule.findUnique({
          where: { id: bucketId },
          include: { destinationWallet: true }
        });
      }
    } catch (e) {
      // ignore db error
    }

    // Look up in merchantState.wallets
    const stateWallet = merchantState.wallets?.find(w => w.id === bucketId);

    // Map template if dbRule has bucket category
    if (!baseTemplate && dbRule?.bucket && aliasMap[dbRule.bucket] && this.policies[aliasMap[dbRule.bucket]]) {
      baseTemplate = this.policies[aliasMap[dbRule.bucket]];
    }

    const defaultCategoryNames = {
      TAX: 'Tax Reserves (ATO)',
      EXPENSES: 'Operating Expenses',
      OWNER_PAY: 'Owner Drawings',
      PROFIT: 'Retained Profit'
    };

    const rawDbLabel = dbRule?.destinationWallet?.label;
    const bucketCategory = (dbRule?.bucket || stateWallet?.bucket || overrides.bucketName || '').toUpperCase();
    const bucketName = (rawDbLabel && rawDbLabel !== 'Main Settlement Vault')
      ? rawDbLabel
      : (stateWallet?.name || defaultCategoryNames[bucketCategory] || overrides.bucketName || (bucketCategory ? bucketCategory.replace('_', ' ') : `Bucket ${bucketId.substring(0, 8)}`));

    let rawChain = (dbRule?.destinationWallet?.blockchain || stateWallet?.blockchain || overrides.chain || 'solana').toLowerCase();
    let chain = 'solana';
    if (rawChain.includes('eth') || rawChain.includes('evm')) chain = 'evm';
    else if (rawChain.includes('btc') || rawChain.includes('bitcoin')) chain = 'btc';
    else chain = 'solana';

    let destinationAddress = dbRule?.destinationWallet?.address || stateWallet?.address || overrides.destinationAddress || (chain === 'evm' ? '0xD978...5C5ED' : (chain === 'btc' ? 'bc1q...VAULT' : '8YLL...VAULT'));

    let inputToken = overrides.inputToken;
    if (!inputToken) {
      if (chain === 'evm') inputToken = 'ETH';
      else if (chain === 'btc') inputToken = 'BTC';
      else if (bucketCategory === 'OWNER_PAY') inputToken = 'DYNK';
      else inputToken = 'SOL';
    }

    let whitelistedRouter = overrides.whitelistedRouter;
    let routerName = overrides.routerName;
    let oracleType = overrides.oracleType;
    let gasReserveMin = 0.005;

    if (chain === 'evm') {
      whitelistedRouter = whitelistedRouter || '0x7a250d5630B4cF539739dF2C5dAcb4c659F2488D';
      routerName = routerName || 'Uniswap V2/V3';
      oracleType = oracleType || 'Chainlink Price Feeds';
      gasReserveMin = 0.003;
    } else if (chain === 'btc') {
      whitelistedRouter = whitelistedRouter || 'thorchain-tss-vault-pool';
      routerName = routerName || 'THORChain TSS Decentralized Vaults';
      oracleType = oracleType || 'THORChain Consensus Oracle';
      gasReserveMin = 0.0001;
    } else {
      whitelistedRouter = whitelistedRouter || 'JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4';
      routerName = routerName || 'Jupiter DEX Aggregator';
      oracleType = oracleType || 'Pyth Network';
      gasReserveMin = 0.005;
    }

    const isEnabled = overrides.enabled !== undefined
      ? Boolean(overrides.enabled)
      : (dbRule ? dbRule.settlementMode === 'STABLE' : (stateWallet ? ['USDC', 'AUDC'].includes(String(stateWallet.settle || '').toUpperCase()) : false));

    const newPolicy = {
      bucketId,
      bucketName,
      chain,
      enabled: isEnabled,
      inputToken,
      outputToken: 'USDC',
      whitelistedRouter,
      routerName,
      oracleType,
      maxSlippageBps: overrides.maxSlippageBps || baseTemplate?.maxSlippageBps || 100,
      dustFloorAUD: overrides.dustFloorAUD !== undefined ? parseFloat(overrides.dustFloorAUD) : (baseTemplate?.dustFloorAUD || 15.00),
      gasReserveMin,
      destinationAddress,
      status: isEnabled ? 'ACTIVE' : 'INACTIVE',
      statusReason: isEnabled ? 'Automation running. Auto-swaps into USDC.' : 'Manual hold mode. Click Configure to enable auto-swap.',
      lastSwapAt: null,
      totalUsdcConverted: 0
    };

    this.policies[bucketId] = newPolicy;
    this.savePolicies(this.policies);
    return newPolicy;
  }

  /**
   * Synchronizes all known merchant revenue split rules and in-memory wallets into policies
   */
  async syncMerchantWallets() {
    try {
      if (prisma && prisma.revenueSplitRule) {
        const rules = await prisma.revenueSplitRule.findMany({
          include: { destinationWallet: true }
        });
        const defaultCategoryLabels = {
          TAX: 'Tax Reserves (ATO)',
          EXPENSES: 'Operating Expenses',
          OWNER_PAY: 'Owner Drawings',
          PROFIT: 'Retained Profit'
        };
        for (const rule of rules) {
          const bLabel = (rule.destinationWallet?.label && rule.destinationWallet.label !== 'Main Settlement Vault')
            ? rule.destinationWallet.label
            : (defaultCategoryLabels[rule.bucket] || rule.bucket);
          await this.ensurePolicy(rule.id, {
            bucketName: bLabel,
            chain: rule.destinationWallet?.blockchain,
            destinationAddress: rule.destinationWallet?.address,
            enabled: rule.settlementMode === 'STABLE'
          });
        }
      }
    } catch (e) {
      // non-fatal
    }

    if (merchantState?.wallets) {
      for (const w of merchantState.wallets) {
        await this.ensurePolicy(w.id, {
          bucketName: w.name,
          chain: w.blockchain,
          destinationAddress: w.address,
          enabled: ['USDC', 'AUDC'].includes(String(w.settle || '').toUpperCase())
        });
      }
    }
  }

  /**
   * Returns current policies with live gas checks and next schedule
   */
  async getPolicies() {
    await this.syncMerchantWallets();

    const pnlData = await getMerchantPnlData(merchantState.venue.id);
    const now = Date.now();

    const enriched = await Promise.all(Object.values(this.policies).map(async policy => {
      // Live balance calculation for this bucket
      const weightBal = await this.getBucketWeightAndBalance(policy.bucketId);
      const bucketBalanceAUD = weightBal.balance;
      
      // Check native gas reserves
      let gasReserve = 0.05; // Mock native reserve
      let gasLow = false;
      if (policy.chain === 'solana' && gasReserve < policy.gasReserveMin) {
        gasLow = true;
      }

      const status = !policy.enabled
        ? 'INACTIVE'
        : (policy.status === 'REVOKED' ? 'REVOKED' : (gasLow ? 'PAUSED' : 'ACTIVE'));

      const statusReason = !policy.enabled
        ? 'Auto-swap disabled (manual hold mode).'
        : (policy.status === 'REVOKED'
            ? 'Policy revoked on-chain by bucket owner.'
            : (gasLow
                ? `Gas reserve too low (${gasReserve} ${policy.chain === 'solana' ? 'SOL' : 'ETH'} < ${policy.gasReserveMin}). Automation paused.`
                : `Active. Auto-converts to USDC when balance ≥ $${policy.dustFloorAUD.toFixed(2)} AUD.`));

      return {
        ...policy,
        bucketBalanceAUD,
        gasReserve,
        gasReserveWarning: gasLow,
        status,
        statusReason,
        liveHoldings: pnlData.rows.find(r => r.symbol === policy.inputToken) || null
      };
    }));

    return {
      policies: enriched,
      nextScheduledCheck: Math.max(0, Math.round((this.nextScheduledCheck - now) / 1000)),
      totalConvertedAllTime: Object.values(this.policies).reduce((s, p) => s + (p.totalUsdcConverted || 0), 0)
    };
  }

  /**
   * Set or update a bucket's auto-swap policy (Requires merchant signature validation)
   */
  async updatePolicy(bucketId, config = {}, signatureInfo = {}) {
    if (!bucketId) {
      throw new Error('bucketId is required');
    }

    // Dynamically ensure policy exists for this bucketId
    await this.ensurePolicy(bucketId, config);

    // Enforce non-custodial constraints
    if (config.outputToken && config.outputToken !== 'USDC') {
      throw new Error('Non-custodial violation: Output token must be strictly pinned to USDC');
    }

    if (config.maxSlippageBps && (config.maxSlippageBps < 1 || config.maxSlippageBps > 500)) {
      throw new Error('Slippage cap must be between 1 and 500 bps (0.01% - 5.0%)');
    }

    const current = this.policies[bucketId];
    this.policies[bucketId] = {
      ...current,
      bucketName: config.bucketName || current.bucketName,
      chain: config.chain || current.chain,
      destinationAddress: config.destinationAddress || current.destinationAddress,
      enabled: config.enabled !== undefined ? Boolean(config.enabled) : current.enabled,
      dustFloorAUD: config.dustFloorAUD !== undefined ? parseFloat(config.dustFloorAUD) : current.dustFloorAUD,
      maxSlippageBps: config.maxSlippageBps !== undefined ? parseInt(config.maxSlippageBps, 10) : current.maxSlippageBps,
      whitelistedRouter: config.whitelistedRouter || current.whitelistedRouter,
      status: config.enabled ? 'ACTIVE' : 'INACTIVE',
      statusReason: config.enabled ? 'Policy signed on-chain and active.' : 'Disabled by owner.',
      lastUpdated: new Date().toISOString()
    };

    this.savePolicies(this.policies);

    // Synchronize Prisma rule if bucket is a database rule
    try {
      if (prisma && prisma.revenueSplitRule) {
        const exists = await prisma.revenueSplitRule.findUnique({ where: { id: bucketId } });
        if (exists) {
          await prisma.revenueSplitRule.update({
            where: { id: bucketId },
            data: { settlementMode: config.enabled ? 'STABLE' : 'CRYPTO' }
          });
        }
      }
    } catch (e) {
      // Non-fatal
    }

    // Synchronize in-memory merchantState wallet
    const stateW = merchantState.wallets?.find(w => w.id === bucketId);
    if (stateW) {
      stateW.settle = config.enabled ? 'USDC' : 'Hold';
    }

    await this.logLedgerEvent({
      bucketId,
      bucketName: this.policies[bucketId].bucketName,
      action: 'POLICY_SET',
      status: 'CONFIRMED',
      inputToken: this.policies[bucketId].inputToken,
      outputToken: 'USDC',
      maxSlippageBps: this.policies[bucketId].maxSlippageBps,
      dustFloorAUD: this.policies[bucketId].dustFloorAUD,
      whitelistedRouter: this.policies[bucketId].whitelistedRouter,
      signature: signatureInfo?.signature || `0x_sig_${Date.now()}`,
      message: `Policy successfully initialized on-chain for ${this.policies[bucketId].bucketName}`
    });

    return this.policies[bucketId];
  }

  /**
   * Bucket owner calls to revoke policy immediately
   */
  async revokePolicy(bucketId, signatureInfo = {}) {
    if (!bucketId) {
      throw new Error('bucketId is required');
    }

    await this.ensurePolicy(bucketId);

    const current = this.policies[bucketId];
    current.enabled = false;
    current.status = 'REVOKED';
    current.statusReason = 'Revoked on-chain by bucket owner.';
    current.lastRevokedAt = new Date().toISOString();

    this.savePolicies(this.policies);

    try {
      if (prisma && prisma.revenueSplitRule) {
        const exists = await prisma.revenueSplitRule.findUnique({ where: { id: bucketId } });
        if (exists) {
          await prisma.revenueSplitRule.update({
            where: { id: bucketId },
            data: { settlementMode: 'CRYPTO' }
          });
        }
      }
    } catch (e) {
      // Non-fatal
    }

    const stateW = merchantState.wallets?.find(w => w.id === bucketId);
    if (stateW) {
      stateW.settle = 'Hold';
    }

    await this.logLedgerEvent({
      bucketId,
      bucketName: current.bucketName,
      action: 'POLICY_REVOKED',
      status: 'CONFIRMED',
      inputToken: current.inputToken,
      signature: signatureInfo?.signature || `0x_revoke_${Date.now()}`,
      message: `Auto-swap authorization revoked on-chain for ${current.bucketName}. No further funds can be moved.`
    });

    return current;
  }

  /**
   * Main Keeper Cycle:
   * 1. Evaluates all active policies against dust floors.
   * 2. Nets balances across buckets holding the same token on the same chain.
   * 3. Queries oracles (Pyth / Chainlink) for price guarantees.
   * 4. Submits on-chain execute_swap / executeSwap.
   * 5. Splits resulting USDC back to contributing buckets pro-rata.
   * 6. Ensures idempotency and safe retry.
   */
  async runKeeperCycle() {
    this.nextScheduledCheck = Date.now() + 60000;
    console.log('[AutoSwapKeeper] Running scheduled automation check...');

    const pnlData = await getMerchantPnlData(merchantState.venue.id);
    const activePolicies = Object.values(this.policies).filter(p => p.enabled && p.status === 'ACTIVE');

    if (activePolicies.length === 0) {
      return { status: 'NOOP', message: 'No active policies enabled for auto-swap' };
    }

    // Group eligible buckets by inputToken to perform Multi-Bucket Netting
    const tokenGroups = {};

    for (const policy of activePolicies) {
      const holdingRow = pnlData.rows.find(r => r.symbol === policy.inputToken);
      if (!holdingRow || holdingRow.grossValueAUD <= 0) {
        continue;
      }

      // 1. Dust-Floor Check: Skip silently if below threshold
      if (holdingRow.grossValueAUD < policy.dustFloorAUD) {
        await this.logLedgerEvent({
          bucketId: policy.bucketId,
          bucketName: policy.bucketName,
          inputToken: policy.inputToken,
          status: 'DUST_SKIPPED',
          grossValueAUD: holdingRow.grossValueAUD,
          dustFloorAUD: policy.dustFloorAUD,
          message: `Balance ($${holdingRow.grossValueAUD.toFixed(2)} AUD) is below dust floor ($${policy.dustFloorAUD.toFixed(2)} AUD). Skipped silently.`
        });
        continue;
      }

      if (!tokenGroups[policy.inputToken]) {
        tokenGroups[policy.inputToken] = {
          inputToken: policy.inputToken,
          chain: policy.chain,
          whitelistedRouter: policy.whitelistedRouter,
          routerName: policy.routerName,
          oracleType: policy.oracleType,
          maxSlippageBps: policy.maxSlippageBps,
          holdingRow,
          participatingBuckets: []
        };
      }

      tokenGroups[policy.inputToken].participatingBuckets.push(policy);
    }

    const swapResults = [];

    // Execute netted swaps per token group
    for (const [token, group] of Object.entries(tokenGroups)) {
      const lockKey = `${token}_${group.chain}`;
      if (this.inFlightSwaps.has(lockKey)) {
        console.warn(`[AutoSwapKeeper] Swap for ${lockKey} already in-flight, skipping for idempotency.`);
        continue;
      }

      this.inFlightSwaps.set(lockKey, Date.now());

      try {
        const result = await this.executeNettedSwap(group);
        swapResults.push(result);
      } catch (err) {
        console.error(`[AutoSwapKeeper] Netted swap failed for ${token}:`, err.message);
        await this.logLedgerEvent({
          action: 'SWAP_FAILED',
          status: 'REVERTED',
          inputToken: token,
          chain: group.chain,
          error: err.message,
          message: `Swap execution reverted: ${err.message}`
        });
      } finally {
        this.inFlightSwaps.delete(lockKey);
      }
    }

    return {
      timestamp: new Date().toISOString(),
      executedCount: swapResults.length,
      swaps: swapResults
    };
  }

  /**
   * Executes a single netted swap across 1 or more contributing buckets
   */
  async executeNettedSwap(group) {
    const { inputToken, chain, participatingBuckets, holdingRow, whitelistedRouter, routerName, oracleType, maxSlippageBps } = group;

    // 2. Net Balances and calculate proportional contribution
    const totalGrossAUD = holdingRow.grossValueAUD;
    const totalAmountIn = holdingRow.holdingNumeric;

    // Weight per bucket based on configured revenue split
    const weights = await Promise.all(participatingBuckets.map(async p => {
      const wb = await this.getBucketWeightAndBalance(p.bucketId);
      return { bucketId: p.bucketId, pct: wb.pct || 25 };
    }));

    const totalWeights = weights.reduce((sum, w) => sum + w.pct, 0) || 1;

    const bucketContributions = participatingBuckets.map(p => {
      const w = weights.find(x => x.bucketId === p.bucketId);
      const weight = w ? w.pct : 25;
      const proportion = weight / totalWeights;
      const bucketAmountIn = totalAmountIn * proportion;
      const bucketGrossAUD = totalGrossAUD * proportion;
      return {
        bucketId: p.bucketId,
        bucketName: p.bucketName,
        destinationAddress: p.destinationAddress,
        proportion,
        bucketAmountIn,
        bucketGrossAUD
      };
    });

    // 3. Oracle Price Cross-Check
    const oraclePriceAUD = holdingRow.currentPriceAUD;
    const expectedAUD = totalGrossAUD;
    const minAcceptableAUD = expectedAUD * (1 - maxSlippageBps / 10000);

    // Compute swap charge
    const swapChargeAUD = holdingRow.swapChargeAUD || 5.00;
    const actualReceivedAUD = Math.max(0, totalGrossAUD - swapChargeAUD);

    if (actualReceivedAUD < minAcceptableAUD) {
      throw new Error(`Oracle slippage violation: expected at least ${audToUsdc(minAcceptableAUD).toFixed(2)} USDC ($${minAcceptableAUD.toFixed(2)} AUD), received quote ${audToUsdc(actualReceivedAUD).toFixed(2)} USDC ($${actualReceivedAUD.toFixed(2)} AUD)`);
    }
    const actualReceivedUSDC = audToUsdc(actualReceivedAUD);

    // 4. On-Chain Transaction Execution Simulation
    const txHash = chain === 'solana'
      ? `5SolSwap${Date.now()}${Math.random().toString(36).substring(2, 6)}`
      : `0xevm_swap_${Date.now()}${Math.random().toString(36).substring(2, 6)}`;

    // 5. Pro-Rata Credit-Back: Distribute resulting USDC to contributing buckets
    // (bucket balances are kept in AUD, so each share is tracked in both)
    let creditedSum = 0;
    let creditedUsdcSum = 0;
    const proRataSettlements = bucketContributions.map((contrib, idx) => {
      let audShare;
      let usdcShare;
      // Remainder absorption on the last bucket prevents 1-cent rounding losses
      if (idx === bucketContributions.length - 1) {
        audShare = Math.round((actualReceivedAUD - creditedSum) * 100) / 100;
        usdcShare = Math.round((actualReceivedUSDC - creditedUsdcSum) * 100) / 100;
      } else {
        audShare = Math.round((actualReceivedAUD * contrib.proportion) * 100) / 100;
        usdcShare = Math.round((actualReceivedUSDC * contrib.proportion) * 100) / 100;
        creditedSum += audShare;
        creditedUsdcSum += usdcShare;
      }

      // Update in-memory wallet state
      const targetWallet = merchantState.wallets?.find(w => w.id === contrib.bucketId) ||
        merchantState.wallets?.find(w => w.name && contrib.bucketName && w.name.toLowerCase() === contrib.bucketName.toLowerCase());
      if (targetWallet) {
        targetWallet.balance = Math.round((targetWallet.balance + audShare) * 100) / 100;
      }

      // Update policy stats
      if (this.policies[contrib.bucketId]) {
        this.policies[contrib.bucketId].totalUsdcConverted = (this.policies[contrib.bucketId].totalUsdcConverted || 0) + usdcShare;
        this.policies[contrib.bucketId].lastSwapAt = new Date().toISOString();
      }

      return {
        bucketId: contrib.bucketId,
        bucketName: contrib.bucketName,
        proportion: `${(contrib.proportion * 100).toFixed(1)}%`,
        inputAmount: contrib.bucketAmountIn.toFixed(4),
        usdcReceived: usdcShare.toFixed(2),
        valueAUD: audShare.toFixed(2),
        destination: contrib.destinationAddress
      };
    });

    this.savePolicies(this.policies);

    // 6. Record to Execution Ledger
    const ledgerRecord = await this.logLedgerEvent({
      action: 'SWAP_EXECUTED',
      status: 'CONFIRMED',
      inputToken,
      outputToken: 'USDC',
      chain,
      router: whitelistedRouter,
      routerName,
      oracleType,
      oraclePriceAUD: oraclePriceAUD.toFixed(2),
      amountIn: totalAmountIn.toFixed(4),
      grossValueAUD: totalGrossAUD.toFixed(2),
      swapChargeAUD: swapChargeAUD.toFixed(2),
      usdcReceived: actualReceivedUSDC.toFixed(2),
      netValueAUD: actualReceivedAUD.toFixed(2),
      slippageEnforced: `${(maxSlippageBps / 100).toFixed(2)}%`,
      txHash,
      explorerUrl: chain === 'solana'
        ? `https://solscan.io/tx/${txHash}?cluster=devnet`
        : `https://sepolia.etherscan.io/tx/${txHash}`,
      isNettedBatch: bucketContributions.length > 1,
      settlements: proRataSettlements,
      message: `Successfully swapped ${totalAmountIn.toFixed(4)} ${inputToken} into ${actualReceivedUSDC.toFixed(2)} USDC ($${actualReceivedAUD.toFixed(2)} AUD) via ${routerName}. Pro-rata credited to ${proRataSettlements.map(s => s.bucketName).join(', ')}.`
    });

    return ledgerRecord;
  }

  /**
   * Exports the entire execution ledger as CSV
   */
  exportLedgerCsv() {
    const headers = [
      'Timestamp',
      'Transaction ID',
      'Status',
      'Chain',
      'Input Token',
      'Amount In',
      'Oracle Price AUD',
      'USDC Received',
      'Swap Charge AUD',
      'Router',
      'Buckets',
      'Tx Hash'
    ];

    const rows = this.ledger.map(entry => [
      `"${entry.timestamp}"`,
      `"${entry.id}"`,
      `"${entry.status}"`,
      `"${entry.chain || 'multi'}"`,
      `"${entry.inputToken || ''}"`,
      `"${entry.amountIn || '0'}"`,
      `"${entry.oraclePriceAUD || ''}"`,
      `"${receivedUsdcOf(entry)}"`,
      `"${entry.swapChargeAUD || '0'}"`,
      `"${entry.routerName || ''}"`,
      `"${(entry.settlements || []).map(s => s.bucketName).join(' + ') || entry.bucketName || ''}"`,
      `"${entry.txHash || ''}"`
    ]);

    return [headers.join(','), ...rows.map(r => r.join(','))].join('\n');
  }

  startBackgroundKeeper(intervalMs = 60000) {
    if (this.intervalId) clearInterval(this.intervalId);
    this.intervalId = setInterval(() => {
      this.runKeeperCycle().catch(err => console.error('[AutoSwapKeeper] Cycle error:', err.message));
    }, intervalMs);
    console.log(`[AutoSwapKeeper] Background keeper active (interval ${intervalMs / 1000}s).`);
  }

  stopBackgroundKeeper() {
    if (this.intervalId) {
      clearInterval(this.intervalId);
      this.intervalId = null;
    }
  }
}

export const autoSwapKeeper = new AutoSwapKeeperService();
