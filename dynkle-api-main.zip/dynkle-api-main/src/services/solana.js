import {
  Connection,
  PublicKey,
  Transaction,
  SystemProgram,
  Keypair,
  LAMPORTS_PER_SOL
} from '@solana/web3.js';
import {
  getAssociatedTokenAddressSync,
  createTransferInstruction,
  createAssociatedTokenAccountIdempotentInstruction,
  TOKEN_PROGRAM_ID
} from '@solana/spl-token';
import crypto from 'crypto';
import { SOLANA_CLUSTER_URL, MERCHANT, DEMO_MODE } from '../config.js';
import prisma from '../db.js';
import { terminalGateway } from '../gateway/terminalGateway.js';
import { recordCryptoReceipt } from './pnlService.js';

const connection = new Connection(SOLANA_CLUSTER_URL, { commitment: 'confirmed', disableRetryOnRateLimit: true });
const rpcConnections = [connection];

// Well-known token mints (Devnet / Mainnet)
export const KNOWN_MINTS = {
  USDC_DEVNET: '4zMMC9srt5Ri5X14GAgXhaHii3GnPAEERYPJgZJDncDU',
  USDC_MAINNET: 'EPjFWdd5AufqSSqeM2qN1xzybapC8G4wEGGkZwyTDt1v',
};

// DYNK has one real mint per deployment, shared with the DYNK backend.
// It comes only from DYNK_MINT_ADDRESS (no placeholder default).
export function dynkMintAddress() {
  const v = String(process.env.DYNK_MINT_ADDRESS || '').trim();
  if (!v) throw new Error('UNSUPPORTED_MINT: DYNK_MINT_ADDRESS is not configured.');
  return v;
}

export function generateReference() {
  return Keypair.generate().publicKey;
}

const TOKEN_DECIMALS = { DYNK: Number(process.env.DYNK_MINT_DECIMALS || 9), USDC: 6 };

/**
 * Resolves the mint and decimals for an SPL token symbol on the active cluster.
 * Throws rather than silently defaulting to USDC — paying in the wrong mint is
 * indistinguishable from paying nothing once it is on-chain.
 */
export function resolveTokenMint(tokenSymbol) {
  const sym = (tokenSymbol || '').toUpperCase();
  if (sym === 'DYNK') return { mint: dynkMintAddress(), decimals: TOKEN_DECIMALS.DYNK };
  const isDevnet = SOLANA_CLUSTER_URL.includes('devnet');
  const key = `${sym}_${isDevnet ? 'DEVNET' : 'MAINNET'}`;
  const mint = KNOWN_MINTS[key];

  if (!mint) {
    throw new Error(`UNSUPPORTED_MINT: No ${sym} mint configured for this cluster.`);
  }

  return { mint, decimals: TOKEN_DECIMALS[sym] ?? 6 };
}

let cachedBlockhashData = null;
let lastBlockhashFetchTime = 0;

export async function fetchSolanaBlockhash() {
  if (cachedBlockhashData && (Date.now() - lastBlockhashFetchTime < 30000)) {
    return cachedBlockhashData;
  }
  for (const conn of rpcConnections) {
    try {
      const res = await conn.getLatestBlockhash('confirmed');
      if (res && res.blockhash) {
        cachedBlockhashData = res;
        lastBlockhashFetchTime = Date.now();
        return res;
      }
    } catch (err) {
      // try next RPC
    }
  }
  if (cachedBlockhashData) return cachedBlockhashData;
  // Never invent a blockhash: a transaction built on one can't land.
  throw new Error('BLOCKHASH_UNAVAILABLE: Could not reach Solana for a recent blockhash.');
}

/**
 * Builds an atomic multi-instruction Solana transaction.
 * Distributes customer payment across the 4 configured revenue split buckets in ONE atomic transaction.
 * If any single transfer fails, the entire transaction reverts on-chain.
 * 
 * @param {Object} order - Order record from database
 * @param {string} payerAddress - Customer wallet public key
 * @returns {Promise<Transaction>}
 */
export async function buildSolanaTransaction(order, payerAddress) {
  const payer = new PublicKey(payerAddress);
  const tx = new Transaction();

  // 1. Fetch merchant's active revenue split rules and destination wallets
  const splitRules = await prisma.revenueSplitRule.findMany({
    where: { merchantId: order.merchantId },
    include: { destinationWallet: true }
  });

  const isSplToken = order.tokenSymbol !== 'SOL';
  const totalCryptoAmount = parseFloat(order.cryptoAmount.toString());

  if (!isSplToken) {
    // SINGLE MERCHANT TREASURY DEPOSIT (Post-Payment Flow — OPTIMISED)
    // 100% of customer funds transfer to the Merchant Treasury. Category splits are tracked off-chain in the accounting ledger.
    const totalLamports = Math.round(totalCryptoAmount * LAMPORTS_PER_SOL);
    const treasuryAddress = order.merchant?.solanaAddress || MERCHANT.solanaAddress;
    const treasuryPubkey = new PublicKey(treasuryAddress);

    const transferIx = SystemProgram.transfer({
      fromPubkey: payer,
      toPubkey: treasuryPubkey,
      lamports: totalLamports
    });

    if (order.referenceKey) {
      try {
        transferIx.keys.push({
          pubkey: new PublicKey(order.referenceKey),
          isSigner: false,
          isWritable: false
        });
      } catch (e) {
        console.warn('[Reference Key Push Warning]:', e.message);
      }
    }

    tx.add(transferIx);

  } else {
    // SPL TOKEN SINGLE TREASURY DEPOSIT (DYNK / USDC)
    const { mint: mintString, decimals } = resolveTokenMint(order.tokenSymbol);

    const mintPubkey = new PublicKey(mintString);
    const totalRawUnits = BigInt(Math.round(totalCryptoAmount * Math.pow(10, decimals)));
    const payerAta = getAssociatedTokenAddressSync(mintPubkey, payer);

    const treasuryAddress = order.merchant?.solanaAddress || MERCHANT.solanaAddress;
    const treasuryOwner = new PublicKey(treasuryAddress);
    const treasuryAta = getAssociatedTokenAddressSync(mintPubkey, treasuryOwner);

    // Ensure recipient Treasury ATA exists idempotently
    tx.add(createAssociatedTokenAccountIdempotentInstruction(
      payer,
      treasuryAta,
      treasuryOwner,
      mintPubkey
    ));

    // Transfer SPL tokens directly to Merchant Treasury ATA
    const transferIx = createTransferInstruction(
      payerAta,
      treasuryAta,
      payer,
      totalRawUnits,
      [],
      TOKEN_PROGRAM_ID
    );

    if (order.referenceKey) {
      transferIx.keys.push({
        pubkey: new PublicKey(order.referenceKey),
        isSigner: false,
        isWritable: false
      });
    }

    tx.add(transferIx);
  }

  if (tx.instructions.length === 0) {
    throw new Error('EMPTY_TRANSACTION: Refusing to build a payment that transfers nothing.');
  }

  const { blockhash, lastValidBlockHeight } = await fetchSolanaBlockhash();
  tx.recentBlockhash = blockhash;
  tx.lastValidBlockHeight = lastValidBlockHeight;
  tx.feePayer = payer;

  return tx;
}

/**
 * Rigorously parses and verifies an on-chain Solana transaction.
 * Ensures:
 * - Transaction was confirmed and succeeded without on-chain errors (meta.err === null)
 * - order.referenceKey is included in transaction account keys (Solana Pay standard)
 * - Recipient address receives at least the required token or native SOL amount
 */
export async function verifyParsedTransaction(order, txHash, { allowDemoHash = false } = {}) {
  // Legacy demo only: a fake `sol_test_...` hash is accepted when DEMO_MODE is
  // on AND the caller is the explicit demo submit. No tap-and-pay channel ever
  // passes allowDemoHash.
  if (allowDemoHash && DEMO_MODE && /^(sol_test_|mock_)/.test(txHash)) {
    return { verified: true, senderAddress: 'Demo wallet' };
  }

  const isRealSolSig = typeof txHash === 'string' && txHash.length >= 64 && !txHash.includes('_');
  if (!isRealSolSig) {
    throw new Error('INVALID_TRANSACTION_SIGNATURE: Must be a valid 64+ character Solana signature.');
  }

  let parsedTx = null;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      parsedTx = await connection.getParsedTransaction(txHash, {
        maxSupportedTransactionVersion: 0,
        commitment: 'confirmed'
      });
      if (parsedTx) break;
    } catch (err) {
      console.warn(`[Solana RPC Parse Attempt ${attempt + 1} Warning]:`, err.message);
    }
    if (attempt < 2) await new Promise(r => setTimeout(r, 800));
  }

  if (!parsedTx) {
    const status = await connection.getSignatureStatus(txHash);
    if (status?.value?.err) {
      throw new Error(`TRANSACTION_FAILED_ON_CHAIN: ${JSON.stringify(status.value.err)}`);
    }
    if (!status?.value?.confirmationStatus) {
      throw new Error('TRANSACTION_NOT_FOUND: The submitted transaction signature was not found on Solana.');
    }
    // Seen on-chain but not yet parseable. Never book a payment we could not
    // check the amount and recipient of — let the caller keep polling.
    throw new Error('TRANSACTION_PENDING_VERIFICATION: Confirmed but not yet parseable; retry shortly.');
  }

  if (parsedTx.meta?.err) {
    throw new Error(`TRANSACTION_FAILED_ON_CHAIN: ${JSON.stringify(parsedTx.meta.err)}`);
  }

  // 1. Verify Reference Key if present on order
  let hasReference = false;
  if (order.referenceKey) {
    const rawAccountKeys = parsedTx.transaction?.message?.accountKeys || [];
    const accountKeys = rawAccountKeys.map(k => (typeof k === 'string' ? k : k.pubkey?.toBase58?.() || k.pubkey || ''));
    hasReference = accountKeys.includes(order.referenceKey);
  }
  // POS-H2: a payment counts for this order only if it carries this order's
  // reference. Matching by recipient and amount alone could credit another
  // customer's transfer to this order.
  if (order.referenceKey && !hasReference) {
    throw new Error('MISSING_REFERENCE: The transaction does not carry this order\'s reference.');
  }

  // 2. Identify sender (fee payer / first signer)
  let detectedSender = 'Solana Wallet';
  const firstKey = parsedTx.transaction?.message?.accountKeys?.[0];
  if (firstKey) {
    detectedSender = typeof firstKey === 'string' ? firstKey : (firstKey.pubkey?.toBase58?.() || firstKey.pubkey);
  }

  // 3. Verify Recipient and Amount
  const merchantSolAddress = order.merchant?.solanaAddress || MERCHANT.solanaAddress;
  const expectedCrypto = parseFloat(order.cryptoAmount.toString());

  if (order.tokenSymbol === 'SOL') {
    const expectedLamports = Math.floor(expectedCrypto * LAMPORTS_PER_SOL);
    let transferredLamports = 0;

    const instructions = [
      ...(parsedTx.transaction?.message?.instructions || []),
      ...(parsedTx.meta?.innerInstructions?.flatMap(i => i.instructions) || [])
    ];

    for (const ix of instructions) {
      if (ix.program === 'system' && ix.parsed?.type === 'transfer') {
        const dest = ix.parsed.info?.destination;
        if (dest === merchantSolAddress || (order.merchant?.revenueSplitRules || []).some(r => r.destinationWallet?.address === dest)) {
          transferredLamports += parseInt(ix.parsed.info?.lamports || 0, 10);
        }
      }
    }

    if (transferredLamports === 0 && parsedTx.meta?.postBalances && parsedTx.meta?.preBalances) {
      const keys = parsedTx.transaction.message.accountKeys.map(k => typeof k === 'string' ? k : k.pubkey.toBase58());
      const merchIdx = keys.indexOf(merchantSolAddress);
      if (merchIdx !== -1) {
        const delta = parsedTx.meta.postBalances[merchIdx] - parsedTx.meta.preBalances[merchIdx];
        if (delta > 0) transferredLamports = delta;
      }
    }

    if (transferredLamports < Math.floor(expectedLamports * 0.99)) {
      throw new Error(`INSUFFICIENT_AMOUNT: Transferred ${transferredLamports / LAMPORTS_PER_SOL} SOL < required ${expectedCrypto} SOL`);
    }

  } else {
    // SPL Token Verification (USDC / DYNK)
    // Credit only balance increases on accounts owned by the merchant or a
    // configured split destination, and only for the mint this order was quoted in.
    const { mint: expectedMint } = resolveTokenMint(order.tokenSymbol);

    const payoutOwners = new Set(
      [
        merchantSolAddress,
        ...(order.merchant?.revenueSplitRules || []).map(r => r.destinationWallet?.address)
      ].filter(Boolean)
    );

    const pre = parsedTx.meta?.preTokenBalances || [];
    const post = parsedTx.meta?.postTokenBalances || [];

    if (post.length === 0) {
      throw new Error(`WRONG_TOKEN: No SPL token movement found in transaction for ${order.tokenSymbol}.`);
    }

    let transferredTokens = 0;
    let sawExpectedMint = false;

    for (const postBal of post) {
      if (postBal.mint !== expectedMint) continue;
      sawExpectedMint = true;
      if (!payoutOwners.has(postBal.owner)) continue;

      const preBal = pre.find(p => p.accountIndex === postBal.accountIndex);
      const postAmt = postBal.uiTokenAmount?.uiAmount || 0;
      const preAmt = preBal?.uiTokenAmount?.uiAmount || 0;
      if (postAmt > preAmt) transferredTokens += (postAmt - preAmt);
    }

    if (!sawExpectedMint) {
      throw new Error(`WRONG_TOKEN: Transaction did not move ${order.tokenSymbol} (mint ${expectedMint}).`);
    }

    if (transferredTokens === 0) {
      throw new Error(`WRONG_RECIPIENT: No ${order.tokenSymbol} reached the merchant or its payout wallets.`);
    }

    if (transferredTokens < (expectedCrypto * 0.99)) {
      throw new Error(`INSUFFICIENT_TOKEN_AMOUNT: Transferred ${transferredTokens} < required ${expectedCrypto} ${order.tokenSymbol}`);
    }
  }

  return { verified: true, senderAddress: detectedSender };
}

/**
 * Verifies and confirms an on-chain transaction.
 * Enforces persistent anti-replay protection via PostgreSQL UNIQUE(blockchain, txHash).
 * Creates audit settlement records for each revenue split bucket.
 */
// opts (EVM payments found by services/evmWatch.js): { blockchain, token, receiverAddress, verified }
export async function confirmSolanaPayment(orderId, txHash, senderAddress = 'Solana Wallet', opts = {}) {
  const chainName = opts.blockchain || 'solana';
  // 1. Strict 90-second Rate Lock Check
  const order = await prisma.order.findUnique({
    where: { id: orderId },
    include: {
      merchant: {
        include: {
          revenueSplitRules: {
            include: { destinationWallet: true }
          }
        }
      }
    }
  });

  if (!order) {
    throw new Error('ORDER_NOT_FOUND');
  }

  if (order.status === 'PAID' || order.status === 'SETTLED') {
    return { alreadyPaid: true, orderId: order.id, status: order.status };
  }

  // A cashier starting a new sale on the same counter cancels this order
  // (see orders.js POST /), but that cancellation only touches the database —
  // it cannot revoke a transaction the customer already signed and is still
  // in flight to broadcast. If it lands anyway, the money is real and must be
  // tracked, not silently dropped because the order "shouldn't" be payable.
  const isStrayPayment = order.status === 'CANCELLED' || order.status === 'EXPIRED';

  // Rate Lock Validation: If rate lock passed but customer completed on-chain payment,
  // accept settlement seamlessly so customer funds and merchant revenues are safely booked.

  // 2. Anti-Replay Check in PostgreSQL
  const existingOrderTx = await prisma.transaction.findUnique({
    where: { orderId: order.id }
  });
  if (existingOrderTx) {
    // Same hash replayed: harmless, report the original settlement.
    if (existingOrderTx.txHash === txHash) {
      return { alreadyPaid: true, orderId: order.id, status: order.status, txHash: existingOrderTx.txHash };
    }
    // A different hash means the customer paid a second time for one bill.
    // Surface it so a refund can be raised instead of silently keeping the funds.
    const err = new Error(
      `DUPLICATE_PAYMENT: Order ${order.orderNumber} was already settled by ${existingOrderTx.txHash}; a second payment ${txHash} was received.`
    );
    err.originalTxHash = existingOrderTx.txHash;
    err.duplicateTxHash = txHash;
    throw err;
  }

  const existingTx = await prisma.transaction.findUnique({
    where: {
      blockchain_txHash: {
        blockchain: chainName,
        txHash
      }
    }
  });

  if (existingTx) {
    throw new Error('DUPLICATE_TRANSACTION_HASH: This on-chain transaction has already been settled.');
  }

  // 3. Verify on-chain status, recipient, amount and referenceKey via Solana RPC connection
  let detectedSender = senderAddress;

  // EVM transfers were already matched on-chain by evmWatch (address + order tag)
  const verification = opts.verified ? { verified: true, senderAddress } : await verifyParsedTransaction(order, txHash, { allowDemoHash: opts.allowDemoHash === true });
  if (!verification || !verification.verified) {
    throw new Error('TRANSACTION_VERIFICATION_FAILED: The transaction could not be verified on-chain.');
  }
  if (verification.senderAddress && verification.senderAddress !== 'Solana Wallet') {
    detectedSender = verification.senderAddress;
  }

  // 4. Atomic PostgreSQL Transaction: Record Transaction + Settlement Splits + Order status
  const splitRules = order.merchant.revenueSplitRules;
  const totalCrypto = parseFloat(order.cryptoAmount.toString());
  const totalAUD = parseFloat(order.totalAUD.toString());

  const result = await prisma.$transaction(async (tx) => {
    // Record transaction with unique constraint
    const recordedTx = await tx.transaction.create({
      data: {
        merchantId: order.merchantId,
        orderId: order.id,
        blockchain: chainName,
        token: opts.token || order.tokenSymbol,
        amount: order.cryptoAmount,
        senderAddress: detectedSender,
        receiverAddress: opts.receiverAddress || MERCHANT.solanaAddress,
        txHash,
        status: 'confirmed'
      }
    });

    // Create settlement breakdown records
    const settlements = [];
    for (const rule of splitRules) {
      const shareFraction = rule.basisPoints / 10000;
      const bucketAUD = totalAUD * shareFraction;
      const bucketCrypto = totalCrypto * shareFraction;

      const settlement = await tx.settlementTransaction.create({
        data: {
          transactionId: recordedTx.id,
          bucket: rule.bucket,
          basisPoints: rule.basisPoints,
          amountAUD: bucketAUD,
          tokenAmount: bucketCrypto,
          tokenSymbol: order.tokenSymbol,
          destinationWallet: rule.destinationWallet.address,
          settlementTxHash: txHash,
          status: 'settled'
        }
      });
      settlements.push(settlement);
    }

    // Update order status. The money genuinely arrived, so it is booked as
    // PAID either way — but a stray payment (order was CANCELLED/EXPIRED when
    // this landed) gets an audit trail instead of silently looking identical
    // to a normal sale, since the terminal may already be serving someone else.
    const updatedOrder = await tx.order.update({
      where: { id: order.id },
      data: {
        status: 'PAID',
        paidAt: new Date(),
        customerWallet: detectedSender
      }
    });

    if (isStrayPayment) {
      await tx.auditLog.create({
        data: {
          merchantId: order.merchantId,
          action: 'STRAY_PAYMENT_ON_CANCELLED_ORDER',
          resource: 'ORDER',
          resourceId: order.id,
          metadata: {
            orderNumber: order.orderNumber,
            statusAtPaymentTime: order.status,
            txHash,
            amountAUD: totalAUD,
            tokenSymbol: order.tokenSymbol,
            senderAddress: detectedSender,
            detectedAt: new Date().toISOString()
          }
        }
      });
    }

    return { recordedTx, settlements, updatedOrder };
  });

  // Feeds the merchant's real P&L/Holdings ledger. This used to have no
  // caller anywhere in the codebase — the P&L page showed the same
  // fabricated demo numbers forever, regardless of real sales volume.
  try {
    recordCryptoReceipt(
      order.merchantId,
      order.tokenSymbol,
      parseFloat(order.cryptoAmount.toString()),
      parseFloat(order.quotePrice.toString()),
      order.orderNumber
    );
  } catch (e) {
    console.warn('[P&L Receipt Recording Warning]:', e.message);
  }

  // 5. Trigger hardware success event on screenless terminal — but not for a
  // stray payment, since the terminal may already be armed for a different,
  // newer order and flashing "success" would misattribute it to that customer.
  if (!isStrayPayment) {
    terminalGateway.setSuccess(order.terminalId, {
      orderId: order.id,
      txHash,
      tokenSymbol: order.tokenSymbol,
      amount: order.cryptoAmount.toString()
    }).catch(e => console.warn('[Terminal Chime Warning]:', e.message));
  } else {
    console.warn(`[Stray Payment] Order ${order.orderNumber} was ${order.status} but received a real payment (${txHash}). Flagged for manual review.`);
  }

  return {
    success: true,
    orderId: result.updatedOrder.id,
    orderNumber: result.updatedOrder.orderNumber,
    txHash: result.recordedTx.txHash,
    strayPayment: isStrayPayment,
    status: 'PAID',
    settlements: result.settlements.map(s => ({
      bucket: s.bucket,
      basisPoints: s.basisPoints,
      amountAUD: s.amountAUD.toString(),
      tokenAmount: s.tokenAmount.toString(),
      destinationWallet: s.destinationWallet
    }))
  };
}

const inFlightChecks = new Map();
const lastCheckedOrder = new Map();

let cachedMerchSigs = [];
let lastMerchSigsFetch = 0;

async function getRecentMerchantSignatures(merchPubkey) {
  const now = Date.now();
  if (now - lastMerchSigsFetch < 10000 && cachedMerchSigs.length > 0) {
    return cachedMerchSigs;
  }
  try {
    for (const conn of rpcConnections) {
      try {
        const sigs = await Promise.race([
          conn.getSignaturesForAddress(merchPubkey, { limit: 10 }),
          new Promise((_, rej) => setTimeout(() => rej(new Error('TIMEOUT')), 4500))
        ]);
        if (sigs && sigs.length > 0) {
          cachedMerchSigs = sigs;
          lastMerchSigsFetch = now;
          return sigs;
        }
      } catch (e) {}
    }
  } catch (err) {}
  return cachedMerchSigs;
}

export async function checkSolanaPayment(order) {
  try {
    if (!order || order.status === 'PAID' || order.status === 'SETTLED') return null;
    // Tap-and-pay orders are verified and booked by src/tappay only.
    if (order.paymentLock || order.tapPayAmount != null) return null;

    // Return in-flight check if one is already querying the blockchain for this order
    if (inFlightChecks.has(order.id)) {
      return await inFlightChecks.get(order.id);
    }

    const now = Date.now();
    const lastCheck = lastCheckedOrder.get(order.id) || 0;
    // Throttle: minimum 2500ms between completed queries per order
    if (now - lastCheck < 2500) {
      return null;
    }

    const checkPromise = (async () => {
      try {
        // 1. Check reference public key (Standard Solana Pay reference tracking)
        if (order.referenceKey) {
          try {
            const refPubkey = new PublicKey(order.referenceKey);
            let sigs = null;
            for (const conn of rpcConnections) {
              try {
                sigs = await Promise.race([
                  conn.getSignaturesForAddress(refPubkey, { limit: 2 }),
                  new Promise((_, rej) => setTimeout(() => rej(new Error('TIMEOUT')), 4500))
                ]);
                if (sigs && sigs.length > 0) break;
              } catch (err) {}
            }

            if (sigs && sigs.length > 0) {
              const confirmedSig = sigs.find(s => !s.err);
              if (confirmedSig) {
                console.log(`[Solana Pay Reference Detected]: ${confirmedSig.signature}`);
                return await confirmSolanaPayment(order.id, confirmedSig.signature);
              }
            }
          } catch (e) {}
        }

        // No fallback by merchant address (POS-H2): only the order's reference identifies its payment.
      } finally {
        lastCheckedOrder.set(order.id, Date.now());
        inFlightChecks.delete(order.id);
      }
      return null;
    })();

    inFlightChecks.set(order.id, checkPromise);
    return await checkPromise;
  } catch (err) {
    // RPC or network warning
  }
  return null;
}

/**
 * Executes a real cryptocurrency refund on Solana.
 * Builds and signs a transfer instruction directly to the customer's wallet address.
 */
export async function executeSolanaRefund(order, destinationAddress, tokenSymbol, cryptoAmount) {
  let merchantKeypair = null;
  if (process.env.MERCHANT_SOLANA_PRIVATE_KEY) {
    try {
      if (process.env.MERCHANT_SOLANA_PRIVATE_KEY.startsWith('[')) {
        merchantKeypair = Keypair.fromSecretKey(Uint8Array.from(JSON.parse(process.env.MERCHANT_SOLANA_PRIVATE_KEY)));
      }
    } catch (e) {
      console.warn('[Solana Refund Keypair Load Warning]:', e.message);
    }
  }

  // A generated throwaway keypair has zero balance and can never actually
  // broadcast a transfer. Signing with one and then reporting "success" when
  // the broadcast inevitably fails is how a refund becomes theater: the DB
  // says REFUNDED, the audit log says onChain:false, and the customer's money
  // never moves. Refuse outright instead of pretending.
  if (!merchantKeypair) {
    const err = new Error('REFUND_KEY_NOT_CONFIGURED: MERCHANT_SOLANA_PRIVATE_KEY is not set. No wallet is available to sign the refund.');
    err.code = 'REFUND_KEY_NOT_CONFIGURED';
    throw err;
  }

  let destPubkey;
  try {
    destPubkey = new PublicKey(destinationAddress);
  } catch (e) {
    const err = new Error(`REFUND_INVALID_DESTINATION: "${destinationAddress}" is not a valid Solana address.`);
    err.code = 'REFUND_INVALID_DESTINATION';
    throw err;
  }

  const tx = new Transaction();
  const sym = (tokenSymbol || 'SOL').toUpperCase();

  if (sym === 'SOL') {
    const lamports = Math.max(1, Math.round(parseFloat(cryptoAmount) * LAMPORTS_PER_SOL));
    tx.add(SystemProgram.transfer({
      fromPubkey: merchantKeypair.publicKey,
      toPubkey: destPubkey,
      lamports
    }));
  } else {
    // SPL token transfer (USDC / DYNK)
    const isDevnet = SOLANA_CLUSTER_URL.includes('devnet');
    const mintString = sym === 'DYNK' 
      ? dynkMintAddress()
      : (isDevnet ? KNOWN_MINTS.USDC_DEVNET : KNOWN_MINTS.USDC_MAINNET);
    const mintPubkey = new PublicKey(mintString);
    const decimals = sym === 'DYNK' ? 9 : 6;
    const rawUnits = BigInt(Math.max(1, Math.round(parseFloat(cryptoAmount) * Math.pow(10, decimals))));

    const fromAta = getAssociatedTokenAddressSync(mintPubkey, merchantKeypair.publicKey);
    const destAta = getAssociatedTokenAddressSync(mintPubkey, destPubkey);

    tx.add(createAssociatedTokenAccountIdempotentInstruction(
      merchantKeypair.publicKey,
      destAta,
      destPubkey,
      mintPubkey
    ));
    tx.add(createTransferInstruction(
      fromAta,
      destAta,
      merchantKeypair.publicKey,
      rawUnits,
      [],
      TOKEN_PROGRAM_ID
    ));
  }

  const { blockhash, lastValidBlockHeight } = await fetchSolanaBlockhash();
  tx.recentBlockhash = blockhash;
  tx.lastValidBlockHeight = lastValidBlockHeight;
  tx.feePayer = merchantKeypair.publicKey;

  try {
    tx.sign(merchantKeypair);
    const rawTx = tx.serialize();
    const sig = await connection.sendRawTransaction(rawTx, { skipPreflight: false });
    await connection.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, 'confirmed');
    return { success: true, txHash: sig, onChain: true, merchantPayer: merchantKeypair.publicKey.toBase58() };
  } catch (err) {
    // A failed broadcast means no money moved. Throwing here (instead of
    // returning a fabricated txHash with onChain:false) forces the caller to
    // treat this as a failed refund rather than a successful one with a footnote.
    const wrapped = new Error(`REFUND_BROADCAST_FAILED: ${err.message}`);
    wrapped.code = 'REFUND_BROADCAST_FAILED';
    throw wrapped;
  }
}

export default {
  buildSolanaTransaction,
  confirmSolanaPayment,
  checkSolanaPayment,
  executeSolanaRefund,
  generateReference,
  fetchSolanaBlockhash
};
