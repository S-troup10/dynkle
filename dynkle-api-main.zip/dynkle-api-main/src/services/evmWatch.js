// Detects customer payments made from an EVM wallet app (MetaMask, Trust) via an
// EIP-681 payment link. The wallet never reports back to our page, so the server
// finds the transfer itself: pay.html adds a 6-digit order tag to the last digits
// of the wei amount (worth far less than a cent), and we match transfers to the
// merchant address whose value ends in that tag. Another customer's payment can't
// match by accident, and no extra API is needed.
import { ethers } from 'ethers';
import { EVM_CHAINS, MERCHANT } from '../config.js';

const SEPOLIA = 11155111;
const TAG_MOD = 1000000n;          // the tag lives in the last 6 digits of the wei amount
const FIRST_LOOKBACK = 20;         // blocks to look back on the first check (~4 min on Sepolia)
const BATCH = 5;                   // blocks fetched in parallel
const MIN_INTERVAL_MS = 5000;      // public RPC: don't rescan more often than this per order

// Same formula as orderEvmTag() in frontend/pay.html. Keep the two in sync.
export function orderEvmTag(orderId) {
  let h = 0;
  for (const c of String(orderId)) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  return BigInt(100000 + (h % 900000));
}

const scanState = new Map(); // orderId -> { lastBlock, lastAt }
let provider = null;
function rpc() {
  if (!provider) provider = new ethers.JsonRpcProvider(EVM_CHAINS[SEPOLIA].rpcUrl, SEPOLIA, { staticNetwork: true });
  return provider;
}

/**
 * Returns { txHash, from, valueWei } once a tagged transfer for this order lands
 * on Sepolia, or null. Cheap to call on every status poll: it is throttled and
 * only reads blocks it has not seen yet.
 */
export async function findSepoliaPayment(order) {
  const merchant = (MERCHANT.evmAddress || '').toLowerCase();
  if (!order?.id || !merchant || merchant.endsWith('dead')) return null;

  const state = scanState.get(order.id) || { lastBlock: 0, lastAt: 0 };
  if (Date.now() - state.lastAt < MIN_INTERVAL_MS) return null;
  state.lastAt = Date.now();
  scanState.set(order.id, state);

  const tag = orderEvmTag(order.id);
  const head = await rpc().getBlockNumber();
  const from = state.lastBlock ? state.lastBlock + 1 : Math.max(0, head - FIRST_LOOKBACK);
  const createdAt = order.createdAt ? new Date(order.createdAt).getTime() / 1000 : 0;

  for (let top = head; top >= from; top -= BATCH) {
    const nums = [];
    for (let b = top; b > top - BATCH && b >= from; b--) nums.push(b);
    const blocks = await Promise.all(nums.map((b) => rpc().getBlock(b, true).catch(() => null)));
    let tooOld = false;
    for (const block of blocks) {
      if (!block) continue;
      if (createdAt && block.timestamp < createdAt - 60) { tooOld = true; continue; } // older than the bill
      for (const tx of block.prefetchedTransactions || []) {
        if ((tx.to || '').toLowerCase() !== merchant || !tx.value) continue;
        if (tx.value % TAG_MOD === tag) {
          state.lastBlock = head;
          return { txHash: tx.hash, from: tx.from, valueWei: tx.value.toString() };
        }
      }
    }
    if (tooOld) break;
  }
  state.lastBlock = head;
  return null;
}

// Non-blocking form for the order-status poll: returns a payment found by an
// earlier scan, and starts the next scan in the background (one at a time per order).
const found = new Map();    // orderId -> payment
const running = new Set();  // orderIds with a scan in flight
export function pollSepoliaPayment(order) {
  if (found.has(order.id)) return found.get(order.id);
  if (!running.has(order.id)) {
    running.add(order.id);
    findSepoliaPayment(order)
      .then((hit) => { if (hit) found.set(order.id, hit); })
      .catch((err) => console.warn('[EVM] Sepolia scan failed:', err.message))
      .finally(() => running.delete(order.id));
  }
  return null;
}

// Tests only: swap in a fake RPC provider.
export function _setProviderForTests(p) { provider = p; scanState.clear(); }

export function forgetOrder(orderId) {
  scanState.delete(orderId);
  found.delete(orderId);
}
