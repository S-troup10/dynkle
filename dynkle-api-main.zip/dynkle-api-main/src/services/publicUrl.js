// Where a customer's phone opens checkout links: the payment QR and NFC tap on
// the terminal, the register QR on the website, and push notifications.
//
// That has to be a public address. The terminal reaches this server on the
// shop's LAN (http://192.168.x.x:4100), but a customer's phone is usually on
// mobile data and cannot open a LAN IP, localhost or the emulator's 10.0.2.2.
//
// Preference:
//   1. The running cloudflared quick tunnel. Its URL changes on every run, so
//      it is read live from cloudflared's metrics server rather than .env.
//   2. PUBLIC_BASE_URL, when it is a public address (a real domain).
//   3. The address the request came in on, when that is public.
//   4. The caller's fallback (the LAN address), which only works on the same Wi-Fi.

const METRICS_PORTS = (process.env.CLOUDFLARED_METRICS || '20241,20242,20243,20244,20245')
  .split(',').map((s) => s.trim()).filter(Boolean);

let tunnelUrl = null;
let warned = false;

/** True for addresses a customer's phone on mobile data cannot open. */
export function isPrivateUrl(url) {
  let host;
  try { host = new URL(url).hostname.replace(/^\[|\]$/g, ''); } catch { return true; }
  return !host || host === 'localhost' || host === '0.0.0.0' || host === '::1'
    || host.startsWith('127.') || host === '10.0.2.2' || host.endsWith('.local')
    || /^(10|192\.168|169\.254)\./.test(host) || /^172\.(1[6-9]|2\d|3[01])\./.test(host);
}

const trim = (u) => String(u).replace(/\/$/, '');

async function refreshTunnel() {
  for (const port of METRICS_PORTS) {
    try {
      // A cloudflared that lost its edge connections still reports its
      // hostname, which then does not resolve; links built on it fail on the
      // customer's phone (e.g. Phantom: "could not load this transaction
      // request"). Only use a tunnel with a live connection.
      const ready = await fetch(`http://127.0.0.1:${port}/ready`, { signal: AbortSignal.timeout(1500) });
      const readyBody = await ready.json().catch(() => null);
      if (!ready.ok || !(Number(readyBody?.readyConnections) > 0)) continue;
      const r = await fetch(`http://127.0.0.1:${port}/quicktunnel`, { signal: AbortSignal.timeout(1500) });
      const host = r.ok ? (await r.json())?.hostname : null;
      if (host) {
        const url = `https://${host}`;
        if (url !== tunnelUrl) console.log(`[publicUrl] Customer links use ${url}`);
        tunnelUrl = url;
        return;
      }
    } catch { /* not this port */ }
  }
  tunnelUrl = null;
}

refreshTunnel();
setInterval(refreshTunnel, 30_000).unref();

function requestBase(req) {
  const host = req?.headers?.['x-forwarded-host'] || req?.headers?.host;
  if (!host) return null;
  const proto = String(req.headers['x-forwarded-proto'] || (req.secure ? 'https' : 'http')).split(',')[0];
  return `${proto}://${host}`;
}

/**
 * @param {object|null} req       Express request, if there is one.
 * @param {string|null} fallback  Used only when no public address is known.
 */
export function customerBaseUrl(req = null, fallback = null) {
  const env = process.env.PUBLIC_BASE_URL;
  const candidates = [tunnelUrl, env, requestBase(req)];
  const pub = candidates.find((u) => u && !isPrivateUrl(u));
  if (pub) return trim(pub);
  if (!warned) {
    warned = true;
    console.warn('[publicUrl] No public address: customer QR codes use a local address that only works on the same Wi-Fi. Run "cloudflared tunnel --url http://localhost:4100" or set PUBLIC_BASE_URL.');
  }
  return trim(fallback || requestBase(req) || env || 'http://localhost:4100');
}
