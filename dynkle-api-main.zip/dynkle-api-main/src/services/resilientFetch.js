// Outbound HTTP that rides out short network blips: each attempt has its own
// time limit, a failed attempt is tried again on a fresh connection, and a 429
// (public devnet rate limit) is retried after a short pause instead of the
// Solana library's long backoff. Used for Solana RPC (reads, and sends, which
// Solana de-duplicates by signature) and the DYNK login check.
const sleep = (ms) => new Promise((r) => setTimeout(r, ms));

/** The real reason a request failed (DNS, connect timeout, reset…), for the log. */
export function failureReason(e) {
  return e?.cause?.code || e?.cause?.name || e?.code || e?.name || 'ERROR';
}

/**
 * @param {object} o
 * @param {number} o.attemptTimeoutMs  limit for one attempt
 * @param {number} o.retries           extra attempts after the first
 * @param {boolean} o.retryOnTimeout   false: retry only when the connection failed (a slow
 *                                     but working server keeps its whole time limit)
 * @param {string} o.label             for the log
 */
export function resilientFetch({ attemptTimeoutMs = 6_000, retries = 2, retryOnTimeout = true, label = 'http', fetchImpl = fetch } = {}) {
  return async function fetchWithRetry(url, init = {}) {
    let lastErr;
    for (let attempt = 0; attempt <= retries; attempt++) {
      const timeout = AbortSignal.timeout(attemptTimeoutMs);
      const signal = init.signal ? AbortSignal.any([init.signal, timeout]) : timeout;
      try {
        const res = await fetchImpl(url, { ...init, signal });
        if (res.status === 429 && attempt < retries) {
          console.warn(`[net] ${label}: rate limited (429), retrying`);
          await sleep(400 * (attempt + 1));
          continue;
        }
        return res;
      } catch (e) {
        if (init.signal?.aborted) throw e; // the caller gave up
        lastErr = e;
        const timedOut = timeout.aborted;
        console.warn(`[net] ${label}: attempt ${attempt + 1} failed (${timedOut ? 'TIMEOUT' : failureReason(e)})`);
        if (attempt >= retries || (timedOut && !retryOnTimeout)) break;
        await sleep(250 * (attempt + 1));
      }
    }
    throw lastErr;
  };
}
