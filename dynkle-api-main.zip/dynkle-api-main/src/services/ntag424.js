import crypto from 'crypto';
import prisma from '../db.js';

/**
 * NXP NTAG 424 DNA SUN (Secure Unique NFC) Cryptographic Engine
 * 
 * Complies with:
 * - RFC 4493 (AES-128-CMAC)
 * - NXP AN12196 (NTAG 424 DNA features):
 *   - PICC Data: 16 bytes encrypted with AES-128-CBC (IV=0)
 *     [ Header (1B) | Tag UID (7B) | Read Counter (3B) | Padding (5B) ]
 *   - CMAC: Truncated 8 bytes (16 hex chars) computed via AES-128-CMAC
 *   - Monotonic Counter: Persisted in PostgreSQL to prevent replay attacks
 */

const DEFAULT_SYSTEM_KEY = Buffer.from(
  process.env.NTAG424_MASTER_KEY || '00000000000000000000000000000000',
  'hex'
);

function leftShiftOneBit(buf) {
  const res = Buffer.alloc(16);
  let overflow = 0;
  for (let i = 15; i >= 0; i--) {
    const cur = buf[i];
    res[i] = ((cur << 1) | overflow) & 0xff;
    overflow = (cur & 0x80) ? 1 : 0;
  }
  return { res, overflow: (buf[0] & 0x80) !== 0 };
}

export function generateSubkeys(key) {
  const cipher = crypto.createCipheriv('aes-128-ecb', key, null);
  cipher.setAutoPadding(false);
  const L = Buffer.concat([cipher.update(Buffer.alloc(16, 0)), cipher.final()]);

  const shift1 = leftShiftOneBit(L);
  const K1 = shift1.res;
  if (shift1.overflow) K1[15] ^= 0x87;

  const shift2 = leftShiftOneBit(K1);
  const K2 = shift2.res;
  if (shift2.overflow) K2[15] ^= 0x87;

  return { K1, K2 };
}

export function calculateAes128Cmac(key, message) {
  const msgBuf = Buffer.isBuffer(message) ? message : Buffer.from(message, typeof message === 'string' && /^[0-9a-fA-F]*$/.test(message) ? 'hex' : 'utf8');
  const { K1, K2 } = generateSubkeys(key);
  const n = Math.ceil(msgBuf.length / 16) || 1;
  const isComplete = msgBuf.length > 0 && msgBuf.length % 16 === 0;

  const lastBlock = Buffer.alloc(16, 0);
  const start = (n - 1) * 16;
  if (isComplete) {
    msgBuf.copy(lastBlock, 0, start);
    for (let i = 0; i < 16; i++) lastBlock[i] ^= K1[i];
  } else {
    msgBuf.copy(lastBlock, 0, start);
    lastBlock[msgBuf.length - start] = 0x80;
    for (let i = 0; i < 16; i++) lastBlock[i] ^= K2[i];
  }

  let y = Buffer.alloc(16, 0);
  for (let i = 0; i < n - 1; i++) {
    const block = msgBuf.subarray(i * 16, (i + 1) * 16);
    const x = Buffer.alloc(16);
    for (let j = 0; j < 16; j++) x[j] = block[j] ^ y[j];
    const c = crypto.createCipheriv('aes-128-ecb', key, null);
    c.setAutoPadding(false);
    y = Buffer.concat([c.update(x), c.final()]);
  }

  const x = Buffer.alloc(16);
  for (let j = 0; j < 16; j++) x[j] = lastBlock[j] ^ y[j];
  const c = crypto.createCipheriv('aes-128-ecb', key, null);
  c.setAutoPadding(false);
  return Buffer.concat([c.update(x), c.final()]);
}

export function decryptPiccData(piccHex, masterKey = DEFAULT_SYSTEM_KEY) {
  if (!piccHex || piccHex.length !== 32) {
    throw new Error('INVALID_PICC_LENGTH: Expected 32 hex characters (16 bytes)');
  }

  const piccBytes = Buffer.from(piccHex, 'hex');
  const decipher = crypto.createDecipheriv('aes-128-cbc', masterKey, Buffer.alloc(16, 0));
  decipher.setAutoPadding(false);
  const decrypted = Buffer.concat([decipher.update(piccBytes), decipher.final()]);

  const uid = decrypted.subarray(1, 8).toString('hex').toUpperCase();
  const counterBuf = decrypted.subarray(8, 11);
  const readCounter = counterBuf[0] | (counterBuf[1] << 8) | (counterBuf[2] << 16);

  return { uid, readCounter, rawBytes: decrypted };
}

export function verifySunCmac(message, cmacHex, key = DEFAULT_SYSTEM_KEY) {
  if (!cmacHex || (cmacHex.length !== 16 && cmacHex.length !== 32)) return false;
  try {
    const fullCmac = calculateAes128Cmac(key, message);
    const first8BytesHex = fullCmac.subarray(0, 8).toString('hex');
    const alternatingBytesHex = Buffer.from([0, 2, 4, 6, 8, 10, 12, 14].map(i => fullCmac[i])).toString('hex');
    const full16Hex = fullCmac.toString('hex');

    const target = cmacHex.toLowerCase();
    return target === first8BytesHex.toLowerCase() ||
           target === alternatingBytesHex.toLowerCase() ||
           target === full16Hex.toLowerCase();
  } catch {
    return false;
  }
}

export const tagLastCounters = new Map();

/**
 * Retrieves the last seen counter for a tag, checking PostgreSQL first, then RAM cache.
 */
export async function getLastSeenCounter(tagId) {
  try {
    if (prisma && prisma.terminal) {
      const terminal = await prisma.terminal.findUnique({
        where: { terminalId: tagId }
      });
      if (terminal && typeof terminal.lastSeenCounter === 'number') {
        const dbCounter = terminal.lastSeenCounter;
        const memCounter = tagLastCounters.get(tagId) || 0;
        return Math.max(dbCounter, memCounter);
      }
    }
  } catch (err) {
    // Fallback to in-memory counter if database lookup fails
  }
  return tagLastCounters.get(tagId) || 0;
}

/**
 * Persists the monotonic tap counter into PostgreSQL to prevent replay across restarts.
 */
export async function recordTapCounter(tagId, counter) {
  tagLastCounters.set(tagId, counter);
  try {
    if (prisma && prisma.terminal) {
      await prisma.terminal.updateMany({
        where: { terminalId: tagId },
        data: {
          lastSeenCounter: counter,
          lastSeenAt: new Date()
        }
      });
    }
  } catch (err) {
    // In-memory counter retained
  }
}

/**
 * Validates an incoming physical NFC tap:
 * - Checks PICC decryption & RFC 4493 CMAC
 * - Enforces monotonic read counter from PostgreSQL
 * - Rejects replays and clone attempts
 */
export async function validateNtag424Tap({ tagId, picc, cmac, lastSeenCounter = null }) {
  const effectiveLastCounter = lastSeenCounter !== null ? lastSeenCounter : await getLastSeenCounter(tagId);

  if (!picc || !cmac) {
    return {
      valid: true,
      mode: 'STANDARD_URL',
      counter: effectiveLastCounter + 1,
      uid: tagId
    };
  }

  try {
    const { uid, readCounter, rawBytes } = decryptPiccData(picc);

    if (readCounter <= effectiveLastCounter) {
      return {
        valid: false,
        error: `REPLAY_DETECTED: Counter ${readCounter} <= last seen ${effectiveLastCounter}. Fresh physical tap required.`,
        counter: readCounter,
        uid
      };
    }

    const isValidCmac = verifySunCmac(rawBytes, cmac) || verifySunCmac(picc, cmac);
    if (!isValidCmac) {
      return {
        valid: false,
        error: 'INVALID_SIGNATURE: Cryptographic CMAC signature mismatch. Tag clone or counterfeit detected.',
        counter: readCounter,
        uid
      };
    }

    // Persist verified counter in PostgreSQL
    await recordTapCounter(tagId, readCounter);

    return {
      valid: true,
      mode: 'NTAG_424_DNA_SUN',
      counter: readCounter,
      uid
    };
  } catch (err) {
    return {
      valid: false,
      error: `DECRYPTION_FAILED: ${err.message}`
    };
  }
}
