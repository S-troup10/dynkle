/**
 * Pre-flight funding checks.
 *
 * Runs before the customer is handed off to their wallet so "not enough funds"
 * is answered on our screen, in plain language, while the price hold is still
 * running — instead of the customer discovering it inside a wallet app and
 * bouncing back with no idea what happened.
 */

import { Connection, PublicKey, LAMPORTS_PER_SOL } from '@solana/web3.js';
import { getAssociatedTokenAddressSync } from '@solana/spl-token';
import { ethers } from 'ethers';
import { SOLANA_CLUSTER_URL, EVM_CHAINS, DEMO_MODE } from '../config.js';
import { resolveTokenMint } from './solana.js';

const connection = new Connection(SOLANA_CLUSTER_URL, { commitment: 'confirmed', disableRetryOnRateLimit: true });

// Headroom left for signature fees, and for rent when the payer has to create
// a recipient associated-token account as part of the transfer.
const SOL_FEE_BUFFER = 0.00001 * LAMPORTS_PER_SOL;
const ATA_RENT_BUFFER = 0.00204 * LAMPORTS_PER_SOL;

function ok(detail) {
  return { code: 'OK', ...detail };
}

/**
 * @returns {Promise<{code: 'OK'|'INSUFFICIENT_BALANCE'|'INSUFFICIENT_GAS'|'RPC_DEGRADED', ...}>}
 */
export async function preflightSolana(order, payerAddress) {
  let payer;
  try {
    payer = new PublicKey(payerAddress);
  } catch {
    return { code: 'INVALID_ACCOUNT' };
  }

  // DEV BYPASS: lets a tester drive the full checkout flow with an
  // unfunded/empty wallet, without needing devnet SOL/tokens on hand.
  if (DEMO_MODE) {
    return ok({ have: 999999, need: parseFloat(order.cryptoAmount.toString()), symbol: order.tokenSymbol, devBypass: true });
  }

  const required = parseFloat(order.cryptoAmount.toString());

  try {
    const lamports = await connection.getBalance(payer, 'confirmed');

    if (order.tokenSymbol === 'SOL') {
      const requiredLamports = Math.round(required * LAMPORTS_PER_SOL) + SOL_FEE_BUFFER;
      if (lamports < requiredLamports) {
        return {
          code: 'INSUFFICIENT_BALANCE',
          have: lamports / LAMPORTS_PER_SOL,
          need: required,
          shortfall: (requiredLamports - lamports) / LAMPORTS_PER_SOL,
          symbol: 'SOL'
        };
      }
      return ok({ have: lamports / LAMPORTS_PER_SOL, need: required, symbol: 'SOL' });
    }

    // SPL: the token itself must cover the bill, and SOL must cover fees + rent.
    const { mint } = resolveTokenMint(order.tokenSymbol);
    const ata = getAssociatedTokenAddressSync(new PublicKey(mint), payer);

    let held = 0;
    try {
      const bal = await connection.getTokenAccountBalance(ata, 'confirmed');
      held = bal?.value?.uiAmount || 0;
    } catch {
      held = 0; // no token account means no tokens
    }

    if (held < required) {
      return {
        code: 'INSUFFICIENT_BALANCE',
        have: held,
        need: required,
        shortfall: required - held,
        symbol: order.tokenSymbol
      };
    }

    const gasNeeded = SOL_FEE_BUFFER + ATA_RENT_BUFFER;
    if (lamports < gasNeeded) {
      return {
        code: 'INSUFFICIENT_GAS',
        have: lamports / LAMPORTS_PER_SOL,
        need: gasNeeded / LAMPORTS_PER_SOL,
        symbol: 'SOL'
      };
    }

    return ok({ have: held, need: required, symbol: order.tokenSymbol });
  } catch (err) {
    return { code: 'RPC_DEGRADED', reason: err.message };
  }
}

export async function preflightEvm(order, payerAddress, chainId = 11155111) {
  const chain = EVM_CHAINS[chainId];
  if (!chain) return { code: 'WRONG_NETWORK', chainId };

  if (!ethers.isAddress(payerAddress)) return { code: 'INVALID_ACCOUNT' };

  // DEV BYPASS: same as the Solana path above — skip the real balance check.
  if (DEMO_MODE) {
    return ok({ have: 999999, need: parseFloat(order.cryptoAmount.toString()), symbol: chain.nativeSymbol, devBypass: true });
  }

  try {
    const provider = new ethers.JsonRpcProvider(chain.rpcUrl);
    const [balanceWei, feeData] = await Promise.all([
      provider.getBalance(payerAddress),
      provider.getFeeData()
    ]);

    const required = parseFloat(order.cryptoAmount.toString());
    const requiredWei = ethers.parseEther(required.toFixed(18));

    // A plain native transfer is 21000 gas.
    const gasPrice = feeData.maxFeePerGas || feeData.gasPrice || 0n;
    const gasWei = gasPrice * 21000n;

    if (balanceWei < requiredWei + gasWei) {
      const shortfallWei = (requiredWei + gasWei) - balanceWei;
      return {
        code: balanceWei < requiredWei ? 'INSUFFICIENT_BALANCE' : 'INSUFFICIENT_GAS',
        have: parseFloat(ethers.formatEther(balanceWei)),
        need: required,
        shortfall: parseFloat(ethers.formatEther(shortfallWei)),
        symbol: chain.nativeSymbol
      };
    }

    return ok({
      have: parseFloat(ethers.formatEther(balanceWei)),
      need: required,
      symbol: chain.nativeSymbol
    });
  } catch (err) {
    return { code: 'RPC_DEGRADED', reason: err.message };
  }
}

export const orderPreflightResults = new Map();

export function recordPreflightResult(orderId, result) {
  orderPreflightResults.set(orderId, {
    timestamp: Date.now(),
    ...result
  });
}

export function getPreflightResult(orderId) {
  return orderPreflightResults.get(orderId);
}

export function clearPreflightResult(orderId) {
  orderPreflightResults.delete(orderId);
}

export async function preflight(order, payerAddress, { chain = 'solana', chainId } = {}) {
  return chain === 'evm'
    ? preflightEvm(order, payerAddress, chainId)
    : preflightSolana(order, payerAddress);
}
