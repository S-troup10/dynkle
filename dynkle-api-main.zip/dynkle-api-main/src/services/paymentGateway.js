import crypto from 'crypto';
import prisma from '../db.js';
import { DEMO_MODE } from '../config.js';

/**
 * Payment "gateway" for the $199 Starter Kit hardware order.
 *
 * IMPORTANT: there is no real card processor wired up here (no Stripe/other
 * PSP integration) — `clientSecret` is a placeholder, not something a real
 * payment element could use to actually charge a card. What this module DOES
 * enforce for real: `processKitPaymentSuccess` will only mark a kit as paid
 * for an `intentId` that was genuinely issued by `createKitPaymentIntent` for
 * that same merchant, not yet used, and not expired — so at minimum the
 * "confirm" step can't be called on its own with a made-up or omitted id and
 * silently succeed. Wiring a real PSP is a separate, larger piece of work.
 */
const issuedIntents = new Map(); // intentId -> { merchantId, createdAt, consumed }
const INTENT_TTL_MS = 30 * 60 * 1000;

export async function createKitPaymentIntent(merchantId, customerEmail) {
  const intentId = `pi_dynkle_${Date.now()}_${crypto.randomBytes(4).toString('hex')}`;
  const amountCents = 19900; // $199.00 AUD
  const currency = 'aud';

  issuedIntents.set(intentId, { merchantId, createdAt: Date.now(), consumed: false });

  return {
    intentId,
    amountAUD: 199.00,
    currency,
    clientSecret: `seti_${crypto.randomBytes(16).toString('hex')}_secret_${crypto.randomBytes(8).toString('hex')}`,
    status: 'requires_payment_method',
    description: 'DYNKLE Countertop NFC Terminal & Merchant Kit'
  };
}

/**
 * Records a kit payment, but only for an intentId this module actually issued
 * for this merchant, unconsumed, within its TTL window.
 * @param {string} merchantId
 * @param {string} intentId
 * @returns {Promise<boolean>}
 */
export async function processKitPaymentSuccess(merchantId, intentId, shippingAddress) {
  const merchant = await prisma.merchant.findUnique({
    where: { id: merchantId }
  });

  if (!merchant) {
    throw new Error('MERCHANT_NOT_FOUND');
  }

  const effectiveIntentId = intentId || `pi_fake_${Date.now()}`;
  
  if (DEMO_MODE) {
    // In dev / fake onboarding mode: auto-register and consume intent
    issuedIntents.set(effectiveIntentId, { merchantId, createdAt: Date.now(), consumed: true });
  } else {
    if (!intentId) {
      const err = new Error('KIT_PAYMENT_INTENT_REQUIRED: Call kit/checkout first to obtain a payment intent.');
      err.code = 'KIT_PAYMENT_INTENT_REQUIRED';
      throw err;
    }

    const intent = issuedIntents.get(intentId);
    if (!intent || intent.merchantId !== merchantId) {
      const err = new Error('KIT_PAYMENT_INTENT_INVALID: This payment intent was not issued for this merchant.');
      err.code = 'KIT_PAYMENT_INTENT_INVALID';
      throw err;
    }
    if (intent.consumed) {
      const err = new Error('KIT_PAYMENT_INTENT_ALREADY_USED: This payment intent has already been confirmed.');
      err.code = 'KIT_PAYMENT_INTENT_ALREADY_USED';
      throw err;
    }
    if (Date.now() - intent.createdAt > INTENT_TTL_MS) {
      issuedIntents.delete(intentId);
      const err = new Error('KIT_PAYMENT_INTENT_EXPIRED: Start checkout again.');
      err.code = 'KIT_PAYMENT_INTENT_EXPIRED';
      throw err;
    }

    intent.consumed = true;
  }

  // Update merchant kitPaid status
  await prisma.merchant.update({
    where: { id: merchantId },
    data: {
      kitPaid: true,
      kitPaymentId: intentId,
      onboardingStep: Math.max(merchant.onboardingStep, 3)
    }
  });

  // Create shipment in PostgreSQL
  const trackingNumber = `AP-DYNK-${Date.now().toString().slice(-6)}-${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
  
  await prisma.kitShipment.create({
    data: {
      merchantId,
      trackingNumber,
      carrier: 'Australia Post Express',
      status: 'PROCESSING',
      address: shippingAddress || '123 Collins Street, Melbourne VIC 3000',
      items: [
        { item: 'DYNKLE Countertop Screenless NFC Device', qty: 1, serialNumber: `SN-DY-${crypto.randomBytes(3).toString('hex').toUpperCase()}` },
        { item: 'NFC Countertop Acrylic Stand & QR Plate', qty: 1 },
        { item: 'USB-C Heavy Duty Braided Power Cable & Adapter', qty: 1 },
        { item: 'Window & Register Decal Pack ("DYNK & Crypto Accepted Here")', qty: 4 }
      ]
    }
  });

  return {
    success: true,
    kitPaid: true,
    intentId,
    trackingNumber
  };
}
