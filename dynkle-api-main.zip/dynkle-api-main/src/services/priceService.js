/**
 * Real-time Price Oracle Service with multi-source fallback, caching,
 * stale price rejection (> 60s), and 2% volatility protection.
 */

// In-memory cache: { symbol: { priceAUD: number, fetchedAt: number } }
const priceCache = new Map();
const CACHE_TTL_MS = 30000; // 30 seconds
const MAX_STALE_AGE_MS = 60000; // 60 seconds

// Default fallback prices if external APIs are completely unreachable
const FALLBACK_PRICES_AUD = {
  SOL: 228.45,
  DYNK: 0.15,
  USDC: 1.54,
  ETH: 4120.50,
  BTC: 104500.00,
  TRX: 0.35
};

/**
 * Fetches live market price in AUD for a given cryptocurrency symbol.
 * @param {string} symbol - e.g. 'SOL', 'DYNK', 'USDC'
 * @returns {Promise<{ priceAUD: number, source: string, timestamp: number }>}
 */
export async function getLivePrice(symbol) {
  const sym = symbol.toUpperCase();
  const cached = priceCache.get(sym);
  const age = cached ? Date.now() - cached.fetchedAt : Infinity;

  if (age < CACHE_TTL_MS) {
    return {
      priceAUD: cached.priceAUD,
      source: cached.source,
      timestamp: cached.fetchedAt
    };
  }

  // Still inside the 60 s stale limit: answer now and refresh in the background,
  // so a payment never waits on the external API.
  if (age < MAX_STALE_AGE_MS) {
    fetchPrice(sym).catch(() => {});
    return {
      priceAUD: cached.priceAUD,
      source: cached.source,
      timestamp: cached.fetchedAt
    };
  }

  return fetchPrice(sym);
}

// One request per symbol at a time; concurrent callers share it.
const inFlight = new Map();

function fetchPrice(sym) {
  let p = inFlight.get(sym);
  if (!p) {
    p = fetchPriceNow(sym).finally(() => inFlight.delete(sym));
    inFlight.set(sym, p);
  }
  return p;
}

/**
 * Keeps the given symbols' cache fresh so lookups are answered from memory.
 * @param {string[]} symbols
 * @param {number} everyMs
 */
/**
 * Latest known AUD price without waiting: the cached quote, else the fallback.
 * For synchronous split math (e.g. AUD shares paid out as USDC).
 * @param {string} symbol
 * @returns {number}
 */
export function getCachedPriceAUD(symbol) {
  const sym = String(symbol || '').toUpperCase();
  return priceCache.get(sym)?.priceAUD || FALLBACK_PRICES_AUD[sym] || 0;
}

/**
 * AUD amount converted to USDC at the latest USDC/AUD price (USDC is 1 USD,
 * so it is not 1:1 with AUD). Rounded to cents.
 * @param {number} amountAUD
 * @returns {number}
 */
export function audToUsdc(amountAUD) {
  const usdcPriceAUD = getCachedPriceAUD('USDC') || FALLBACK_PRICES_AUD.USDC;
  return Math.round((Number(amountAUD) || 0) / usdcPriceAUD * 100) / 100;
}

export function startPriceRefresh(symbols, everyMs = 20000) {
  const refresh = () => symbols.forEach((s) => fetchPrice(s.toUpperCase()).catch(() => {}));
  refresh();
  const timer = setInterval(refresh, everyMs);
  timer.unref?.();
  return () => clearInterval(timer);
}

async function fetchPriceNow(sym) {
  const cached = priceCache.get(sym);

  // Try external CoinGecko public API
  try {
    const coinIds = {
      SOL: 'solana',
      USDC: 'usd-coin',
      ETH: 'ethereum',
      BTC: 'bitcoin',
      TRX: 'tron'
    };

    const coinId = coinIds[sym];
    if (coinId) {
      const controller = new AbortController();
      const timeout = setTimeout(() => controller.abort(), 3000);

      const res = await fetch(`https://api.coingecko.com/api/v3/simple/price?ids=${coinId}&vs_currencies=aud`, {
        signal: controller.signal
      });
      clearTimeout(timeout);

      if (res.ok) {
        const data = await res.json();
        const price = data[coinId]?.aud;
        if (price && typeof price === 'number') {
          priceCache.set(sym, { priceAUD: price, source: 'coingecko', fetchedAt: Date.now() });
          return { priceAUD: price, source: 'coingecko', timestamp: Date.now() };
        }
      }
    }
  } catch (err) {
    // network or timeout
  }

  // If cache exists and is not older than 60s, return cached
  if (cached && (Date.now() - cached.fetchedAt < MAX_STALE_AGE_MS)) {
    return {
      priceAUD: cached.priceAUD,
      source: `${cached.source}_stale`,
      timestamp: cached.fetchedAt
    };
  }

  // Use reliable fallback with timestamp
  const fallback = FALLBACK_PRICES_AUD[sym] || 1.00;
  priceCache.set(sym, { priceAUD: fallback, source: 'reference_oracle', fetchedAt: Date.now() });

  return {
    priceAUD: fallback,
    source: 'reference_oracle',
    timestamp: Date.now()
  };
}

/**
 * Calculates customer fee based on token symbol and rule.
 * SOW Rule: DYNK has a flat 1 cent fee. SOL has 1% fee. USDC has 0.5% fee.
 * Other accepted tokens (ETH, BTC, TRX, etc.) default to 1% fee.
 * 
 * @param {string} tokenSymbol 
 * @param {number} subtotalAUD 
 * @returns {number} Fee in AUD
 */
export function calculateCustomerFee(tokenSymbol, subtotalAUD) {
  const sym = tokenSymbol.toUpperCase();
  if (sym === 'DYNK') {
    return 0.01; // Flat 1 cent AUD
  } else if (sym === 'USDC') {
    return parseFloat((subtotalAUD * 0.005).toFixed(4)); // 0.50%
  } else {
    return parseFloat((subtotalAUD * 0.01).toFixed(4)); // 1.00%
  }
}

/**
 * Checks price movement between quote time and current execution time.
 * If price dropped by more than 2%, returns { allowed: false, dropPercent }.
 * 
 * @param {number} quotePrice - Price at quote time
 * @param {number} currentPrice - Current market price
 * @returns {{ allowed: boolean, dropPercent: number }}
 */
export function checkVolatilityThreshold(quotePrice, currentPrice) {
  if (currentPrice >= quotePrice) {
    return { allowed: true, dropPercent: 0 };
  }

  const drop = ((quotePrice - currentPrice) / quotePrice) * 100;
  const dropPercent = parseFloat(drop.toFixed(2));

  if (dropPercent > 2.00) {
    return {
      allowed: false,
      dropPercent,
      reason: `Price dropped by ${dropPercent}%, exceeding the 2% volatility protection limit.`
    };
  }

  return { allowed: true, dropPercent };
}
