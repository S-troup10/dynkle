import prisma from '../db.js';

/**
 * Shipping Service for tracking hardware kit deliveries via Australia Post.
 */
export async function getShipmentStatus(merchantId) {
  const shipment = await prisma.kitShipment.findFirst({
    where: { merchantId },
    orderBy: { createdAt: 'desc' }
  });

  if (!shipment) {
    return null;
  }

  // Calculate dynamic realistic checkpoints based on elapsed time
  const elapsedMinutes = Math.floor((Date.now() - new Date(shipment.createdAt).getTime()) / 60000);
  let status = shipment.status;

  if (status === 'PROCESSING' && elapsedMinutes >= 1) {
    status = 'SHIPPED';
    await prisma.kitShipment.update({
      where: { id: shipment.id },
      data: { status: 'SHIPPED', shippedAt: new Date() }
    });
  }

  return {
    id: shipment.id,
    trackingNumber: shipment.trackingNumber,
    carrier: shipment.carrier,
    status,
    address: shipment.address,
    items: shipment.items,
    createdAt: shipment.createdAt,
    shippedAt: shipment.shippedAt,
    deliveredAt: shipment.deliveredAt
  };
}

export async function updateShipmentStatus(shipmentId, status) {
  const valid = ['PENDING', 'PROCESSING', 'SHIPPED', 'IN_TRANSIT', 'OUT_FOR_DELIVERY', 'DELIVERED', 'FAILED'];
  if (!valid.includes(status)) {
    throw new Error('INVALID_SHIPPING_STATUS');
  }

  const updated = await prisma.kitShipment.update({
    where: { id: shipmentId },
    data: {
      status,
      deliveredAt: status === 'DELIVERED' ? new Date() : undefined
    }
  });

  return updated;
}
