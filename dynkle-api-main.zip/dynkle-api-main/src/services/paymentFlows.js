/**
 * Canonical catalogue of every outcome a payer-side checkout can reach.
 *
 * Both the API and pay.html resolve customer-facing copy from here (the UI
 * fetches it via GET /api/orders/flows) so the two can never drift apart.
 *
 * Fields per flow:
 *   http       - status code the API should answer with
 *   phase      - where in the journey it happens
 *   terminal   - true when the order can never progress from here
 *   retryable  - true when re-attempting the same order can still succeed
 *   funded     - true when the customer's money has already left their wallet
 *   notifyCashier - true when the register needs to show this too
 *   title/message - copy shown to the customer, written for a cafe queue
 *   action     - { label, kind } primary recovery; kind drives UI behaviour
 *   secondary  - optional second button
 */

export const PHASES = {
  SETUP: 'setup',
  HANDOFF: 'handoff',
  FUNDING: 'funding',
  SIGNING: 'signing',
  BROADCAST: 'broadcast',
  SETTLEMENT: 'settlement',
  ENVIRONMENT: 'environment'
};

export const FLOWS = {
  // ---------- setup ----------
  ORDER_NOT_FOUND: {
    http: 404,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: false,
    title: 'Bill not found',
    message: 'This payment link is no longer valid. Ask the cashier to bring up the bill again.',
    action: { label: 'Done', kind: 'CLOSE' }
  },
  TERMINAL_IDLE: {
    http: 200,
    ok: true,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: false,
    title: 'Nothing to pay',
    message: 'There is no active bill on this counter right now. You have not been charged.',
    action: { label: 'Done', kind: 'CLOSE' }
  },
  SESSION_LOCKED: {
    http: 409,
    phase: PHASES.SETUP,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: 'Counter in use',
    message: 'Someone else is already paying this bill. You have not been charged. Wait a moment and tap again.',
    action: { label: 'Try again', kind: 'RECHECK' },
    secondary: { label: 'Done', kind: 'CLOSE' }
  },
  QUOTE_EXPIRED: {
    http: 410,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: true,
    title: 'Price hold expired',
    message: 'Exchange rates are only held for a short window. You have not been charged. Ask the cashier to re-send the bill.',
    action: { label: 'Done', kind: 'CLOSE' }
  },
  ORDER_ALREADY_PAID: {
    http: 200,
    ok: true,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: true,
    notifyCashier: false,
    title: 'Already paid',
    message: 'This bill has already been settled. No further payment is needed.',
    action: { label: 'View receipt', kind: 'RECEIPT' }
  },
  AMOUNT_EXCEEDS_LIMIT: {
    http: 400,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: true,
    title: 'Amount too large',
    message: 'This bill amount is above the single-transaction limit. Check the amount entered on the register — it may be missing a decimal point.',
    action: { label: 'Done', kind: 'CLOSE' }
  },
  CURRENCY_NOT_ACCEPTED: {
    http: 400,
    phase: PHASES.SETUP,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: 'Coin not accepted here',
    message: 'This merchant does not accept that currency. Pick one of the options shown.',
    action: { label: 'Choose another coin', kind: 'PICK_TOKEN' }
  },
  ORDER_CANCELLED: {
    http: 409,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: false,
    title: 'Bill cancelled',
    message: 'The cashier cancelled this bill. You have not been charged.',
    action: { label: 'Done', kind: 'CLOSE' }
  },

  // ---------- wallet handoff ----------
  WALLET_NOT_INSTALLED: {
    http: 200,
    phase: PHASES.HANDOFF,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: "That wallet isn't installed",
    message: "Your phone couldn't open that wallet app. Install it, pick a different wallet, or scan the code with a wallet you already have.",
    action: { label: 'Choose another wallet', kind: 'PICK_WALLET' },
    secondary: { label: 'Show QR instead', kind: 'SHOW_QR' }
  },
  WALLET_LAUNCH_FAILED: {
    http: 200,
    phase: PHASES.HANDOFF,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: "Couldn't open your wallet",
    message: 'Your phone blocked the hand-off. Scanning the code from inside your wallet app works reliably.',
    action: { label: 'Show QR instead', kind: 'SHOW_QR' },
    secondary: { label: 'Try again', kind: 'RELAUNCH' }
  },
  WALLET_RETURNED_UNPAID: {
    http: 200,
    phase: PHASES.HANDOFF,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: 'Payment not completed',
    message: "You came back without finishing. Nothing has been charged — you can try again while the price hold lasts.",
    action: { label: 'Try again', kind: 'RELAUNCH' },
    secondary: { label: 'Pay another way', kind: 'PICK_WALLET' }
  },
  WRONG_NETWORK: {
    http: 400,
    phase: PHASES.HANDOFF,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: 'Wrong network selected',
    message: 'Your wallet is on a different network than this payment. Switch networks and try again.',
    action: { label: 'Switch network', kind: 'SWITCH_CHAIN' },
    secondary: { label: 'Choose another wallet', kind: 'PICK_WALLET' }
  },

  // ---------- funding ----------
  INSUFFICIENT_BALANCE: {
    http: 402,
    phase: PHASES.FUNDING,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'Not enough funds',
    message: 'That wallet does not hold enough to cover this bill. Nothing has been charged. Try another coin, another wallet, or pay by card.',
    action: { label: 'Choose another coin', kind: 'PICK_TOKEN' },
    secondary: { label: 'Pay by card instead', kind: 'FALLBACK_CARD' }
  },
  INSUFFICIENT_GAS: {
    http: 402,
    phase: PHASES.FUNDING,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'Not enough for network fee',
    message: 'You hold enough of the coin, but not enough of the network token to cover the transfer fee. Nothing has been charged.',
    action: { label: 'Choose another coin', kind: 'PICK_TOKEN' },
    secondary: { label: 'Pay by card instead', kind: 'FALLBACK_CARD' }
  },

  // ---------- signing ----------
  USER_REJECTED: {
    http: 200,
    phase: PHASES.SIGNING,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: 'Payment cancelled',
    message: 'You declined the transaction in your wallet. Nothing has been charged.',
    action: { label: 'Try again', kind: 'RELAUNCH' },
    secondary: { label: 'Pay another way', kind: 'PICK_WALLET' }
  },
  SIGNATURE_TIMEOUT: {
    http: 200,
    phase: PHASES.SIGNING,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: 'Still waiting on your wallet',
    message: "We haven't seen a signature yet. If you already approved it, give it a few more seconds — otherwise try again.",
    action: { label: 'Keep waiting', kind: 'RECHECK' },
    secondary: { label: 'Start over', kind: 'RELAUNCH' }
  },
  SIMULATION_FAILED: {
    http: 400,
    phase: PHASES.SIGNING,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: "That payment can't go through",
    message: 'Your wallet rejected the transaction before sending it. Nothing has been charged. Try a different coin or wallet.',
    action: { label: 'Choose another coin', kind: 'PICK_TOKEN' },
    secondary: { label: 'Pay by card instead', kind: 'FALLBACK_CARD' }
  },

  // ---------- broadcast / confirmation ----------
  TX_CONFIRMING: {
    http: 202,
    phase: PHASES.BROADCAST,
    terminal: false,
    retryable: false,
    funded: true,
    notifyCashier: true,
    title: 'Confirming your payment',
    message: 'Your payment is on its way. Keep this screen open — this usually takes a few seconds.',
    action: { label: 'Waiting', kind: 'WAIT' }
  },
  TX_SLOW: {
    http: 202,
    phase: PHASES.BROADCAST,
    terminal: false,
    retryable: false,
    funded: true,
    notifyCashier: true,
    title: 'Taking longer than usual',
    message: "The network is slow right now. Your payment is still live — don't pay again. Show this screen to the cashier.",
    action: { label: 'Keep waiting', kind: 'WAIT' }
  },
  TX_DROPPED: {
    http: 409,
    phase: PHASES.BROADCAST,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'Payment did not go through',
    message: 'The network dropped the transaction before it settled. Nothing has been charged. You can safely try again.',
    action: { label: 'Try again', kind: 'RELAUNCH' }
  },
  TX_FAILED_ONCHAIN: {
    http: 409,
    phase: PHASES.BROADCAST,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'Payment failed',
    message: 'The network rejected the transaction. Any network fee is lost but the bill amount was not taken. You can try again.',
    action: { label: 'Try again', kind: 'RELAUNCH' },
    secondary: { label: 'Pay by card instead', kind: 'FALLBACK_CARD' }
  },

  // ---------- settlement mismatches (money already moved) ----------
  UNDERPAID: {
    http: 409,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: true,
    funded: true,
    notifyCashier: true,
    title: 'Part of the bill is still owing',
    message: 'We received your payment, but it was short of the total. Show this screen to the cashier — you can top up the difference or take a refund.',
    action: { label: 'Pay the difference', kind: 'TOP_UP' },
    secondary: { label: 'Refund what I sent', kind: 'REQUEST_REFUND' }
  },
  OVERPAID: {
    http: 200,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: false,
    funded: true,
    notifyCashier: true,
    title: 'You paid more than the bill',
    message: 'Your bill is settled and the extra amount is owed back to you. Show this screen to the cashier to collect the difference.',
    action: { label: 'Request the difference', kind: 'REQUEST_REFUND' },
    secondary: { label: 'View receipt', kind: 'RECEIPT' }
  },
  DUPLICATE_PAYMENT: {
    http: 409,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: false,
    funded: true,
    notifyCashier: true,
    title: 'This bill was paid twice',
    message: 'We received a second payment for a bill that was already settled. Show this screen to the cashier to arrange the refund.',
    action: { label: 'Request refund', kind: 'REQUEST_REFUND' },
    secondary: { label: 'View receipt', kind: 'RECEIPT' }
  },
  WRONG_TOKEN: {
    http: 409,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: true,
    funded: true,
    notifyCashier: true,
    title: 'Paid in the wrong coin',
    message: 'The coin we received is not the one this bill was quoted in. Show this screen to the cashier to sort out the refund.',
    action: { label: 'Request refund', kind: 'REQUEST_REFUND' }
  },
  WRONG_RECIPIENT: {
    http: 409,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: true,
    funded: true,
    notifyCashier: true,
    title: 'Payment went elsewhere',
    message: 'That transaction did not reach this merchant. Show this screen to the cashier before paying again.',
    action: { label: 'Show cashier', kind: 'ESCALATE' }
  },
  PRICE_MOVED: {
    http: 409,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'The rate moved',
    message: 'The exchange rate shifted past the safe limit while you were paying. Nothing has been charged. Re-quoting at the current rate.',
    action: { label: 'Get new price', kind: 'REQUOTE' }
  },

  // ---------- environment ----------
  NETWORK_OFFLINE: {
    http: 503,
    phase: PHASES.ENVIRONMENT,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: false,
    title: "You're offline",
    message: 'Your phone lost its connection. Nothing has been charged. Reconnect and this screen will pick up where it left off.',
    action: { label: 'Retry now', kind: 'RECHECK' }
  },
  BACKEND_UNREACHABLE: {
    http: 503,
    phase: PHASES.ENVIRONMENT,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: "Can't reach the payment service",
    message: 'We are having trouble reaching the payment service. Nothing has been charged. Trying again automatically.',
    action: { label: 'Retry now', kind: 'RECHECK' }
  },
  RPC_DEGRADED: {
    http: 503,
    phase: PHASES.ENVIRONMENT,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'Network is congested',
    message: 'The blockchain network is responding slowly. You can still pay, but confirmation may take longer than usual.',
    action: { label: 'Continue', kind: 'WAIT' }
  },

  // ---------- resolved states ----------
  PAID: {
    http: 200,
    ok: true,
    phase: PHASES.SETTLEMENT,
    terminal: true,
    retryable: false,
    funded: true,
    notifyCashier: true,
    title: 'Payment complete',
    message: 'Thanks — your payment is confirmed.',
    action: { label: 'View receipt', kind: 'RECEIPT' }
  },
  REFUND_FAILED: {
    http: 502,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: true,
    funded: true,
    notifyCashier: true,
    title: 'Refund could not be sent',
    message: 'We could not send the refund on-chain. Your original payment has not been touched — the cashier needs to arrange this manually.',
    action: { label: 'Show cashier', kind: 'ESCALATE' }
  },
  STRAY_PAYMENT_RECEIVED: {
    http: 200,
    phase: PHASES.SETTLEMENT,
    terminal: false,
    retryable: false,
    funded: true,
    notifyCashier: true,
    title: 'Payment received after this bill was cancelled',
    message: 'This bill was cancelled, but a payment for it arrived anyway. Your funds are safe and recorded — show this screen to the cashier to arrange a refund or apply it to a new order.',
    action: { label: 'Show cashier', kind: 'ESCALATE' }
  },
  TERMINAL_OFFLINE: {
    http: 503,
    phase: PHASES.ENVIRONMENT,
    terminal: false,
    retryable: true,
    funded: false,
    notifyCashier: true,
    title: 'Register disconnected',
    message: "The counter's register has gone offline. Nothing has been charged — wait a moment or ask staff for a new bill.",
    action: { label: 'Retry now', kind: 'RECHECK' }
  },
  REFUNDED: {
    http: 200,
    ok: true,
    phase: PHASES.SETTLEMENT,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: true,
    title: 'Refunded',
    message: 'This payment has been refunded to your wallet.',
    action: { label: 'View receipt', kind: 'RECEIPT' }
  },
  ABANDONED: {
    http: 200,
    ok: true,
    phase: PHASES.SETUP,
    terminal: true,
    retryable: false,
    funded: false,
    notifyCashier: true,
    title: 'Payment closed',
    message: 'You have not been charged. The counter is free for the next customer.',
    action: { label: 'Done', kind: 'CLOSE' }
  }
};

/** Order statuses from which an order may still legitimately move forward. */
export const NON_TERMINAL_STATUSES = [
  'CREATED',
  'QUOTED',
  'DEVICE_ARMED',
  'WAITING_FOR_CUSTOMER',
  'CUSTOMER_DETECTED',
  'AWAITING_APPROVAL'
];

/** Statuses meaning the customer's funds are in flight — never auto-expire these. */
export const IN_FLIGHT_STATUSES = ['SUBMITTED', 'CONFIRMING'];

/** Statuses meaning the order is finished, successfully or otherwise. */
export const SETTLED_STATUSES = ['PAID', 'SETTLED', 'RECEIPT_READY'];

export function getFlow(code) {
  return FLOWS[code] || null;
}

/**
 * Builds the response body for a flow outcome. `detail` carries machine-readable
 * specifics (amounts, hashes) without ever leaking raw RPC text to the customer.
 */
export function flowResponse(code, detail = {}) {
  const flow = FLOWS[code];
  if (!flow) {
    return {
      ok: false,
      code: 'UNKNOWN_ERROR',
      title: 'Something went wrong',
      message: 'Please show this screen to the cashier.',
      action: { label: 'Show cashier', kind: 'ESCALATE' },
      detail
    };
  }
  return {
    ok: flow.ok === true,
    success: flow.ok === true,
    code,
    phase: flow.phase,
    title: flow.title,
    message: flow.message,
    action: flow.action,
    secondary: flow.secondary || null,
    terminal: flow.terminal,
    retryable: flow.retryable,
    funded: flow.funded,
    notifyCashier: flow.notifyCashier,
    detail
  };
}

/** Sends a flow outcome with its canonical HTTP status. */
export function sendFlow(res, code, detail = {}) {
  const flow = FLOWS[code];
  return res.status(flow ? flow.http : 500).json(flowResponse(code, detail));
}

/**
 * Maps an internal error thrown by the chain services onto a customer-facing flow.
 * Everything unrecognised becomes an escalation rather than raw error text.
 */
export function classifyError(err) {
  const msg = (err?.message || '').toUpperCase();

  if (msg.includes('REFUND_KEY_NOT_CONFIGURED') || msg.includes('REFUND_BROADCAST_FAILED') || msg.includes('REFUND_INVALID_DESTINATION') || msg.includes('REFUND_UNSUPPORTED_TOKEN')) return 'REFUND_FAILED';
  if (msg.includes('STRAY_PAYMENT')) return 'STRAY_PAYMENT_RECEIVED';
  if (msg.includes('TRANSACTION_PENDING_VERIFICATION')) return 'TX_CONFIRMING';
  if (msg.includes('INSUFFICIENT_AMOUNT') || msg.includes('INSUFFICIENT_TOKEN_AMOUNT')) return 'UNDERPAID';
  if (msg.includes('EMPTY_TRANSACTION') || msg.includes('UNSUPPORTED_MINT')) return 'SIMULATION_FAILED';
  if (msg.includes('DUPLICATE_TRANSACTION_HASH') || msg.includes('DUPLICATE_PAYMENT')) return 'DUPLICATE_PAYMENT';
  if (msg.includes('QUOTE_EXPIRED')) return 'QUOTE_EXPIRED';
  if (msg.includes('ALREADY_PAID')) return 'ORDER_ALREADY_PAID';
  if (msg.includes('ORDER_NOT_FOUND')) return 'ORDER_NOT_FOUND';
  if (msg.includes('REFERENCE_MISMATCH') || msg.includes('WRONG_RECIPIENT')) return 'WRONG_RECIPIENT';
  if (msg.includes('WRONG_MINT') || msg.includes('WRONG_TOKEN')) return 'WRONG_TOKEN';
  if (msg.includes('TRANSACTION_FAILED_ON_CHAIN')) return 'TX_FAILED_ONCHAIN';
  if (msg.includes('TRANSACTION_NOT_FOUND') || msg.includes('BLOCKHASH')) return 'TX_DROPPED';
  if (msg.includes('INSUFFICIENT_FUNDS') || msg.includes('INSUFFICIENT_LAMPORTS')) return 'INSUFFICIENT_BALANCE';
  if (msg.includes('TIMEOUT') || msg.includes('FETCH FAILED') || msg.includes('ECONNREFUSED')) return 'RPC_DEGRADED';

  return 'TX_FAILED_ONCHAIN';
}
