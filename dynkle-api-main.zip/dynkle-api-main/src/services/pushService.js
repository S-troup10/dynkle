import webpush from 'web-push';
import { VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY, VAPID_CONTACT_EMAIL, PUBLIC_BASE_URL } from '../config.js';
import { customerBaseUrl } from './publicUrl.js';

webpush.setVapidDetails(VAPID_CONTACT_EMAIL, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);

// Keyed by orderId — a subscription is only ever relevant to the one checkout
// session that created it, and orders are short-lived (minutes), so an
// in-memory Map is the right scope here rather than persisting to Postgres.
const subscriptionsByOrder = new Map();

export function saveSubscription(orderId, subscription) {
  subscriptionsByOrder.set(orderId, subscription);
}

export function clearSubscription(orderId) {
  subscriptionsByOrder.delete(orderId);
}

/**
 * Pushes a real OS-level notification to the customer's phone the moment
 * DYNKLE's own balance check confirms their chosen wallet can't cover the
 * bill. This matters most for the mobile deep-link flow: the customer has
 * already switched away from the browser tab into the wallet app itself, so
 * an in-page popup on our page is invisible to them at that exact moment —
 * this is the only way to reach them until they manually switch back.
 *
 * Clicking the notification (see frontend/sw.js) reopens the checkout page
 * with ?action=pick-wallet, jumping straight to the token/wallet picker
 * instead of leaving them to figure out how to back out of the wallet app
 * and retry on their own.
 */
export async function sendInsufficientFundsPush(orderId, { symbol, have, need, walletKey }) {
  const subscription = subscriptionsByOrder.get(orderId);
  if (!subscription) return { sent: false, reason: 'NO_SUBSCRIPTION' };

  const walletLabel = walletKey ? walletKey.charAt(0).toUpperCase() + walletKey.slice(1) : 'Your wallet';
  const payload = JSON.stringify({
    title: 'Not enough funds for this bill',
    body: `${walletLabel} has ${Number(have || 0).toFixed(4)} ${symbol}, but this bill needs ${Number(need || 0).toFixed(4)} ${symbol}. Tap to pick another coin or wallet.`,
    tag: `dynkle-insufficient-${orderId}`,
    url: `${customerBaseUrl(null, PUBLIC_BASE_URL)}/pay.html?orderId=${orderId}&action=pick-wallet`
  });

  try {
    await webpush.sendNotification(subscription, payload);
    return { sent: true };
  } catch (err) {
    // 404/410 means the browser revoked or expired this subscription —
    // stop trying to send to it rather than erroring on every future attempt.
    if (err.statusCode === 404 || err.statusCode === 410) {
      clearSubscription(orderId);
    }
    return { sent: false, reason: err.message };
  }
}
