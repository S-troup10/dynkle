/**
 * DYNK Merchant Store & State Manager
 * Strictly enforces 100% split invariant, auto-balancing, wallet balances, and real transaction splits.
 *
 * Amounts are in AUD (the venue currency). The stable settlement token is
 * USDC (1 USD), so AUD shares are converted at the live USDC/AUD price.
 */
import { audToUsdc } from './services/priceService.js';

/** Stable settlement token for wallets that do not hold crypto. */
export const STABLE_SETTLE_TOKEN = 'USDC';

/** 'AUDC' was the stable token before USDC; old clients may still send it. */
export const normalizeSettle = (settle) => {
  const s = String(settle || '').trim();
  return s.toUpperCase() === 'AUDC' ? STABLE_SETTLE_TOKEN : s;
};

export const merchantState = {
  venue: {
    id: 'VENUE-ANCHOR-001',
    name: 'The Anchor Hotel',
    terminalId: 'DY-009',
    currency: 'AUD',
    solanaVault: '8YLLyTszMhVb4k46sC7i6y17tB551Yc8Gv2y7m5NYFH',
    evmAddress: '0xD978167408123ca6162474A3191D198748d5C5ED'
  },
  kpis: {
    revenue: 3412.60,
    txCount: 187,
    dynkCount: 120,
    savedVsCard: 54.68
  },
  wallets: [
    { id: 'gst',    name: 'GST / VAT (ATO)', color: '#4C7DF5', tagColor: '#7DA1F8', tagBg: 'rgba(76,125,245,0.12)',  pct: 15, balance: 2174.98, settle: 'USDC', locked: false, address: '8YLL...GST1' },
    { id: 'exp',    name: 'Operating Costs', color: '#8B7CF6', tagColor: '#B2A4FA', tagBg: 'rgba(139,124,246,0.12)', pct: 20, balance: 2899.97, settle: 'USDC', locked: false, address: '8YLL...EXP2' },
    { id: 'owner',  name: "Owner's Pay",     color: '#3DD68C', tagColor: '#6FE0AC', tagBg: 'rgba(61,214,140,0.12)',  pct: 20, balance: 2899.97, settle: 'Hold', locked: false, address: '8YLL...OWN3' },
    { id: 'profit', name: 'Retained Profit', color: '#FF7A29', tagColor: '#FFA35C', tagBg: 'rgba(255,122,41,0.12)',  pct: 45, balance: 6524.93, settle: 'Hold', locked: false, address: '8YLL...PRF4' }
  ],
  autoSwapConfig: {
    enabled: true,
    targetAsset: 'USDC',
    batchSchedule: 'Threshold Trigger (≥ Min Floor)',
    batchWindowHours: 0,
    minThresholdAUD: 50.00,
    slippageToleranceBps: 50, // 0.50%
    status: 'ACTIVE',
    mode: 'TREASURY_THRESHOLD'
  },
  products: [
    { id: 'p1', name: 'Schooner · House Lager', cat: 'Bar',     price: 8.50 },
    { id: 'p2', name: 'Pint · Craft Pale Ale',  cat: 'Bar',     price: 12.00 },
    { id: 'p3', name: 'House Red · Glass',      cat: 'Bar',     price: 10.50 },
    { id: 'p4', name: 'Chicken Parmigiana',     cat: 'Kitchen', price: 26.00 },
    { id: 'p5', name: 'Fish & Chips',           cat: 'Kitchen', price: 24.50 },
    { id: 'p6', name: 'Wagyu Steak Sandwich',   cat: 'Kitchen', price: 22.00 },
    { id: 'p7', name: 'Flat White Coffee',      cat: 'Coffee',  price: 5.00 },
    { id: 'p8', name: 'Venue Trucker Cap',      cat: 'Merch',   price: 35.00 },
    { id: 'p9', name: 'Croissant Combo',        cat: 'Coffee',  price: 10.00 }
  ],
  currencies: {
    accepted: [
      { symbol: 'SOL',  name: 'Solana',       chain: 'Solana L1',      fee: '1% Included', direct: true,  icon: '◎' },
      { symbol: 'USDC', name: 'USDC Stable',  chain: 'Solana Stable',  fee: '0.5% Included', direct: true,  icon: '💲' },
      { symbol: 'DYNK', name: 'DYNK Token',   chain: 'DYNK Protocol',  fee: '1¢ Flat Fee', direct: true,  icon: '⚡' }
    ],
    swapAndSend: [
      { symbol: 'ETH',  name: 'Ethereum',     chain: 'EVM Mainnet',    fee: 'Swap 0.5% + 1%', direct: false, solver: 'deBridge',         icon: '⟠' },
      { symbol: 'BTC',  name: 'Bitcoin',      chain: 'Bitcoin Native', fee: 'Swap 0.5% + 1%', direct: false, solver: 'Lightning/Solana', icon: '₿' }
    ]
  },
  campaigns: [
    { id: 'camp1', title: 'Walk-Past Welcome Spin', type: 'spin_wheel', discount: '10%', code: 'WELCOME10', active: true },
    { id: 'camp2', title: 'Happy Hour 4-6 PM',      type: 'happy_hour', discount: '15%', code: 'HAPPY15',   active: true },
    { id: 'camp3', title: 'Coffee Punch Card',      type: 'loyalty',    discount: 'Free 6th', code: 'PUNCHCARD', active: true }
  ],
  onboarding: {
    status: 'live', // 'setup' | 'live'
    currentStep: 7,
    account: {
      email: 'alex@beanandbrew.com.au',
      phone: '+61 412 345 678',
      signatoryName: 'Alex Mercer',
      verified: true
    },
    business: {
      legalName: 'Bean & Brew Pty Ltd',
      tradingName: 'Bean & Brew Café',
      businessType: 'company',
      abn: '51 824 753 556',
      address: '142 George St, The Rocks NSW 2000',
      kybStatus: 'approved',
      submittedAt: '2026-09-01T08:00:00Z',
      verifiedAt: '2026-09-01T08:05:00Z'
    },
    starterKit: {
      ordered: true,
      paid: true,
      amountUSD: 199,
      paidMethod: 'card',
      orderedAt: '2026-09-01T08:15:00Z',
      trackingNumber: 'DY-SHIP-9941',
      carrier: 'Australia Post Express',
      status: 'delivered',
      kitItems: [
        'Dynkle Terminal (Screenless Square Tap-to-Pay Reader)',
        'Cold Storage Security Card (Seed Recovery Card)',
        'Prepaid Business Debit Card',
        'Countertop Acrylic Signage ("Pay with DYNKLE — 0% Card Fees")'
      ]
    },
    device: {
      paired: true,
      deviceId: 'DY-009',
      serialNumber: 'DNK-9008-8812',
      status: 'connected',
      pairedAt: '2026-09-02T09:30:00Z'
    }
  }
};

/**
 * Validate that splits sum to exactly 100%
 */
export function validateSplitPercentages(wallets) {
  if (!Array.isArray(wallets) || wallets.length === 0) {
    return { valid: false, error: 'At least one split wallet is required.' };
  }
  const total = wallets.reduce((sum, w) => sum + (parseFloat(w.pct) || 0), 0);
  const rounded = Math.round(total * 10) / 10;
  if (Math.abs(rounded - 100) > 0.05) {
    return {
      valid: false,
      total: rounded,
      error: `Split allocations must equal exactly 100.0%. Current sum: ${rounded}%! Real-world financial settlement requires 100% allocation.`
    };
  }
  return { valid: true, total: 100 };
}

/**
 * Update merchant wallets with strict 100% verification
 */
export function setMerchantWallets(newWallets) {
  const check = validateSplitPercentages(newWallets);
  if (!check.valid) {
    throw new Error(check.error);
  }
  merchantState.wallets = newWallets.map(w => ({
    ...w,
    settle: normalizeSettle(w.settle),
    pct: Math.round(parseFloat(w.pct) * 10) / 10,
    balance: parseFloat(w.balance) || 0
  }));
  return merchantState.wallets;
}

/**
 * Calculate dynamic multi-asset cross-chain swap & split routing preview
 * based on merchant's active wallet settlement rules.
 * Wallets with settle === 'USDC' receive USDC (AUD share converted at USDC/AUD).
 * Wallets with settle === 'Hold' receive native SOL.
 */
export function getMerchantSplitSwapPreview(amountAUD, fromToken = 'ETH') {
  const totalAUD = parseFloat(amountAUD) || 10.10;
  const ethPrice = 3800.00;
  const solPrice = 220.00;
  const fromPrice = fromToken === 'ETH' ? ethPrice : (fromToken === 'BTC' ? 98000.00 : 1.53);
  const fromAmount = fromToken === 'BTC' 
    ? parseFloat((totalAUD / fromPrice).toFixed(6))
    : parseFloat((totalAUD / fromPrice).toFixed(4));
  
  let usdcPct = 0;
  let solPct = 0;
  
  const walletAllocations = merchantState.wallets.map(w => {
    const isStable = normalizeSettle(w.settle).toUpperCase() === STABLE_SETTLE_TOKEN;
    const pct = parseFloat(w.pct) || 0;
    const shareAUD = Math.round(totalAUD * (pct / 100) * 100) / 100;
    
    if (isStable) {
      usdcPct += pct;
      const shareUSDC = audToUsdc(shareAUD);
      return {
        walletId: w.id,
        name: w.name,
        pct: pct,
        settleMode: STABLE_SETTLE_TOKEN,
        token: STABLE_SETTLE_TOKEN,
        shareAUD,
        amount: shareUSDC.toFixed(2),
        formatted: `${shareUSDC.toFixed(2)} USDC`
      };
    } else {
      solPct += pct;
      const shareSOL = parseFloat((shareAUD / solPrice).toFixed(4));
      return {
        walletId: w.id,
        name: w.name,
        pct: pct,
        settleMode: 'Hold',
        token: 'SOL',
        shareAUD,
        amount: shareSOL.toFixed(4),
        formatted: `${shareSOL.toFixed(4)} SOL`
      };
    }
  });

  usdcPct = Math.round(usdcPct * 10) / 10;
  solPct = Math.round(solPct * 10) / 10;

  const totalSwappedUSDC = audToUsdc(totalAUD * (usdcPct / 100));
  const totalSwappedSOL = parseFloat(((totalAUD * (solPct / 100)) / solPrice).toFixed(4));

  return {
    isCrossChainSwap: true,
    solver: 'deBridge',
    fromToken: fromToken.toUpperCase(),
    fromAmount,
    totalAUD,
    usdcPercentage: usdcPct,
    solPercentage: solPct,
    totalSwappedUSDC: totalSwappedUSDC.toFixed(2),
    totalSwappedSOL: totalSwappedSOL.toFixed(4),
    summary: `Swapping ${fromAmount} ${fromToken} via deBridge → ${totalSwappedUSDC.toFixed(2)} USDC (${usdcPct}%) + ${totalSwappedSOL.toFixed(4)} SOL (${solPct}%)`,
    walletAllocations
  };
}

/**
 * Execute real auto-split when an order is paid
 */
export function executeOrderSplitSettlement(order, paidCurrencyOverride) {
  const totalAmountAUD = parseFloat(order.amountUSD || order.finalTotalAUD || 10.00);
  const isDynk = order.tokenSymbol === 'DYNK' || order.useCase === 'dynk_token';
  const paidCurrency = (paidCurrencyOverride || order.paidCurrency || order.tokenSymbol || 'SOL').toUpperCase();
  const acceptedSymbols = getAcceptedCurrencySymbols();
  const isDirectAccepted = acceptedSymbols.includes(paidCurrency);
  const solPrice = 220.00;

  // Determine if this payment requires cross-chain swap & split
  const isSwapAndSplit = !isDirectAccepted && (paidCurrency === 'ETH' || paidCurrency === 'BTC');
  
  let swapExecution = null;
  if (isSwapAndSplit) {
    swapExecution = getMerchantSplitSwapPreview(totalAmountAUD, paidCurrency);
  }

  // 1. Calculate splits according to active percentages and settlement mode
  const splits = merchantState.wallets.map(wallet => {
    const shareAUD = Math.round((totalAmountAUD * (wallet.pct / 100)) * 100) / 100;
    
    // Credit real wallet balance
    wallet.balance = Math.round((wallet.balance + shareAUD) * 100) / 100;

    let shareCrypto = null;
    let targetAsset = wallet.settle === 'Hold' ? 'SOL' : STABLE_SETTLE_TOKEN;

    if (isSwapAndSplit) {
      if (wallet.settle === 'Hold') {
        const solAmt = (shareAUD / solPrice).toFixed(4);
        shareCrypto = `${solAmt} SOL`;
      } else {
        shareCrypto = `${audToUsdc(shareAUD).toFixed(2)} USDC`;
      }
    } else {
      const cryptoAmount = parseFloat(order.amount || order.cryptoAmount || 0);
      const tokenSymbol = order.tokenSymbol || 'SOL';
      shareCrypto = cryptoAmount > 0 
        ? (wallet.settle === 'Hold' ? `${(cryptoAmount * (wallet.pct / 100)).toFixed(4)} ${tokenSymbol}` : `${audToUsdc(shareAUD).toFixed(2)} USDC`)
        : null;
    }

    return {
      walletId: wallet.id,
      name: wallet.name,
      walletName: wallet.name,
      pct: wallet.pct,
      color: wallet.color,
      settleMode: normalizeSettle(wallet.settle), // 'USDC' or 'Hold'
      targetAsset,
      shareAUD,
      shareCrypto,
      address: wallet.address
    };
  });

  // 2. Update real merchant cumulative KPIs
  merchantState.kpis.revenue = Math.round((merchantState.kpis.revenue + totalAmountAUD) * 100) / 100;
  merchantState.kpis.txCount += 1;
  if (isDynk) merchantState.kpis.dynkCount += 1;

  const cardCost = merchantState.kpis.revenue * 0.016;
  const dynkCost = merchantState.kpis.dynkCount * 0.01;
  merchantState.kpis.savedVsCard = Math.round((cardCost - dynkCost) * 100) / 100;

  return {
    orderId: order.id,
    totalAmountAUD,
    tokenSymbol: paidCurrency,
    cryptoAmount: isSwapAndSplit ? swapExecution.fromAmount : (order.amount || order.cryptoAmount),
    isCrossChainSwap: isSwapAndSplit,
    swapExecution,
    splits,
    kpis: { ...merchantState.kpis }
  };
}

/**
 * Get list of all currently directly accepted currency symbols
 */
export function getAcceptedCurrencySymbols() {
  if (!merchantState.currencies || !merchantState.currencies.accepted) return ['DYNK', 'SOL', 'USDC'];
  return merchantState.currencies.accepted.map(c => c.symbol.toUpperCase());
}

/**
 * Add or update a currency in the acceptance matrix
 */
export function addMerchantCurrency({ symbol, name, chain, fee, direct = true, solver = 'Direct', icon = '🪙' }) {
  if (!symbol || !name) {
    throw new Error('Currency symbol and name are required.');
  }
  const cleanSymbol = symbol.trim().toUpperCase();
  const cleanName = name.trim();
  const cleanChain = (chain || 'Solana / EVM').trim();
  const cleanFee = fee ? fee.trim() : (direct ? '1% Included' : 'Swap 0.5% + 1%');
  const cleanSolver = direct ? 'Direct' : (solver || 'deBridge');
  const cleanIcon = icon ? icon.trim() : (direct ? '◎' : '⚡');

  // Remove if exists in either list first
  removeMerchantCurrency(cleanSymbol);

  const entry = {
    symbol: cleanSymbol,
    name: cleanName,
    chain: cleanChain,
    fee: cleanFee,
    direct: !!direct,
    solver: cleanSolver,
    icon: cleanIcon
  };

  if (direct) {
    merchantState.currencies.accepted.push(entry);
  } else {
    merchantState.currencies.swapAndSend.push(entry);
  }

  return {
    currencies: merchantState.currencies,
    acceptedSymbols: getAcceptedCurrencySymbols()
  };
}

/**
 * Toggle a currency between Directly Accepted and Swap & Send
 */
export function toggleMerchantCurrency(symbol) {
  const cleanSymbol = symbol.trim().toUpperCase();
  const acceptedIdx = merchantState.currencies.accepted.findIndex(c => c.symbol.toUpperCase() === cleanSymbol);
  
  if (acceptedIdx !== -1) {
    // Move from accepted to swap & send
    const item = merchantState.currencies.accepted.splice(acceptedIdx, 1)[0];
    item.direct = false;
    item.solver = item.solver === 'Direct' ? 'deBridge' : item.solver;
    item.fee = item.fee.includes('Swap') ? item.fee : 'Swap 0.5% + 1%';
    merchantState.currencies.swapAndSend.push(item);
    return { movedTo: 'swapAndSend', item, currencies: merchantState.currencies, acceptedSymbols: getAcceptedCurrencySymbols() };
  }

  const swapIdx = merchantState.currencies.swapAndSend.findIndex(c => c.symbol.toUpperCase() === cleanSymbol);
  if (swapIdx !== -1) {
    // Move from swap & send to accepted
    const item = merchantState.currencies.swapAndSend.splice(swapIdx, 1)[0];
    item.direct = true;
    item.solver = 'Direct';
    item.fee = item.fee.includes('1¢') ? item.fee : '1% Included';
    merchantState.currencies.accepted.push(item);
    return { movedTo: 'accepted', item, currencies: merchantState.currencies, acceptedSymbols: getAcceptedCurrencySymbols() };
  }

  throw new Error(`Currency with symbol '${symbol}' not found in Acceptance Matrix.`);
}

/**
 * Remove a currency completely from the matrix
 */
export function removeMerchantCurrency(symbol) {
  const cleanSymbol = symbol.trim().toUpperCase();
  merchantState.currencies.accepted = merchantState.currencies.accepted.filter(c => c.symbol.toUpperCase() !== cleanSymbol);
  merchantState.currencies.swapAndSend = merchantState.currencies.swapAndSend.filter(c => c.symbol.toUpperCase() !== cleanSymbol);
  return {
    currencies: merchantState.currencies,
    acceptedSymbols: getAcceptedCurrencySymbols()
  };
}

/**
 * Onboarding Helper Methods (SOW Stages 1 - 7)
 */
export function getOnboardingState() {
  return merchantState.onboarding;
}

export function saveOnboardingAccount(data = {}) {
  const { email, phone, signatoryName } = data;
  merchantState.onboarding.account = {
    email: email || 'alex@beanandbrew.com.au',
    phone: phone || '+61 412 345 678',
    signatoryName: signatoryName || 'Alex Mercer',
    verified: true
  };
  merchantState.onboarding.currentStep = Math.max(merchantState.onboarding.currentStep, 2);
  return merchantState.onboarding;
}

export function saveOnboardingBusiness(data = {}) {
  const { legalName, tradingName, businessType, abn, address, documents } = data;
  merchantState.onboarding.business = {
    legalName: legalName || 'Bean & Brew Pty Ltd',
    tradingName: tradingName || 'Bean & Brew Café',
    businessType: businessType || 'company',
    abn: abn || '51 824 753 556',
    address: address || '142 George St, The Rocks NSW 2000',
    kybStatus: 'approved',
    documents: documents || ['Business_Registration_Certificate.pdf', 'Signatory_Passport.pdf'],
    submittedAt: new Date().toISOString(),
    verifiedAt: new Date().toISOString()
  };
  if (tradingName) {
    merchantState.venue.name = tradingName;
  }
  merchantState.onboarding.currentStep = Math.max(merchantState.onboarding.currentStep, 3);
  return merchantState.onboarding;
}

export function orderStarterKit(data = {}) {
  const { paidMethod = 'card' } = data;
  merchantState.onboarding.starterKit = {
    ordered: true,
    paid: true,
    amountUSD: 199,
    paidMethod,
    orderedAt: new Date().toISOString(),
    trackingNumber: 'DY-SHIP-' + Math.floor(1000 + Math.random() * 9000),
    carrier: 'Australia Post Express',
    status: 'delivered',
    kitItems: [
      'Dynkle Terminal (Screenless Square Tap-to-Pay Reader)',
      'Cold Storage Security Card (Seed Recovery Card)',
      'Prepaid Business Debit Card',
      'Countertop Acrylic Signage ("Pay with DYNKLE — 0% Card Fees")'
    ]
  };
  merchantState.onboarding.currentStep = Math.max(merchantState.onboarding.currentStep, 4);
  return merchantState.onboarding;
}

export function pairDevice(data = {}) {
  const { deviceId = 'DY-009', serialNumber = 'DNK-9008-8812' } = data;
  merchantState.onboarding.device = {
    paired: true,
    deviceId,
    serialNumber,
    status: 'connected',
    pairedAt: new Date().toISOString()
  };
  merchantState.venue.terminalId = deviceId;
  merchantState.onboarding.currentStep = Math.max(merchantState.onboarding.currentStep, 5);
  return merchantState.onboarding;
}

export function setGoLiveStatus(isLive = true) {
  merchantState.onboarding.status = isLive ? 'live' : 'setup';
  merchantState.onboarding.currentStep = isLive ? 7 : merchantState.onboarding.currentStep;
  return merchantState.onboarding;
}

export function resetOnboardingState() {
  merchantState.onboarding = {
    status: 'setup',
    currentStep: 1,
    account: { email: '', phone: '', signatoryName: '', verified: false },
    business: { legalName: '', tradingName: '', businessType: 'company', abn: '', address: '', kybStatus: 'unsubmitted' },
    starterKit: { ordered: false, paid: false, amountUSD: 199, status: 'unpaid', kitItems: [] },
    device: { paired: false, deviceId: '', serialNumber: '', status: 'offline' }
  };
  return merchantState.onboarding;
}

export function getAutoSwapConfig() {
  return merchantState.autoSwapConfig || {
    enabled: true,
    targetAsset: 'USDC',
    batchSchedule: 'Threshold Trigger (≥ Min Floor)',
    batchWindowHours: 0,
    minThresholdAUD: 50.00,
    slippageToleranceBps: 50,
    status: 'ACTIVE',
    mode: 'TREASURY_THRESHOLD'
  };
}

export function updateAutoSwapConfig(updates = {}) {
  merchantState.autoSwapConfig = {
    ...getAutoSwapConfig(),
    ...updates,
    updatedAt: new Date().toISOString()
  };
  return merchantState.autoSwapConfig;
}

