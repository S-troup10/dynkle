// Catalogue import: reads a menu photo or PDF into editable product rows.
//
// Per the design POC: Gemini Flash by default (cheap, reads PDFs natively);
// when several rows come back uncertain (handwritten specials, cramped layouts)
// the menu is re-read by Claude Sonnet and that answer is used. With no model
// key configured, DEMO_MODE returns a sample menu so the flow can be shown;
// otherwise extraction reports it is not set up. Nothing here saves products:
// every row goes to the merchant's review screen first.
//
// Env: GEMINI_API_KEY, GEMINI_MODEL (default gemini-3.5-flash),
//      ANTHROPIC_API_KEY, ANTHROPIC_MODEL (default claude-sonnet-5-5),
//      CATALOG_EXTRACT_PROVIDER = gemini | anthropic | demo (default: first configured),
//      CATALOG_ESCALATE_MIN_UNCERTAIN (default 3): uncertain rows that trigger the re-read.

import '../config.js'; // loads .env

export const ACCEPTED_TYPES = ['image/jpeg', 'image/png', 'image/webp', 'image/gif', 'application/pdf'];
export const MAX_FILES = 8;
export const MAX_FILE_BYTES = 15 * 1024 * 1024;
export const UNCERTAIN_BELOW = 0.8;
const TIMEOUT_MS = 90_000;
const MAX_ROWS = 500;

export class ExtractError extends Error {
  constructor(status, code, message) {
    super(message);
    this.status = status;
    this.code = code;
  }
}

/** Trusts file contents, not the browser's label. */
export function sniffType(buf) {
  if (!buf || buf.length < 12) return null;
  if (buf.slice(0, 4).toString('latin1') === '%PDF') return 'application/pdf';
  if (buf[0] === 0x89 && buf.slice(1, 4).toString('latin1') === 'PNG') return 'image/png';
  if (buf[0] === 0xff && buf[1] === 0xd8 && buf[2] === 0xff) return 'image/jpeg';
  if (buf.slice(0, 4).toString('latin1') === 'RIFF' && buf.slice(8, 12).toString('latin1') === 'WEBP') return 'image/webp';
  if (buf.slice(0, 3).toString('latin1') === 'GIF') return 'image/gif';
  return null;
}

export const PROMPT = `You are reading a cafe or restaurant menu (photo or PDF) to build a point-of-sale product list.
Return ONLY JSON, no prose, in exactly this shape:
{"items":[{"name":"Flat white","price":4.80,"section":"Coffee","subsection":null,"gst":null,"confidence":0.97,"page":1}],"notes":""}
Rules:
- One entry per item that has a price. Skip headings, descriptions, opening hours, phone numbers, addresses.
- "name": the item name as printed, without the price or dots/leaders. Keep size words that distinguish items ("Latte large").
- If one item lists several prices for sizes/variants, return one entry per size with the size in the name.
- "price": a number in the menu's currency, no symbol. If you cannot read it, use null.
- "section": the menu heading the item sits under (e.g. "Coffee", "Mains"), title case. "subsection": a smaller heading inside that section, else null.
- "gst": "free" only when the menu says that item is GST-free or tax-exempt; "inc" when the menu says prices include GST; otherwise null.
- "confidence": 0-1, how sure you are that BOTH name and price are read correctly. Use below 0.8 for blurry, handwritten, cramped or ambiguous entries.
- "page": the page or image number (1-based) the item is on.
- "notes": one short sentence about anything the merchant should check, or "".`;

// ── Normalising model output ─────────────────────────────────────────────

const titleCase = (s) => s.toLowerCase().replace(/(^|[\s/&(-])([a-z])/g, (m, a, b) => a + b.toUpperCase());

function cleanText(v, max) {
  return String(v ?? '').replace(/\s+/g, ' ').replace(/[.·…_\s-]+$/u, '').trim().slice(0, max);
}

/** Model JSON → rows the review screen understands. Two category levels max. */
export function normalizeRows(raw) {
  const items = Array.isArray(raw?.items) ? raw.items : Array.isArray(raw) ? raw : [];
  const rows = [];
  for (const it of items.slice(0, MAX_ROWS)) {
    const name = cleanText(it?.name, 80);
    if (name.length < 2) continue;
    let price = it?.price;
    if (typeof price === 'string') price = parseFloat(price.replace(/[^0-9.,-]/g, '').replace(',', '.'));
    price = Number.isFinite(price) && price >= 0 && price < 100000 ? Math.round(price * 100) / 100 : null;
    const section = cleanText(it?.section, 40);
    const sub = cleanText(it?.subsection, 40);
    const fix = (s) => (s && s === s.toUpperCase() ? titleCase(s) : s);
    const category = [fix(section), fix(sub)].filter(Boolean).join(' > ') || 'Uncategorised';
    let confidence = Number(it?.confidence);
    if (!Number.isFinite(confidence)) confidence = 0.7;
    confidence = Math.max(0, Math.min(1, confidence));
    if (price === null) confidence = Math.min(confidence, 0.4);
    rows.push({
      name,
      price,
      category,
      gst: it?.gst === 'free' ? 'free' : 'inc',
      confidence: Math.round(confidence * 100) / 100,
      page: Number.isInteger(it?.page) && it.page > 0 ? it.page : 1,
    });
  }
  return { rows, notes: cleanText(raw?.notes, 300) };
}

export function parseJsonLoose(text) {
  const s = String(text || '').trim();
  try { return JSON.parse(s); } catch { /* fall through */ }
  const fenced = s.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (fenced) { try { return JSON.parse(fenced[1]); } catch { /* fall through */ } }
  const start = s.indexOf('{');
  const end = s.lastIndexOf('}');
  if (start >= 0 && end > start) { try { return JSON.parse(s.slice(start, end + 1)); } catch { /* fall through */ } }
  throw new ExtractError(502, 'EXTRACT_UNREADABLE', 'The menu reader returned something we could not understand. Try again or upload a clearer file.');
}

const uncertainCount = (rows) => rows.filter((r) => r.confidence < UNCERTAIN_BELOW).length;

// ── Providers ────────────────────────────────────────────────────────────

async function postJson(url, headers, body, name) {
  const ctrl = new AbortController();
  const timer = setTimeout(() => ctrl.abort(), TIMEOUT_MS);
  try {
    const res = await fetch(url, { method: 'POST', headers: { 'content-type': 'application/json', ...headers }, body: JSON.stringify(body), signal: ctrl.signal });
    const json = await res.json().catch(() => ({}));
    if (!res.ok) {
      console.warn(`[catalog] ${name} ${res.status}: ${json?.error?.message || json?.error?.type || 'error'}`);
      throw new ExtractError(502, 'EXTRACT_FAILED', 'The menu reader is not available right now. Try again shortly, or import a spreadsheet instead.');
    }
    return json;
  } catch (e) {
    if (e instanceof ExtractError) throw e;
    console.warn(`[catalog] ${name}: ${e.name === 'AbortError' ? 'timed out' : e.message}`);
    throw new ExtractError(504, 'EXTRACT_TIMEOUT', 'Reading the menu took too long. Try a smaller file or fewer pages.');
  } finally {
    clearTimeout(timer);
  }
}

export const providers = {
  async gemini(files, env = process.env) {
    // Pinned: the "gemini-flash-latest" alias was often overloaded (85-120 s or 503 at busy times; 3.5 Flash read the same menu in 9 s).
    const model = env.GEMINI_MODEL || 'gemini-3.5-flash';
    const parts = [{ text: PROMPT }, ...files.map((f) => ({ inline_data: { mime_type: f.type, data: f.buffer.toString('base64') } }))];
    const json = await postJson(
      `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent`,
      { 'x-goog-api-key': env.GEMINI_API_KEY },
      { contents: [{ role: 'user', parts }], generationConfig: { temperature: 0, responseMimeType: 'application/json' } },
      'gemini',
    );
    const text = (json?.candidates?.[0]?.content?.parts || []).map((p) => p.text || '').join('');
    return { ...normalizeRows(parseJsonLoose(text)), provider: 'gemini', model };
  },

  async anthropic(files, env = process.env) {
    const model = env.ANTHROPIC_MODEL || 'claude-sonnet-5-5';
    const content = [
      ...files.map((f) => (f.type === 'application/pdf'
        ? { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: f.buffer.toString('base64') } }
        : { type: 'image', source: { type: 'base64', media_type: f.type, data: f.buffer.toString('base64') } })),
      { type: 'text', text: PROMPT },
    ];
    const json = await postJson(
      'https://api.anthropic.com/v1/messages',
      { 'x-api-key': env.ANTHROPIC_API_KEY, 'anthropic-version': '2023-06-01' },
      { model, max_tokens: 16000, temperature: 0, messages: [{ role: 'user', content }] },
      'anthropic',
    );
    const text = (json?.content || []).filter((b) => b.type === 'text').map((b) => b.text).join('');
    return { ...normalizeRows(parseJsonLoose(text)), provider: 'anthropic', model };
  },

  // DEMO_MODE stand-in: a fixed cafe menu so the review flow can be shown without a model key.
  async demo() {
    const raw = {
      notes: 'Demo reading: this sample menu is returned for any file because no menu reader is configured.',
      items: [
        ['Flat white', 4.8, 'Coffee', 0.97], ['Long black', 4.2, 'Coffee', 0.96], ['Cappuccino', 4.8, 'Coffee', 0.94],
        ['Mocha', 5.6, 'Coffee', 0.91], ['Chai latte', 5.2, 'Coffee', 0.84],
        ['Almond croissant', 6.5, 'Bakery', 0.95], ['Sourdough loaf', 8.0, 'Bakery', 0.94, 'free'],
        ['Banana bread, toasted', 7.0, 'Bakery', 0.79], ['Portuguese tart', 5.5, 'Bakery', 0.92],
        ['Banh mi', 14.5, 'All Day', 0.93], ['Pad thai', 18.9, 'All Day', 0.68], ['Avocado on sourdough', 16.0, 'All Day', 0.95],
        ['Bacon & egg roll', 12.5, 'All Day', 0.9], ['Soup of the day', 13.0, 'All Day', 0.92],
        ['House red, glass', 11.0, 'Drinks', 0.72, null, 'Wine'], ['Sparkling water', 4.0, 'Drinks', 0.95],
        ['Fresh orange juice', 6.5, 'Drinks', 0.94],
      ].map(([name, price, section, confidence, gst = null, subsection = null]) => ({ name, price, section, subsection, gst, confidence, page: 1 })),
    };
    return { ...normalizeRows(raw), provider: 'demo', model: null, demo: true };
  },
};

export function extractionConfig(env = process.env) {
  const demo = env.DEMO_MODE === 'true';
  const configured = [env.GEMINI_API_KEY && 'gemini', env.ANTHROPIC_API_KEY && 'anthropic'].filter(Boolean);
  let primary = env.CATALOG_EXTRACT_PROVIDER || configured[0] || (demo ? 'demo' : null);
  if (primary === 'demo' && !demo) primary = configured[0] || null;
  if (primary && primary !== 'demo' && !configured.includes(primary)) primary = configured[0] || (demo ? 'demo' : null);
  const fallback = primary === 'gemini' && env.ANTHROPIC_API_KEY ? 'anthropic' : null;
  const minUncertain = Math.max(1, parseInt(env.CATALOG_ESCALATE_MIN_UNCERTAIN || '3', 10) || 3);
  return { primary, fallback, minUncertain, available: !!primary };
}

/** files: [{ buffer, type, name }] already checked. */
export async function extractMenu(files, env = process.env, impl = providers) {
  const cfg = extractionConfig(env);
  if (!cfg.primary) {
    throw new ExtractError(503, 'EXTRACT_NOT_CONFIGURED', 'Reading menus from photos is not set up on this server yet. Import a spreadsheet instead.');
  }
  let result = await impl[cfg.primary](files, env);
  let escalated = false;
  // Cheap model first; the premium one only when several rows came back uncertain.
  if (cfg.fallback && (uncertainCount(result.rows) >= cfg.minUncertain || !result.rows.length)) {
    try {
      const second = await impl[cfg.fallback](files, env);
      if (second.rows.length && uncertainCount(second.rows) <= uncertainCount(result.rows)) {
        result = second;
        escalated = true;
      }
    } catch (e) {
      console.warn('[catalog] fallback reader:', e.message);
    }
  }
  if (!result.rows.length) {
    throw new ExtractError(422, 'NOTHING_FOUND', 'No items with prices were found. Try a clearer photo, or upload the PDF menu from your designer.');
  }
  return { ...result, escalated, uncertain: uncertainCount(result.rows) };
}
