// Catalogue import commit: the reviewed rows become products.
// Re-import merges by product name (case-insensitive): existing products are
// updated, new ones added, nothing is duplicated. Rows that fail validation are
// returned as skipped with the reason, and the clean rows still import.

import prisma from '../db.js';
import { mapProduct, cleanCategoryPath } from '../routes/merchant.js';

export const MAX_IMPORT_ROWS = 1000;
const MAX_PRICE = 100000;

const nameKey = (s) => String(s || '').replace(/\s+/g, ' ').trim().toLowerCase();

/** Two category levels at most, as the menu headings give them. */
export function importCategory(v) {
  const path = cleanCategoryPath(v).split(' > ').slice(0, 2).map((s) => s.slice(0, 40)).join(' > ');
  return path || 'Uncategorised';
}

/** Checks one row. Returns { ok, product } or { ok:false, reason }. */
export function validateRow(row) {
  const name = String(row?.name ?? '').replace(/\s+/g, ' ').trim();
  if (!name) return { ok: false, reason: 'Missing product name.' };
  if (name.length > 80) return { ok: false, reason: 'Name is longer than 80 characters.' };
  let price = row?.price;
  if (typeof price === 'string') price = price.replace(/[$\s,]/g, '') === '' ? NaN : Number(price.replace(/[$\s,]/g, ''));
  if (!Number.isFinite(price)) return { ok: false, reason: 'Price is missing or not a number.' };
  if (price <= 0) return { ok: false, reason: 'Price must be above zero.' };
  if (price > MAX_PRICE) return { ok: false, reason: 'Price looks too high.' };
  const gst = String(row?.gst ?? row?.tax ?? 'inc').toLowerCase();
  const tax = ['free', '0', 'gst-free', 'gst free', 'exempt', 'no'].includes(gst) ? '0' : '10';
  const icon = typeof row?.icon === 'string' && [...row.icon].length <= 4 ? row.icon : undefined;
  return {
    ok: true,
    product: {
      name,
      price: Math.round(price * 100) / 100,
      category: importCategory(row?.category),
      tax,
      icon,
      sku: row?.sku ? String(row.sku).trim().slice(0, 40) : undefined,
      desc: row?.description ? String(row.description).trim().slice(0, 500) : undefined,
    },
  };
}

/** Every path plus its parents, e.g. "Drinks > Wine" → ["Drinks", "Drinks > Wine"]. */
function withParents(paths) {
  const out = new Set();
  for (const p of paths) {
    const parts = p.split(' > ');
    for (let i = 1; i <= parts.length; i++) out.add(parts.slice(0, i).join(' > '));
  }
  return [...out];
}

export async function commitImport(merchantId, rows, { source = null } = {}) {
  if (!Array.isArray(rows) || !rows.length) return { added: 0, updated: 0, skipped: [], products: null };
  if (rows.length > MAX_IMPORT_ROWS) {
    const err = new Error(`Import up to ${MAX_IMPORT_ROWS} products at a time.`);
    err.status = 400; err.code = 'TOO_MANY_ROWS';
    throw err;
  }
  const skipped = [];
  // Within one import, a later row with the same name wins.
  const byName = new Map();
  rows.forEach((row, index) => {
    const v = validateRow(row);
    if (!v.ok) { skipped.push({ row: index, name: String(row?.name ?? ''), reason: v.reason }); return; }
    const key = nameKey(v.product.name);
    if (byName.has(key)) skipped.push({ row: byName.get(key).index, name: byName.get(key).product.name, reason: 'Same name appears again further down; the later row was used.' });
    byName.set(key, { index, product: v.product });
  });

  const existing = await prisma.product.findMany({ where: { merchantId, active: true }, orderBy: { createdAt: 'asc' } });
  const existingByName = new Map();
  for (const p of existing) if (!existingByName.has(nameKey(p.name))) existingByName.set(nameKey(p.name), p);

  const ops = [];
  const previous = [];
  let added = 0;
  let updated = 0;
  for (const [key, { product }] of byName) {
    const hit = existingByName.get(key);
    if (hit) {
      previous.push({ id: hit.id, name: hit.name, price: hit.price.toString(), category: hit.category, description: hit.description, meta: hit.meta ?? null });
      const meta = { ...(hit.meta && typeof hit.meta === 'object' ? hit.meta : {}), tax: product.tax };
      if (product.icon && !meta.icon) meta.icon = product.icon;
      if (product.sku) meta.sku = product.sku;
      if (product.desc) meta.desc = product.desc;
      ops.push(prisma.product.update({ where: { id: hit.id }, data: { price: product.price, category: product.category, meta } }));
      updated++;
    } else {
      const meta = { tax: product.tax };
      if (product.icon) meta.icon = product.icon;
      if (product.sku) meta.sku = product.sku;
      if (product.desc) meta.desc = product.desc;
      ops.push(prisma.product.create({
        data: { merchantId, name: product.name, price: product.price, category: product.category, description: product.desc || null, meta },
      }));
      added++;
    }
  }

  const merchant = await prisma.merchant.findUnique({ where: { id: merchantId } });
  const current = Array.isArray(merchant?.catalogCategories) ? merchant.catalogCategories : [];
  const categories = [...new Set([...current, ...withParents([...byName.values()].map((r) => r.product.category))])].slice(0, 500);
  ops.push(prisma.merchant.update({ where: { id: merchantId }, data: { catalogCategories: categories } }));

  const results = await prisma.$transaction(ops);
  const createdIds = results.slice(0, byName.size).filter((p, i) => !previous.some((x) => x.id === p.id) && p?.id).map((p) => p.id);
  const record = await prisma.catalogImport.create({
    data: { merchantId, createdIds, previous, categories: current, added, updated, source: source ? String(source).slice(0, 120) : null },
  });
  const all = await prisma.product.findMany({ where: { merchantId, active: true }, orderBy: { createdAt: 'asc' } });
  skipped.sort((a, b) => a.row - b.row);
  return { added, updated, skipped, products: all.map(mapProduct), categories, importId: record.id };
}

export const UNDO_WINDOW_MS = 24 * 60 * 60 * 1000;

/** The merchant's most recent import that can still be undone, or null. */
export async function lastImport(merchantId) {
  const r = await prisma.catalogImport.findFirst({ where: { merchantId }, orderBy: { createdAt: 'desc' } });
  if (!r || r.undoneAt || Date.now() - r.createdAt.getTime() > UNDO_WINDOW_MS) return null;
  return { id: r.id, added: r.added, updated: r.updated, source: r.source, createdAt: r.createdAt };
}

/**
 * Undoes the last import: products it added are removed, products it updated
 * get their previous name, price, category and details back, and the category
 * list returns to what it was. Only the most recent import, within 24 hours.
 */
export async function undoImport(merchantId, importId) {
  const last = await prisma.catalogImport.findFirst({ where: { merchantId }, orderBy: { createdAt: 'desc' } });
  const fail = (status, code, message) => Object.assign(new Error(message), { status, code });
  if (!last || last.id !== importId) throw fail(409, 'NOT_LAST_IMPORT', 'Only the most recent import can be undone.');
  if (last.undoneAt) throw fail(409, 'ALREADY_UNDONE', 'This import has already been undone.');
  if (Date.now() - last.createdAt.getTime() > UNDO_WINDOW_MS) throw fail(409, 'UNDO_EXPIRED', 'Imports can be undone for 24 hours. Edit the products instead.');
  const createdIds = Array.isArray(last.createdIds) ? last.createdIds : [];
  const previous = Array.isArray(last.previous) ? last.previous : [];
  const ops = [
    prisma.product.deleteMany({ where: { merchantId, id: { in: createdIds } } }),
    ...previous.map((p) => prisma.product.updateMany({
      where: { id: p.id, merchantId },
      data: { name: p.name, price: p.price, category: p.category, description: p.description ?? null, meta: p.meta ?? undefined },
    })),
    prisma.merchant.update({ where: { id: merchantId }, data: { catalogCategories: Array.isArray(last.categories) ? last.categories : [] } }),
    prisma.catalogImport.update({ where: { id: last.id }, data: { undoneAt: new Date() } }),
  ];
  await prisma.$transaction(ops);
  const all = await prisma.product.findMany({ where: { merchantId, active: true }, orderBy: { createdAt: 'asc' } });
  const merchant = await prisma.merchant.findUnique({ where: { id: merchantId } });
  return { removed: createdIds.length, restored: previous.length, products: all.map(mapProduct), categories: Array.isArray(merchant?.catalogCategories) ? merchant.catalogCategories : [] };
}
