import express from 'express';
import http from 'http';
import cors from 'cors';
import path from 'path';
import fs from 'fs';
import { fileURLToPath } from 'url';
import { PORT, MERCHANT, assertNoPaymentBypass } from './config.js';
import { portalFloorRouter, deviceFloorRouter, publicTableRouter } from './routes/tables.js';
import { sweepTables } from './tables/service.js';
import catalogImportRouter from './routes/catalogImport.js';

// Before anything else: a retired payment bypass must never be live.
assertNoPaymentBypass();
import ordersRouter, { terminalSessions } from './routes/orders.js';
import solanaPayRouter from './routes/solanaPay.js';
import merchantRouter from './routes/merchant.js';
import autoSwapRouter from './routes/autoSwap.js';
import { autoSwapKeeper } from './services/autoSwapKeeperService.js';
import authRouter from './routes/auth.js';
import kybRouter from './routes/kyb.js';
import terminalsRouter, { consumeNfcPairCode } from './routes/terminals.js';
import { terminalGateway } from './gateway/terminalGateway.js';
import deviceRouter from './devices/deviceRoutes.js';
import tappayRouter from './tappay/routes.js';
import { appleAppSiteAssociation, androidAssetLinks } from './tappay/appLinks.js';
import { initTapPay, resumeInFlight, sweepAbandoned, scanDuplicates, checkSponsorBalance, watchWebPayments, tapPay } from './tappay/service.js';
import prisma, { connectDB } from './db.js';
import { checkSolanaPayment } from './services/solana.js';
import { startPriceRefresh } from './services/priceService.js';
import { validateNtag424Tap, recordTapCounter, getLastSeenCounter } from './services/ntag424.js';
import { NON_TERMINAL_STATUSES, IN_FLIGHT_STATUSES } from './services/paymentFlows.js';

// How long a submitted payment may stay unconfirmed before the register is told
// to stop waiting. Deliberately generous — the funds may still land.
const IN_FLIGHT_GRACE_MS = 15 * 60 * 1000;

// How long a terminal may be OFFLINE (missed heartbeats, see terminalGateway's
// 15s ping) before an order armed on it is treated as unreachable. Short
// enough that a customer isn't left staring at a dead register for the full
// 180s quote window.
const TERMINAL_OFFLINE_GRACE_MS = 30 * 1000;

process.on('uncaughtException', (err) => {
  console.warn('[Server Warning] Caught exception:', err.message);
});

process.on('unhandledRejection', (reason) => {
  console.warn('[Server Warning] Unhandled rejection:', reason);
});

const __dirname = path.dirname(fileURLToPath(import.meta.url));

const app = express();
app.use(cors());

// Automatically bypass ngrok free development warning page and prevent browser caching
app.use((req, res, next) => {
  res.setHeader('ngrok-skip-browser-warning', 'true');
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Cache-Control', 'no-store, no-cache, must-revalidate, proxy-revalidate');
  res.setHeader('Pragma', 'no-cache');
  res.setHeader('Expires', '0');
  next();
});

// Catalogue import commits carry up to 1000 reviewed rows; everything else keeps the 100 KB default.
const jsonDefault = express.json();
const jsonImport = express.json({ limit: '2mb' });
app.use((req, res, next) => (req.path === '/api/merchant/catalog-import/commit' ? jsonImport : jsonDefault)(req, res, next));

// Public web assets & uploads
// The website is the dynkle-web repo, served from here. FRONTEND_DIR points at it; otherwise a
// dynkle-web checkout next to this repo is used (the old ../frontend layout still works).
const FRONTEND_DIR = process.env.FRONTEND_DIR
  || [path.join(__dirname, '..', '..', 'dynkle-web'), path.join(__dirname, '..', '..', 'frontend')].find((d) => fs.existsSync(d))
  || path.join(__dirname, '..', '..', 'dynkle-web');
app.use(express.static(FRONTEND_DIR, {
  etag: false,
  maxAge: 0
}));
// KYB compliance documents must never be reachable through the blanket
// static mount below — they're ownership-checked and served exclusively via
// GET /api/kyb/documents/:id/download instead. Blocked before the static
// handler even sees the request, so a filename guess/leak can't bypass it.
app.use('/uploads/kyb', (req, res) => {
  res.status(404).json({ error: 'NOT_FOUND', message: 'Use GET /api/kyb/documents/:id/download instead.' });
});
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

// App association files for /o/* (src/tappay/appLinks.js).
app.get(['/.well-known/apple-app-site-association', '/apple-app-site-association'], (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(200).json(appleAppSiteAssociation());
});

app.get(['/.well-known/assetlinks.json', '/assetlinks.json'], (req, res) => {
  res.setHeader('Content-Type', 'application/json');
  res.status(200).json(androidAssetLinks());
});

// Routes
// Table payments first: their paths sit under /api/merchant and /api/terminals.
app.use('/api/merchant/floor', portalFloorRouter);
app.use('/api/merchant/catalog-import', catalogImportRouter);
app.use('/api/terminals/me/floor', deviceFloorRouter);
app.use(publicTableRouter);
app.use('/api/auth', authRouter);
app.use('/api/kyb', kybRouter);
app.use('/api/terminals', terminalsRouter);
app.use('/api/orders', ordersRouter);
app.use('/api/solana-pay', solanaPayRouter);
app.use('/api/merchant', merchantRouter);
app.use('/api/auto-swap', autoSwapRouter);

// ── Tap and pay (src/tappay): terminal payments, offline relay, DYNK app, /o/:orderId ──
app.use(tappayRouter);

// ── Counter devices (real FP9810 pairing + device API, see src/devices) ──
app.use('/api/terminals', deviceRouter);

// Helper to normalize short terminal IDs (e.g. 1 -> POS_001, 2 -> POS_002, c1 -> POS_001)
function normalizeTerminalId(tid) {
  if (!tid) return 'POS_001';
  const clean = tid.toString().trim().toLowerCase();
  if (clean === '1' || clean === 'c1' || clean === 'pos1' || clean === 'pos_1') return 'POS_001';
  if (clean === '2' || clean === 'c2' || clean === 'pos2' || clean === 'pos_2') return 'POS_002';
  if (clean === '3' || clean === 'c3' || clean === 'pos3' || clean === 'pos_3') return 'POS_003';
  if (clean === '4' || clean === 'c4' || clean === 'pos4' || clean === 'pos_4') return 'POS_004';
  return tid;
}

// STATIC COUNTERTOP NFC RESOLUTION ENGINE
// Resolves ultra-short static tag URLs (e.g. /t/9f3a2b, /t/POS_001, /t/POS_002) to active dynamic bills.
// NTAG 424 DNA SUN: Validates picc & cmac anti-replay and anti-cloning signatures.
// Rule: First tap locks the bill. If bill is already claimed, 2nd customer is shown 'Counter In Use'.
async function resolveNfcTap(merchantParam, terminalParam, req, res) {
  let merchantId = merchantParam;
  let rawTid = terminalParam;

  if (!rawTid) {
    rawTid = merchantParam || 'POS_001';
    merchantId = null;
  }

  const terminalId = normalizeTerminalId(rawTid);

  // 1. Merchant Pairing Mode (Merchant taps tag to bind it to their account/POS)
  if (req?.query?.pair === 'true' || req?.query?.action === 'pair' || req?.query?.mode === 'pair') {
    try {
      // A bare GET can't carry a bearer token, but it must not trust a raw
      // merchantId typed into the URL/header either — that let anyone bind
      // any physical terminal to any merchant account with zero proof of
      // ownership. Instead it must present a short-lived code minted moments
      // earlier by an authenticated owner/admin via
      // POST /api/terminals/nfc-pair-code.
      const pairCode = req.query.pairCode || req.headers['x-pair-code'];
      if (!pairCode) {
        return res.status(401).send('A pairing code from an authenticated merchant session is required. Generate one from your merchant dashboard first.');
      }
      const pairMerchantId = consumeNfcPairCode(pairCode, terminalId);
      if (!pairMerchantId) {
        return res.status(401).send('Invalid, expired, or already-used pairing code. Generate a new one from your merchant dashboard.');
      }

      // Tag Hijacking Protection: block reassigning ANY terminal that already
      // belongs to a different merchant, regardless of its current status —
      // an OFFLINE/ARMED/ERROR terminal was previously reassignable silently,
      // only READY was protected.
      const existingTerminal = await prisma.terminal.findUnique({ where: { terminalId } });
      if (existingTerminal && existingTerminal.merchantId !== pairMerchantId) {
        return res.status(403).send('Tag is already paired to another merchant. Unlink from existing register before re-pairing.');
      }

      await prisma.terminal.upsert({
        where: { terminalId },
        update: {
          merchantId: pairMerchantId,
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        },
        create: {
          merchantId: pairMerchantId,
          terminalId,
          label: `Counter (${terminalId})`,
          serialNumber: `SN-${terminalId}-${Date.now().toString().slice(-4)}`,
          status: 'READY',
          pairedAt: new Date(),
          lastSeenAt: new Date()
        }
      });
      console.log(`[Merchant Tag Paired]: Tag ${terminalId} successfully bound to merchant ${pairMerchantId}`);
      return res.redirect(`/index.html?pairedTerminal=${terminalId}&pairedSuccess=true`);
    } catch (pairErr) {
      console.warn('[Tag Pairing Error]:', pairErr.message);
    }
  }

  // 2. NTAG 424 DNA SUN Cryptographic Validation & Anti-Replay Engine
  const picc = req?.query?.picc;
  const cmac = req?.query?.cmac;
  if (picc || cmac) {
    const tapValidation = await validateNtag424Tap({ tagId: terminalId, picc, cmac });
    if (!tapValidation.valid) {
      console.warn(`[NTAG424 Tap Rejection]: ${tapValidation.error} on tag ${terminalId}`);
      return res.redirect(`/standby.html?terminalId=${terminalId}&error=invalid_tap&reason=${encodeURIComponent(tapValidation.error)}`);
    }
    console.log(`[NTAG424 Valid Tap]: Verified counter #${tapValidation.counter} on tag ${terminalId} (${tapValidation.mode})`);
  }

  try {
    const now = new Date();

    // Lazy cleanup: transition expired open orders on this terminal to EXPIRED
    await prisma.order.updateMany({
      where: {
        terminalId,
        status: { in: ['CREATED', 'QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'] },
        quoteExpiresAt: { lte: now }
      },
      data: { status: 'EXPIRED' }
    });

    const baseWhere = {
      terminalId,
      quoteExpiresAt: { gt: now }
    };

    if (merchantId) {
      const m = await prisma.merchant.findFirst({
        where: {
          OR: [
            { id: merchantId },
            { tradingName: { equals: merchantId, mode: 'insensitive' } }
          ]
        }
      });
      if (m) baseWhere.merchantId = m.id;
    }

    // 🔒 ATOMIC FIRST-TAP LOCK: Exactly one concurrent tap can transition status
    const claimResult = await prisma.order.updateMany({
      where: {
        ...baseWhere,
        status: { in: ['CREATED', 'QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'] }
      },
      data: { status: 'CUSTOMER_DETECTED' }
    });

    if (claimResult.count > 0) {
      const freshOrder = await prisma.order.findFirst({
        where: {
          ...baseWhere,
          status: 'CUSTOMER_DETECTED'
        },
        orderBy: { createdAt: 'desc' }
      });

      if (freshOrder) {
        const sessionData = {
          orderId: freshOrder.id,
          state: 'CLAIMED',
          merchantId: freshOrder.merchantId,
          terminalId
        };
        terminalSessions.set(terminalId, sessionData);
        terminalSessions.set(`${freshOrder.merchantId}:${terminalId}`, sessionData);

        console.log(`[Tag Session Claimed]: Tag ${terminalId} locked by customer tap for order ${freshOrder.orderNumber}`);
        return res.redirect(`/pay.html?orderId=${freshOrder.id}&via=nfc&terminal=${terminalId}`);
      }
    }

    // Tier 2: If customer already initiated checkout on this active bill (or camera pre-fetched the link):
    const activeOrder = await prisma.order.findFirst({
      where: {
        ...baseWhere,
        status: { in: ['CUSTOMER_DETECTED', 'AWAITING_APPROVAL'] }
      },
      orderBy: { createdAt: 'desc' }
    });

    if (activeOrder) {
      console.log(`[Tag Active Session]: Resuming checkout for order ${activeOrder.orderNumber} on terminal ${terminalId}`);
      return res.redirect(`/pay.html?orderId=${activeOrder.id}&via=nfc&terminal=${terminalId}`);
    }

    // Tier 3: In-flight blockchain broadcast lock
    const inFlightOrder = await prisma.order.findFirst({
      where: {
        ...baseWhere,
        status: { in: ['SUBMITTED', 'CONFIRMING'] }
      },
      orderBy: { createdAt: 'desc' }
    });

    if (inFlightOrder) {
      return res.redirect(`/standby.html?terminalId=${terminalId}&status=claimed&message=${encodeURIComponent('Payment is currently confirming on-chain. Please wait a moment.')}&via=nfc`);
    }

    // Tier 4: IDLE state -> standby page ($0.00 / Nothing to pay)
    // Tapping while in IDLE state does nothing and charges $0
    return res.redirect(`/standby.html?terminalId=${terminalId}&status=idle&via=nfc`);
  } catch (err) {
    return res.redirect(`/standby.html?terminalId=${terminalId || 'POS_001'}&error=lookup`);
  }
}

// Multi-counter ultra-short NFC routes (/c/... for ultra-short, /t/... and /m/... aliases)
app.get('/c/:terminalId', (req, res) => resolveNfcTap(null, req.params.terminalId, req, res));
app.get('/c/:merchantId/:terminalId', (req, res) => resolveNfcTap(req.params.merchantId, req.params.terminalId, req, res));
app.get('/t/:terminalId', (req, res) => resolveNfcTap(null, req.params.terminalId, req, res));
app.get('/t/:merchantId/:terminalId', (req, res) => resolveNfcTap(req.params.merchantId, req.params.terminalId, req, res));
app.get('/m/:merchantId/:terminalId', (req, res) => resolveNfcTap(req.params.merchantId, req.params.terminalId, req, res));
app.get('/api/tap/:terminalId', (req, res) => resolveNfcTap(null, req.params.terminalId, req, res));
app.get('/api/tap/:merchantId/:terminalId', (req, res) => resolveNfcTap(req.params.merchantId, req.params.terminalId, req, res));

app.get('/m/:identifier', async (req, res) => {
  const id = req.params.identifier;
  if (id && (id.startsWith('POS_') || id.startsWith('DY-') || id.startsWith('TERM_') || ['1', '2', '3', '4', 'c1', 'c2', 'c3'].includes(id.toLowerCase()))) {
    return resolveNfcTap(null, id, res);
  }
  return resolveNfcTap(id, null, res);
});

// Real-time active terminal session query for standby.html polling & UI syncing
async function getActiveTerminalSession(merchantParam, terminalParam, res) {
  let merchantId = merchantParam;
  let rawTid = terminalParam || merchantParam || 'POS_001';
  let terminalId = normalizeTerminalId(rawTid);

  try {
    const now = new Date();
    const where = {
      terminalId,
      status: { in: ['QUOTED', 'CUSTOMER_DETECTED', 'AWAITING_APPROVAL', 'SUBMITTED', 'CONFIRMING'] },
      quoteExpiresAt: { gt: now }
    };

    let matchedMerchant = null;
    if (merchantId) {
      matchedMerchant = await prisma.merchant.findFirst({
        where: {
          OR: [
            { id: merchantId },
            { tradingName: { equals: merchantId, mode: 'insensitive' } }
          ]
        }
      });
      if (matchedMerchant) where.merchantId = matchedMerchant.id;
    }

    const activeOrder = await prisma.order.findFirst({
      where,
      include: {
        merchant: {
          select: {
            id: true,
            tradingName: true,
            legalName: true
          }
        }
      },
      orderBy: { createdAt: 'desc' }
    });

    if (activeOrder) {
      let sessionState = 'ARMED';
      if (['CUSTOMER_DETECTED', 'AWAITING_APPROVAL'].includes(activeOrder.status)) {
        sessionState = 'CLAIMED';
      } else if (['SUBMITTED', 'CONFIRMING'].includes(activeOrder.status)) {
        sessionState = 'SIGNED';
      } else if (['PAID', 'SETTLED', 'RECEIPT_READY'].includes(activeOrder.status)) {
        sessionState = 'SETTLED';
      }

      return res.json({
        hasOrder: true,
        orderId: activeOrder.id,
        orderNumber: activeOrder.orderNumber,
        amountAUD: activeOrder.totalAUD.toString(),
        tokenSymbol: activeOrder.tokenSymbol,
        quoteExpiresAt: activeOrder.quoteExpiresAt,
        merchantName: activeOrder.merchant?.tradingName || activeOrder.merchant?.legalName || MERCHANT.name,
        merchantId: activeOrder.merchantId,
        terminalId,
        sessionState,
        status: activeOrder.status
      });
    }

    const defaultMerchant = matchedMerchant || await prisma.merchant.findFirst({ orderBy: { updatedAt: 'desc' } });
    return res.json({
      hasOrder: false,
      terminalId,
      merchantId: defaultMerchant?.id || merchantId || 'MERCHANT_123',
      merchantName: defaultMerchant?.tradingName || defaultMerchant?.legalName || MERCHANT.name,
      sessionState: 'IDLE'
    });
  } catch (e) {
    return res.status(500).json({ hasOrder: false, error: e.message });
  }
}

app.get('/api/terminals/:merchantId/:terminalId/active-session', (req, res) => getActiveTerminalSession(req.params.merchantId, req.params.terminalId, res));
app.get('/api/terminals/:terminalId/active-session', (req, res) => getActiveTerminalSession(null, req.params.terminalId, res));
app.get('/api/c/:terminalId/active-session', (req, res) => getActiveTerminalSession(null, req.params.terminalId, res));

app.get('/health', (req, res) => res.json({ ok: true, timestamp: Date.now(), database: 'PostgreSQL 14' }));

// Multer errors (file too large, wrong type) occur in middleware BEFORE a
// route handler's own try/catch runs, and are passed to next(err). With no
// 4-argument error handler registered anywhere, those fell through to
// Express's default handler, which renders an HTML page including a stack
// trace outside production mode. This catches them (and any other next(err))
// and returns clean JSON instead.
app.use((err, req, res, next) => {
  if (res.headersSent) return next(err);
  const status = err.status || (err.message?.includes('INVALID_FILE_TYPE') ? 400 : 500);
  console.error('[Unhandled Route Error]:', err.message);
  res.status(status).json({ error: 'REQUEST_FAILED', message: err.message });
});

const HOST = '0.0.0.0';
const server = http.createServer(app);

// Mount persistent WebSocket device gateway
terminalGateway.initialize(server);

// Start server and connect database
connectDB().then(async () => {
  // Ensure default countertop terminals are registered
  try {
    const defaultMerchant = await prisma.merchant.findFirst({ orderBy: { createdAt: 'asc' } });
    if (defaultMerchant) {
      for (const tid of ['POS_001', 'POS_002', 'POS_003', 'DY-009']) {
        await prisma.terminal.upsert({
          where: { terminalId: tid },
          update: { merchantId: defaultMerchant.id, lastSeenAt: new Date() },
          create: {
            merchantId: defaultMerchant.id,
            terminalId: tid,
            serialNumber: `SN-${tid}`,
            status: 'READY',
            pairedAt: new Date()
          }
        });
      }
    }
  } catch (e) {
    // Non-fatal
  }

  // Tap and pay: refuse to start on a wrong DYNK mint; otherwise it reports
  // what is missing and stays off until configured.
  try {
    await initTapPay();
  } catch (e) {
    console.error(`[tappay] FATAL ${e.message}`);
    process.exit(1);
  }
  const retryTapPay = setInterval(async () => {
    if (tapPay.ready || tapPay.reason !== 'RPC_UNREACHABLE') return clearInterval(retryTapPay);
    await initTapPay().catch((e) => { console.error(`[tappay] FATAL ${e.message}`); process.exit(1); });
    if (tapPay.ready) resumeInFlight();
  }, 60_000);
  resumeInFlight();
  setInterval(() => sweepAbandoned().catch((e) => console.warn('[tappay] sweep:', e.message)), 60_000);
  setInterval(() => scanDuplicates().catch((e) => console.warn('[tappay] duplicates:', e.message)), 60_000);
  setInterval(() => watchWebPayments().catch((e) => console.warn('[tappay] web payments:', e.message)), 4_000);
  // Table bills: mark tables paid and re-quote lapsed price holds.
  setInterval(() => sweepTables().catch((e) => console.warn('[tables] sweep:', e.message)), 3_000);
  checkSponsorBalance();
  setInterval(() => checkSponsorBalance(), 5 * 60_000);
  // USDC prices the platform fee on every payment; keep it warm so no payment waits on CoinGecko.
  startPriceRefresh(['USDC', 'SOL']);

  server.listen(PORT, HOST, () => {
    console.log(`[DYNKLE POS] Production server listening on http://${HOST}:${PORT}`);
    console.log(`[DYNKLE POS] Terminal UI: http://localhost:${PORT}/index.html`);

    // Start Automated Non-Custodial USDC Auto-Swap Keeper
    autoSwapKeeper.startBackgroundKeeper(60000);

    // Active Background Blockchain & 90s Expiry Monitor: Polls every 3s
    setInterval(async () => {
      try {
        const now = Date.now();
        // Sweep every state a customer can be stranded in, not just QUOTED.
        // Orders abandoned at CUSTOMER_DETECTED/AWAITING_APPROVAL previously sat
        // there forever and never reached EXPIRED.
        const activeOrders = await prisma.order.findMany({
          where: { status: { in: NON_TERMINAL_STATUSES } },
          take: 50,
          orderBy: { createdAt: 'desc' }
        });

        // One lookup for every terminal involved, instead of one query per
        // order, to check which registers have gone dark mid-sale.
        const terminalIds = [...new Set(activeOrders.map(o => o.terminalId).filter(Boolean))];
        const terminals = terminalIds.length
          ? await prisma.terminal.findMany({ where: { terminalId: { in: terminalIds } } })
          : [];
        const terminalById = new Map(terminals.map(t => [t.terminalId, t]));

        for (const ord of activeOrders) {
          // A customer can already be on pay.html for a register that has
          // since gone offline (missed heartbeats). Left unchecked they'd sit
          // there until the full 180s quote expiry with no explanation.
          const terminal = terminalById.get(ord.terminalId);
          const heartbeatAge = terminal?.lastSeenAt ? now - new Date(terminal.lastSeenAt).getTime() : Infinity;
          if (terminal?.status === 'OFFLINE' && heartbeatAge > TERMINAL_OFFLINE_GRACE_MS) {
            await prisma.order.update({
              where: { id: ord.id },
              data: { status: 'CANCELLED' }
            });
            terminalSessions.delete(ord.terminalId);
            terminalSessions.delete(`${ord.merchantId}:${ord.terminalId}`);
            console.warn(`[Terminal Offline] Order ${ord.orderNumber} cancelled — terminal ${ord.terminalId} unreachable for ${Math.round(heartbeatAge / 1000)}s.`);
            continue;
          }

          // Check on-chain payment for any active order that is not expired
          if (now <= new Date(ord.quoteExpiresAt).getTime()) {
            try {
              const settled = await checkSolanaPayment(ord);
              if (settled) {
                terminalSessions.delete(ord.terminalId);
                terminalSessions.delete(`${ord.merchantId}:${ord.terminalId}`);
                continue;
              }
            } catch (e) {}
          }

          // 2. Check 180s (3-min) expiry only if not settled on-chain
          if (now > new Date(ord.quoteExpiresAt).getTime()) {
            await prisma.order.update({
              where: { id: ord.id },
              data: { status: 'EXPIRED' }
            });
            terminalSessions.delete(ord.terminalId);
            terminalSessions.delete(`${ord.merchantId}:${ord.terminalId}`);
            terminalGateway.disarm(ord.terminalId).catch(() => {});
            continue;
          }
        }

        // Payments that were submitted but never confirmed. Keep checking the
        // chain, and only give up once well past the point a retry is sensible.
        const inFlight = await prisma.order.findMany({
          where: { status: { in: IN_FLIGHT_STATUSES } },
          take: 50,
          orderBy: { createdAt: 'desc' }
        });

        for (const ord of inFlight) {
          try {
            const settled = await checkSolanaPayment(ord);
            if (settled) {
              terminalSessions.delete(ord.terminalId);
              terminalSessions.delete(`${ord.merchantId}:${ord.terminalId}`);
              continue;
            }
          } catch (e) {}

          if (now - new Date(ord.createdAt).getTime() > IN_FLIGHT_GRACE_MS) {
            await prisma.order.update({
              where: { id: ord.id },
              data: { status: 'PAYMENT_FAILED' }
            });
            terminalSessions.delete(ord.terminalId);
            terminalSessions.delete(`${ord.merchantId}:${ord.terminalId}`);
            terminalGateway.disarm(ord.terminalId).catch(() => {});
            console.warn(`[Stuck Payment] Order ${ord.orderNumber} never confirmed; marked PAYMENT_FAILED for manual review.`);
          }
        }
      } catch (err) {
        // Keep loop running smoothly
      }
    }, 5000);
  });
}).catch((err) => {
  console.error('[Fatal Startup Error]:', err);
  process.exit(1);
});
