// Counter devices: dashboard management + the device API used by the Dynkle
// terminal app (dynkle-terminal-android). Mounted at /api/terminals.
//
// Dashboard  GET    /devices                  devices + counters for this merchant
//            POST   /pairing-codes            { terminalId | newCounterLabel, label } -> code + QR
//            GET    /pairing-codes/:id        PENDING | PAIRED | EXPIRED (modal polls this)
//            PATCH  /devices/:id              { label?, terminalId? }
//            POST   /devices/:id/revoke
// Device     POST   /pair                     { code, publicKey, keyAlgorithm, deviceInfo }
//            POST   /auth/challenge           { deviceId }
//            POST   /auth/token               { deviceId, nonce, signature }
//            GET    /me/active-order
//            POST   /me/orders                { totalCents, tipCents, currency }
//            POST   /me/orders/:id/cancel
//            GET    /me/orders?limit=
//            POST   /me/staff/verify          { pin }
//            GET    /me/app-update
//            POST   /me/logs
//            POST   /me/unpair
//            GET    /me/catalog               products + categories for the device register
//            POST   /me/products              { name, priceCents, category, pin } (cashier PIN)
import { Router } from 'express';
import crypto from 'crypto';
import prisma from '../db.js';
import { PORT } from '../config.js';
import { getActiveMerchant } from '../routes/merchant.js';
import { deviceStore, formatPairingCode } from './deviceStore.js';
import {
  signDeviceToken, requireDevice, verifyDeviceSignature, isValidPublicKey,
  reachableBaseUrl, DEVICE_TOKEN_TTL_SECONDS,
} from './deviceAuth.js';
import { deviceHub, deviceStatus } from './deviceHub.js';
import { priceCart, variantsOf, CartPricingError } from './pricing.js';

const router = Router();
const fail = (res, status, error, message) => res.status(status).json({ error, message });
const cents = (decimal) => Math.round(parseFloat(decimal?.toString() || '0') * 100);
const OPEN_DB_STATUSES = ['CREATED', 'QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER', 'CUSTOMER_DETECTED', 'AWAITING_APPROVAL', 'SUBMITTED', 'CONFIRMING'];

// ── Dashboard ─────────────────────────────────────────────────────────

async function countersFor(merchantId) {
  return prisma.terminal.findMany({ where: { merchantId }, orderBy: { terminalId: 'asc' } });
}

function deviceView(d, counters) {
  const counter = counters.find((c) => c.terminalId === d.terminalId);
  return {
    id: d.id,
    label: d.label,
    model: d.model || 'SZFP FP9810',
    terminalId: d.terminalId,
    terminalCode: d.terminalId,
    counterLabel: counter?.label || d.terminalId,
    counter: counter?.label || d.terminalId,
    status: d.status,
    serialNumber: d.serialNumber || null,
    online: d.status === 'ACTIVE' && deviceHub.isDeviceOnline(d.id),
    batteryPct: d.batteryPct,
    network: d.network,
    appVersion: d.appVersion,
    osVersion: d.osVersion,
    pairedAt: d.pairedAt,
    lastSeenAt: d.lastSeenAt,
    revokedReason: d.revokedReason || null,
    revokedAt: d.revokedAt || null,
  };
}

router.get('/devices', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'No merchant found.');
  const counters = await countersFor(merchant.id);
  const devices = deviceStore.list(merchant.id)
    .sort((a, b) => (a.status === b.status ? String(b.pairedAt).localeCompare(String(a.pairedAt)) : a.status === 'ACTIVE' ? -1 : 1))
    .map((d) => deviceView(d, counters));
  res.json({
    merchantId: merchant.id,
    devices,
    counters: counters.map((c) => {
      const device = deviceStore.activeForTerminal(c.terminalId);
      return { terminalId: c.terminalId, label: c.label, deviceId: device?.id || null, deviceLabel: device?.label || null, deviceOnline: !!device && deviceHub.isDeviceOnline(device.id) };
    }),
  });
});

async function nextCounterId(merchantId) {
  const all = await prisma.terminal.findMany({ select: { terminalId: true } });
  const used = new Set(all.map((t) => t.terminalId));
  for (let n = 1; n < 1000; n += 1) {
    const id = `POS_${String(n).padStart(3, '0')}`;
    if (!used.has(id)) return id;
  }
  return `POS_${crypto.randomBytes(2).toString('hex').toUpperCase()}`;
}

router.post('/counters', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'No merchant found.');
  const label = String(req.body?.label || '').trim().slice(0, 60);
  if (!label) return fail(res, 400, 'LABEL_REQUIRED', 'Please provide a counter name.');
  const tid = await nextCounterId(merchant.id);
  const counter = await prisma.terminal.create({
    data: {
      merchantId: merchant.id,
      terminalId: tid,
      label,
      serialNumber: `SN-${tid}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
      status: 'UNPAIRED',
    },
  });
  deviceHub.broadcast(merchant.id, { type: 'COUNTER_CREATED', terminalId: counter.terminalId });
  res.status(201).json({ counter: { terminalId: counter.terminalId, label: counter.label, deviceId: null, deviceLabel: null, deviceOnline: false } });
});

router.patch('/counters/:terminalId', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'No merchant found.');
  const label = String(req.body?.label || '').trim().slice(0, 60);
  if (!label) return fail(res, 400, 'LABEL_REQUIRED', 'Please provide a counter name.');
  const counter = await prisma.terminal.findFirst({ where: { terminalId: req.params.terminalId, merchantId: merchant.id } });
  if (!counter) return fail(res, 404, 'COUNTER_NOT_FOUND', 'Counter not found.');
  const updated = await prisma.terminal.update({
    where: { id: counter.id },
    data: { label },
  });
  const device = deviceStore.activeForTerminal(counter.terminalId);
  if (device) await deviceHub.sendConfig(device);
  deviceHub.broadcast(merchant.id, { type: 'COUNTER_UPDATED', terminalId: counter.terminalId });
  res.json({ counter: { terminalId: updated.terminalId, label: updated.label } });
});

router.delete('/counters/:terminalId', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'No merchant found.');
  const counter = await prisma.terminal.findFirst({ where: { terminalId: req.params.terminalId, merchantId: merchant.id } });
  if (!counter) return fail(res, 404, 'COUNTER_NOT_FOUND', 'Counter not found.');
  const device = deviceStore.activeForTerminal(counter.terminalId);
  if (device) return fail(res, 409, 'COUNTER_HAS_DEVICE', 'Cannot delete a counter with an active device. Unpair or move the device first.');
  await prisma.terminal.delete({ where: { id: counter.id } });
  deviceHub.broadcast(merchant.id, { type: 'COUNTER_DELETED', terminalId: counter.terminalId });
  res.json({ success: true, terminalId: counter.terminalId });
});

router.post('/pairing-codes', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  if (!merchant) return fail(res, 404, 'MERCHANT_NOT_FOUND', 'No merchant found.');
  const { terminalId, newCounterLabel } = req.body || {};
  const label = String(req.body?.label || '').trim().slice(0, 60) || null;

  let counter;
  if (newCounterLabel && String(newCounterLabel).trim()) {
    const tid = await nextCounterId(merchant.id);
    counter = await prisma.terminal.create({
      data: {
        merchantId: merchant.id,
        terminalId: tid,
        label: String(newCounterLabel).trim().slice(0, 60),
        serialNumber: `SN-${tid}-${crypto.randomBytes(3).toString('hex').toUpperCase()}`,
        status: 'UNPAIRED',
      },
    });
  } else {
    counter = terminalId
      ? await prisma.terminal.findFirst({ where: { terminalId: String(terminalId), merchantId: merchant.id } })
      : (await countersFor(merchant.id))[0];
    if (!counter) return fail(res, 400, 'COUNTER_REQUIRED', 'Choose a counter for this device.');
  }

  const replaces = deviceStore.activeForTerminal(counter.terminalId);
  if (replaces && !req.body?.replace) {
    return fail(res, 409, 'COUNTER_HAS_DEVICE', `${counter.label} already has an active device (${replaces.label}). Each counter can have only 1 device.`);
  }

  const pairing = deviceStore.createPairing({ merchantId: merchant.id, terminalId: counter.terminalId, label });
  const endpoint = reachableBaseUrl(req);
  const code = formatPairingCode(pairing.code);
  res.status(201).json({
    pairingId: pairing.id,
    code,
    expiresAt: new Date(pairing.expiresAt).toISOString(),
    endpoint,
    counter: { terminalId: counter.terminalId, label: counter.label },
    replacesDevice: replaces ? { id: replaces.id, label: replaces.label } : null,
    // The terminal app's QrPairingPayload, kept small and ASCII-only (\u escapes)
    // so it fits a low-density QR the FP9810's 0.3 MP camera can read.
    qrPayload: JSON.stringify({
      v: 1,
      endpoint,
      code,
      rawCode: pairing.code,
      terminalId: counter.terminalId,
      counter: counter.label,
    }).replace(/[\u0080-\uffff]/g, (c) => `\\u${c.charCodeAt(0).toString(16).padStart(4, '0')}`),
  });
});

router.get('/pairing-codes/:id', async (req, res) => {
  const pairing = deviceStore.getPairing(req.params.id);
  if (!pairing) return fail(res, 404, 'NOT_FOUND', 'Pairing code not found.');
  if (pairing.deviceId) {
    const counters = await countersFor(pairing.merchantId);
    const device = deviceStore.get(pairing.deviceId);
    return res.json({ status: 'PAIRED', device: device ? deviceView(device, counters) : null });
  }
  res.json({ status: pairing.expiresAt > Date.now() ? 'PENDING' : 'EXPIRED', expiresAt: new Date(pairing.expiresAt).toISOString() });
});

router.patch('/devices/:id', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  const device = deviceStore.get(req.params.id);
  if (!merchant || !device || device.merchantId !== merchant.id) return fail(res, 404, 'NOT_FOUND', 'Device not found.');
  if (device.status !== 'ACTIVE') return fail(res, 409, 'DEVICE_REVOKED', 'This device is revoked.');
  const patch = {};
  if (typeof req.body?.label === 'string' && req.body.label.trim()) patch.label = req.body.label.trim().slice(0, 60);
  if (typeof req.body?.terminalId === 'string' && req.body.terminalId !== device.terminalId) {
    const counter = await prisma.terminal.findFirst({ where: { terminalId: req.body.terminalId, merchantId: merchant.id } });
    if (!counter) return fail(res, 400, 'COUNTER_NOT_FOUND', 'That counter does not exist.');
    const occupant = deviceStore.activeForTerminal(counter.terminalId);
    if (occupant) return fail(res, 409, 'COUNTER_HAS_DEVICE', `${counter.label} already has a device (${occupant.label}). Move or revoke that device first.`);
    patch.terminalId = counter.terminalId;
  }
  const updated = deviceStore.update(device.id, patch);
  // The device reconnects to pick up its new counter identity in CONFIG.
  if (patch.terminalId) deviceHub.sockets.get(device.id)?.close(4012, 'Counter changed');
  else await deviceHub.sendConfig(updated);
  deviceHub.broadcast(merchant.id, { type: 'DEVICE_STATUS', deviceId: device.id });
  res.json({ device: deviceView(updated, await countersFor(merchant.id)) });
});

function revoke(device, reason) {
  deviceStore.update(device.id, { status: 'REVOKED', revokedAt: new Date().toISOString(), revokedReason: reason });
  deviceHub.disconnectDevice(device.id, 4011, reason);
  deviceHub.setCounterStatus(device, 'UNPAIRED').catch(() => {});
}

router.post('/devices/:id/revoke', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  const device = deviceStore.get(req.params.id);
  if (!merchant || !device || device.merchantId !== merchant.id) return fail(res, 404, 'NOT_FOUND', 'Device not found.');
  if (device.status === 'ACTIVE') revoke(device, 'Revoked from the dashboard');
  deviceHub.broadcast(merchant.id, { type: 'DEVICE_STATUS', deviceId: device.id });
  res.json({ device: deviceView(deviceStore.get(device.id), await countersFor(merchant.id)) });
});

router.post('/devices/:id/identify', async (req, res) => {
  const merchant = await getActiveMerchant(req);
  const device = deviceStore.get(req.params.id);
  if (!merchant || !device || device.merchantId !== merchant.id) return fail(res, 404, 'NOT_FOUND', 'Device not found.');
  if (device.status !== 'ACTIVE') return fail(res, 409, 'DEVICE_REVOKED', 'This device is revoked.');
  const sent = deviceHub.identifyDevice(device.id);
  if (!sent) return fail(res, 400, 'DEVICE_OFFLINE', 'Terminal is not currently connected.');
  res.json({ success: true, message: `Identify ping sent to ${device.label}` });
});

// ── Device: pairing and auth ──────────────────────────────────────────

router.post('/pair', async (req, res) => {
  const { code, publicKey, deviceInfo } = req.body || {};
  if (!code || !publicKey) return fail(res, 400, 'VALIDATION_ERROR', 'Pairing code and device key are required.');
  if (!isValidPublicKey(publicKey)) return fail(res, 400, 'INVALID_KEY', 'The device key is not a valid EC public key.');
  const pairing = deviceStore.claimPairing(code);
  if (!pairing) return fail(res, 400, 'INVALID_PAIRING_CODE', 'Pairing code is invalid or has expired.');

  const merchant = await prisma.merchant.findUnique({ where: { id: pairing.merchantId } });
  const counter = await prisma.terminal.findFirst({ where: { terminalId: pairing.terminalId, merchantId: pairing.merchantId } });
  if (!merchant || !counter) return fail(res, 400, 'INVALID_PAIRING_CODE', 'The counter for this code no longer exists.');

  // One device per counter: the new device takes over.
  const previous = deviceStore.activeForTerminal(counter.terminalId);
  if (previous) revoke(previous, 'Replaced by a newer device');

  const info = deviceInfo || {};
  const device = deviceStore.create({
    merchantId: merchant.id,
    terminalId: counter.terminalId,
    label: pairing.label || `${counter.label} device`,
    publicKey,
    model: info.model || 'FP9810',
    serialNumber: info.serialNumber || null,
    appVersion: info.appVersion || null,
    osVersion: info.osVersion || null,
  });
  pairing.deviceId = device.id;
  await deviceHub.setCounterStatus(device, 'CONNECTED');
  deviceHub.broadcast(merchant.id, { type: 'DEVICE_PAIRED', deviceId: device.id, pairingId: pairing.id });

  res.status(201).json({
    deviceId: device.id,
    deviceLabel: device.label,
    serialNumber: device.serialNumber,
    merchantId: merchant.id,
    terminalId: counter.terminalId,
    terminalCode: counter.terminalId,
    counterLabel: counter.label,
    merchantName: merchant.tradingName || merchant.legalName || 'Dynkle merchant',
    currency: 'AUD',
    token: signDeviceToken(device),
    refreshToken: crypto.randomBytes(32).toString('hex'), // unused by the app; auth renews by challenge
  });
});

router.post('/auth/challenge', (req, res) => {
  const device = deviceStore.get(req.body?.deviceId);
  if (!device) return fail(res, 404, 'DEVICE_NOT_FOUND', 'Device not found.');
  if (device.status !== 'ACTIVE') return fail(res, 401, 'DEVICE_REVOKED', 'This device has been revoked.');
  const { nonce, expiresAt } = deviceStore.createChallenge(device.id);
  res.json({ nonce, expiresAt: new Date(expiresAt).toISOString() });
});

router.post('/auth/token', (req, res) => {
  const { deviceId, nonce, signature } = req.body || {};
  const device = deviceStore.get(deviceId);
  if (!device) return fail(res, 404, 'DEVICE_NOT_FOUND', 'Device not found.');
  if (device.status !== 'ACTIVE') return fail(res, 401, 'DEVICE_REVOKED', 'This device has been revoked.');
  if (!deviceStore.takeChallenge(device.id, nonce)) return fail(res, 401, 'INVALID_CHALLENGE', 'Challenge expired or unknown.');
  if (!verifyDeviceSignature(device.publicKey, nonce, signature)) return fail(res, 401, 'INVALID_SIGNATURE', 'Signature check failed.');
  res.json({ token: signDeviceToken(device), expiresIn: DEVICE_TOKEN_TTL_SECONDS, tokenType: 'Bearer' });
});

// ── Device: sales ─────────────────────────────────────────────────────

async function orderDto(order, req) {
  const base = deviceHub.baseUrlFor(req.device.id) || reachableBaseUrl(req);
  const p = await deviceHub.payloadForOrder(order, base);
  return {
    id: order.id,
    totalCents: p.totalCents,
    currency: 'AUD',
    status: deviceStatus(order.status),
    expiresAt: p.expiresAt,
    ttlSeconds: p.ttlSeconds,
    claimed: order.status === 'CUSTOMER_DETECTED' || order.status === 'AWAITING_APPROVAL',
    paymentUrl: p.paymentUrl,
    acceptedTokens: p.acceptedTokens,
  };
}

async function openOrderFor(device) {
  return prisma.order.findFirst({
    where: { merchantId: device.merchantId, terminalId: device.terminalId, status: { in: OPEN_DB_STATUSES }, quoteExpiresAt: { gt: new Date() } },
    orderBy: { createdAt: 'desc' },
  });
}

/** Calls this server's own order API so device sales follow exactly the register's rules. */
async function internal(path, { method = 'POST', body, merchantId } = {}) {
  const r = await fetch(`http://127.0.0.1:${PORT}${path}`, {
    method,
    headers: { 'Content-Type': 'application/json', 'x-merchant-id': merchantId },
    body: body ? JSON.stringify(body) : undefined,
  });
  const json = await r.json().catch(() => ({}));
  return { ok: r.ok, status: r.status, json };
}

router.get('/me/active-order', requireDevice, async (req, res) => {
  const order = await openOrderFor(req.device);
  if (!order) return res.json({ order: null });
  deviceHub.track(order); // the device is about to show it: watch its real status
  res.json({ order: await orderDto(order, req) });
});

router.post('/me/orders', requireDevice, async (req, res) => {
  const tipCents = Math.max(0, Math.round(Number(req.body?.tipCents) || 0));
  let totalCents = Number(req.body?.totalCents);
  let items = [];

  // Register sale: price every line from the catalog, never from the device.
  if (Array.isArray(req.body?.items) && req.body.items.length) {
    const products = await prisma.product.findMany({ where: { merchantId: req.device.merchantId, active: true } });
    try {
      const priced = priceCart(products, req.body.items);
      totalCents = priced.subtotalCents;
      items = priced.lines.map((l) => ({ name: l.name, price: l.unitCents / 100, quantity: l.qty, qty: l.qty, productId: l.productId }));
    } catch (e) {
      if (e instanceof CartPricingError) return fail(res, 409, e.code, e.message);
      throw e;
    }
    // orders.js bills the item sum when items are present, so the tip travels as a line.
    if (tipCents > 0) items.push({ name: 'Tip', price: tipCents / 100, quantity: 1, qty: 1, isTip: true });
  }

  if (!Number.isInteger(totalCents) || totalCents <= 0) return fail(res, 400, 'INVALID_AMOUNT', 'Enter an amount above zero.');
  const amountAUD = ((totalCents + tipCents) / 100).toFixed(2);
  const created = await internal('/api/orders', {
    merchantId: req.device.merchantId,
    body: { terminalId: req.device.terminalId, amountAUD, merchantId: req.device.merchantId, items },
  });
  if (!created.ok) return res.status(created.status).json({ error: created.json.error || 'CREATE_FAILED', message: created.json.message || 'The order could not be created.' });
  const orderId = created.json.orderId || created.json.order?.id || created.json.id;
  const order = orderId ? await prisma.order.findUnique({ where: { id: orderId } }) : null;
  if (!order) return fail(res, 500, 'CREATE_FAILED', 'The order was not found after creation.');
  const dto = await orderDto(order, req);
  res.status(201).json({ order: { ...dto, baseAmountCents: totalCents, tipCents } });
});

router.post('/me/orders/:id/cancel', requireDevice, async (req, res) => {
  const order = await prisma.order.findUnique({ where: { id: req.params.id } });
  const mine = order && order.merchantId === req.device.merchantId && order.terminalId === req.device.terminalId;
  if (!mine || !OPEN_DB_STATUSES.includes(order.status)) return fail(res, 404, 'NOT_FOUND', 'Order not found.');
  deviceHub.cancelReasons.set(order.id, 'CANCELLED_BY_TERMINAL');
  const r = await internal(`/api/orders/${order.id}/cancel`, { merchantId: req.device.merchantId, body: {} });
  if (!r.ok) {
    deviceHub.cancelReasons.delete(order.id);
    return res.status(r.status).json({ error: r.json.error || 'CANCEL_FAILED', message: r.json.message || 'The order could not be cancelled.' });
  }
  res.json({ success: true, orderId: order.id, status: 'CANCELLED' });
});

router.get('/me/orders', requireDevice, async (req, res) => {
  const limit = Math.min(100, Math.max(1, parseInt(req.query.limit, 10) || 20));
  const orders = await prisma.order.findMany({
    where: { merchantId: req.device.merchantId, terminalId: req.device.terminalId },
    orderBy: { createdAt: 'desc' },
    take: limit,
  });
  res.json({
    orders: orders.map((o) => ({
      id: o.id,
      totalCents: cents(o.totalAUD),
      currency: 'AUD',
      // An open order past its window is no longer payable.
      status: deviceStatus(o.status) === 'OPEN' && new Date(o.quoteExpiresAt) <= new Date() ? 'EXPIRED' : deviceStatus(o.status),
      createdAt: o.createdAt.toISOString(),
    })),
  });
});

// ── Device: register catalog ──────────────────────────────────────────

const cleanCategory = (v) => String(v || '').split('>').map((x) => x.trim()).filter(Boolean).slice(0, 8).join(' > ');

function catalogProduct(p) {
  const meta = p.meta && typeof p.meta === 'object' ? p.meta : {};
  return {
    id: p.id,
    name: p.name,
    category: p.category || 'General',
    priceCents: cents(p.price),
    description: meta.desc || p.description || null,
    icon: typeof meta.icon === 'string' && meta.icon.length <= 4 ? meta.icon : null,
    popular: !!meta.isPopular,
    variants: variantsOf(p),
  };
}

router.get('/me/catalog', requireDevice, async (req, res) => {
  const [merchant, products] = await Promise.all([
    prisma.merchant.findUnique({ where: { id: req.device.merchantId } }),
    prisma.product.findMany({ where: { merchantId: req.device.merchantId, active: true }, orderBy: [{ category: 'asc' }, { name: 'asc' }] }),
  ]);
  const tree = Array.isArray(merchant?.catalogCategories) ? merchant.catalogCategories.map(cleanCategory).filter(Boolean) : [];
  const categories = [...new Set([...tree, ...products.map((p) => cleanCategory(p.category) || 'General')])];
  res.json({ currency: 'AUD', categories, products: products.map(catalogProduct) });
});

// New product from the device register. Same catalog as the website; cashier PIN required.
router.post('/me/products', requireDevice, async (req, res) => {
  const expected = process.env.TERMINAL_STAFF_PIN || '1234';
  if (String(req.body?.pin || '') !== expected) return fail(res, 401, 'INVALID_PIN', 'Incorrect cashier PIN');
  const name = String(req.body?.name || '').trim().slice(0, 80);
  const priceCents = Number(req.body?.priceCents);
  const category = cleanCategory(req.body?.category) || 'General';
  if (!name) return fail(res, 400, 'VALIDATION_ERROR', 'Give the product a name.');
  if (!Number.isInteger(priceCents) || priceCents < 0 || priceCents > 100000000) return fail(res, 400, 'VALIDATION_ERROR', 'Enter a price from $0.00 to $1,000,000.');
  const duplicate = await prisma.product.findFirst({ where: { merchantId: req.device.merchantId, active: true, name: { equals: name, mode: 'insensitive' } } });
  if (duplicate) return fail(res, 409, 'DUPLICATE_PRODUCT', `${duplicate.name} is already in the catalog.`);
  const product = await prisma.product.create({
    data: { merchantId: req.device.merchantId, name, category, price: priceCents / 100, currency: 'AUD', meta: {}, active: true },
  });
  // Keep the website's category tree in step so the new category shows there too.
  const merchant = await prisma.merchant.findUnique({ where: { id: req.device.merchantId } });
  const tree = Array.isArray(merchant?.catalogCategories) ? merchant.catalogCategories : [];
  if (!tree.map(cleanCategory).includes(category)) {
    await prisma.merchant.update({ where: { id: merchant.id }, data: { catalogCategories: [...tree, category] } }).catch(() => {});
  }
  res.status(201).json({ product: catalogProduct(product) });
});

// The device was unpaired from its own Settings: retire it so the dashboard
// doesn't keep showing an offline device on that counter.
router.post('/me/unpair', requireDevice, (req, res) => {
  revoke(req.device, 'Unpaired on the device');
  deviceHub.broadcast(req.device.merchantId, { type: 'DEVICE_STATUS', deviceId: req.device.id });
  res.json({ success: true });
});

// POC: one cashier PIN for every device (TERMINAL_STAFF_PIN, default 1234).
router.post('/me/staff/verify', requireDevice, (req, res) => {
  const expected = process.env.TERMINAL_STAFF_PIN || '1234';
  if (String(req.body?.pin || '') !== expected) return fail(res, 401, 'INVALID_PIN', 'Incorrect cashier PIN');
  res.json({ valid: true });
});

router.get('/me/app-update', requireDevice, (req, res) => {
  const current = req.device.appVersion || '1.0.0';
  res.json({ hasUpdate: false, currentVersion: current, latestVersion: current, mandatory: false, downloadUrl: null, sha256: null, releaseNotes: null });
});

router.post('/me/logs', requireDevice, (req, res) => {
  const count = Array.isArray(req.body?.logs) ? req.body.logs.length : 0;
  deviceStore.touch(req.device.id);
  res.json({ received: true, count });
});

export default router;
