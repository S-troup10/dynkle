// Device authentication for the Dynkle terminal app (protocol v2):
// EC P-256 key generated in the device keystore at pairing, then a signed
// challenge -> short-lived device JWT for REST and the /ws/terminal socket.
import crypto from 'crypto';
import os from 'os';
import jwt from 'jsonwebtoken';
import { JWT_SECRET, PORT, PUBLIC_BASE_URL } from '../config.js';
import { deviceStore } from './deviceStore.js';

export const DEVICE_TOKEN_TTL_SECONDS = 15 * 60;

export function signDeviceToken(device) {
  return jwt.sign(
    { typ: 'device', deviceId: device.id, merchantId: device.merchantId, terminalId: device.terminalId },
    JWT_SECRET,
    { expiresIn: DEVICE_TOKEN_TTL_SECONDS }
  );
}

/** Returns the device for a valid device token, or throws with an HTTP-ish code. */
export function deviceFromToken(token) {
  let payload;
  try {
    payload = jwt.verify(token, JWT_SECRET);
  } catch (err) {
    const e = new Error(err.name === 'TokenExpiredError' ? 'Device token expired.' : 'Invalid device token.');
    e.status = 401;
    e.code = err.name === 'TokenExpiredError' ? 'TOKEN_EXPIRED' : 'INVALID_TOKEN';
    throw e;
  }
  if (payload.typ !== 'device') {
    const e = new Error('Expected a device token.');
    e.status = 401; e.code = 'INVALID_TOKEN';
    throw e;
  }
  const device = deviceStore.get(payload.deviceId);
  if (!device) {
    const e = new Error('Device not found.'); e.status = 401; e.code = 'DEVICE_NOT_FOUND';
    throw e;
  }
  if (device.status !== 'ACTIVE') {
    const e = new Error('This device has been revoked.'); e.status = 401; e.code = 'DEVICE_REVOKED';
    throw e;
  }
  return device;
}

/** Express middleware for /api/terminals/me/* */
export function requireDevice(req, res, next) {
  const header = req.headers.authorization || '';
  if (!header.startsWith('Bearer ')) {
    return res.status(401).json({ error: 'UNAUTHORIZED', message: 'Missing device token.' });
  }
  try {
    req.device = deviceFromToken(header.slice(7));
    next();
  } catch (e) {
    res.status(e.status || 401).json({ error: e.code || 'UNAUTHORIZED', message: e.message });
  }
}

/** Verifies an Android keystore SHA256withECDSA (DER) signature over the nonce. */
export function verifyDeviceSignature(publicKeyB64, nonce, signatureB64) {
  try {
    const key = crypto.createPublicKey({ key: Buffer.from(publicKeyB64, 'base64'), format: 'der', type: 'spki' });
    return crypto.verify('sha256', Buffer.from(nonce, 'utf8'), key, Buffer.from(signatureB64, 'base64'));
  } catch {
    return false;
  }
}

export function isValidPublicKey(publicKeyB64) {
  try {
    const key = crypto.createPublicKey({ key: Buffer.from(publicKeyB64, 'base64'), format: 'der', type: 'spki' });
    return key.asymmetricKeyType === 'ec';
  } catch {
    return false;
  }
}

function lanAddress() {
  const candidates = [];
  for (const list of Object.values(os.networkInterfaces())) {
    for (const a of list || []) {
      if (a.family === 'IPv4' && !a.internal) candidates.push(a.address);
    }
  }
  const privateRange = (ip) => /^(10\.|192\.168\.|172\.(1[6-9]|2\d|3[01])\.)/.test(ip);
  return candidates.find(privateRange) || candidates[0] || null;
}

/**
 * The base URL a device (and a customer's phone) can actually reach.
 * A dashboard opened on localhost, or an emulator's 10.0.2.2, is not reachable
 * from a real device, so those fall back to this machine's LAN address.
 * DEVICE_BASE_URL overrides everything (e.g. a public tunnel).
 */
export function reachableBaseUrl(req) {
  if (process.env.DEVICE_BASE_URL) return process.env.DEVICE_BASE_URL.replace(/\/$/, '');
  const host = String(req.headers['x-forwarded-host'] || req.headers.host || '');
  const proto = String(req.headers['x-forwarded-proto'] || (req.socket?.encrypted ? 'https' : 'http')).split(',')[0];
  const hostname = host.replace(/:\d+$/, '').replace(/^\[|\]$/g, '');
  const port = (host.match(/:(\d+)$/) || [])[1] || PORT;
  const unreachable = !hostname || hostname === 'localhost' || hostname === '::1' || hostname.startsWith('127.') || hostname === '10.0.2.2' || hostname === '0.0.0.0';
  if (!unreachable) return `${proto}://${host}`;
  const ip = lanAddress();
  return ip ? `http://${ip}:${port}` : PUBLIC_BASE_URL.replace(/\/$/, '');
}
