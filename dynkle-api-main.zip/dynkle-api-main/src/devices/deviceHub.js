// Live connections for paired counter devices (Dynkle terminal app, protocol v2)
// and for dashboards watching the Counter devices page.
//
// The register keeps calling terminalGateway.arm/disarm/setSuccess/setError as
// before; the gateway forwards those here, and this hub turns them into v2
// messages for the device bound to that counter. Because not every code path
// that pays, expires or fails an order notifies the gateway, the hub also
// watches the armed order's real status and pushes any change. The device is
// only ever told what the database says.
import WebSocket from 'ws';
import crypto from 'crypto';
import prisma from '../db.js';
import { deviceStore } from './deviceStore.js';
import { deviceFromToken, reachableBaseUrl } from './deviceAuth.js';
import { customerBaseUrl } from '../services/publicUrl.js';

const WATCH_INTERVAL_MS = 3000;

/** Server order status -> the status vocabulary the terminal app understands. */
export function deviceStatus(status) {
  switch (status) {
    case 'PAID': case 'SETTLING': case 'SETTLED': case 'RECEIPT_READY':
    // The customer paid; a failed settlement is a merchant-side problem.
    case 'SETTLEMENT_FAILED':
      return 'PAID';
    case 'SUBMITTED': case 'CONFIRMING':
      return 'PROCESSING';
    case 'EXPIRED': case 'PRICE_MOVED':
      return 'EXPIRED';
    case 'CANCELLED':
      return 'CANCELLED';
    case 'PAYMENT_FAILED':
      return 'FAILED';
    case 'REFUNDED':
      return 'REFUNDED';
    default:
      return 'OPEN'; // CREATED, QUOTED, DEVICE_ARMED, WAITING_FOR_CUSTOMER, CUSTOMER_DETECTED, AWAITING_APPROVAL
  }
}

const FINAL = new Set(['PAID', 'EXPIRED', 'CANCELLED', 'FAILED', 'REFUNDED']);
const CUSTOMER_ENGAGED = new Set(['CUSTOMER_DETECTED', 'AWAITING_APPROVAL']);

const cents = (decimal) => Math.round(parseFloat(decimal?.toString() || '0') * 100);

class DeviceHub {
  constructor() {
    this.sockets = new Map(); // deviceId -> ws
    this.dashboards = new Set(); // ws (with .merchantId)
    this.active = new Map(); // `${merchantId}:${terminalId}` -> { orderId, sent }
    this.pending = new Map(); // deviceId -> last critical message, replayed until ACKed
    this.cancelReasons = new Map(); // orderId -> DISARM reason chosen by whoever cancelled
    this.timer = setInterval(() => this.watchOrders().catch(() => {}), WATCH_INTERVAL_MS);
    this.timer.unref?.();
  }

  // ── Connections ─────────────────────────────────────────────────────

  async attachDevice(ws, req, token) {
    let device;
    try {
      device = deviceFromToken(token);
    } catch (e) {
      ws.close(e.code === 'DEVICE_REVOKED' ? 4011 : 4003, e.message);
      return;
    }
    const prev = this.sockets.get(device.id);
    if (prev && prev !== ws) prev.close(4009, 'Replaced by newer connection');

    ws.deviceId = device.id;
    ws.isAlive = true;
    ws.baseUrl = reachableBaseUrl(req);
    this.sockets.set(device.id, ws);
    deviceStore.touch(device.id);
    await this.setCounterStatus(device, 'READY');

    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('message', (data) => {
      let msg;
      try { msg = JSON.parse(data.toString()); } catch { return; }
      this.onDeviceMessage(ws, msg).catch(() => {});
    });
    ws.on('close', () => {
      if (this.sockets.get(device.id) !== ws) return;
      this.sockets.delete(device.id);
      deviceStore.touch(device.id);
      const fresh = deviceStore.get(device.id);
      if (fresh?.status === 'ACTIVE') this.setCounterStatus(fresh, 'OFFLINE').catch(() => {});
      this.broadcast(device.merchantId, { type: 'DEVICE_OFFLINE', deviceId: device.id });
    });

    await this.sendConfig(device);
    const pending = this.pending.get(device.id);
    if (pending) this.raw(ws, { ...pending, replay: true });
    this.broadcast(device.merchantId, { type: 'DEVICE_ONLINE', deviceId: device.id });
  }

  attachDashboard(ws, merchantId) {
    ws.merchantId = merchantId || null;
    ws.isAlive = true;
    this.dashboards.add(ws);
    ws.on('pong', () => { ws.isAlive = true; });
    ws.on('close', () => this.dashboards.delete(ws));
    this.raw(ws, { type: 'DASHBOARD_READY' });
  }

  heartbeat() {
    for (const ws of [...this.sockets.values(), ...this.dashboards]) {
      if (!ws.isAlive) { ws.terminate(); continue; }
      ws.isAlive = false;
      try { ws.ping(); } catch {}
    }
  }

  isDeviceOnline(deviceId) {
    const ws = this.sockets.get(deviceId);
    return !!(ws && ws.readyState === WebSocket.OPEN);
  }

  /** A counter is online when its paired device is connected. */
  isCounterOnline(terminalId, merchantId) {
    for (const ws of this.sockets.values()) {
      const d = deviceStore.get(ws.deviceId);
      if (d && d.terminalId === terminalId && (!merchantId || d.merchantId === merchantId) && ws.readyState === WebSocket.OPEN) return true;
    }
    return false;
  }

  disconnectDevice(deviceId, code, reason) {
    const ws = this.sockets.get(deviceId);
    if (!ws) return;
    this.send(ws, 'REVOKED', { reason });
    ws.close(code, reason);
  }

  broadcast(merchantId, event) {
    for (const ws of this.dashboards) {
      if (!ws.merchantId || !merchantId || ws.merchantId === merchantId) this.raw(ws, event);
    }
  }

  /** Sends a v2 message to every connected device of a merchant (e.g. TABLES_CHANGED). */
  sendToMerchantDevices(merchantId, type, payload) {
    for (const ws of this.sockets.values()) {
      const d = deviceStore.get(ws.deviceId);
      if (d && d.status === 'ACTIVE' && d.merchantId === merchantId) this.send(ws, type, payload);
    }
  }

  // ── Messages ────────────────────────────────────────────────────────

  raw(ws, msg) {
    if (ws && ws.readyState === WebSocket.OPEN) {
      ws.send(JSON.stringify(msg));
      return true;
    }
    return false;
  }

  send(ws, type, payload) {
    return this.raw(ws, { v: 2, type, id: crypto.randomBytes(8).toString('hex'), ts: Date.now(), payload });
  }

  /** Sends to the device bound to a counter. Critical messages are replayed until ACKed. */
  sendToCounter(merchantId, terminalId, type, payload, { critical = false } = {}) {
    const device = deviceStore.activeForTerminal(terminalId);
    if (!device) return false;
    const msg = { v: 2, type, id: crypto.randomBytes(8).toString('hex'), ts: Date.now(), payload };
    if (critical) this.pending.set(device.id, msg);
    return this.raw(this.sockets.get(device.id), msg);
  }

  async onDeviceMessage(ws, msg) {
    const device = deviceStore.get(ws.deviceId);
    if (!device) return;
    ws.isAlive = true;
    const p = msg.payload || {};
    const telemetry = {};
    if (typeof p.batteryPct === 'number') telemetry.batteryPct = p.batteryPct;
    if (typeof p.network === 'string') telemetry.network = p.network;
    if (typeof p.appVersion === 'string') telemetry.appVersion = p.appVersion;
    if (typeof p.osVersion === 'string') telemetry.osVersion = p.osVersion;

    switch (msg.type) {
      case 'HELLO':
        deviceStore.touch(device.id, telemetry);
        await this.sendConfig(device);
        this.raw(ws, { v: 2, type: 'HELLO_ACK', id: msg.id, ts: Date.now() });
        this.broadcast(device.merchantId, { type: 'DEVICE_STATUS', deviceId: device.id });
        break;
      case 'HEARTBEAT':
        deviceStore.touch(device.id, telemetry);
        this.raw(ws, { v: 2, type: 'HEARTBEAT_ACK', id: msg.id, ts: Date.now() });
        break;
      case 'STATUS':
        deviceStore.touch(device.id);
        this.broadcast(device.merchantId, { type: 'DEVICE_STATUS', deviceId: device.id, state: p.state });
        break;
      case 'ACK':
        this.pending.delete(device.id);
        break;
      default:
        break;
    }
  }

  async sendConfig(device) {
    const ws = this.sockets.get(device.id);
    if (!ws) return;
    const [merchant, terminal, tokens] = await Promise.all([
      prisma.merchant.findUnique({ where: { id: device.merchantId } }).catch(() => null),
      prisma.terminal.findUnique({ where: { terminalId: device.terminalId } }).catch(() => null),
      prisma.acceptedToken.findMany({ where: { merchantId: device.merchantId, enabled: true } }).catch(() => []),
    ]);
    this.send(ws, 'CONFIG', {
      deviceId: device.id,
      deviceLabel: device.label || null,
      serialNumber: device.serialNumber || null,
      merchantName: merchant?.tradingName || merchant?.legalName || null,
      terminalLabel: terminal?.label || null,
      terminalCode: device.terminalId,
      currency: 'AUD',
      tipOptions: [0, 10, 15, 20],
      quickAmounts: [500, 1000, 2000, 5000],
      acceptedTokens: tokens.map((t) => t.tokenSymbol),
      locale: 'en-AU',
    });
  }

  identifyDevice(deviceId) {
    const ws = this.sockets.get(deviceId);
    if (!ws) return false;
    const device = deviceStore.get(deviceId);
    return this.send(ws, 'IDENTIFY', {
      deviceId,
      deviceLabel: device?.label || 'Terminal',
      serialNumber: device?.serialNumber || null,
      terminalCode: device?.terminalId || null,
    });
  }

  // ── Order lifecycle (called by terminalGateway) ─────────────────────

  async payloadForOrder(order, baseUrl) {
    const tokens = await prisma.acceptedToken.findMany({ where: { merchantId: order.merchantId, enabled: true } }).catch(() => []);
    const items = Array.isArray(order.items) ? order.items : [];
    const expiresAt = new Date(order.quoteExpiresAt);
    return {
      orderId: order.id,
      totalCents: cents(order.totalAUD),
      currency: 'AUD',
      expiresAt: expiresAt.toISOString(),
      // Device-clock independent: the app counts down from this.
      ttlSeconds: Math.max(0, Math.round((expiresAt.getTime() - Date.now()) / 1000)),
      // Opened by the customer's phone (QR / NFC), so it must be public, not
      // the LAN address the device itself uses.
      // Tap-and-pay orders carry the signed intent link; others the checkout page.
      paymentUrl: (order.tapPayAmount != null && (await import('../tappay/service.js').then((m) => m.linkForOrder(order.id)).catch(() => null)))
        || `${customerBaseUrl(null, baseUrl)}/pay.html?orderId=${order.id}`,
      acceptedTokens: tokens.length ? tokens.map((t) => t.tokenSymbol) : [order.tokenSymbol].filter(Boolean),
      items: items
        .filter((i) => i && i.name && !i.isTip) // the tip is part of the total, not an item
        .map((i) => ({ name: String(i.name), price: Number(i.price) || null, qty: Number(i.quantity || i.qty) || 1 })),
      note: null,
    };
  }

  baseUrlFor(deviceId) {
    const ws = this.sockets.get(deviceId);
    return ws?.baseUrl || null;
  }

  /** Start watching an order the device is showing (e.g. restored after a reconnect). */
  track(order) {
    const key = `${order.merchantId}:${order.terminalId}`;
    const cur = this.active.get(key);
    if (!cur || cur.orderId !== order.id) this.active.set(key, { orderId: order.id, sent: deviceStatus(order.status), engaged: false });
  }

  async onArm(terminalId, orderId) {
    const order = await prisma.order.findUnique({ where: { id: orderId } }).catch(() => null);
    if (!order) return false;
    const device = deviceStore.activeForTerminal(terminalId);
    if (!device) return false;
    this.active.set(`${order.merchantId}:${terminalId}`, { orderId, sent: 'OPEN', engaged: false });
    this.pending.delete(device.id);
    const base = this.baseUrlFor(device.id);
    if (!base) return false; // offline: the device restores the order on reconnect
    return this.sendToCounter(order.merchantId, terminalId, 'ARM', await this.payloadForOrder(order, base));
  }

  /** The register disarmed a counter (cancel, expiry or failure). Tell the device which. */
  async onDisarm(terminalId) {
    for (const [key, entry] of this.active) {
      const [merchantId, tid] = key.split(':');
      if (tid !== terminalId) continue;
      const order = await prisma.order.findUnique({ where: { id: entry.orderId } }).catch(() => null);
      const status = deviceStatus(order?.status);
      if (status === 'CANCELLED' || !order) {
        this.active.delete(key);
        const reason = this.cancelReasons.get(entry.orderId) || 'DISARMED_FROM_DASHBOARD';
        this.cancelReasons.delete(entry.orderId);
        this.sendToCounter(merchantId, tid, 'DISARM', { orderId: entry.orderId, reason }, { critical: true });
      } else {
        await this.pushStatus(key, entry, order);
      }
    }
  }

  async onSuccess(terminalId, { orderId, tokenSymbol, txHash, receipt = null }) {
    const order = await prisma.order.findUnique({ where: { id: orderId } }).catch(() => null);
    if (!order) return;
    this.active.delete(`${order.merchantId}:${terminalId}`);
    this.sendToCounter(order.merchantId, terminalId, 'ORDER_STATUS', {
      orderId, status: 'PAID', totalCents: cents(order.totalAUD), token: tokenSymbol || order.tokenSymbol, txHash: txHash || null,
      // The Dynkle-signed receipt (tap-and-pay): the terminal hands it to phones on Bluetooth.
      ...(receipt ? { receipt } : {}),
    }, { critical: true });
  }

  async onError(terminalId, { orderId }) {
    const order = await prisma.order.findUnique({ where: { id: orderId } }).catch(() => null);
    if (!order) return;
    this.active.delete(`${order.merchantId}:${terminalId}`);
    this.sendToCounter(order.merchantId, terminalId, 'ORDER_STATUS', { orderId, status: 'FAILED' }, { critical: true });
  }

  async pushStatus(key, entry, order) {
    const [merchantId, terminalId] = key.split(':');
    const status = deviceStatus(order.status);
    if (!entry.engaged && CUSTOMER_ENGAGED.has(order.status)) {
      entry.engaged = true;
      this.sendToCounter(merchantId, terminalId, 'CUSTOMER_TAPPED', { orderId: order.id });
    }
    if (status === entry.sent) return;
    entry.sent = status;
    if (FINAL.has(status)) this.active.delete(key);
    if (status === 'CANCELLED') {
      const reason = this.cancelReasons.get(order.id) || 'DISARMED_FROM_DASHBOARD';
      this.cancelReasons.delete(order.id);
      this.sendToCounter(merchantId, terminalId, 'DISARM', { orderId: order.id, reason }, { critical: true });
      return;
    }
    this.sendToCounter(merchantId, terminalId, 'ORDER_STATUS', {
      orderId: order.id,
      status,
      totalCents: cents(order.totalAUD),
      token: status === 'PAID' ? order.tokenSymbol : null,
    }, { critical: FINAL.has(status) });
  }

  /** Server-side truth: re-read every armed order and push changes. */
  async watchOrders() {
    await this.adoptNewerOrders();
    if (!this.active.size) return;
    const ids = [...this.active.values()].map((e) => e.orderId);
    const orders = await prisma.order.findMany({ where: { id: { in: ids } } });
    const byId = new Map(orders.map((o) => [o.id, o]));
    for (const [key, entry] of [...this.active]) {
      const order = byId.get(entry.orderId);
      if (order) await this.pushStatus(key, entry, order);
      else this.active.delete(key);
    }
  }

  /**
   * The register cancels a counter's open order when it starts a new one. If
   * that new order didn't reach the device through arm() (another server
   * instance, a missed socket write), push it from the database.
   */
  async adoptNewerOrders() {
    for (const ws of this.sockets.values()) {
      const device = deviceStore.get(ws.deviceId);
      if (!device || device.status !== 'ACTIVE') continue;
      const latest = await prisma.order.findFirst({
        where: { terminalId: device.terminalId, status: { in: ['CREATED', 'QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER', 'CUSTOMER_DETECTED', 'AWAITING_APPROVAL'] }, quoteExpiresAt: { gt: new Date() } },
        orderBy: { createdAt: 'desc' },
      }).catch(() => null);
      if (!latest) continue;
      const key = `${latest.merchantId}:${device.terminalId}`;
      const cur = this.active.get(key);
      if (cur && cur.orderId === latest.id) continue;
      if (cur) {
        // Report the old one's real outcome first, then show the new bill.
        const old = await prisma.order.findUnique({ where: { id: cur.orderId } }).catch(() => null);
        if (old) await this.pushStatus(key, cur, old);
      }
      this.active.set(key, { orderId: latest.id, sent: 'OPEN', engaged: false });
      if (ws.baseUrl) this.sendToCounter(latest.merchantId, device.terminalId, 'ARM', await this.payloadForOrder(latest, ws.baseUrl));
    }
  }

  async setCounterStatus(device, status) {
    await prisma.terminal.updateMany({
      where: { terminalId: device.terminalId, merchantId: device.merchantId },
      data: { status, lastSeenAt: new Date() },
    }).catch(() => {});
  }
}

export const deviceHub = new DeviceHub();
