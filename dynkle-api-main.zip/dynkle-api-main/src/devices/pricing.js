// Prices a device cart from the catalog in the database. The device only says
// which product, which options and how many; every price comes from here, so a
// stale or edited price on the device can never change what the customer pays.
// Option handling matches the web register: options are add-ons, each with its
// own price, and the line name becomes "Product · Option A, Option B".

export class CartPricingError extends Error {
  constructor(message, code = 'PRODUCT_CHANGED') {
    super(message);
    this.code = code;
  }
}

const toCents = (v) => Math.round((parseFloat(v?.toString?.() ?? v) || 0) * 100);

/** Variants as stored in Product.meta.variants: [{ name, price }] (price in dollars). */
export function variantsOf(product) {
  const meta = product?.meta && typeof product.meta === 'object' ? product.meta : {};
  return (Array.isArray(meta.variants) ? meta.variants : [])
    .filter((v) => v && String(v.name || '').trim())
    .map((v) => ({ name: String(v.name).trim(), priceCents: toCents(v.price) }));
}

/**
 * @param {Array} products  Product rows for the merchant (active ones).
 * @param {Array} items     [{ productId, variants?: string[], qty }]
 * @returns {{ lines: Array<{productId,name,unitCents,qty,lineCents}>, subtotalCents: number }}
 */
export function priceCart(products, items) {
  if (!Array.isArray(items) || !items.length) throw new CartPricingError('The bill is empty.', 'EMPTY_CART');
  if (items.length > 100) throw new CartPricingError('Too many lines on one bill.', 'TOO_MANY_LINES');
  const byId = new Map(products.map((p) => [p.id, p]));
  const lines = items.map((it) => {
    const product = byId.get(it?.productId);
    if (!product || product.active === false) {
      throw new CartPricingError('A product on this bill is no longer for sale. Refresh and check the bill.');
    }
    const qty = Number(it.qty);
    if (!Number.isInteger(qty) || qty < 1 || qty > 999) throw new CartPricingError('Quantity must be between 1 and 999.', 'INVALID_QTY');
    const available = variantsOf(product);
    const chosen = [...new Set((Array.isArray(it.variants) ? it.variants : []).map((n) => String(n).trim()))].map((name) => {
      const v = available.find((x) => x.name === name);
      if (!v) throw new CartPricingError(`An option for ${product.name} changed. Refresh and check the bill.`);
      return v;
    });
    const unitCents = toCents(product.price) + chosen.reduce((s, v) => s + v.priceCents, 0);
    const name = chosen.length ? `${product.name} · ${chosen.map((v) => v.name).join(', ')}` : product.name;
    return { productId: product.id, name, unitCents, qty, lineCents: unitCents * qty };
  });
  return { lines, subtotalCents: lines.reduce((s, l) => s + l.lineCents, 0) };
}
