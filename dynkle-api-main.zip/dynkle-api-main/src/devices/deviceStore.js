// Paired counter devices (SZFP FP9810 running the Dynkle terminal app).
// POC persistence follows this backend's *_store.json pattern so the shared
// Prisma schema is untouched. Pairing codes and auth challenges are short-lived
// and kept in memory only.
import fs from 'fs';
import path from 'path';
import crypto from 'crypto';
import { fileURLToPath } from 'url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const STORE_PATH = process.env.DEVICES_STORE_PATH || path.join(__dirname, '..', '..', 'devices_store.json');

const PAIRING_TTL_MS = 10 * 60 * 1000;
const CHALLENGE_TTL_MS = 60 * 1000;
// No 0/O, 1/I/L: the code is read off a screen and typed on a 4" keypad.
const CODE_ALPHABET = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';

let devices = load();
const pairings = new Map(); // pairingId -> { code, merchantId, terminalId, label, expiresAt, deviceId? }
const challenges = new Map(); // deviceId -> { nonce, expiresAt }

function load() {
  try {
    const raw = JSON.parse(fs.readFileSync(STORE_PATH, 'utf8'));
    return Array.isArray(raw.devices) ? raw.devices : [];
  } catch {
    return [];
  }
}

function persist() {
  const tmp = `${STORE_PATH}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify({ devices }, null, 2));
  fs.renameSync(tmp, STORE_PATH);
}

function randomCode() {
  const bytes = crypto.randomBytes(8);
  let out = '';
  for (const b of bytes) out += CODE_ALPHABET[b % CODE_ALPHABET.length];
  return out;
}

export const deviceStore = {
  // ── Devices ──
  list(merchantId) {
    return devices.filter((d) => d.merchantId === merchantId);
  },
  get(id) {
    return devices.find((d) => d.id === id) || null;
  },
  /** Counter ids (POS_001…) are globally unique, so a counter has at most one active device. */
  activeForTerminal(terminalId) {
    return devices.find((d) => d.terminalId === terminalId && d.status === 'ACTIVE') || null;
  },
  activeForCounter(merchantId, terminalId) {
    return devices.find((d) => d.merchantId === merchantId && d.terminalId === terminalId && d.status === 'ACTIVE') || null;
  },
  create(fields) {
    const now = new Date().toISOString();
    const device = {
      id: crypto.randomUUID(),
      status: 'ACTIVE',
      createdAt: now,
      pairedAt: now,
      lastSeenAt: null,
      batteryPct: null,
      network: null,
      appVersion: null,
      osVersion: null,
      ...fields,
    };
    devices.push(device);
    persist();
    return device;
  },
  update(id, patch) {
    const d = devices.find((x) => x.id === id);
    if (!d) return null;
    Object.assign(d, patch);
    persist();
    return d;
  },
  /** Telemetry updates arrive every few seconds; persist them lazily. */
  touch(id, patch = {}) {
    const d = devices.find((x) => x.id === id);
    if (!d) return null;
    Object.assign(d, patch, { lastSeenAt: new Date().toISOString() });
    clearTimeout(this._touchTimer);
    this._touchTimer = setTimeout(persist, 2000);
    return d;
  },

  // ── Pairing codes (single use, 10 minutes) ──
  createPairing({ merchantId, terminalId, label }) {
    const id = crypto.randomUUID();
    const code = randomCode();
    const entry = { id, code, merchantId, terminalId, label, expiresAt: Date.now() + PAIRING_TTL_MS, deviceId: null };
    pairings.set(id, entry);
    return entry;
  },
  getPairing(id) {
    return pairings.get(id) || null;
  },
  /** Consumes an unexpired, unused code. Returns the pairing entry or null. */
  claimPairing(code) {
    const clean = String(code || '').replace(/[^A-Za-z0-9]/g, '').toUpperCase();
    for (const entry of pairings.values()) {
      if (entry.code === clean && !entry.deviceId && entry.expiresAt > Date.now()) return entry;
    }
    return null;
  },

  // ── Auth challenges ──
  createChallenge(deviceId) {
    const nonce = crypto.randomBytes(32).toString('base64');
    const expiresAt = Date.now() + CHALLENGE_TTL_MS;
    challenges.set(deviceId, { nonce, expiresAt });
    return { nonce, expiresAt };
  },
  takeChallenge(deviceId, nonce) {
    const c = challenges.get(deviceId);
    challenges.delete(deviceId);
    if (!c || c.nonce !== nonce || c.expiresAt < Date.now()) return false;
    return true;
  },
};

export function formatPairingCode(code) {
  return `${code.slice(0, 4)}-${code.slice(4)}`;
}
