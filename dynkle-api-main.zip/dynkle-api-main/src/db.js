import { PrismaClient } from '@prisma/client';

export const prisma = new PrismaClient({
  log: ['warn', 'error'],
});

export async function connectDB() {
  try {
    await prisma.$connect();
    console.log('[Database] Connected to PostgreSQL successfully.');
  } catch (err) {
    console.error('[Database Error] Failed to connect to PostgreSQL:', err.message);
    throw err;
  }
}

export async function disconnectDB() {
  await prisma.$disconnect();
}

export default prisma;
