// Table payments (design POC "Table-NFC Tags").
//
// A venue has floor plans; a floor plan has zones and tables. A table may carry
// an NFC tag (or a QR sticker) holding the fixed URL /tb/<tagCode>. Staff build
// the table's bill here (server-side, priced from the catalogue), then "send"
// it: that creates a normal DYNK payment order with a longer price hold and
// binds it to the table. Only a bound table takes payment (binding is the gate).
//
// States: FREE (no bill) → OCCUPIED (items being added) → READY (bill sent,
// tag live) → PAID (settled, awaiting clear-down) → FREE.
//
// Concurrency: editing a table's bill takes a short lease (lockedBy/lockedUntil)
// so two staff members cannot change it at once. Every change bumps `version`
// and pushes TABLES_CHANGED to the portal and every terminal of the merchant.

import crypto from 'crypto';
import prisma from '../db.js';
import { TABLE_HOLD_MINUTES, PORT } from '../config.js';
import { deviceStore } from '../devices/deviceStore.js';
import { priceCart, CartPricingError } from '../devices/pricing.js';
import { tapPay, createPayment, currentIntent, payBase, feeCentsOf, OPEN_STATUSES, TapPayError } from '../tappay/service.js';
import { publishOrderEvent } from '../tappay/events.js';
import { SETTLED_STATUSES, IN_FLIGHT_STATUSES } from '../services/paymentFlows.js';

export const LOCK_MS = 60_000;
export const STATUSES = ['FREE', 'OCCUPIED', 'READY', 'PAID'];
const MAX_TABLES_PER_PLAN = 300;
const MAX_PLANS = 20;
const MAX_ZONES = 20;
const TAG_RE = /^[a-z0-9][a-z0-9-]{3,39}$/;
// Statuses where the customer may be mid-payment: never cancel or re-quote under them.
const BUSY_STATUSES = ['CUSTOMER_DETECTED', 'AWAITING_APPROVAL', ...IN_FLIGHT_STATUSES];

export class TableError extends Error {
  constructor(status, code, message, extra = {}) {
    super(message);
    this.status = status;
    this.code = code;
    Object.assign(this, extra);
  }
}

// ── Helpers ─────────────────────────────────────────────────────────────

const clampInt = (v, min, max, dflt) => {
  const n = Math.round(Number(v));
  return Number.isFinite(n) ? Math.min(max, Math.max(min, n)) : dflt;
};
const cleanName = (v, max = 40) => String(v ?? '').replace(/\s+/g, ' ').trim().slice(0, max);
const newZoneId = () => `z_${crypto.randomBytes(4).toString('hex')}`;

/** Random, unguessable tag code: 12 chars of base32 (60 bits). */
export function newTagCode() {
  const alphabet = 'abcdefghjkmnpqrstuvwxyz23456789';
  const bytes = crypto.randomBytes(12);
  let out = '';
  for (const b of bytes) out += alphabet[b % alphabet.length];
  return out;
}

export function normalizeTagCode(v) {
  const code = String(v ?? '').trim().toLowerCase();
  return TAG_RE.test(code) ? code : null;
}

export const tagUrl = (code) => (code ? `${payBase()}/tb/${code}` : null);

/** The counter code orders for this table carry (Order.terminalId). */
export const tableCounterCode = (table) => `TB-${table.id.replace(/-/g, '').slice(0, 10).toUpperCase()}`;

const linesOf = (t) => (Array.isArray(t.items) ? t.items : []);
const subtotalCents = (items) => items.reduce((s, l) => s + l.unitCents * l.qty, 0);
const itemCount = (items) => items.reduce((s, l) => s + l.qty, 0);
const hasOpenBill = (t) => t.status !== 'FREE' || linesOf(t).length > 0;

function lockActive(t, now = Date.now()) {
  return !!(t.lockedBy && t.lockedUntil && new Date(t.lockedUntil).getTime() > now);
}

export function tableDto(t, order = null, now = Date.now()) {
  const items = linesOf(t);
  return {
    id: t.id,
    floorPlanId: t.floorPlanId,
    zoneId: t.zoneId,
    name: t.name,
    seats: t.seats,
    shape: t.shape,
    x: t.x, y: t.y, w: t.w, h: t.h,
    tagCode: t.tagCode,
    tagUrl: tagUrl(t.tagCode),
    status: t.status,
    items,
    itemCount: itemCount(items),
    subtotalCents: subtotalCents(items),
    order: order && t.status !== 'FREE' && t.status !== 'OCCUPIED' ? {
      id: order.id,
      orderNumber: order.displayNumber,
      status: order.status,
      totalCents: Math.round(parseFloat(String(order.totalAUD)) * 100),
      feeCents: feeCentsOf(order),
      holdExpiresAt: order.quoteExpiresAt ? new Date(order.quoteExpiresAt).toISOString() : null,
    } : null,
    sentAt: t.sentAt,
    paidAt: t.paidAt,
    lastTappedAt: t.lastTappedAt || null,
    lock: lockActive(t, now) ? { by: t.lockedBy, label: t.lockLabel, until: t.lockedUntil } : null,
    owner: t.ownerKey ? { key: t.ownerKey, label: t.ownerLabel || 'Staff' } : null,
    // Connected tables: every table in the group carries the same group (bill on group.leaderId).
    group: t._group || null,
    payMode: t.payMode || 'TAG',
    version: t.version,
  };
}

// ── Connected tables (one bill for several tables) ──────────────────────

/** Group info for a table from the venue's tables (null when it isn't connected). */
export function groupOf(t, all, now = Date.now()) {
  const leaderId = t.groupLeaderId || t.id;
  const leader = t.groupLeaderId ? all.find((x) => x.id === t.groupLeaderId) : t;
  const members = all.filter((x) => x.groupLeaderId === leaderId);
  if (!leader || (!t.groupLeaderId && !members.length)) return null;
  const tables = [leader, ...members].sort((a, b) => a.name.localeCompare(b.name, undefined, { numeric: true }));
  const claimed = leader.groupClaimTag && leader.groupClaimUntil && new Date(leader.groupClaimUntil).getTime() > now;
  const claimTable = claimed ? tables.find((x) => x.tagCode === leader.groupClaimTag) : null;
  return {
    leaderId,
    name: leader.groupName || null,
    tableIds: tables.map((x) => x.id),
    names: tables.map((x) => x.name),
    claim: claimed ? { tagCode: leader.groupClaimTag, tableName: claimTable ? claimTable.name : null, until: leader.groupClaimUntil } : null,
  };
}

/** "Table 1 + 2 + 3" (or the group's name) for the customer screens. */
export function groupTitle(g) {
  if (!g) return null;
  const nums = g.names.every((n) => /^\d+$/.test(n));
  const list = nums ? `Tables ${g.names.join(' + ')}` : g.names.join(' + ');
  return g.name ? `${g.name} · ${list}` : list;
}

/**
 * First tap wins: may this tag pay the group's bill now? The tag that tapped
 * first holds the group while the bill is open; other tags in the group are
 * turned away until it is paid, cleared, released or the hold runs out.
 */
export function claimDecision(leader, tagCode, now = Date.now()) {
  const active = !!(leader.groupClaimTag && leader.groupClaimUntil && new Date(leader.groupClaimUntil).getTime() > now);
  if (active && leader.groupClaimTag !== tagCode) return { allowed: false, by: leader.groupClaimTag };
  const open = leader.status === 'OCCUPIED' || leader.status === 'READY';
  return { allowed: true, claim: open };
}

async function withGroup(t) {
  if (!t) return t;
  const leaderId = t.groupLeaderId || t.id;
  const rows = await prisma.diningTable.findMany({ where: { OR: [{ id: leaderId }, { groupLeaderId: leaderId }] } });
  const g = groupOf(t, rows.some((r) => r.id === t.id) ? rows : [...rows, t]);
  return g ? { ...t, _group: g } : t;
}

/** Bill actions on any connected table act on the group's first table. */
export async function billTableId(merchantId, tableId) {
  const t = await prisma.diningTable.findFirst({ where: { id: String(tableId), merchantId }, select: { id: true, groupLeaderId: true } });
  return t ? (t.groupLeaderId || t.id) : String(tableId);
}

/** Merchant: connect tables into one group with one bill (on the first table). */
export async function connectTables(merchantId, body = {}) {
  const ids = [...new Set((Array.isArray(body.tableIds) ? body.tableIds : []).map(String))];
  if (ids.length < 2) throw new TableError(400, 'PICK_TABLES', 'Pick at least two tables to connect.');
  if (ids.length > 30) throw new TableError(400, 'TOO_MANY_TABLES', 'Connect up to 30 tables at a time.');
  const rows = await prisma.diningTable.findMany({ where: { merchantId, id: { in: ids } } });
  if (rows.length !== ids.length) throw new TableError(404, 'TABLE_NOT_FOUND', 'One of those tables no longer exists.');
  if (new Set(rows.map((t) => t.floorPlanId)).size > 1) throw new TableError(409, 'DIFFERENT_PLANS', 'Connect tables on the same floor plan.');
  const grouped = await prisma.diningTable.findMany({ where: { merchantId, OR: [{ id: { in: ids }, groupLeaderId: { not: null } }, { groupLeaderId: { in: ids } }] } });
  if (grouped.length) throw new TableError(409, 'ALREADY_CONNECTED', 'One of those tables is already connected. Disconnect it first.');
  const busy = rows.find((t) => t.status === 'READY' || t.status === 'PAID');
  if (busy) throw new TableError(409, 'BILL_SENT', `Table ${busy.name} has a bill sent or paid. Cancel or clear it first.`);
  const byId = new Map(rows.map((t) => [t.id, t]));
  // The first picked table with a bill leads (keeps that bill's waiter); otherwise the first picked.
  const leader = ids.map((id) => byId.get(id)).find((t) => linesOf(t).length) || byId.get(ids[0]);
  const members = rows.filter((t) => t.id !== leader.id);
  let items = linesOf(leader);
  for (const m of members) items = mergeLines(items, linesOf(m));
  if (items.length > 100) throw new TableError(409, 'TOO_MANY_LINES', 'Too many lines on one bill.');
  const owner = [leader, ...members].find((t) => t.ownerKey);
  await prisma.$transaction([
    prisma.diningTable.update({
      where: { id: leader.id },
      data: {
        groupName: String(body.name || '').replace(/\s+/g, ' ').trim().slice(0, 30) || null,
        groupClaimTag: null, groupClaimUntil: null,
        items, status: items.length ? 'OCCUPIED' : 'FREE',
        ...(owner ? { ownerKey: owner.ownerKey, ownerLabel: owner.ownerLabel } : {}),
        version: { increment: 1 },
      },
    }),
    prisma.diningTable.updateMany({
      where: { id: { in: members.map((t) => t.id) } },
      data: { groupLeaderId: leader.id, items: [], status: 'FREE', boundOrderId: null, sentAt: null, paidAt: null, ownerKey: null, ownerLabel: null, payMode: 'TAG', version: { increment: 1 } },
    }),
  ]);
  await tablesChanged(merchantId, ids);
  return dtoOf(await tableOf(merchantId, leader.id));
}

/** Merchant: split a group again; the bill stays on the first table. */
export async function disconnectTables(merchantId, tableId) {
  const leaderId = await billTableId(merchantId, tableId);
  const leader = await tableOf(merchantId, leaderId);
  const members = await prisma.diningTable.findMany({ where: { merchantId, groupLeaderId: leader.id } });
  await prisma.$transaction([
    prisma.diningTable.updateMany({ where: { id: { in: members.map((t) => t.id) } }, data: { groupLeaderId: null, version: { increment: 1 } } }),
    prisma.diningTable.update({ where: { id: leader.id }, data: { groupName: null, groupClaimTag: null, groupClaimUntil: null, version: { increment: 1 } } }),
  ]);
  await tablesChanged(merchantId, [leader.id, ...members.map((t) => t.id)]);
  return dtoOf(await tableOf(merchantId, leader.id));
}

/** Merchant: let another tag in the group pay (e.g. the first tapper walked off). */
export async function releaseGroupClaim(merchantId, tableId) {
  const leaderId = await billTableId(merchantId, tableId);
  const updated = await prisma.diningTable.update({ where: { id: leaderId }, data: { groupClaimTag: null, groupClaimUntil: null, version: { increment: 1 } } });
  await tablesChanged(merchantId, [leaderId]);
  return dtoOf(updated);
}

async function ordersFor(tables) {
  const ids = [...new Set(tables.map((t) => t.boundOrderId).filter(Boolean))];
  if (!ids.length) return new Map();
  const orders = await prisma.order.findMany({ where: { id: { in: ids } } });
  return new Map(orders.map((o) => [o.id, o]));
}

// ── Live updates ─────────────────────────────────────────────────────────

let hub = null;
async function deviceHub() {
  if (!hub) hub = (await import('../devices/deviceHub.js')).deviceHub;
  return hub;
}

/** Tells the portal and every terminal of the merchant which tables changed. */
export async function tablesChanged(merchantId, tableIds = []) {
  try {
    const h = await deviceHub();
    const payload = { tableIds, at: Date.now() };
    h.broadcast(merchantId, { type: 'TABLES_CHANGED', ...payload });
    h.sendToMerchantDevices(merchantId, 'TABLES_CHANGED', payload);
  } catch (e) {
    console.warn('[tables] notify:', e.message);
  }
}

// ── Floor plans ──────────────────────────────────────────────────────────

/** The whole venue: plans with zones and tables. Creates a first plan if none exists. */
const TABLE_INDUSTRIES = ['cafe', 'restaurant', 'bar'];

/** TABLES (bills per table) or COUNTER (bills per counter). Unset: from the business type, or tables already set up. */
export function resolveServiceMode(merchant, tableCount = 0) {
  if (merchant?.serviceMode === 'TABLES' || merchant?.serviceMode === 'COUNTER') return merchant.serviceMode;
  return TABLE_INDUSTRIES.includes(String(merchant?.industry || '').toLowerCase()) || tableCount > 0 ? 'TABLES' : 'COUNTER';
}

export async function getFloor(merchantId, viewer = null) {
  let plans = await prisma.floorPlan.findMany({ where: { merchantId }, orderBy: [{ sort: 'asc' }, { createdAt: 'asc' }] });
  if (!plans.length) {
    plans = [await prisma.floorPlan.create({
      data: { merchantId, name: 'Main venue', zones: [{ id: newZoneId(), name: 'Main floor' }] },
    })];
  }
  const tables = await prisma.diningTable.findMany({ where: { merchantId }, orderBy: [{ createdAt: 'asc' }] });
  const orders = await ordersFor(tables);
  const now = Date.now();
  const merchant = await prisma.merchant.findUnique({ where: { id: merchantId }, select: { tableAutoClearMinutes: true, serviceMode: true, industry: true } });
  return {
    holdMinutes: TABLE_HOLD_MINUTES,
    settings: {
      autoClearMinutes: merchant?.tableAutoClearMinutes ?? null,
      serviceMode: resolveServiceMode(merchant, tables.length),
      serviceModeSet: merchant?.serviceMode || null,
    },
    // Who is asking: lets a screen tell "my tables" from other waiters' (read-only).
    viewer: viewer ? { ownerKey: viewer.ownerKey, label: viewer.ownerLabel } : null,
    lockSeconds: LOCK_MS / 1000,
    tagBaseUrl: `${payBase()}/tb/`,
    plans: plans.map((p) => ({
      id: p.id,
      name: p.name,
      zones: Array.isArray(p.zones) ? p.zones : [],
      tables: tables.filter((t) => t.floorPlanId === p.id).map((t) => {
        const g = groupOf(t, tables, now);
        return tableDto(g ? { ...t, _group: g } : t, orders.get(t.boundOrderId), now);
      }),
    })),
  };
}

function cleanZones(zones, existing = []) {
  if (!Array.isArray(zones) || !zones.length) throw new TableError(400, 'ZONES_REQUIRED', 'A floor plan needs at least one zone.');
  if (zones.length > MAX_ZONES) throw new TableError(400, 'TOO_MANY_ZONES', `Up to ${MAX_ZONES} zones per floor plan.`);
  const known = new Set(existing.map((z) => z.id));
  const seen = new Set();
  return zones.map((z) => {
    const name = cleanName(z?.name, 30);
    if (!name) throw new TableError(400, 'ZONE_NAME_REQUIRED', 'Give every zone a name.');
    if (seen.has(name.toLowerCase())) throw new TableError(400, 'ZONE_NAME_TAKEN', `There are two zones called ${name}.`);
    seen.add(name.toLowerCase());
    const id = z?.id && known.has(z.id) ? z.id : newZoneId();
    return { id, name };
  });
}

export async function createPlan(merchantId, body = {}) {
  const count = await prisma.floorPlan.count({ where: { merchantId } });
  if (count >= MAX_PLANS) throw new TableError(400, 'TOO_MANY_PLANS', `Up to ${MAX_PLANS} floor plans.`);
  const name = cleanName(body.name) || `Floor plan ${count + 1}`;
  const zones = body.zones ? cleanZones(body.zones) : [{ id: newZoneId(), name: 'Main floor' }];
  const plan = await prisma.floorPlan.create({ data: { merchantId, name, zones, sort: count } });
  await tablesChanged(merchantId, []);
  return plan;
}

async function planOf(merchantId, planId) {
  const plan = await prisma.floorPlan.findFirst({ where: { id: String(planId), merchantId } });
  if (!plan) throw new TableError(404, 'PLAN_NOT_FOUND', 'That floor plan no longer exists.');
  return plan;
}

export async function updatePlan(merchantId, planId, body = {}) {
  const plan = await planOf(merchantId, planId);
  const data = {};
  if (body.name !== undefined) {
    data.name = cleanName(body.name);
    if (!data.name) throw new TableError(400, 'NAME_REQUIRED', 'Give the floor plan a name.');
  }
  if (body.zones !== undefined) {
    const zones = cleanZones(body.zones, plan.zones || []);
    const kept = new Set(zones.map((z) => z.id));
    const orphaned = await prisma.diningTable.findMany({ where: { floorPlanId: plan.id, zoneId: { notIn: [...kept] } } });
    if (orphaned.length) {
      throw new TableError(409, 'ZONE_NOT_EMPTY', 'Move or delete the tables in a zone before removing it.', { tableIds: orphaned.map((t) => t.id) });
    }
    data.zones = zones;
  }
  const updated = await prisma.floorPlan.update({ where: { id: plan.id }, data });
  await tablesChanged(merchantId, []);
  return updated;
}

export async function deletePlan(merchantId, planId) {
  const plan = await planOf(merchantId, planId);
  const tables = await prisma.diningTable.findMany({ where: { floorPlanId: plan.id } });
  if (tables.some(hasOpenBill)) throw new TableError(409, 'OPEN_BILLS', 'A table on this floor plan has an open bill. Settle or clear it first.');
  if ((await prisma.floorPlan.count({ where: { merchantId } })) <= 1) throw new TableError(409, 'LAST_PLAN', 'Keep at least one floor plan.');
  await prisma.floorPlan.delete({ where: { id: plan.id } });
  await tablesChanged(merchantId, tables.map((t) => t.id));
  return { ok: true };
}

// ── Tables (layout, from the floor plan editor) ──────────────────────────

function layoutData(body, plan) {
  const data = {};
  if (body.name !== undefined) {
    data.name = cleanName(body.name, 20);
    if (!data.name) throw new TableError(400, 'NAME_REQUIRED', 'Give the table a name.');
  }
  if (body.zoneId !== undefined) {
    if (!(plan.zones || []).some((z) => z.id === body.zoneId)) throw new TableError(400, 'ZONE_NOT_FOUND', 'Pick one of this floor plan’s zones.');
    data.zoneId = body.zoneId;
  }
  if (body.seats !== undefined) data.seats = clampInt(body.seats, 1, 40, 2);
  if (body.shape !== undefined) data.shape = body.shape === 'round' ? 'round' : 'rect';
  if (body.x !== undefined) data.x = clampInt(body.x, 0, 4000, 0);
  if (body.y !== undefined) data.y = clampInt(body.y, 0, 4000, 0);
  if (body.w !== undefined) data.w = clampInt(body.w, 40, 400, 80);
  if (body.h !== undefined) data.h = clampInt(body.h, 40, 400, 64);
  return data;
}

async function tableOf(merchantId, tableId) {
  const t = await prisma.diningTable.findFirst({ where: { id: String(tableId), merchantId } });
  if (!t) throw new TableError(404, 'TABLE_NOT_FOUND', 'That table no longer exists.');
  return t;
}

async function dtoOf(t) {
  const order = t.boundOrderId ? await prisma.order.findUnique({ where: { id: t.boundOrderId } }) : null;
  return tableDto(await withGroup(t), order);
}

export async function createTable(merchantId, body = {}) {
  const plan = await planOf(merchantId, body.floorPlanId);
  if ((await prisma.diningTable.count({ where: { floorPlanId: plan.id } })) >= MAX_TABLES_PER_PLAN) {
    throw new TableError(400, 'TOO_MANY_TABLES', `Up to ${MAX_TABLES_PER_PLAN} tables per floor plan.`);
  }
  const zoneId = body.zoneId || plan.zones?.[0]?.id;
  const data = layoutData({ seats: 2, ...body, zoneId, name: body.name ?? String((await prisma.diningTable.count({ where: { merchantId } })) + 1) }, plan);
  const t = await prisma.diningTable.create({ data: { merchantId, floorPlanId: plan.id, ...data } });
  await tablesChanged(merchantId, [t.id]);
  return tableDto(t);
}

export async function updateTable(merchantId, tableId, body = {}) {
  const t = await tableOf(merchantId, tableId);
  let plan = await planOf(merchantId, t.floorPlanId);
  const data = {};
  if (body.floorPlanId && body.floorPlanId !== t.floorPlanId) {
    plan = await planOf(merchantId, body.floorPlanId);
    data.floorPlanId = plan.id;
    if (body.zoneId === undefined) data.zoneId = plan.zones?.[0]?.id;
  }
  Object.assign(data, layoutData(body, plan));
  const updated = await prisma.diningTable.update({ where: { id: t.id }, data: { ...data, version: { increment: 1 } } });
  await tablesChanged(merchantId, [t.id]);
  return dtoOf(updated);
}

export async function deleteTable(merchantId, tableId) {
  const t = await tableOf(merchantId, tableId);
  if (hasOpenBill(t)) throw new TableError(409, 'OPEN_BILL', 'This table has an open bill. Settle or clear it before deleting the table.');
  if (await prisma.diningTable.count({ where: { groupLeaderId: t.id } })) throw new TableError(409, 'CONNECTED', 'This table leads a group of connected tables. Disconnect them first.');
  await prisma.diningTable.delete({ where: { id: t.id } });
  await tablesChanged(merchantId, [t.id]);
  return { ok: true };
}

// ── Venue settings and layout tools ──────────────────────────────────────

/** autoClearMinutes: clear Paid tables automatically after N minutes (null = off). */
export async function updateSettings(merchantId, body = {}) {
  const data = {};
  if (body.autoClearMinutes !== undefined) {
    if (body.autoClearMinutes === null || body.autoClearMinutes === '' || body.autoClearMinutes === 0) data.tableAutoClearMinutes = null;
    else {
      const n = Number(body.autoClearMinutes);
      if (!Number.isInteger(n) || n < 1 || n > 240) throw new TableError(400, 'BAD_AUTO_CLEAR', 'Auto-clear is 1 to 240 minutes, or off.');
      data.tableAutoClearMinutes = n;
    }
  }
  if (body.serviceMode !== undefined) {
    if (body.serviceMode === null || body.serviceMode === '') data.serviceMode = null;
    else if (body.serviceMode === 'TABLES' || body.serviceMode === 'COUNTER') data.serviceMode = body.serviceMode;
    else throw new TableError(400, 'BAD_SERVICE_MODE', 'Service mode is TABLES or COUNTER.');
  }
  const m = await prisma.merchant.update({ where: { id: merchantId }, data, select: { tableAutoClearMinutes: true, serviceMode: true, industry: true } });
  const count = await prisma.diningTable.count({ where: { merchantId } });
  await tablesChanged(merchantId, []);
  return { autoClearMinutes: m.tableAutoClearMinutes ?? null, serviceMode: resolveServiceMode(m, count), serviceModeSet: m.serviceMode || null };
}

/** Next free table numbers ("1", "2", …) across the venue. */
function nextNumbers(existing, count, prefix = '') {
  const taken = new Set(existing.map((t) => t.name.toLowerCase()));
  const out = [];
  for (let n = 1; out.length < count && n < 10000; n++) {
    const name = `${prefix}${n}`;
    if (!taken.has(name.toLowerCase())) out.push(name);
  }
  return out;
}

/**
 * Adds `count` tables at once, numbered after the venue's existing tables and
 * laid out in a grid (columns × rows) starting below whatever the zone holds.
 */
export async function createTablesBulk(merchantId, body = {}) {
  const plan = await planOf(merchantId, body.floorPlanId);
  const zoneId = body.zoneId && (plan.zones || []).some((z) => z.id === body.zoneId) ? body.zoneId : plan.zones?.[0]?.id;
  const count = clampInt(body.count, 1, 60, 1);
  const existingInPlan = await prisma.diningTable.count({ where: { floorPlanId: plan.id } });
  if (existingInPlan + count > MAX_TABLES_PER_PLAN) throw new TableError(400, 'TOO_MANY_TABLES', `Up to ${MAX_TABLES_PER_PLAN} tables per floor plan.`);
  const seats = clampInt(body.seats, 1, 40, 2);
  const shape = body.shape === 'round' ? 'round' : 'rect';
  const w = clampInt(body.w, 40, 400, seats > 4 ? 104 : 80);
  const h = clampInt(body.h, 40, 400, shape === 'round' ? w : (seats > 4 ? 80 : 64));
  const cols = clampInt(body.columns, 1, 20, Math.min(count, 5));
  const gap = clampInt(body.gap, 0, 200, 39);
  const prefix = cleanName(body.prefix, 6);
  const all = await prisma.diningTable.findMany({ where: { merchantId } });
  const inZone = all.filter((t) => t.floorPlanId === plan.id && t.zoneId === zoneId);
  const startY = clampInt(body.y, 0, 4000, inZone.length ? Math.max(...inZone.map((t) => t.y + t.h)) + gap : 26);
  const startX = clampInt(body.x, 0, 4000, 26);
  const names = nextNumbers(all, count, prefix);
  const rows = names.map((name, i) => ({
    merchantId, floorPlanId: plan.id, zoneId, name, seats, shape, w, h,
    x: startX + (i % cols) * (w + gap),
    y: startY + Math.floor(i / cols) * (h + gap),
  }));
  await prisma.diningTable.createMany({ data: rows });
  const created = await prisma.diningTable.findMany({ where: { floorPlanId: plan.id, name: { in: names } } });
  await tablesChanged(merchantId, created.map((t) => t.id));
  return { tables: created.map((t) => tableDto(t)) };
}

/** Moves/resizes many tables in one go (align, distribute, multi-drag). */
export async function updateLayoutBatch(merchantId, body = {}) {
  const updates = Array.isArray(body.updates) ? body.updates.slice(0, MAX_TABLES_PER_PLAN) : [];
  if (!updates.length) return { tables: [] };
  const ids = updates.map((u) => String(u?.id || ''));
  const found = await prisma.diningTable.findMany({ where: { merchantId, id: { in: ids } } });
  const byId = new Map(found.map((t) => [t.id, t]));
  const ops = [];
  for (const u of updates) {
    if (!byId.has(String(u?.id))) continue;
    const data = {};
    for (const [k, min, max] of [['x', 0, 4000], ['y', 0, 4000], ['w', 40, 400], ['h', 40, 400]]) {
      if (u[k] !== undefined) data[k] = clampInt(u[k], min, max, 0);
    }
    if (Object.keys(data).length) ops.push(prisma.diningTable.update({ where: { id: String(u.id) }, data: { ...data, version: { increment: 1 } } }));
  }
  const updated = ops.length ? await prisma.$transaction(ops) : [];
  await tablesChanged(merchantId, updated.map((t) => t.id));
  return { tables: updated.map((t) => tableDto(t)) };
}

// ── Tag registry ─────────────────────────────────────────────────────────

/** Assign (no code = a new random one), reassign (code on another table) or replace a tag. */
export async function assignTag(merchantId, tableId, body = {}) {
  const t = await tableOf(merchantId, tableId);
  let code = newTagCode();
  if (body.tagCode !== undefined && body.tagCode !== null && body.tagCode !== '') {
    code = normalizeTagCode(body.tagCode);
    if (!code) throw new TableError(400, 'BAD_TAG_CODE', 'A tag code is 4–40 letters, digits or dashes.');
  }
  const changed = [t.id];
  if (code !== t.tagCode) {
    const holder = await prisma.diningTable.findUnique({ where: { tagCode: code } });
    if (holder && holder.merchantId !== merchantId) throw new TableError(409, 'TAG_IN_USE', 'That tag belongs to another business.');
    if (holder) {
      if (holder.status === 'READY') throw new TableError(409, 'TAG_BUSY', `That tag is live on table ${holder.name} with a bill waiting. Cancel the send there first.`);
      await prisma.diningTable.update({ where: { id: holder.id }, data: { tagCode: null, version: { increment: 1 } } });
      changed.push(holder.id);
    }
  }
  const updated = await prisma.diningTable.update({ where: { id: t.id }, data: { tagCode: code, version: { increment: 1 } } });
  await tablesChanged(merchantId, changed);
  return dtoOf(updated);
}

export async function removeTag(merchantId, tableId) {
  const t = await tableOf(merchantId, tableId);
  if (t.status === 'READY') throw new TableError(409, 'BILL_SENT', 'A bill is waiting on this tag. Cancel the send before removing the tag.');
  const updated = await prisma.diningTable.update({ where: { id: t.id }, data: { tagCode: null, version: { increment: 1 } } });
  await tablesChanged(merchantId, [t.id]);
  return dtoOf(updated);
}

// ── Ownership (each waiter runs their own tables) ────────────────────────
//
// The POS that opens a table's bill owns it: other POS devices see it live but
// cannot change it. The merchant (portal) can change any table and can hand a
// table over to another waiter. actor = { kind: 'device'|'portal', key,
// label, ownerKey, ownerLabel, device? }.

export function canEdit(t, actor) {
  return actor.kind === 'portal' || !t.ownerKey || t.ownerKey === actor.ownerKey;
}

function assertCanEdit(t, actor) {
  if (canEdit(t, actor)) return;
  throw new TableError(403, 'TABLE_OWNED', `Table ${t.name} is ${t.ownerLabel || 'another waiter'}'s. You can see it, but only they or the merchant can change it.`, { owner: t.ownerLabel || null });
}

/** Owner fields for a table getting its first items (keeps an existing owner). */
const ownerFor = (t, actor) => (t.ownerKey ? {} : { ownerKey: actor.ownerKey, ownerLabel: actor.ownerLabel });
const NO_OWNER = { ownerKey: null, ownerLabel: null, payMode: 'TAG' };

/** Merchant only: hand a table to a waiter's POS (deviceId), to the merchant, or release it (null). */
export async function assignOwner(merchantId, tableId, body = {}) {
  const t = await tableOf(merchantId, tableId);
  let data;
  if (body.to === null || body.to === '' || body.to === undefined) data = { ownerKey: null, ownerLabel: null };
  else if (body.to === 'merchant') data = { ownerKey: 'merchant', ownerLabel: 'Merchant' };
  else {
    const d = deviceStore.get(String(body.to));
    if (!d || d.merchantId !== merchantId || d.status !== 'ACTIVE') throw new TableError(404, 'DEVICE_NOT_FOUND', 'That POS device is not paired with this business.');
    data = { ownerKey: `device:${d.id}`, ownerLabel: d.label || `POS ${d.terminalId}` };
  }
  // The previous owner's open edit lease goes too, so the new owner can start at once.
  const updated = await prisma.diningTable.update({ where: { id: t.id }, data: { ...data, lockedBy: null, lockLabel: null, lockedUntil: null, version: { increment: 1 } } });
  await tablesChanged(merchantId, [t.id]);
  return dtoOf(updated);
}

// ── Locks (one member of staff edits a table's bill at a time) ───────────

/**
 * Takes or renews the edit lease. actor = { key, label }. Throws TABLE_LOCKED
 * while someone else holds an unexpired lease.
 */
export async function lockTable(merchantId, tableId, actor) {
  const t = await tableOf(merchantId, tableId);
  assertCanEdit(t, actor);
  const now = new Date();
  const until = new Date(now.getTime() + LOCK_MS);
  const r = await prisma.diningTable.updateMany({
    where: {
      id: t.id,
      OR: [{ lockedBy: null }, { lockedBy: actor.key }, { lockedUntil: null }, { lockedUntil: { lt: now } }],
    },
    data: { lockedBy: actor.key, lockLabel: actor.label, lockedUntil: until },
  });
  if (!r.count) {
    const fresh = await tableOf(merchantId, tableId);
    throw new TableError(423, 'TABLE_LOCKED', `${fresh.lockLabel || 'Another device'} is using table ${fresh.name}.`, { lockedBy: fresh.lockLabel });
  }
  const isNew = t.lockedBy !== actor.key || !lockActive(t);
  if (isNew) await tablesChanged(merchantId, [t.id]);
  return dtoOf(await tableOf(merchantId, tableId));
}

export async function unlockTable(merchantId, tableId, actor) {
  const t = await tableOf(merchantId, tableId);
  const r = await prisma.diningTable.updateMany({ where: { id: t.id, lockedBy: actor.key }, data: { lockedBy: null, lockLabel: null, lockedUntil: null } });
  if (r.count) await tablesChanged(merchantId, [t.id]);
  return { ok: true };
}

/** Bill changes need the lease: take it if free, refuse if someone else holds it. */
async function withLease(merchantId, tableId, actor) {
  await lockTable(merchantId, tableId, actor);
  return tableOf(merchantId, tableId);
}

// ── Orders bound to tables ───────────────────────────────────────────────

/** Cancels a table's sent order unless the customer is paying it right now. */
async function cancelBoundOrder(t) {
  if (!t.boundOrderId) return;
  const order = await prisma.order.findUnique({ where: { id: t.boundOrderId } });
  if (!order) return;
  if (SETTLED_STATUSES.includes(order.status)) throw new TableError(409, 'ALREADY_PAID', 'This bill has been paid.');
  if (BUSY_STATUSES.includes(order.status) || order.paymentLock) {
    throw new TableError(409, 'PAYMENT_IN_PROGRESS', 'The customer is paying this bill right now. Wait for it to finish.');
  }
  if (!OPEN_STATUSES.includes(order.status)) return; // already expired or cancelled
  const r = await prisma.order.updateMany({
    where: { id: order.id, status: { in: ['QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'] }, paymentLock: null },
    data: { status: 'CANCELLED' },
  });
  if (!r.count) throw new TableError(409, 'PAYMENT_IN_PROGRESS', 'The customer is paying this bill right now. Wait for it to finish.');
  publishOrderEvent(order.id, { status: 'CANCELLED' });
}

function requireTapPay() {
  if (!tapPay.ready) {
    throw new TableError(503, 'PAYMENTS_UNAVAILABLE', 'DYNK payments are not set up on this server yet, so bills cannot be sent to tags.', { missing: tapPay.missing });
  }
}

/** Creates a fresh order for the table's bill (priced now) with the table price hold. */
async function issueTableOrder(t) {
  requireTapPay();
  const products = await prisma.product.findMany({ where: { merchantId: t.merchantId, active: true } });
  let priced;
  try {
    priced = priceCart(products, linesOf(t).map((l) => ({ productId: l.productId, variants: l.variants || [], qty: l.qty })));
  } catch (e) {
    if (e instanceof CartPricingError) throw new TableError(409, e.code || 'CART_CHANGED', e.message);
    throw e;
  }
  // The intent carries no Bluetooth session: an all-zero session id tells the
  // DYNK app there is no terminal to reach, so it pays over the internet.
  const device = { id: t.id, merchantId: t.merchantId, terminalId: tableCounterCode(t) };
  try {
    const created = await createPayment({
      device,
      billCents: priced.subtotalCents,
      items: priced.lines.map((l) => ({ name: l.name, price: l.unitCents / 100, quantity: l.qty, qty: l.qty, productId: l.productId })),
      terminalEphemeralPub: crypto.randomBytes(32).toString('base64'),
      bleSessionId: Buffer.alloc(8).toString('base64'),
      ttlSeconds: TABLE_HOLD_MINUTES * 60,
      arm: false,
    });
    return { order: created.order, priced };
  } catch (e) {
    if (e instanceof TapPayError) throw new TableError(e.status, e.code, e.message);
    throw e;
  }
}

// ── Bill actions (staff) ─────────────────────────────────────────────────

function cleanItems(items) {
  if (!Array.isArray(items)) throw new TableError(400, 'BAD_ITEMS', 'items must be a list.');
  if (items.length > 100) throw new TableError(400, 'TOO_MANY_LINES', 'Too many lines on one bill.');
  return items.map((it) => ({
    productId: String(it?.productId || ''),
    variants: Array.isArray(it?.variants) ? it.variants.map((v) => String(v)) : [],
    qty: Number(it?.qty),
  }));
}

/** Replaces the bill's lines (server-priced). Empty lines free the table. */
export async function setItems(merchantId, tableId, actor, body = {}) {
  const t = await withLease(merchantId, tableId, actor);
  if (body.version !== undefined && Number(body.version) !== t.version) {
    throw new TableError(409, 'STALE_TABLE', 'This table changed on another device. Check the bill and try again.');
  }
  if (t.status === 'READY') throw new TableError(409, 'BILL_SENT', 'The bill has been sent to the tag. Cancel the send to change it.');
  if (t.status === 'PAID') throw new TableError(409, 'ALREADY_PAID', 'This table has paid. Clear it before starting a new bill.');
  const wanted = cleanItems(body.items);
  let items = [];
  if (wanted.length) {
    const products = await prisma.product.findMany({ where: { merchantId, active: true } });
    try {
      const priced = priceCart(products, wanted);
      items = priced.lines.map((l, i) => ({ productId: l.productId, name: l.name, variants: wanted[i].variants, unitCents: l.unitCents, qty: l.qty }));
    } catch (e) {
      if (e instanceof CartPricingError) throw new TableError(409, e.code || 'CART_CHANGED', e.message);
      throw e;
    }
  }
  const updated = await prisma.diningTable.update({
    where: { id: t.id },
    data: { items, status: items.length ? 'OCCUPIED' : 'FREE', ...(items.length ? ownerFor(t, actor) : NO_OWNER), version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [t.id]);
  return dtoOf(updated);
}

/** "Send bill to tag": the tag goes live, bound to a fresh order for this bill. */
export async function sendBill(merchantId, tableId, actor) {
  const t = await withLease(merchantId, tableId, actor);
  if (t.status === 'READY') return dtoOf(t);
  if (t.status !== 'OCCUPIED' || !linesOf(t).length) throw new TableError(409, 'EMPTY_BILL', 'Add something to the bill first.');
  if (!t.tagCode) throw new TableError(409, 'NO_TAG', 'This table has no tag, so customers cannot tap to pay it. Assign a tag on the floor plan.');
  const { order } = await issueTableOrder(t);
  const updated = await prisma.diningTable.update({
    where: { id: t.id },
    data: { status: 'READY', payMode: 'TAG', boundOrderId: order.id, sentAt: new Date(), ...ownerFor(t, actor), version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [t.id]);
  return tableDto(updated, order);
}

/** "Cancel send": the tag returns to idle, the bill stays open for more items. */
export async function cancelSend(merchantId, tableId, actor) {
  const t = await withLease(merchantId, tableId, actor);
  if (t.status !== 'READY') return dtoOf(t);
  await cancelBoundOrder(t);
  const updated = await prisma.diningTable.update({
    where: { id: t.id },
    data: { status: 'OCCUPIED', payMode: 'TAG', boundOrderId: null, sentAt: null, groupClaimTag: null, groupClaimUntil: null, version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [t.id]);
  return dtoOf(updated);
}

/** "Clear table": after payment (clear-down) or to void an unpaid bill. */
export async function clearTable(merchantId, tableId, actor) {
  const t = await withLease(merchantId, tableId, actor);
  if (t.status === 'READY') await cancelBoundOrder(t);
  const updated = await prisma.diningTable.update({
    where: { id: t.id },
    data: {
      status: 'FREE', items: [], boundOrderId: null, sentAt: null, paidAt: null, ...NO_OWNER,
      groupClaimTag: null, groupClaimUntil: null,
      lockedBy: null, lockLabel: null, lockedUntil: null, version: { increment: 1 },
    },
  });
  await tablesChanged(merchantId, [t.id]);
  return tableDto(updated);
}

function mergeLines(a, b) {
  const out = a.map((l) => ({ ...l }));
  for (const l of b) {
    const key = `${l.productId}|${(l.variants || []).join(',')}`;
    const hit = out.find((x) => `${x.productId}|${(x.variants || []).join(',')}` === key);
    if (hit) hit.qty = Math.min(999, hit.qty + l.qty);
    else out.push({ ...l });
  }
  return out;
}

/** "Move party": the bill goes to an empty table and its tag; the old table frees up. */
export async function moveTable(merchantId, tableId, actor, body = {}) {
  const from = await withLease(merchantId, tableId, actor);
  const to = await withLease(merchantId, body.toTableId, actor);
  if (from.id === to.id) throw new TableError(400, 'SAME_TABLE', 'Pick a different table.');
  if (to.groupLeaderId || (await prisma.diningTable.count({ where: { groupLeaderId: { in: [from.id, to.id] } } }))) throw new TableError(409, 'CONNECTED', 'Connected tables move together. Disconnect them first.');
  if (from.status === 'FREE' || !linesOf(from).length) throw new TableError(409, 'EMPTY_BILL', 'There is no bill on this table to move.');
  if (from.status === 'PAID') throw new TableError(409, 'ALREADY_PAID', 'This bill has been paid. Clear the table instead.');
  if (hasOpenBill(to)) throw new TableError(409, 'TARGET_BUSY', `Table ${to.name} already has a bill. Join the tables instead.`);
  const wasSent = from.status === 'READY';
  if (wasSent) await cancelBoundOrder(from);

  await prisma.diningTable.update({
    where: { id: to.id },
    data: {
      items: linesOf(from), status: 'OCCUPIED', boundOrderId: null, sentAt: null, payMode: 'TAG',
      ownerKey: from.ownerKey || actor.ownerKey, ownerLabel: from.ownerKey ? from.ownerLabel : actor.ownerLabel, version: { increment: 1 },
    },
  });
  await prisma.diningTable.update({
    where: { id: from.id },
    data: { items: [], status: 'FREE', boundOrderId: null, sentAt: null, paidAt: null, ...NO_OWNER, lockedBy: null, lockLabel: null, lockedUntil: null, version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [from.id, to.id]);
  // A bill that was waiting on the old tag carries on waiting on the new one.
  if (wasSent && to.tagCode) {
    try { return await sendBill(merchantId, to.id, actor); } catch (e) { console.warn('[tables] resend after move:', e.message); }
  }
  return dtoOf(await tableOf(merchantId, to.id));
}

/** "Join tables": both bills merge under the target's tag; the other tag returns to idle. */
export async function joinTables(merchantId, tableId, actor, body = {}) {
  const from = await withLease(merchantId, tableId, actor);
  const into = await withLease(merchantId, body.intoTableId, actor);
  if (from.id === into.id) throw new TableError(400, 'SAME_TABLE', 'Pick a different table.');
  if (into.groupLeaderId || (await prisma.diningTable.count({ where: { groupLeaderId: { in: [from.id, into.id] } } }))) throw new TableError(409, 'CONNECTED', 'To add a table to a group, connect it on the floor plan.');
  if (from.status === 'PAID' || into.status === 'PAID') throw new TableError(409, 'ALREADY_PAID', 'One of these tables has paid. Clear it first.');
  if (from.status === 'READY') await cancelBoundOrder(from);
  if (into.status === 'READY') await cancelBoundOrder(into);
  const items = mergeLines(linesOf(into), linesOf(from));
  if (items.length > 100) throw new TableError(409, 'TOO_MANY_LINES', 'Too many lines on one bill.');
  await prisma.diningTable.update({
    where: { id: into.id },
    data: {
      items, status: items.length ? 'OCCUPIED' : 'FREE', boundOrderId: null, sentAt: null, payMode: 'TAG',
      ownerKey: into.ownerKey || from.ownerKey || actor.ownerKey,
      ownerLabel: into.ownerKey ? into.ownerLabel : (from.ownerKey ? from.ownerLabel : actor.ownerLabel),
      version: { increment: 1 },
    },
  });
  await prisma.diningTable.update({
    where: { id: from.id },
    data: { items: [], status: 'FREE', boundOrderId: null, sentAt: null, paidAt: null, ...NO_OWNER, lockedBy: null, lockLabel: null, lockedUntil: null, version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [from.id, into.id]);
  return dtoOf(await tableOf(merchantId, into.id));
}

/** Prices the table's bill from the catalogue now. */
async function pricedLines(t) {
  const products = await prisma.product.findMany({ where: { merchantId: t.merchantId, active: true } });
  try {
    return priceCart(products, linesOf(t).map((l) => ({ productId: l.productId, variants: l.variants || [], qty: l.qty })));
  } catch (e) {
    if (e instanceof CartPricingError) throw new TableError(409, e.code || 'CART_CHANGED', e.message);
    throw e;
  }
}

async function readyToCharge(merchantId, tableId, actor) {
  const t = await withLease(merchantId, tableId, actor);
  if (t.status === 'PAID') throw new TableError(409, 'ALREADY_PAID', 'This table has paid. Clear it first.');
  if (!linesOf(t).length) throw new TableError(409, 'EMPTY_BILL', 'Add something to the bill first.');
  // Generating again replaces an earlier, unpaid bill (e.g. the tag one).
  if (t.status === 'READY') await cancelBoundOrder(t);
  return t;
}

/**
 * "Generate bill → Pay here" on a waiter's POS: a normal terminal payment
 * (QR, tap, Bluetooth) for the table's bill, on this device. The table is Paid
 * when it settles. Returns the same payment fields as POST /me/payments.
 */
export async function chargeOnTerminal(merchantId, tableId, actor, body = {}) {
  if (actor.kind !== 'device' || !actor.device) throw new TableError(400, 'DEVICE_ONLY', 'Pay here is for a POS device.');
  requireTapPay();
  const t = await readyToCharge(merchantId, tableId, actor);
  const priced = await pricedLines(t);
  let created;
  try {
    created = await createPayment({
      device: actor.device,
      billCents: priced.subtotalCents,
      items: priced.lines.map((l) => ({ name: l.name, price: l.unitCents / 100, quantity: l.qty, qty: l.qty, productId: l.productId })),
      terminalEphemeralPub: body.terminalEphemeralPub,
      bleSessionId: body.bleSessionId,
    });
  } catch (e) {
    if (e instanceof TapPayError) throw new TableError(e.status, e.code, e.message);
    throw e;
  }
  const updated = await prisma.diningTable.update({
    where: { id: t.id },
    data: { status: 'READY', payMode: 'TERMINAL', boundOrderId: created.order.id, sentAt: new Date(), ...ownerFor(t, actor), version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [t.id]);
  return {
    table: tableDto(updated, created.order),
    payment: {
      orderId: created.order.id,
      orderNumber: created.order.displayNumber,
      totalCents: priced.subtotalCents,
      feeCents: feeCentsOf(created.order),
      currency: 'AUD',
      intent: created.intent,
      link: created.link,
      expiresAt: created.expiresAt,
      ttlSeconds: created.ttlSeconds,
      dynk: created.dynk,
    },
  };
}

/**
 * Merchant: send a table's bill to a counter POS to collect it there (the same
 * order the Register creates, so that POS shows it like any counter bill).
 */
export async function chargeOnCounter(merchantId, tableId, actor, body = {}) {
  const terminalId = String(body.terminalId || '');
  const counter = terminalId ? await prisma.terminal.findFirst({ where: { merchantId, terminalId } }) : null;
  if (!counter) throw new TableError(404, 'COUNTER_NOT_FOUND', 'Pick one of your counters.');
  const t = await readyToCharge(merchantId, tableId, actor);
  const priced = await pricedLines(t);
  const res = await fetch(`http://127.0.0.1:${PORT}/api/orders`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json', 'x-merchant-id': merchantId },
    body: JSON.stringify({
      terminalId, merchantId,
      amountAUD: (priced.subtotalCents / 100).toFixed(2),
      items: priced.lines.map((l) => ({ name: `${l.name}`, price: l.unitCents / 100, quantity: l.qty, qty: l.qty, productId: l.productId })),
    }),
  });
  const json = await res.json().catch(() => ({}));
  const orderId = json.orderId || json.order?.id || json.id;
  if (!res.ok || !orderId) throw new TableError(res.status >= 400 ? res.status : 502, json.error || 'CREATE_FAILED', json.message || 'The bill could not be sent to that counter.');
  const order = await prisma.order.findUnique({ where: { id: orderId } });
  const updated = await prisma.diningTable.update({
    where: { id: t.id },
    data: { status: 'READY', payMode: 'COUNTER', boundOrderId: orderId, sentAt: new Date(), ...ownerFor(t, actor), version: { increment: 1 } },
  });
  await tablesChanged(merchantId, [t.id]);
  return { table: tableDto(updated, order), orderId, counter: { terminalId, label: counter.label } };
}

// ── Price hold and payment watch ─────────────────────────────────────────

/**
 * Brings one READY table up to date with its order: PAID once settled, and a
 * new quote (new order, new hold) once the hold lapsed unpaid. Returns the
 * fresh table + order, or null when nothing changed.
 */
async function reconcile(t, order) {
  if (t.status !== 'READY') return null;
  if (order && SETTLED_STATUSES.includes(order.status)) {
    const updated = await prisma.diningTable.update({
      where: { id: t.id },
      data: { status: 'PAID', paidAt: new Date(), lockedBy: null, lockLabel: null, lockedUntil: null, version: { increment: 1 } },
    });
    return { table: updated, order };
  }
  if (order && (BUSY_STATUSES.includes(order.status) || order.paymentLock)) return null;
  const lapsed = !order || !OPEN_STATUSES.includes(order.status) || new Date(order.quoteExpiresAt).getTime() <= Date.now();
  if (!lapsed) return null;
  // A bill being paid on a POS isn't re-quoted: when it lapses the table goes back
  // to Occupied and the waiter generates the bill again.
  if ((t.payMode || 'TAG') !== 'TAG') {
    const r = await prisma.diningTable.updateMany({
      where: { id: t.id, status: 'READY', boundOrderId: t.boundOrderId },
      data: { status: 'OCCUPIED', payMode: 'TAG', boundOrderId: null, sentAt: null, version: { increment: 1 } },
    });
    return r.count ? { table: await prisma.diningTable.findUnique({ where: { id: t.id } }), order: null } : null;
  }
  if (!tapPay.ready) return null;
  if (order && OPEN_STATUSES.includes(order.status)) {
    await prisma.order.updateMany({ where: { id: order.id, status: { in: ['QUOTED', 'DEVICE_ARMED', 'WAITING_FOR_CUSTOMER'] }, paymentLock: null }, data: { status: 'EXPIRED' } });
    publishOrderEvent(order.id, { status: 'EXPIRED' });
  }
  try {
    const { order: fresh } = await issueTableOrder(t);
    // Only rebind if nobody changed the table meanwhile.
    const r = await prisma.diningTable.updateMany({
      where: { id: t.id, status: 'READY', boundOrderId: t.boundOrderId },
      data: { boundOrderId: fresh.id, version: { increment: 1 } },
    });
    if (!r.count) {
      await prisma.order.updateMany({ where: { id: fresh.id, status: 'QUOTED' }, data: { status: 'CANCELLED' } });
      return null;
    }
    return { table: await prisma.diningTable.findUnique({ where: { id: t.id } }), order: fresh };
  } catch (e) {
    // Bill no longer priceable (product removed): the tag goes idle, staff see it as occupied.
    if (e instanceof TableError && e.status === 409) {
      const updated = await prisma.diningTable.update({ where: { id: t.id }, data: { status: 'OCCUPIED', boundOrderId: null, sentAt: null, version: { increment: 1 } } });
      return { table: updated, order: null };
    }
    console.warn('[tables] re-quote:', e.message);
    return null;
  }
}

/** Background sweep (every few seconds): payments landing and price holds lapsing. */
export async function sweepTables() {
  const changed = new Map();
  const mark = (merchantId, id) => {
    if (!changed.has(merchantId)) changed.set(merchantId, []);
    changed.get(merchantId).push(id);
  };
  // Auto-clear: Paid tables past the merchant's clear-down time (skipped while someone is editing).
  const paid = await prisma.diningTable.findMany({ where: { status: 'PAID', paidAt: { not: null } }, take: 200 });
  if (paid.length) {
    const ms = await prisma.merchant.findMany({ where: { id: { in: [...new Set(paid.map((t) => t.merchantId))] }, tableAutoClearMinutes: { not: null } }, select: { id: true, tableAutoClearMinutes: true } });
    const minutes = new Map(ms.map((m) => [m.id, m.tableAutoClearMinutes]));
    const now = Date.now();
    for (const t of paid) {
      const m = minutes.get(t.merchantId);
      if (!m || new Date(t.paidAt).getTime() + m * 60_000 > now || lockActive(t, now)) continue;
      const r = await prisma.diningTable.updateMany({
        where: { id: t.id, status: 'PAID', version: t.version },
        data: { status: 'FREE', items: [], boundOrderId: null, sentAt: null, paidAt: null, ...NO_OWNER, groupClaimTag: null, groupClaimUntil: null, version: { increment: 1 } },
      });
      if (r.count) mark(t.merchantId, t.id);
    }
  }
  const ready = await prisma.diningTable.findMany({ where: { status: 'READY' }, take: 200 });
  const orders = await ordersFor(ready);
  for (const t of ready) {
    const r = await reconcile(t, orders.get(t.boundOrderId));
    if (r) mark(t.merchantId, t.id);
  }
  for (const [merchantId, ids] of changed) await tablesChanged(merchantId, ids);
}

// ── Customer tap (public) ────────────────────────────────────────────────

/**
 * What a customer tapping a tag gets. READY carries the order id and signed
 * intent (same as a QR); the other states are view-only.
 */
export async function resolveTag(code) {
  const tagCode = normalizeTagCode(code);
  let t = tagCode ? await prisma.diningTable.findUnique({ where: { tagCode } }) : null;
  if (!t) return { state: 'UNKNOWN', message: 'This tag is not linked to a table.' };
  // Tag health: when this tag was last tapped (throttled to one write a minute).
  if (!t.lastTappedAt || Date.now() - new Date(t.lastTappedAt).getTime() > 60_000) {
    await prisma.diningTable.update({ where: { id: t.id }, data: { lastTappedAt: new Date() } }).catch(() => {});
  }
  const tapped = t;
  let group = null;
  // Connected tables: the bill lives on the group's first table, and the first tag tapped holds it.
  const leaderId = t.groupLeaderId || t.id;
  const groupRows = await prisma.diningTable.findMany({ where: { OR: [{ id: leaderId }, { groupLeaderId: leaderId }] } });
  if (groupRows.length > 1) {
    const leader = groupRows.find((x) => x.id === leaderId);
    group = groupOf(leader, groupRows);
    const d = claimDecision(leader, tapped.tagCode);
    if (!d.allowed) {
      const by = groupRows.find((x) => x.tagCode === d.by);
      const merchant0 = await prisma.merchant.findUnique({ where: { id: t.merchantId } });
      return {
        state: 'PROCESSING',
        merchant: { name: merchant0?.tradingName || 'Merchant', logoUrl: null },
        table: { name: group.names.join(' + ') },
        group: { name: group.name, tables: group.names, payingAt: by ? by.name : null },
        message: `This group's bill is being paid from ${by ? (/^\d+$/.test(by.name) ? `Table ${by.name}` : by.name) : 'another table'}'s tag.`,
      };
    }
    if (d.claim && !(leader.status === 'PAID')) {
      await prisma.diningTable.update({ where: { id: leader.id }, data: { groupClaimTag: tapped.tagCode, groupClaimUntil: new Date(Date.now() + TABLE_HOLD_MINUTES * 60_000) } });
      if (leader.groupClaimTag !== tapped.tagCode) await tablesChanged(t.merchantId, group.tableIds);
    }
    t = leader;
  }
  const merchant = await prisma.merchant.findUnique({ where: { id: t.merchantId }, include: { profile: true } });
  const logo = merchant?.profile?.logoUrl || null;
  const base = {
    merchant: {
      name: merchant?.tradingName || 'Merchant',
      logoUrl: logo && /^https?:\/\//.test(logo) ? logo : (logo ? `${payBase()}${logo.startsWith('/') ? '' : '/'}${logo}` : null),
    },
    // "Table 1 + 2 + 3" on the customer screens; the group's own name travels as group.name.
    table: { name: group ? group.names.join(' + ') : t.name },
    ...(group ? { group: { name: group.name, tables: group.names, payingAt: tapped.name } } : {}),
  };
  let table = t;
  let order = t.boundOrderId ? await prisma.order.findUnique({ where: { id: t.boundOrderId } }) : null;
  if (table.status === 'READY') {
    const r = await reconcile(table, order);
    if (r) {
      table = r.table;
      order = r.order;
      await tablesChanged(t.merchantId, [t.id]);
    }
  }
  const items = linesOf(table).map((l) => ({ name: l.name, qty: l.qty, unitCents: l.unitCents, lineCents: l.unitCents * l.qty }));
  const sub = subtotalCents(linesOf(table));
  if (table.status === 'FREE') return { state: 'FREE', ...base, message: 'Nothing to pay yet.' };
  if (table.status === 'OCCUPIED') return { state: 'OCCUPIED', ...base, items, subtotalCents: sub, message: 'Your server will send the bill when you are ready to pay.' };
  if (table.status === 'PAID') {
    return {
      state: 'PAID', ...base, items, subtotalCents: sub,
      receipt: order ? {
        orderId: order.id, orderNumber: order.displayNumber,
        totalCents: Math.round(parseFloat(String(order.totalAUD)) * 100), paidAt: table.paidAt,
      } : null,
    };
  }
  // READY
  if (!order) return { state: 'OCCUPIED', ...base, items, subtotalCents: sub, message: 'Your bill is being updated. Tap again in a moment.' };
  if ((table.payMode || 'TAG') !== 'TAG') return { state: 'OCCUPIED', ...base, items, subtotalCents: sub, message: 'Your server is taking payment for this table on their device.' };
  if (BUSY_STATUSES.includes(order.status)) return { state: 'PROCESSING', ...base, items, subtotalCents: sub, orderId: order.id, message: 'A payment for this table is in progress.' };
  let intent = null;
  try { intent = await currentIntent(order.id); } catch { /* lapsed between checks */ }
  if (!intent) return { state: 'OCCUPIED', ...base, items, subtotalCents: sub, message: 'Your bill is being updated. Tap again in a moment.' };
  return {
    state: 'READY', ...base, items, subtotalCents: sub,
    order: {
      id: order.id,
      orderNumber: order.displayNumber,
      totalCents: Math.round(parseFloat(String(order.totalAUD)) * 100),
      feeCents: feeCentsOf(order),
      intent: intent.intent,
      link: intent.link,
      expiresAt: intent.expiresAt,
    },
  };
}
