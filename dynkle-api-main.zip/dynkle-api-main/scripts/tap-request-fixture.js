// Tap request v2 (spec v6 02 §4.2): a signed intent, the backend-built
// transaction, the signed tap quote and the exact NFC PUT_REQUEST / PUT_DECLINE
// payloads, from the backend's real code. The DYNK app (request check) and the
// terminal (chunking) test against this file. Fixed label-derived test keys,
// no network (stub blockhash).
//   node scripts/tap-request-fixture.js --write   -> tests/fixtures/tap-request-v2.json
import crypto from 'crypto';
import fs from 'fs';
import { Keypair, PublicKey } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { buildDirectTransaction, sha256Hex } from '../src/tappay/chain.js';
import { signIntent, toBase64Url } from '../src/tappay/intent.js';
import { signTapQuote, signDecline } from '../src/tappay/crypto.js';
import { encodeTapRequest, encodeDecline } from '../src/tappay/tapRequest.js';
import { ed25519FromSeed } from '../src/tappay/keystore.js';

const seed = (l) => crypto.createHash('sha256').update(`dynkle-tap-request-v2:${l}`).digest();
const kp = (l) => Keypair.fromSeed(seed(l));
const pk = (l) => kp(l).publicKey.toBase58();

export async function tapRequestFixture() {
  const key = ed25519FromSeed(seed('intent-key'));
  const signer = { kid: 1, privateKey: key.privateKey };
  const customer = pk('customer');
  const orderId = '6f1c2a3b-4d5e-4f60-8172-839405a6b7c8';
  const expiresAt = 1_791_000_000;
  const fields = {
    kid: 1, orderId, orderNumber: 1042, itemCount: 2, terminalId: '0a1b2c3d-4e5f-4061-8273-94a5b6c7d8e9',
    merchantWallet: pk('merchant'), mint: pk('dynk-mint'), amount: 83_333_333_334n, decimals: 9,
    fiatAmount: 1250n, currency: 'AUD', reference: pk('reference'), expiresAt,
    bleSessionId: seed('ble-session').subarray(0, 8), terminalEphemeralPub: seed('terminal-eph').subarray(0, 32),
    merchantName: 'Reels Coffee',
  };
  const intent = signIntent(fields, key.privateKey);
  const connection = { getLatestBlockhash: async () => ({ blockhash: new PublicKey(seed('blockhash')).toBase58(), lastValidBlockHeight: 1000 }) };
  const sponsor = kp('sponsor');
  const fee = 66_667n;
  const built = await buildDirectTransaction({
    connection, sponsor, customer, mint: fields.mint, tokenProgram: TOKEN_PROGRAM_ID, decimals: 9,
    merchant: fields.merchantWallet, amount: fields.amount, feeCollector: pk('fee-collector'), fee,
    reference: fields.reference, computeUnitLimit: 120_000, priorityFeeMicroLamports: 1000,
  });
  const tapQuote = signTapQuote({
    orderId, quoteId: '1b9d6bcd-bbfd-4b2d-9b5d-ab8dfbbd4bed', messageHash: sha256Hex(built.messageBytes),
    fee: fee.toString(), expiresAt: new Date(expiresAt * 1000).toISOString(),
  }, signer);
  const decline = signDecline({ orderId, customerPubkey: customer, reason: 'INSUFFICIENT', declinedAt: '2026-10-09T10:00:00.000Z' }, signer);
  return {
    description: 'Tap request v2 from the Dynkle backend (test keys only): NFC PUT_REQUEST / PUT_DECLINE payloads.',
    intentPublicKey: key.publicKeyRaw.toString('base64'),
    customer, gasSponsor: sponsor.publicKey.toBase58(), feeCollector: pk('fee-collector'), dynkMint: fields.mint,
    intent: toBase64Url(intent),
    transaction: built.unsignedTx.toString('base64'),
    tapQuote,
    request: encodeTapRequest({ intent, tapQuote, transaction: built.unsignedTx }).toString('base64'),
    decline,
    declineBytes: encodeDecline(decline).toString('base64'),
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const json = JSON.stringify(await tapRequestFixture(), null, 2) + '\n';
  if (process.argv.includes('--write')) {
    fs.writeFileSync(new URL('../tests/fixtures/tap-request-v2.json', import.meta.url), json);
    console.log('wrote tests/fixtures/tap-request-v2.json');
  } else process.stdout.write(json);
}
