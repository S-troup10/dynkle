#!/usr/bin/env node
// Tap-and-pay key tool. Never prints or logs secret material.
//
// The passphrase is read from TAP_PAY_KEYSTORE_PASSPHRASE (never a CLI
// argument, so it stays out of shell history).
//
//   node scripts/tappay-keygen.js init   --out keys/tappay.keystore.json
//   node scripts/tappay-keygen.js rotate --file keys/tappay.keystore.json --kid 2
//   node scripts/tappay-keygen.js show   --file keys/tappay.keystore.json
//
// `show` prints the intent PUBLIC keys (pin these in the DYNK app, keyed by
// kid) and the gas sponsor address (fund it with a little SOL).

import crypto from 'crypto';
import fs from 'fs';
import path from 'path';
import { Keypair } from '@solana/web3.js';
import { encryptKeystore, decryptKeystore, ed25519FromSeed } from '../src/tappay/keystore.js';

const [cmd, ...rest] = process.argv.slice(2);
const arg = (name) => { const i = rest.indexOf(`--${name}`); return i >= 0 ? rest[i + 1] : undefined; };
const passphrase = process.env.TAP_PAY_KEYSTORE_PASSPHRASE;

function die(msg) { console.error(msg); process.exit(1); }
function write(file, plain) {
  fs.mkdirSync(path.dirname(path.resolve(file)), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(encryptKeystore(plain, passphrase), null, 2), { mode: 0o600 });
}
function show(plain) {
  console.log('Intent public keys (Ed25519, base64; pin in the DYNK app by kid):');
  for (const k of plain.intentKeys) {
    const pub = ed25519FromSeed(Buffer.from(k.seed, 'base64')).publicKeyRaw.toString('base64');
    console.log(`  kid ${k.kid}${k.kid === plain.activeKid ? ' (active)' : ''}: ${pub}`);
  }
  const sponsor = Keypair.fromSecretKey(Uint8Array.from(Buffer.from(plain.sponsorSecretKey, 'base64')));
  console.log(`Gas sponsor address: ${sponsor.publicKey.toBase58()}`);
}

if (!passphrase) die('Set TAP_PAY_KEYSTORE_PASSPHRASE first.');

try {
if (cmd === 'init') {
  const out = arg('out') || die('--out <file> is required');
  if (fs.existsSync(out)) die(`${out} already exists; use rotate.`);
  const plain = {
    activeKid: 1,
    intentKeys: [{ kid: 1, seed: crypto.randomBytes(32).toString('base64'), createdAt: new Date().toISOString() }],
    sponsorSecretKey: Buffer.from(Keypair.generate().secretKey).toString('base64'),
  };
  write(out, plain);
  console.log(`Wrote ${out} (mode 600).`);
  show(plain);
} else if (cmd === 'rotate') {
  const file = arg('file') || die('--file <file> is required');
  const kid = Number(arg('kid'));
  if (!Number.isInteger(kid) || kid < 0 || kid > 255) die('--kid must be 0-255');
  const plain = decryptKeystore(JSON.parse(fs.readFileSync(file, 'utf8')), passphrase);
  if (plain.intentKeys.some((k) => k.kid === kid)) die(`kid ${kid} already exists.`);
  plain.intentKeys.push({ kid, seed: crypto.randomBytes(32).toString('base64'), createdAt: new Date().toISOString() });
  plain.activeKid = kid; // older kids stay, so intents already issued still verify
  write(file, plain);
  console.log(`Added kid ${kid} and made it active.`);
  show(plain);
} else if (cmd === 'show') {
  const file = arg('file') || die('--file <file> is required');
  show(decryptKeystore(JSON.parse(fs.readFileSync(file, 'utf8')), passphrase));
} else {
  die('Usage: tappay-keygen.js init --out <file> | rotate --file <file> --kid <n> | show --file <file>');
}
} catch (e) {
  die(e.message); // messages never contain key material
}
