// Dynkle Bluetooth protocol v1 (spec 02 §5): reference implementation and
// golden vectors. The FP9810 terminal (Kotlin) and the DYNK app (TypeScript)
// must both reproduce tests/fixtures/ble-v1.json byte for byte.
//
//   node scripts/ble-golden-vectors.js --write
//
// ── Wire format ──────────────────────────────────────────────────────────
// GATT value (rx write / tx notify):  msgId u8 | index u8 | total u8 | chunk
//   chunk <= ATT MTU - 3 - 3 bytes; a message is the chunks of one msgId in order.
// Message:
//   HELLO (phone -> terminal, clear):  0x01 | phoneEphemeralPub 32 | bleSessionId 8
//   SEALED (both ways):                0x02 | ChaCha20-Poly1305(key, nonce, plaintext, aad = bleSessionId)
//     plaintext = type u8 | JSON (UTF-8)
//     nonce     = direction u8 (0x01 phone->terminal, 0x02 terminal->phone) | 00 00 00 | counter u64 LE
//     counters start at 0 per direction; a receiver accepts exactly the next one
//     (replays and gaps are refused and end the session).
//   key = HKDF-SHA256(ikm = X25519(own eph, peer eph), salt = bleSessionId, info = "dynkle-ble-v1", 32 B)
// Types (inside SEALED):
//   0x11 MERCHANT_DISPLAY  T->P {merchantName, location}
//   0x12 PUBKEY            P->T {customerPubkey, phoneEphemeralPub, phoneOnline}   (Swap and Pay only if online, Case 1)
//   0x13 PRECHECK_RESULT   T->P {result: OK|SWAP_OFFER (Case 1 only)|INSUFFICIENT, fee, private, expiresAt}
//   0x14 BUILD_REQUEST     P->T {option: DIRECT|SWAP (Case 1 only)}
//   0x15 TX_TO_SIGN        T->P {quoteId, option, transaction, expiresAt}
//   0x16 SIGNATURE         P->T {signature, quoteId}            (QR / Swap and Pay)
//                               {signature, customerPubkey, tap: true, phoneOnline}   (tap signature delivered late)
//   0x17 STATUS            T->P {status: PROCESSING|CONFIRMED|DECLINED|FAILED, reason?, decline?, code?, txSignature?}
//                               (also the result channel after a tap, Cases 3-4; DECLINED never offers Swap and Pay)
//   0x18 RECEIPT           T->P {receipt}                         (Dynkle-signed)
//   0x7E ERROR             both {code, message}
//   0x7F BYE               both {reason?}                         (DECLINED = customer declined)

import crypto from 'crypto';
import fs from 'fs';

export const T = { HELLO: 0x01, SEALED: 0x02, MERCHANT_DISPLAY: 0x11, PUBKEY: 0x12, PRECHECK_RESULT: 0x13, BUILD_REQUEST: 0x14, TX_TO_SIGN: 0x15, SIGNATURE: 0x16, STATUS: 0x17, RECEIPT: 0x18, ERROR: 0x7e, BYE: 0x7f };
export const DIR = { PHONE_TO_TERMINAL: 0x01, TERMINAL_TO_PHONE: 0x02 };

const X_PKCS8 = Buffer.from('302e020100300506032b656e04220420', 'hex');
const X_SPKI = Buffer.from('302a300506032b656e032100', 'hex');
const priv = (seed) => crypto.createPrivateKey({ key: Buffer.concat([X_PKCS8, seed]), format: 'der', type: 'pkcs8' });
const pubRaw = (k) => Buffer.from(crypto.createPublicKey(k).export({ format: 'der', type: 'spki' }).subarray(-32));
const pubKey = (raw) => crypto.createPublicKey({ key: Buffer.concat([X_SPKI, raw]), format: 'der', type: 'spki' });

export function sessionKey(ownPriv, peerPubRaw, bleSessionId) {
  const shared = crypto.diffieHellman({ privateKey: ownPriv, publicKey: pubKey(peerPubRaw) });
  return Buffer.from(crypto.hkdfSync('sha256', shared, bleSessionId, Buffer.from('dynkle-ble-v1'), 32));
}

export function nonce(direction, counter) {
  const n = Buffer.alloc(12);
  n[0] = direction;
  n.writeBigUInt64LE(BigInt(counter), 4);
  return n;
}

export function seal(key, direction, counter, type, body, bleSessionId) {
  const plain = Buffer.concat([Buffer.from([type]), Buffer.from(JSON.stringify(body), 'utf8')]);
  const c = crypto.createCipheriv('chacha20-poly1305', key, nonce(direction, counter), { authTagLength: 16 });
  c.setAAD(bleSessionId, { plaintextLength: plain.length });
  return Buffer.concat([Buffer.from([T.SEALED]), c.update(plain), c.final(), c.getAuthTag()]);
}

export function open(key, direction, counter, wire, bleSessionId) {
  if (wire[0] !== T.SEALED) throw new Error('NOT_SEALED');
  const body = wire.subarray(1);
  const d = crypto.createDecipheriv('chacha20-poly1305', key, nonce(direction, counter), { authTagLength: 16 });
  d.setAAD(bleSessionId, { plaintextLength: body.length - 16 });
  d.setAuthTag(body.subarray(body.length - 16));
  const plain = Buffer.concat([d.update(body.subarray(0, body.length - 16)), d.final()]);
  return { type: plain[0], body: JSON.parse(plain.subarray(1).toString('utf8')) };
}

export function frames(msgId, message, mtu) {
  const max = mtu - 3 - 3;
  const total = Math.max(1, Math.ceil(message.length / max));
  if (total > 255) throw new Error('TOO_LONG');
  return Array.from({ length: total }, (_, i) => Buffer.concat([Buffer.from([msgId, i, total]), message.subarray(i * max, (i + 1) * max)]));
}

export function goldenVectors() {
  const seed = (l) => crypto.createHash('sha256').update(`dynkle-ble-golden-v1:${l}`).digest();
  const terminal = priv(seed('terminal-eph'));
  const phone = priv(seed('phone-eph'));
  const bleSessionId = seed('ble-session').subarray(0, 8);
  const key = sessionKey(terminal, pubRaw(phone), bleSessionId);
  const keyFromPhone = sessionKey(phone, pubRaw(terminal), bleSessionId);
  if (!key.equals(keyFromPhone)) throw new Error('key mismatch');
  const hello = Buffer.concat([Buffer.from([T.HELLO]), pubRaw(phone), bleSessionId]);
  const script = [
    [DIR.TERMINAL_TO_PHONE, 0, T.MERCHANT_DISPLAY, { merchantName: 'Bean & Brew Café', location: '1 George St, Sydney' }],
    [DIR.PHONE_TO_TERMINAL, 0, T.PUBKEY, { customerPubkey: '9xQeWvG816bUx9EPjHmaT23yvVM2ZWbrrpZb9PusVFin', phoneEphemeralPub: Buffer.alloc(32, 7).toString('base64') }],
    [DIR.TERMINAL_TO_PHONE, 1, T.PRECHECK_RESULT, { result: 'OK', fee: { baseUnits: '66667', fiatCents: 2, currency: 'AUD' }, private: { v: 1, epk: 'AA==', nonce: 'AA==', ct: 'AA==' }, expiresAt: '2026-10-08T10:02:00.000Z' }],
    [DIR.PHONE_TO_TERMINAL, 1, T.BUILD_REQUEST, { option: 'DIRECT' }],
    [DIR.TERMINAL_TO_PHONE, 2, T.TX_TO_SIGN, { quoteId: '2b1f0c2e-1d3e-4f5a-8b6c-7d8e9f0a1b2c', option: 'DIRECT', transaction: Buffer.alloc(300, 1).toString('base64'), expiresAt: '2026-10-08T10:02:00.000Z' }],
    [DIR.PHONE_TO_TERMINAL, 2, T.SIGNATURE, { signature: Buffer.alloc(64, 9).toString('base64'), quoteId: '2b1f0c2e-1d3e-4f5a-8b6c-7d8e9f0a1b2c' }],
    [DIR.TERMINAL_TO_PHONE, 3, T.STATUS, { status: 'PROCESSING' }],
    [DIR.TERMINAL_TO_PHONE, 4, T.STATUS, { status: 'DECLINED', reason: 'INSUFFICIENT' }],
    [DIR.PHONE_TO_TERMINAL, 3, T.BYE, { reason: 'DECLINED' }],
  ];
  const messages = script.map(([direction, counter, type, body]) => {
    const wire = seal(key, direction, counter, type, body, bleSessionId);
    const back = open(key, direction, counter, wire, bleSessionId);
    if (back.type !== type) throw new Error('round trip');
    return { direction, counter, type, json: JSON.stringify(body), wireHex: wire.toString('hex') };
  });
  const big = Buffer.from(messages[4].wireHex, 'hex');
  return {
    description: 'Dynkle BLE protocol v1 golden vectors (dynkle-payments-spec 02 §5; format in scripts/ble-golden-vectors.js). Test keys only.',
    terminalEphemeralPrivateHex: seed('terminal-eph').toString('hex'),
    terminalEphemeralPubHex: pubRaw(terminal).toString('hex'),
    phoneEphemeralPrivateHex: seed('phone-eph').toString('hex'),
    phoneEphemeralPubHex: pubRaw(phone).toString('hex'),
    bleSessionIdHex: bleSessionId.toString('hex'),
    sessionKeyHex: key.toString('hex'),
    helloHex: hello.toString('hex'),
    messages,
    chunking: { msgId: 42, mtu: 23, messageIndex: 4, framesHex: frames(42, big, 23).map((f) => f.toString('hex')) },
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const json = JSON.stringify(goldenVectors(), null, 2) + '\n';
  if (process.argv.includes('--write')) {
    fs.writeFileSync(new URL('../tests/fixtures/ble-v1.json', import.meta.url), json);
    console.log('wrote tests/fixtures/ble-v1.json');
  } else process.stdout.write(json);
}
