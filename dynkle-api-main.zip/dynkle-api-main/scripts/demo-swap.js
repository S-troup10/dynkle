#!/usr/bin/env node
// Sets up the local demo stand-in for Swap and Pay (src/tappay/demoSwap.js). Devnet only.
//
//   node scripts/demo-swap.js init                       demo wallet, demo USDC mint, vault + treasury accounts
//   node scripts/demo-swap.js status                     addresses and balances
//   node scripts/demo-swap.js mint-usdc <wallet> <amount> give a customer demo USDC
//
// The demo wallet pays its own fees: fund it with devnet SOL (init prints the address).
// The vault needs DYNK: send DYNK to the vault address from any wallet that holds some.
// Prints public addresses only.
import 'dotenv/config';
import fs from 'fs';
import path from 'path';
import { Connection, Keypair, LAMPORTS_PER_SOL, PublicKey, Transaction, sendAndConfirmTransaction } from '@solana/web3.js';
import {
  TOKEN_PROGRAM_ID, createAssociatedTokenAccountIdempotentInstruction, createMint, getAssociatedTokenAddressSync,
  createMintToCheckedInstruction,
} from '@solana/spl-token';
import { demoSwapKeyPath, DEMO_USDC_DECIMALS } from '../src/tappay/demoSwap.js';

const env = process.env;
const rpc = env.SOLANA_RPC || 'https://api.devnet.solana.com';
if (!/devnet|localhost|127\.0\.0\.1/.test(rpc)) { console.error('Refusing: the demo swap is for devnet only.'); process.exit(1); }
const connection = new Connection(rpc, 'confirmed');
const dynkMint = new PublicKey(env.DYNK_MINT_ADDRESS);

function loadOrCreateWallet() {
  const file = demoSwapKeyPath(env);
  if (fs.existsSync(file)) return Keypair.fromSecretKey(Uint8Array.from(JSON.parse(fs.readFileSync(file, 'utf8'))));
  const kp = Keypair.generate();
  fs.mkdirSync(path.dirname(file), { recursive: true });
  fs.writeFileSync(file, JSON.stringify(Array.from(kp.secretKey)), { mode: 0o600 });
  console.log(`Created the demo wallet (${path.relative(process.cwd(), file)}, not committed).`);
  return kp;
}

async function dynkProgram() {
  const info = await connection.getAccountInfo(dynkMint);
  if (!info) throw new Error('DYNK mint not found on this cluster');
  return info.owner;
}

async function addresses(wallet) {
  const program = await dynkProgram();
  const vault = getAssociatedTokenAddressSync(dynkMint, wallet.publicKey, false, program);
  const usdcMint = env.DEMO_SWAP_USDC_MINT ? new PublicKey(env.DEMO_SWAP_USDC_MINT) : null;
  const treasury = usdcMint ? getAssociatedTokenAddressSync(usdcMint, wallet.publicKey, false, TOKEN_PROGRAM_ID) : null;
  return { program, vault, usdcMint, treasury };
}

const balance = (acct) => connection.getTokenAccountBalance(acct).then((r) => r.value.uiAmountString).catch(() => '0 (no account yet)');

async function init() {
  const wallet = loadOrCreateWallet();
  const sol = await connection.getBalance(wallet.publicKey);
  if (sol < 0.02 * LAMPORTS_PER_SOL) {
    console.log(`Fund the demo wallet first, then run init again:\n  solana transfer ${wallet.publicKey.toBase58()} 0.2 -u devnet --allow-unfunded-recipient -k <a funded devnet keypair>`);
    process.exit(2);
  }
  let usdcMint = env.DEMO_SWAP_USDC_MINT ? new PublicKey(env.DEMO_SWAP_USDC_MINT) : null;
  if (!usdcMint) {
    usdcMint = await createMint(connection, wallet, wallet.publicKey, null, DEMO_USDC_DECIMALS);
    console.log(`Created the demo USDC mint. Add to .env:\n  DEMO_SWAP_USDC_MINT=${usdcMint.toBase58()}`);
  }
  const program = await dynkProgram();
  const vault = getAssociatedTokenAddressSync(dynkMint, wallet.publicKey, false, program);
  const treasury = getAssociatedTokenAddressSync(usdcMint, wallet.publicKey, false, TOKEN_PROGRAM_ID);
  const tx = new Transaction().add(
    createAssociatedTokenAccountIdempotentInstruction(wallet.publicKey, vault, wallet.publicKey, dynkMint, program),
    createAssociatedTokenAccountIdempotentInstruction(wallet.publicKey, treasury, wallet.publicKey, usdcMint, TOKEN_PROGRAM_ID),
  );
  await sendAndConfirmTransaction(connection, tx, [wallet]);
  console.log(`Demo wallet:   ${wallet.publicKey.toBase58()}`);
  console.log(`DYNK vault:    ${vault.toBase58()}  (send DYNK here: to the wallet address above)`);
  console.log(`USDC treasury: ${treasury.toBase58()}`);
}

async function status() {
  const wallet = loadOrCreateWallet();
  const a = await addresses(wallet);
  console.log(`Demo wallet:     ${wallet.publicKey.toBase58()}  SOL ${(await connection.getBalance(wallet.publicKey)) / LAMPORTS_PER_SOL}`);
  console.log(`DYNK vault:      ${a.vault.toBase58()}  DYNK ${await balance(a.vault)}`);
  console.log(`Demo USDC mint:  ${a.usdcMint?.toBase58() || '(not set: run init)'}`);
  if (a.treasury) console.log(`USDC treasury:   ${a.treasury.toBase58()}  USDC ${await balance(a.treasury)}`);
  console.log(`Active in the backend: ${env.DEMO_MODE === 'true' && a.usdcMint ? 'yes (DEMO_MODE=true)' : 'no (needs DEMO_MODE=true and DEMO_SWAP_USDC_MINT)'}`);
}

async function mintUsdc(to, amount) {
  if (!to || !(Number(amount) > 0)) { console.error('Usage: mint-usdc <wallet> <amount>'); process.exit(1); }
  const wallet = loadOrCreateWallet();
  const usdcMint = new PublicKey(env.DEMO_SWAP_USDC_MINT);
  const owner = new PublicKey(to);
  const ata = getAssociatedTokenAddressSync(usdcMint, owner, false, TOKEN_PROGRAM_ID);
  const units = BigInt(Math.round(Number(amount) * 10 ** DEMO_USDC_DECIMALS));
  const tx = new Transaction().add(
    createAssociatedTokenAccountIdempotentInstruction(wallet.publicKey, ata, owner, usdcMint, TOKEN_PROGRAM_ID),
    createMintToCheckedInstruction(usdcMint, ata, wallet.publicKey, units, DEMO_USDC_DECIMALS, [], TOKEN_PROGRAM_ID),
  );
  const sig = await sendAndConfirmTransaction(connection, tx, [wallet]);
  console.log(`Minted ${amount} demo USDC to ${to} (tx ${sig}). Balance: ${await balance(ata)}`);
}

const [cmd, ...args] = process.argv.slice(2);
const run = { init, status, 'mint-usdc': () => mintUsdc(...args) }[cmd];
if (!run) { console.error('Commands: init | status | mint-usdc <wallet> <amount>'); process.exit(1); }
run().catch((e) => { console.error(e.message); process.exit(1); });
