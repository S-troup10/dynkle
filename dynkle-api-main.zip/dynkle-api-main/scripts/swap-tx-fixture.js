// A Swap and Pay transaction made by the backend's real builder
// (src/tappay/chain.js buildDirectTransaction with swap instructions shaped
// like the DYNK backend's quote), for the DYNK app's transaction-check tests.
// Fixed, label-derived test keys; no network (stub blockhash).
//   node scripts/swap-tx-fixture.js --write   -> tests/fixtures/swap-tx.json
import crypto from 'crypto';
import fs from 'fs';
import { Keypair, PublicKey } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, createTransferCheckedInstruction, getAssociatedTokenAddressSync } from '@solana/spl-token';
import { buildDirectTransaction } from '../src/tappay/chain.js';
import { signDecline } from '../src/tappay/crypto.js';
import { ed25519FromSeed } from '../src/tappay/keystore.js';

const seed = (l) => crypto.createHash('sha256').update(`dynkle-swap-fixture-v1:${l}`).digest();
const kp = (l) => Keypair.fromSeed(seed(l));
const pk = (l) => kp(l).publicKey;
const ix = (i) => ({ programId: i.programId.toBase58(), keys: i.keys.map((k) => ({ pubkey: k.pubkey.toBase58(), isSigner: k.isSigner, isWritable: k.isWritable })), data: Buffer.from(i.data).toString('base64') });

export async function swapFixture() {
  const customer = pk('customer');
  const dynkMint = pk('dynk-mint');
  const usdcMint = pk('usdc-mint');
  const vault = pk('vault');
  const delegate = pk('delegate');
  const treasury = pk('treasury');
  const terms = { usdcAmount: 15_000_000n, dynkAmount: 99_000_000_000n };
  const instructions = [
    ix(createTransferCheckedInstruction(getAssociatedTokenAddressSync(usdcMint, customer), usdcMint, treasury, customer, terms.usdcAmount, 6)),
    ix(createTransferCheckedInstruction(vault, dynkMint, getAssociatedTokenAddressSync(dynkMint, customer, true), delegate, terms.dynkAmount, 9)),
  ];
  const connection = { getLatestBlockhash: async () => ({ blockhash: new PublicKey(seed('blockhash')).toBase58(), lastValidBlockHeight: 1000 }) };
  const sponsor = kp('sponsor');
  const built = await buildDirectTransaction({
    connection, sponsor, customer: customer.toBase58(), mint: dynkMint.toBase58(), tokenProgram: TOKEN_PROGRAM_ID, decimals: 9,
    merchant: pk('merchant').toBase58(), amount: 100_000_000_000n, feeCollector: pk('fee-collector').toBase58(), fee: 66_667n,
    reference: pk('reference').toBase58(), computeUnitLimit: 120_000, priorityFeeMicroLamports: 1000, swapInstructions: instructions,
  });
  const key = ed25519FromSeed(seed('intent-key'));
  const decline = signDecline({
    orderId: '6f1c2a3b-4d5e-4f60-8172-839405a6b7c8', customerPubkey: customer.toBase58(), reason: 'INSUFFICIENT',
    declinedAt: '2026-10-08T10:00:00.000Z',
  }, { kid: 1, privateKey: key.privateKey });
  return {
    intentPublicKey: key.publicKeyRaw.toString('base64'),
    decline,
    description: 'Swap and Pay transaction from the Dynkle backend builder (test keys only). For the DYNK app txCheck tests.',
    transaction: built.unsignedTx.toString('base64'),
    customer: customer.toBase58(), gasSponsor: sponsor.publicKey.toBase58(), feeCollector: pk('fee-collector').toBase58(), fee: '66667',
    intent: { mint: dynkMint.toBase58(), decimals: 9, amount: '100000000000', merchantWallet: pk('merchant').toBase58(), reference: pk('reference').toBase58() },
    swap: {
      usdcMint: usdcMint.toBase58(), usdcAmount: terms.usdcAmount.toString(), dynkAmount: terms.dynkAmount.toString(),
      treasuryUsdcAccount: treasury.toBase58(), vault: vault.toBase58(), delegate: delegate.toBase58(),
    },
  };
}

if (import.meta.url === `file://${process.argv[1]}`) {
  const json = JSON.stringify(await swapFixture(), null, 2) + '\n';
  if (process.argv.includes('--write')) {
    fs.writeFileSync(new URL('../tests/fixtures/swap-tx.json', import.meta.url), json);
    console.log('wrote tests/fixtures/swap-tx.json');
  } else process.stdout.write(json);
}
