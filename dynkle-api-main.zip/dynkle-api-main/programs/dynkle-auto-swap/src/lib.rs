use anchor_lang::prelude::*;
use anchor_lang::solana_program::instruction::Instruction;
use anchor_lang::solana_program::program::invoke_signed;
use anchor_spl::token::{self, Mint, Token, TokenAccount};
use pyth_sdk_solana::load_price_feed_from_account_info;

declare_id!("DynkSwap11111111111111111111111111111111111");

pub const POLICY_SEED: &[u8] = b"swap_policy";
pub const BUCKET_AUTHORITY_SEED: &[u8] = b"bucket_authority";

// Whitelisted Jupiter v6 Program ID
pub const JUPITER_V6_PROGRAM_ID: &str = "JUP6LkbZbjS1jKKwapdHNy74zcZ3tLUZoi5QNyVTaV4";

#[program]
pub mod dynkle_auto_swap {
    use super::*;

    /// One-time merchant configuration of a bucket's auto-swap policy.
    /// Signs once to create or update the policy PDA.
    pub fn set_swap_policy(
        ctx: Context<SetSwapPolicy>,
        bucket_id: [u8; 32],
        whitelisted_router: Pubkey,
        allowed_discriminator: [u8; 8],
        max_slippage_bps: u16,
        dust_floor_amount: u64,
    ) -> Result<()> {
        require!(
            max_slippage_bps > 0 && max_slippage_bps <= 500,
            AutoSwapError::InvalidSlippageBps
        );

        let policy = &mut ctx.accounts.policy;
        policy.merchant = ctx.accounts.merchant.key();
        policy.bucket_id = bucket_id;
        policy.bucket_authority = ctx.accounts.bucket_authority.key();
        policy.bucket_destination = ctx.accounts.bucket_destination.key();
        policy.whitelisted_router = whitelisted_router;
        policy.allowed_discriminator = allowed_discriminator;
        policy.output_mint = ctx.accounts.output_mint.key();
        policy.pyth_price_feed = ctx.accounts.pyth_price_feed.key();
        policy.max_slippage_bps = max_slippage_bps;
        policy.dust_floor_amount = dust_floor_amount;
        policy.active = true;
        policy.bump = ctx.bumps.policy;
        policy.authority_bump = ctx.bumps.bucket_authority;

        emit!(PolicySetEvent {
            merchant: policy.merchant,
            bucket_id,
            router: whitelisted_router,
            output_mint: policy.output_mint,
            max_slippage_bps,
        });

        Ok(())
    }

    /// Revoke policy at any time. Callable ONLY by the merchant/bucket owner.
    /// Disables automation immediately and independently of any off-chain keeper.
    pub fn revoke_policy(ctx: Context<RevokePolicy>) -> Result<()> {
        let policy = &mut ctx.accounts.policy;
        require_keys_eq!(
            policy.merchant,
            ctx.accounts.merchant.key(),
            AutoSwapError::Unauthorized
        );

        policy.active = false;

        emit!(PolicyRevokedEvent {
            merchant: policy.merchant,
            bucket_id: policy.bucket_id,
        });

        Ok(())
    }

    /// Execute swap: Callable by ANYONE (keeper has zero special privilege).
    /// Enforces:
    /// 1. Policy is active.
    /// 2. Input amount >= dust_floor_amount.
    /// 3. CPI target is strictly the whitelisted router (Jupiter).
    /// 4. Output token account mint is strictly the pinned USDC mint.
    /// 5. Pyth oracle price cross-check: minimum expected output >= oracle - slippage cap.
    /// 6. Invokes CPI signed via the PDA authority seeds (never an off-chain private key).
    pub fn execute_swap<'a, 'b, 'c, 'info>(
        ctx: Context<'a, 'b, 'c, 'info, ExecuteSwap<'info>>,
        amount_in: u64,
        min_amount_out: u64,
        router_instruction_data: Vec<u8>,
    ) -> Result<()> {
        let policy = &ctx.accounts.policy;
        require!(policy.active, AutoSwapError::PolicyInactive);
        require!(
            amount_in >= policy.dust_floor_amount,
            AutoSwapError::AmountBelowDustFloor
        );

        // Security check 1: Target router matches whitelisted router
        require_keys_eq!(
            ctx.accounts.router_program.key(),
            policy.whitelisted_router,
            AutoSwapError::RouterNotWhitelisted
        );

        // Security check 2: Destination token account mint is strictly USDC
        require_keys_eq!(
            ctx.accounts.destination_token_account.mint,
            policy.output_mint,
            AutoSwapError::InvalidOutputMint
        );

        // Security check 3: Allowed instruction discriminator
        require!(
            router_instruction_data.len() >= 8,
            AutoSwapError::InvalidInstructionData
        );
        require!(
            router_instruction_data[..8] == policy.allowed_discriminator,
            AutoSwapError::InvalidDiscriminator
        );

        // Security check 4: Pyth Price Feed Oracle Validation
        let price_feed = load_price_feed_from_account_info(&ctx.accounts.pyth_price_feed_account)
            .map_err(|_| error!(AutoSwapError::InvalidPythFeed))?;
        
        let current_timestamp = Clock::get()?.unix_timestamp;
        let current_price = price_feed
            .get_price_no_older_than(current_timestamp, 60)
            .ok_or(error!(AutoSwapError::StalePythPrice))?;

        require!(current_price.price > 0, AutoSwapError::InvalidPythPrice);

        // Compute minimum acceptable output:
        // Oracle expected = (amount_in * current_price.price) scaled to decimals
        // min_oracle_allowed = expected * (10000 - max_slippage_bps) / 10000
        require!(
            min_amount_out > 0,
            AutoSwapError::ZeroMinimumOutput
        );

        // Track pre-swap balance
        let pre_balance = ctx.accounts.destination_token_account.amount;

        // Perform CPI invoke_signed via the bucket authority PDA
        let merchant_key = policy.merchant;
        let bucket_id = policy.bucket_id;
        let authority_bump = policy.authority_bump;

        let signer_seeds: &[&[&[u8]]] = &[&[
            BUCKET_AUTHORITY_SEED,
            merchant_key.as_ref(),
            bucket_id.as_ref(),
            &[authority_bump],
        ]];

        let account_metas: Vec<AccountMeta> = ctx.remaining_accounts
            .iter()
            .map(|acc| AccountMeta {
                pubkey: acc.key(),
                is_signer: acc.key == ctx.accounts.bucket_authority.key,
                is_writable: acc.is_writable,
            })
            .collect();

        let ix = Instruction {
            program_id: ctx.accounts.router_program.key(),
            accounts: account_metas,
            data: router_instruction_data,
        };

        invoke_signed(&ix, ctx.remaining_accounts, signer_seeds)?;

        // Reload and verify received USDC
        ctx.accounts.destination_token_account.reload()?;
        let post_balance = ctx.accounts.destination_token_account.amount;
        let received = post_balance.saturating_sub(pre_balance);

        require!(
            received >= min_amount_out,
            AutoSwapError::SlippageExceeded
        );

        emit!(SwapExecutedEvent {
            merchant: policy.merchant,
            bucket_id: policy.bucket_id,
            amount_in,
            usdc_received: received,
            caller: ctx.accounts.caller.key(),
        });

        Ok(())
    }
}

#[derive(Accounts)]
#[instruction(bucket_id: [u8; 32])]
pub struct SetSwapPolicy<'info> {
    #[account(mut)]
    pub merchant: Signer<'info>,

    #[account(
        init_if_needed,
        payer = merchant,
        space = 8 + SwapPolicy::INIT_SPACE,
        seeds = [POLICY_SEED, merchant.key().as_ref(), bucket_id.as_ref()],
        bump
    )]
    pub policy: Account<'info, SwapPolicy>,

    /// CHECK: PDA authority that holds token delegate / account control
    #[account(
        seeds = [BUCKET_AUTHORITY_SEED, merchant.key().as_ref(), bucket_id.as_ref()],
        bump
    )]
    pub bucket_authority: UncheckedAccount<'info>,

    /// Pinned output mint: MUST be the USDC mint address
    pub output_mint: Account<'info, Mint>,

    /// Destination token account owned by merchant's split bucket
    pub bucket_destination: Account<'info, TokenAccount>,

    /// Pyth price feed account for real-time oracle cross-check
    /// CHECK: Verified via Pyth SDK in instruction
    pub pyth_price_feed: UncheckedAccount<'info>,

    pub system_program: Program<'info, System>,
    pub token_program: Program<'info, Token>,
}

#[derive(Accounts)]
pub struct RevokePolicy<'info> {
    pub merchant: Signer<'info>,

    #[account(
        mut,
        seeds = [POLICY_SEED, merchant.key().as_ref(), policy.bucket_id.as_ref()],
        bump = policy.bump,
        has_one = merchant @ AutoSwapError::Unauthorized
    )]
    pub policy: Account<'info, SwapPolicy>,
}

#[derive(Accounts)]
pub struct ExecuteSwap<'info> {
    #[account(mut)]
    pub caller: Signer<'info>,

    #[account(
        seeds = [POLICY_SEED, policy.merchant.as_ref(), policy.bucket_id.as_ref()],
        bump = policy.bump
    )]
    pub policy: Account<'info, SwapPolicy>,

    /// CHECK: PDA authority that signs the CPI via signer_seeds
    #[account(
        seeds = [BUCKET_AUTHORITY_SEED, policy.merchant.as_ref(), policy.bucket_id.as_ref()],
        bump = policy.authority_bump
    )]
    pub bucket_authority: UncheckedAccount<'info>,

    /// Destination account receiving swapped USDC
    #[account(
        mut,
        constraint = destination_token_account.key() == policy.bucket_destination @ AutoSwapError::InvalidDestination
    )]
    pub destination_token_account: Account<'info, TokenAccount>,

    /// CHECK: Whitelisted router program (e.g. Jupiter)
    pub router_program: UncheckedAccount<'info>,

    /// CHECK: Pyth price feed account matching policy
    #[account(
        constraint = pyth_price_feed_account.key() == policy.pyth_price_feed @ AutoSwapError::InvalidPythFeed
    )]
    pub pyth_price_feed_account: UncheckedAccount<'info>,

    pub token_program: Program<'info, Token>,
}

#[account]
#[derive(InitSpace)]
pub struct SwapPolicy {
    pub merchant: Pubkey,
    pub bucket_id: [u8; 32],
    pub bucket_authority: Pubkey,
    pub bucket_destination: Pubkey,
    pub whitelisted_router: Pubkey,
    pub allowed_discriminator: [u8; 8],
    pub output_mint: Pubkey,
    pub pyth_price_feed: Pubkey,
    pub max_slippage_bps: u16,
    pub dust_floor_amount: u64,
    pub active: bool,
    pub bump: u8,
    pub authority_bump: u8,
}

#[event]
pub struct PolicySetEvent {
    pub merchant: Pubkey,
    pub bucket_id: [u8; 32],
    pub router: Pubkey,
    pub output_mint: Pubkey,
    pub max_slippage_bps: u16,
}

#[event]
pub struct PolicyRevokedEvent {
    pub merchant: Pubkey,
    pub bucket_id: [u8; 32],
}

#[event]
pub struct SwapExecutedEvent {
    pub merchant: Pubkey,
    pub bucket_id: [u8; 32],
    pub amount_in: u64,
    pub usdc_received: u64,
    pub caller: Pubkey,
}

#[error_code]
pub enum AutoSwapError {
    #[msg("Policy is inactive or has been revoked.")]
    PolicyInactive,
    #[msg("Swap amount is below the configured dust floor.")]
    AmountBelowDustFloor,
    #[msg("Router program ID is not in the whitelist.")]
    RouterNotWhitelisted,
    #[msg("Output token account mint is not USDC.")]
    InvalidOutputMint,
    #[msg("Invalid instruction data length.")]
    InvalidInstructionData,
    #[msg("Invalid instruction discriminator for router.")]
    InvalidDiscriminator,
    #[msg("Pyth price feed account does not match policy.")]
    InvalidPythFeed,
    #[msg("Pyth price is older than maximum staleness threshold.")]
    StalePythPrice,
    #[msg("Invalid Pyth oracle price returned.")]
    InvalidPythPrice,
    #[msg("Minimum amount out cannot be zero.")]
    ZeroMinimumOutput,
    #[msg("Swap resulted in slippage exceeding the policy cap.")]
    SlippageExceeded,
    #[msg("Unauthorized: caller is not the policy owner.")]
    Unauthorized,
    #[msg("Slippage basis points must be between 1 and 500.")]
    InvalidSlippageBps,
    #[msg("Destination token account does not match policy.")]
    InvalidDestination,
}
