// Device register cart pricing (src/devices/pricing.js). Run: node --test tests/pricing.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { priceCart, CartPricingError } from '../src/devices/pricing.js';

const products = [
  { id: 'fw', name: 'Flat White', price: '4.50', active: true, meta: { variants: [{ name: 'Oat milk', price: 0.8 }, { name: 'Extra shot', price: '0.70' }, { name: 'Decaf', price: 0 }] } },
  { id: 'bb', name: 'Banana bread', price: '7.00', active: true, meta: {} },
];

test('prices come from the catalog, with option add-ons and quantities', () => {
  const r = priceCart(products, [
    { productId: 'fw', variants: ['Oat milk', 'Extra shot'], qty: 2 },
    { productId: 'bb', qty: 1, price: 0.01 /* ignored: device prices are never trusted */ },
  ]);
  assert.equal(r.lines[0].name, 'Flat White · Oat milk, Extra shot');
  assert.equal(r.lines[0].unitCents, 450 + 80 + 70);
  assert.equal(r.lines[0].lineCents, 1200);
  assert.equal(r.lines[1].unitCents, 700);
  assert.equal(r.subtotalCents, 1900);
});

test('a free option keeps the base price; duplicate option names count once', () => {
  const r = priceCart(products, [{ productId: 'fw', variants: ['Decaf', 'Decaf'], qty: 1 }]);
  assert.equal(r.lines[0].name, 'Flat White · Decaf');
  assert.equal(r.subtotalCents, 450);
});

test('removed products, unknown options and bad quantities are rejected', () => {
  assert.throws(() => priceCart(products, [{ productId: 'gone', qty: 1 }]), CartPricingError);
  assert.throws(() => priceCart([{ ...products[1], active: false }], [{ productId: 'bb', qty: 1 }]), CartPricingError);
  assert.throws(() => priceCart(products, [{ productId: 'fw', variants: ['Soy milk'], qty: 1 }]), CartPricingError);
  for (const qty of [0, -1, 1.5, 1000, 'two']) {
    assert.throws(() => priceCart(products, [{ productId: 'bb', qty }]), CartPricingError);
  }
  assert.throws(() => priceCart(products, []), (e) => e.code === 'EMPTY_CART');
});
