// Tap-and-pay chain code against a REAL local validator (no mocks):
// build -> customer signs -> sponsor signs -> simulate -> send -> confirm -> verify.
//
// Skipped unless TAPPAY_TEST_RPC points at a local validator:
//   solana-test-validator --reset --quiet &
//   TAPPAY_TEST_RPC=http://127.0.0.1:8899 node --test tests/tappayChain.integration.test.js
import { test, describe, before } from 'node:test';
import assert from 'node:assert/strict';
import { Connection, Keypair, LAMPORTS_PER_SOL, VersionedTransaction } from '@solana/web3.js';
import { createMint, getOrCreateAssociatedTokenAccount, mintTo, getAssociatedTokenAddressSync, TOKEN_PROGRAM_ID, TOKEN_2022_PROGRAM_ID } from '@solana/spl-token';
import { buildDirectTransaction, ensureFeeCollectorAta, signMessage, assembleSignedTransaction, verifyTapPayTransaction, requiredSigners } from '../src/tappay/chain.js';
import { checkDynkMint } from '../src/tappay/config.js';

const RPC = process.env.TAPPAY_TEST_RPC;
const DECIMALS = 9;

async function airdrop(conn, pk, sol = 2) {
  const sig = await conn.requestAirdrop(pk, sol * LAMPORTS_PER_SOL);
  const bh = await conn.getLatestBlockhash();
  await conn.confirmTransaction({ signature: sig, ...bh }, 'confirmed');
}

async function waitConfirmed(conn, sig, ms = 30000) {
  const end = Date.now() + ms;
  while (Date.now() < end) {
    const st = (await conn.getSignatureStatuses([sig])).value[0];
    if (st?.err) throw new Error(`failed: ${JSON.stringify(st.err)}`);
    if (st && ['confirmed', 'finalized'].includes(st.confirmationStatus)) return;
    await new Promise((r) => setTimeout(r, 400));
  }
  throw new Error('timeout');
}

for (const [label, programId] of [['SPL Token', TOKEN_PROGRAM_ID], ['Token-2022', TOKEN_2022_PROGRAM_ID]]) {
  describe(`tap-and-pay DIRECT payment on ${label}`, { skip: !RPC && 'set TAPPAY_TEST_RPC to a local validator' }, () => {
    let conn, auth, sponsor, customer, merchant, collector, mint;

    before(async () => {
      conn = new Connection(RPC, 'confirmed');
      [auth, sponsor, customer, merchant, collector] = [0, 1, 2, 3, 4].map(() => Keypair.generate());
      await Promise.all([airdrop(conn, auth.publicKey), airdrop(conn, sponsor.publicKey)]);
      mint = await createMint(conn, auth, auth.publicKey, null, DECIMALS, Keypair.generate(), { commitment: 'confirmed' }, programId);
      const ata = await getOrCreateAssociatedTokenAccount(conn, auth, mint, customer.publicKey, false, 'confirmed', { commitment: 'confirmed' }, programId);
      await mintTo(conn, auth, mint, ata.address, auth, 1000n * 10n ** 9n, [], { commitment: 'confirmed' }, programId);
    });

    test('the fee collector account is created once by the sponsor, then left alone', async () => {
      const args = { connection: conn, sponsor, feeCollector: collector.publicKey.toBase58(), mint: mint.toBase58(), tokenProgram: programId };
      assert.equal(await ensureFeeCollectorAta(args), 'CREATED');
      assert.equal(await ensureFeeCollectorAta(args), 'EXISTS');
    });

    test('tap (v6): built with a blockhash fetched in parallel with the balance check, partially signed, lands and verifies', async () => {
      const recentBlockhash = await conn.getLatestBlockhash('confirmed');
      const { blockhash, lastValidBlockHeight } = recentBlockhash;
      const reference = Keypair.generate().publicKey.toBase58();
      const built = await buildDirectTransaction({
        connection: { getLatestBlockhash: async () => { throw new Error('must use the blockhash it was given'); } },
        sponsor, customer: customer.publicKey.toBase58(), mint: mint.toBase58(), tokenProgram: programId, decimals: DECIMALS,
        merchant: merchant.publicKey.toBase58(), amount: 2_000_000_000n, feeCollector: collector.publicKey.toBase58(), fee: 55_555n,
        reference, computeUnitLimit: 120_000, priorityFeeMicroLamports: 1000, recentBlockhash,
      });
      const msg = built.messageBytes;
      assert.deepEqual(requiredSigners(msg), [sponsor.publicKey.toBase58(), customer.publicKey.toBase58()], 'sponsor pays, customer signs');
      const wire = assembleSignedTransaction(msg, new Map([[sponsor.publicKey.toBase58(), signMessage(sponsor, msg)], [customer.publicKey.toBase58(), signMessage(customer, msg)]]));
      const sig = await conn.sendRawTransaction(wire);
      await conn.confirmTransaction({ signature: sig, blockhash, lastValidBlockHeight }, 'confirmed');
      const parsed = await conn.getParsedTransaction(sig, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 });
      const ata = (o) => getAssociatedTokenAddressSync(mint, o, true, programId).toBase58();
      assert.equal(verifyTapPayTransaction(parsed, {
        mint: mint.toBase58(), customer: customer.publicKey.toBase58(), customerAta: ata(customer.publicKey), merchantAta: ata(merchant.publicKey),
        amount: 2_000_000_000n, feeCollectorAta: ata(collector.publicKey), fee: 55_555n, reference,
      }), true);
    });

    test('the startup mint check reads decimals and the token program', async () => {
      const r = await checkDynkMint(conn, { mint, expectedDecimals: DECIMALS });
      assert.ok(r.programId.equals(programId));
      await assert.rejects(checkDynkMint(conn, { mint, expectedDecimals: 6 }), /MINT_MISMATCH/);
      await assert.rejects(checkDynkMint(conn, { mint: Keypair.generate().publicKey, expectedDecimals: 9 }), /MINT_MISMATCH/);
    });

    test('pays the merchant and the fee, and proves it on-chain', async () => {
      const amount = 12_345_000_000n; // 12.345 DYNK
      const fee = 66_667n;
      const reference = Keypair.generate().publicKey.toBase58();
      const built = await buildDirectTransaction({
        connection: conn, sponsor, customer: customer.publicKey.toBase58(), mint: mint.toBase58(), tokenProgram: programId,
        decimals: DECIMALS, merchant: merchant.publicKey.toBase58(), amount, feeCollector: collector.publicKey.toBase58(),
        fee, reference, computeUnitLimit: 120_000, priorityFeeMicroLamports: 1000,
      });
      assert.deepEqual(requiredSigners(built.messageBytes).sort(), [customer.publicKey.toBase58(), sponsor.publicKey.toBase58()].sort());
      assert.equal(requiredSigners(built.messageBytes)[0], sponsor.publicKey.toBase58(), 'sponsor is the fee payer');

      const sigs = new Map([
        [customer.publicKey.toBase58(), signMessage(customer, built.messageBytes)],
        [sponsor.publicKey.toBase58(), signMessage(sponsor, built.messageBytes)],
      ]);
      const wire = assembleSignedTransaction(built.messageBytes, sigs);
      const sim = await conn.simulateTransaction(VersionedTransaction.deserialize(wire), { sigVerify: true });
      assert.equal(sim.value.err, null, JSON.stringify(sim.value.logs));

      const sig = await conn.sendRawTransaction(wire, { skipPreflight: true, maxRetries: 0 });
      await waitConfirmed(conn, sig);
      const parsed = await conn.getParsedTransaction(sig, { commitment: 'confirmed', maxSupportedTransactionVersion: 0 });
      const expect = { mint: mint.toBase58(), customer: customer.publicKey.toBase58(), customerAta: built.customerAta, merchantAta: built.merchantAta, amount, feeCollectorAta: built.feeCollectorAta, fee, reference };
      assert.equal(verifyTapPayTransaction(parsed, expect), true);
      assert.throws(() => verifyTapPayTransaction(parsed, { ...expect, amount: amount + 1n }), /WRONG_AMOUNT/);
      assert.throws(() => verifyTapPayTransaction(parsed, { ...expect, fee: fee - 1n }), /WRONG_FEE/);
      assert.throws(() => verifyTapPayTransaction(parsed, { ...expect, reference: Keypair.generate().publicKey.toBase58() }), /MISSING_REFERENCE/);
      assert.throws(() => verifyTapPayTransaction(parsed, { ...expect, customer: sponsor.publicKey.toBase58() }), /WRONG_SIGNER/);
      assert.throws(() => verifyTapPayTransaction(parsed, { ...expect, mint: Keypair.generate().publicKey.toBase58() }), /WRONG_MINT/);
      assert.throws(() => verifyTapPayTransaction(parsed, { ...expect, customerAta: built.merchantAta }), /WRONG_AMOUNT/);
    });

    test('a signature over a different message is refused before sending', async () => {
      const common = { connection: conn, sponsor, customer: customer.publicKey.toBase58(), mint: mint.toBase58(), tokenProgram: programId, decimals: DECIMALS, merchant: merchant.publicKey.toBase58(), feeCollector: collector.publicKey.toBase58(), fee: 0n, reference: Keypair.generate().publicKey.toBase58(), computeUnitLimit: 120_000, priorityFeeMicroLamports: 0 };
      const a = await buildDirectTransaction({ ...common, amount: 1n });
      const b = await buildDirectTransaction({ ...common, amount: 2n });
      const sigs = new Map([
        [customer.publicKey.toBase58(), signMessage(customer, a.messageBytes)], // signed A
        [sponsor.publicKey.toBase58(), signMessage(sponsor, b.messageBytes)],
      ]);
      assert.throws(() => assembleSignedTransaction(b.messageBytes, sigs), /BAD_SIGNATURE/);
      assert.throws(() => assembleSignedTransaction(b.messageBytes, new Map()), /MISSING_SIGNATURE/);
    });

    test('simulation catches a customer without enough DYNK', async () => {
      const built = await buildDirectTransaction({
        connection: conn, sponsor, customer: customer.publicKey.toBase58(), mint: mint.toBase58(), tokenProgram: programId,
        decimals: DECIMALS, merchant: merchant.publicKey.toBase58(), amount: 10_000n * 10n ** 9n, feeCollector: collector.publicKey.toBase58(),
        fee: 0n, reference: Keypair.generate().publicKey.toBase58(), computeUnitLimit: 120_000, priorityFeeMicroLamports: 0,
      });
      const wire = assembleSignedTransaction(built.messageBytes, new Map([
        [customer.publicKey.toBase58(), signMessage(customer, built.messageBytes)],
        [sponsor.publicKey.toBase58(), signMessage(sponsor, built.messageBytes)],
      ]));
      const sim = await conn.simulateTransaction(VersionedTransaction.deserialize(wire), { sigVerify: true });
      assert.notEqual(sim.value.err, null);
      assert.ok(sim.value.logs.join('\n').match(/insufficient funds/i));
    });
  });
}
