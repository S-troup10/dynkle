// Outbound HTTP retries (src/services/resilientFetch.js). Run: node --test tests/resilientFetch.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { resilientFetch } from '../src/services/resilientFetch.js';

const ok = () => new Response('{}', { status: 200 });
const connectFailure = () => Object.assign(new TypeError('fetch failed'), { cause: { code: 'UND_ERR_CONNECT_TIMEOUT' } });

test('a failed connection is tried again and succeeds', async () => {
  let calls = 0;
  const f = resilientFetch({ retries: 2, fetchImpl: async () => { calls += 1; if (calls === 1) throw connectFailure(); return ok(); } });
  assert.equal((await f('https://x')).status, 200);
  assert.equal(calls, 2);
});

test('a 429 is retried after a short pause', async () => {
  let calls = 0;
  const f = resilientFetch({ retries: 2, fetchImpl: async () => { calls += 1; return calls === 1 ? new Response('', { status: 429 }) : ok(); } });
  assert.equal((await f('https://x')).status, 200);
  assert.equal(calls, 2);
});

test('gives up after the retries, with the last error', async () => {
  let calls = 0;
  const f = resilientFetch({ retries: 1, fetchImpl: async () => { calls += 1; throw connectFailure(); } });
  await assert.rejects(f('https://x'), /fetch failed/);
  assert.equal(calls, 2);
});

test('a slow but working server is not retried when retryOnTimeout is off', async () => {
  let calls = 0;
  const slow = (_u, init) => new Promise((_r, reject) => { calls += 1; init.signal.addEventListener('abort', () => reject(new DOMException('timeout', 'TimeoutError'))); });
  const f = resilientFetch({ attemptTimeoutMs: 50, retries: 2, retryOnTimeout: false, fetchImpl: slow });
  await assert.rejects(f('https://x'));
  assert.equal(calls, 1);
});
