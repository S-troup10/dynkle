// Itemised bill for the payer (DYNK bill split). No DB: prisma is stubbed.
// Run: node --test tests/tappayBill.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import prisma from '../src/db.js';
import { bill } from '../src/tappay/service.js';

const ORDER = {
  id: '6f1c2d4e-1111-4222-8333-944455556666',
  displayNumber: 1042,
  status: 'PAID',
  subtotalAUD: '30.00', gstAUD: '2.73', totalAUD: '30.01', customerFeeAUD: '0.0100',
  tapPayMint: 'DynkMint1111111111111111111111111111111111',
  paidAt: new Date('2026-10-19T09:00:00Z'),
  items: [
    { name: 'Margherita pizza', price: 11, quantity: 1 },
    { name: 'Iced tea', price: 2, quantity: 2 },
    { name: 'Caesar salad', price: 7.5, quantity: 1 },
    { name: 'Garlic bread', price: 4.5, quantity: 1 },
    { name: 'Tip', price: 3, quantity: 1, isTip: true },
  ],
  merchant: { tradingName: 'Harbour Bistro', registeredAddress: 'Sydney', profile: null },
  paymentAttempts: [{ status: 'CONFIRMED', customerPubkey: 'PAYER', amount: 270000000000n, fee: 100000000n, txSignature: 'SIG', updatedAt: new Date() }],
};
const stub = (order) => { prisma.order.findUnique = async () => order; };

test('the payer gets the itemised bill in cents, with what they paid in DYNK', async () => {
  stub(ORDER);
  const b = await bill(ORDER.id, ['OTHER', 'PAYER']);
  assert.equal(b.merchantName, 'Harbour Bistro');
  assert.equal(b.orderNumber, 1042);
  assert.deepEqual(b.items.map((i) => [i.name, i.qty, i.unitCents, i.lineCents, i.isTip]), [
    ['Margherita pizza', 1, 1100, 1100, false],
    ['Iced tea', 2, 200, 400, false],
    ['Caesar salad', 1, 750, 750, false],
    ['Garlic bread', 1, 450, 450, false],
    ['Tip', 1, 300, 300, true],
  ]);
  assert.equal(b.subtotalCents, 3000);
  assert.equal(b.totalCents, 3001);
  assert.equal(b.feeCents, 1);
  assert.equal(b.gstIncludedCents, 273);
  assert.equal(b.payment.amountBaseUnits, '270100000000');
  assert.equal(b.payment.txSignature, 'SIG');
});

test('anyone else, or an unpaid order, gets nothing', async () => {
  stub(ORDER);
  await assert.rejects(() => bill(ORDER.id, ['SOMEONE']), /Only the person who paid/);
  stub({ ...ORDER, status: 'QUOTED', paymentAttempts: [] });
  await assert.rejects(() => bill(ORDER.id, ['PAYER']), /not been paid/);
  stub(null);
  await assert.rejects(() => bill(ORDER.id, ['PAYER']), /not found/);
});
