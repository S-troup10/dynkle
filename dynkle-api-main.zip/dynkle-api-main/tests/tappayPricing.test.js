// Integer money for tap-and-pay. Run: node --test tests/tappayPricing.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { toMicro, centsToBaseUnits, microUsdToFiatMicro, fiatMicroToBaseUnits, formatUnits, quoteDynk } from '../src/tappay/pricing.js';

test('decimal prices become exact integer micro units', () => {
  assert.equal(toMicro('0.15'), 150_000n);
  assert.equal(toMicro(0.15), 150_000n);
  assert.equal(toMicro('1.54'), 1_540_000n);
  assert.equal(toMicro('0.0000015'), 2n); // half up
  assert.equal(toMicro('228.45'), 228_450_000n);
  assert.throws(() => toMicro('-1'), /PRICE_INVALID/);
  assert.throws(() => toMicro('abc'), /PRICE_INVALID/);
});

test('bill cents convert to DYNK base units, rounded up', () => {
  // $3.00 at $0.15/DYNK = exactly 20 DYNK
  assert.equal(centsToBaseUnits(300, toMicro('0.15'), 9), 20_000_000_000n);
  // $1.00 at $0.30 = 3.333333333...4 DYNK: rounded UP so the merchant is never short
  assert.equal(centsToBaseUnits(100, toMicro('0.30'), 9), 3_333_333_334n);
  assert.equal(centsToBaseUnits(0, toMicro('0.15'), 9), 0n);
  assert.throws(() => centsToBaseUnits(100, 0n, 9), /PRICE_INVALID/);
});

test('the USD 0.01 fee converts through AUD into DYNK', () => {
  // 1 USD = 1.54 AUD -> USD 0.01 = AUD 0.0154 = 15_400 micro-AUD
  const feeAud = microUsdToFiatMicro(10_000n, toMicro('1.54'));
  assert.equal(feeAud, 15_400n);
  // at $0.15/DYNK: 0.0154 / 0.15 = 0.102666... DYNK -> 102_666_667 base units (up)
  assert.equal(fiatMicroToBaseUnits(feeAud, toMicro('0.15'), 9), 102_666_667n);
  assert.equal(fiatMicroToBaseUnits(0n, toMicro('0.15'), 9), 0n);
});

test('quoteDynk uses the price service once and stays integer', async () => {
  const prices = async (sym) => ({ DYNK: { priceAUD: 0.15, source: 'test' }, USDC: { priceAUD: 1.54, source: 'test' } }[sym]);
  const q = await quoteDynk({ billCents: 30000, decimals: 9, platformFeeMicroUsd: 10_000n, prices });
  assert.equal(q.amount, 2_000_000_000_000n); // $300 / $0.15 = 2000 DYNK
  assert.equal(q.fee, 102_666_667n);
  assert.equal(typeof q.amount, 'bigint');
  const free = await quoteDynk({ billCents: 100, decimals: 9, platformFeeMicroUsd: 0n, prices });
  assert.equal(free.fee, 0n);
});

test('formatUnits is display only and exact', () => {
  assert.equal(formatUnits(2_000_000_000_000n, 9), '2000');
  assert.equal(formatUnits(102_666_667n, 9), '0.102666667');
  assert.equal(formatUnits(5n, 9), '0.000000005');
});
