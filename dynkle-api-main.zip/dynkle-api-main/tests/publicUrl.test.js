import test from 'node:test';
import assert from 'node:assert/strict';

// No cloudflared probing in tests: the result must not depend on this machine.
process.env.CLOUDFLARED_METRICS = '';
const { customerBaseUrl, isPrivateUrl } = await import('../src/services/publicUrl.js');

const req = (host, proto = 'http') => ({ headers: { host, 'x-forwarded-proto': proto } });

test('LAN, loopback and emulator addresses are not public', () => {
  for (const u of ['http://localhost:4100', 'http://127.0.0.1:4100', 'http://10.0.2.2:4100',
    'http://192.168.90.149:4100', 'http://172.20.1.5', 'http://10.1.2.3', 'not a url']) {
    assert.equal(isPrivateUrl(u), true, u);
  }
  assert.equal(isPrivateUrl('https://pay.dynkle.com'), false);
  assert.equal(isPrivateUrl('https://abc.trycloudflare.com'), false);
});

test('customer links prefer a public PUBLIC_BASE_URL over the LAN address the device uses', () => {
  process.env.PUBLIC_BASE_URL = 'https://pay.dynkle.com/';
  assert.equal(customerBaseUrl(req('192.168.90.149:4100'), 'http://192.168.90.149:4100'), 'https://pay.dynkle.com');
});

test('a public request host is used when PUBLIC_BASE_URL is local', () => {
  process.env.PUBLIC_BASE_URL = 'http://localhost:4100';
  assert.equal(customerBaseUrl(req('shop.example.com', 'https'), 'http://192.168.1.2:4100'), 'https://shop.example.com');
});

test('with nothing public, the LAN fallback is kept (same Wi-Fi only)', () => {
  process.env.PUBLIC_BASE_URL = 'http://localhost:4100';
  assert.equal(customerBaseUrl(null, 'http://192.168.1.2:4100/'), 'http://192.168.1.2:4100');
});
