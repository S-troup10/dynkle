// DYNKLE payments spec, P1 (no chain, no DB): tap intents, tap builder v1
// golden vectors, signed declines.
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import { Message, PublicKey, Transaction, ComputeBudgetProgram } from '@solana/web3.js';
import { ASSOCIATED_TOKEN_PROGRAM_ID, TOKEN_PROGRAM_ID } from '@solana/spl-token';
import { sha256Hex } from '../src/tappay/chain.js';
import { signIntent, decodeIntent, verifyIntent, fromBase64Url } from '../src/tappay/intent.js';
import { signDecline, verifyDecline, signTapQuote, verifyTapQuote } from '../src/tappay/crypto.js';
import { encodeTapRequest, decodeTapRequest } from '../src/tappay/tapRequest.js';
import { ed25519FromSeed } from '../src/tappay/keystore.js';

const fixture = JSON.parse(fs.readFileSync(new URL('./fixtures/tap-request-v2.json', import.meta.url), 'utf8'));
const intentPub = crypto.createPublicKey({ key: Buffer.concat([Buffer.from('302a300506032b6570032100', 'hex'), Buffer.from(fixture.intentPublicKey, 'base64')]), format: 'der', type: 'spki' });
const keys = new Map([[1, intentPub]]);
const LATER = { now: 0 }; // vectors carry a fixed expiry; verify as if before it

test('tap request v2 fixture: the live code still produces the committed bytes', async () => {
  const { tapRequestFixture } = await import('../scripts/tap-request-fixture.js');
  assert.deepEqual(JSON.parse(JSON.stringify(await tapRequestFixture())), fixture, 'run: node scripts/tap-request-fixture.js --write, then copy it to the DYNK app');
});

test('intent: one layout for QR and tap (v6), 289 B max; tamper, truncation and expiry refused', () => {
  const bytes = fromBase64Url(fixture.intent);
  const intent = verifyIntent(bytes, keys, LATER);
  assert.equal(intent.merchantName, 'Reels Coffee');
  assert.equal('tap' in intent, false, 'no tap extension any more');
  for (const i of [0, 40, bytes.length - 70, bytes.length - 1]) {
    const bad = Buffer.from(bytes); bad[i] ^= 1;
    assert.throws(() => verifyIntent(bad, keys, LATER));
  }
  assert.throws(() => decodeIntent(Buffer.concat([bytes, Buffer.alloc(126)])), /INTENT_LENGTH_MISMATCH/, 'an old v5 tap intent is refused');
  assert.throws(() => decodeIntent(bytes.subarray(0, bytes.length - 1)), /INTENT_LENGTH_MISMATCH/);
  assert.throws(() => verifyIntent(bytes, keys), /INTENT_EXPIRED/);
  const { body, signature, ...fields } = decodeIntent(bytes);
  const key = ed25519FromSeed(crypto.createHash('sha256').update('x').digest());
  assert.equal(signIntent({ ...fields, merchantName: 'x'.repeat(40) }, key.privateKey).length, 289);
});

test('tap request v2: the payload carries the intent, the signed tap quote and the backend-built transaction', () => {
  const r = decodeTapRequest(Buffer.from(fixture.request, 'base64'));
  assert.equal(Buffer.from(r.intent).toString('base64url'), fixture.intent);
  assert.deepEqual(r.tapQuote, fixture.tapQuote);
  assert.equal(Buffer.from(r.transaction).toString('base64'), fixture.transaction);
  assert.equal(verifyTapQuote(r.tapQuote, keys), true);
  const tx = Transaction.from(r.transaction);
  assert.equal(sha256Hex(tx.serializeMessage()), r.tapQuote.messageHash, 'the quote binds this exact message');
  const m = Message.from(tx.serializeMessage());
  assert.deepEqual(m.instructions.map((ix) => m.accountKeys[ix.programIdIndex].toBase58()), [
    ComputeBudgetProgram.programId.toBase58(), ComputeBudgetProgram.programId.toBase58(),
    ASSOCIATED_TOKEN_PROGRAM_ID.toBase58(), TOKEN_PROGRAM_ID.toBase58(), TOKEN_PROGRAM_ID.toBase58(),
  ]);
  assert.equal(m.accountKeys[0].toBase58(), fixture.gasSponsor, 'gas sponsor pays');
  assert.equal(m.header.numRequiredSignatures, 2, 'sponsor + customer: the phone partially signs');
  assert.deepEqual(encodeTapRequest({ intent: r.intent, tapQuote: r.tapQuote, transaction: r.transaction }), Buffer.from(fixture.request, 'base64'));
  assert.throws(() => decodeTapRequest(Buffer.from(fixture.request, 'base64').subarray(0, 100)), /TAP_REQUEST_TRUNCATED/);
});

test('tap quote: signed by the intent key; any change to the message hash, fee or expiry is refused', () => {
  const key = ed25519FromSeed(crypto.randomBytes(32));
  const pub = new Map([[2, key.publicKey]]);
  const q = signTapQuote({ orderId: 'o1', quoteId: 'q1', messageHash: 'ab'.repeat(32), fee: 66667n, expiresAt: '2026-10-09T00:00:00.000Z' }, { kid: 2, privateKey: key.privateKey });
  assert.equal(q.fee, '66667');
  assert.equal(verifyTapQuote(q, pub), true);
  for (const [k, v] of [['messageHash', 'cd'.repeat(32)], ['fee', '66668'], ['expiresAt', '2026-10-09T00:00:01.000Z'], ['quoteId', 'q2'], ['orderId', 'o2']]) {
    assert.throws(() => verifyTapQuote({ ...q, [k]: v }, pub), /TAPQUOTE_BAD_SIGNATURE/, k);
  }
  assert.throws(() => verifyTapQuote({ ...q, kid: 9 }, pub), /TAPQUOTE_UNKNOWN_KID/);
});

test('signed declines verify, and any change is refused', () => {
  const key = ed25519FromSeed(crypto.randomBytes(32));
  const pub = new Map([[3, key.publicKey]]);
  const d = signDecline({ orderId: 'o1', customerPubkey: fixture.customer, reason: 'INSUFFICIENT', swapAvailable: true, declinedAt: '2026-10-08T00:00:00.000Z' }, { kid: 3, privateKey: key.privateKey });
  assert.equal(verifyDecline(d, pub), true);
  assert.equal('swapAvailable' in d, false, 'v2 declines never carry a Swap and Pay offer');
  assert.throws(() => verifyDecline({ ...d, reason: 'OTHER' }, pub), /DECLINE_BAD_SIGNATURE/);
  assert.throws(() => verifyDecline({ ...d, declinedAt: '2026-10-08T00:00:01.000Z' }, pub), /DECLINE_BAD_SIGNATURE/);
  assert.throws(() => verifyDecline({ ...d, customerPubkey: new PublicKey(Buffer.alloc(32, 7)).toBase58() }, pub), /DECLINE_BAD_SIGNATURE/);
  assert.throws(() => verifyDecline({ ...d, kid: 4 }, pub), /DECLINE_UNKNOWN_KID/);
});

test('BLE v1 golden vectors: the reference still produces the committed bytes; replay and gap refused', async () => {
  const ble = await import('../scripts/ble-golden-vectors.js');
  const fx = JSON.parse(fs.readFileSync(new URL('./fixtures/ble-v1.json', import.meta.url), 'utf8'));
  assert.deepEqual(ble.goldenVectors(), fx, 'run: node scripts/ble-golden-vectors.js --write, and update the terminal and app tests');
  const key = Buffer.from(fx.sessionKeyHex, 'hex');
  const sid = Buffer.from(fx.bleSessionIdHex, 'hex');
  const m = fx.messages[1];
  const wire = Buffer.from(m.wireHex, 'hex');
  assert.equal(ble.open(key, m.direction, m.counter, wire, sid).type, m.type);
  assert.throws(() => ble.open(key, m.direction, m.counter + 1, wire, sid), 'a gap (wrong counter) fails authentication');
  assert.throws(() => ble.open(key, ble.DIR.TERMINAL_TO_PHONE, m.counter, wire, sid), 'the other direction fails');
  assert.throws(() => ble.open(key, m.direction, m.counter, wire, Buffer.alloc(8)), 'bound to the session id');
});

test('swap-tx fixture (for the DYNK app txCheck tests) still matches the backend builder', async () => {
  const { swapFixture } = await import('../scripts/swap-tx-fixture.js');
  const fx = JSON.parse(fs.readFileSync(new URL('./fixtures/swap-tx.json', import.meta.url), 'utf8'));
  assert.deepEqual(JSON.parse(JSON.stringify(await swapFixture())), fx, 'run: node scripts/swap-tx-fixture.js --write, then copy it to the DYNK app');
});

// The website checkout lives in the dynkle-web repo: DYNKLE_WEB_DIR, or a checkout next to this repo.
const payHtml = [process.env.DYNKLE_WEB_DIR && `${process.env.DYNKLE_WEB_DIR}/pay.html`,
  new URL('../../dynkle-web/pay.html', import.meta.url).pathname,
  new URL('../../frontend/pay.html', import.meta.url).pathname].filter(Boolean).find((p) => fs.existsSync(p));

test('website: the first script moves the #intent into memory and strips it before anything else runs', { skip: !payHtml && 'dynkle-web not found (set DYNKLE_WEB_DIR or check it out next to dynkle-api)' }, async () => {
  const vm = await import('node:vm');
  const html = fs.readFileSync(payHtml, 'utf8');
  const head = html.slice(0, html.indexOf('</head>'));
  const first = head.match(/<script(?![^>]*src)[^>]*>([\s\S]*?)<\/script>/);
  assert.ok(first && head.indexOf(first[0]) < head.search(/<script[^>]*src=/), 'inline strip script comes before any external script');
  const calls = [];
  const window = {
    location: { hash: '#abcDEF123_-', href: 'https://pay.test/o/x#abcDEF123_-', pathname: '/o/x', search: '' },
    history: { replaceState: (...a) => calls.push(a), state: null },
  };
  window.window = window;
  vm.runInNewContext(first[1], { window, location: window.location, history: window.history, document: { title: '' }, console: { log() {}, warn() {} } });
  assert.equal(window.__dynkleIntent, 'abcDEF123_-');
  assert.equal(calls.length, 1);
  assert.ok(!String(calls[0][2]).includes('#'), 'the address bar no longer carries the intent');
});

test('session check, test mode (DYNK_SESSION_CHECK=profile): hosted /api/auth/profile with the user token; Solana wallets only', async () => {
  const { verifyDynkSession } = await import('../src/tappay/dynkService.js');
  const env = { DYNK_SESSION_CHECK: 'profile', DYNK_API_BASE_URL: 'https://api.example.test/' };
  const calls = [];
  const ok = async (url, init) => {
    calls.push([url, init.headers.authorization]);
    return new Response(JSON.stringify({ data: { user: { id: 42, primary_wallet_address: 'WalletA' }, wallet_accounts: [
      { chain_code: 'SOLANA', address: 'WalletB' }, { chain_code: 'ethereum', address: '0xabc' },
    ] } }), { status: 200 });
  };
  const r = await verifyDynkSession('tok-1', { env, fetchImpl: ok });
  assert.deepEqual(r, { userId: 42, wallets: ['WalletA', 'WalletB'] });
  assert.deepEqual(calls, [['https://api.example.test/api/auth/profile', 'Bearer tok-1']]);
  await verifyDynkSession('tok-1', { env, fetchImpl: ok });
  assert.equal(calls.length, 1, 'cached for a minute');
  const denied = async () => new Response('{}', { status: 401 });
  await assert.rejects(verifyDynkSession('tok-2', { env, fetchImpl: denied }), (e) => e.code === 'UNAUTHENTICATED' && e.status === 401);
  const down = async () => { throw new Error('ECONNREFUSED'); };
  await assert.rejects(verifyDynkSession('tok-3', { env, fetchImpl: down }), (e) => e.code === 'DYNK_SERVICE_UNREACHABLE');
  await assert.rejects(verifyDynkSession('', { env, fetchImpl: ok }), (e) => e.code === 'UNAUTHENTICATED');
  await assert.rejects(verifyDynkSession('tok-4', { env: { DYNK_SESSION_CHECK: 'profile' }, fetchImpl: ok }), (e) => e.code === 'DYNK_SERVICE_NOT_CONFIGURED');
});
