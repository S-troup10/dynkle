import { test } from 'node:test';
import assert from 'node:assert/strict';
// A merchant address of its own: without one, config falls back to the 0x…dEaD placeholder,
// which the watcher deliberately ignores, so the test must not depend on someone's .env.
if (!process.env.MERCHANT_EVM_ADDRESS) process.env.MERCHANT_EVM_ADDRESS = '0x1111111111111111111111111111111111111111';
const { MERCHANT } = await import('../src/config.js');
const { orderEvmTag, findSepoliaPayment, _setProviderForTests } = await import('../src/services/evmWatch.js');

const order = { id: 'order-abc-123', createdAt: new Date(Date.now() - 30000) };
const tag = orderEvmTag(order.id);
const base = 2500000000000000n;
const now = Math.floor(Date.now() / 1000);
const merchant = MERCHANT.evmAddress;

function fakeProvider(txs) {
  return {
    getBlockNumber: async () => 100,
    getBlock: async (n) => ({ number: n, timestamp: now - (100 - n) * 12, prefetchedTransactions: n === 98 ? txs : [] }),
  };
}

test('tag is 6 digits and stable per order', () => {
  assert.equal(orderEvmTag('x'), orderEvmTag('x'));
  assert.ok(tag >= 100000n && tag < 1000000n);
  assert.notEqual(orderEvmTag('order-1'), orderEvmTag('order-2'));
});

test('finds the transfer whose amount carries this order tag', async () => {
  _setProviderForTests(fakeProvider([
    { hash: '0xother', to: merchant, from: '0xa', value: base + 111111n },            // someone else's bill
    { hash: '0xwrongto', to: '0x000000000000000000000000000000000000beef', from: '0xb', value: base + tag },
    { hash: '0xmine', to: merchant.toLowerCase(), from: '0xcustomer', value: base + tag },
  ]));
  const hit = await findSepoliaPayment(order);
  assert.equal(hit.txHash, '0xmine');
  assert.equal(hit.from, '0xcustomer');
});

test('ignores transfers without the tag', async () => {
  _setProviderForTests(fakeProvider([{ hash: '0xplain', to: merchant, from: '0xa', value: base }]));
  assert.equal(await findSepoliaPayment(order), null);
});
