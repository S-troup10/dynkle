// Tap-and-pay foundations: keystore, intent v1, config.
// Run: node --test tests/tappayFoundations.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { Keypair } from '@solana/web3.js';
import { encryptKeystore, decryptKeystore, loadKeystore, ed25519FromSeed } from '../src/tappay/keystore.js';
import { signIntent, verifyIntent, decodeIntent, clampName, toBase64Url, fromBase64Url } from '../src/tappay/intent.js';
import { readTapPayConfig } from '../src/tappay/config.js';

const PASS = 'correct horse battery staple';

function sampleFields(over = {}) {
  return {
    kid: 1,
    orderId: crypto.randomUUID(),
    orderNumber: 1042,
    itemCount: 2,
    terminalId: crypto.randomUUID(),
    merchantWallet: Keypair.generate().publicKey.toBase58(),
    mint: Keypair.generate().publicKey.toBase58(),
    amount: 300_000_000_000n,
    decimals: 9,
    fiatAmount: 30000n,
    currency: 'AUD',
    reference: Keypair.generate().publicKey.toBase58(),
    expiresAt: Math.floor(Date.now() / 1000) + 120,
    bleSessionId: crypto.randomBytes(8),
    terminalEphemeralPub: crypto.randomBytes(32),
    merchantName: 'Bean & Brew Café',
    ...over,
  };
}

test('keystore round-trips and rejects a wrong passphrase', () => {
  const plain = { activeKid: 1, intentKeys: [{ kid: 1, seed: crypto.randomBytes(32).toString('base64') }], sponsorSecretKey: Buffer.from(Keypair.generate().secretKey).toString('base64') };
  const file = encryptKeystore(plain, PASS);
  assert.ok(!JSON.stringify(file).includes(plain.intentKeys[0].seed), 'seed must not appear in clear');
  assert.deepEqual(decryptKeystore(file, PASS), plain);
  assert.throws(() => decryptKeystore(file, PASS + 'x'), /KEYSTORE_DECRYPT_FAILED/);
  assert.throws(() => encryptKeystore(plain, 'short'), /PASSPHRASE_TOO_SHORT/);

  const p = path.join(os.tmpdir(), `ks-${process.pid}.json`);
  fs.writeFileSync(p, JSON.stringify(file));
  const ks = loadKeystore(p, PASS);
  assert.equal(ks.activeKid, 1);
  assert.equal(ks.sponsorSecretKey.length, 64);
  fs.unlinkSync(p);
});

test('intent v1 signs, verifies and fits the 290-byte budget', () => {
  const k = ed25519FromSeed(crypto.randomBytes(32));
  const f = sampleFields({ merchantName: 'A merchant name that is far too long for the intent' });
  const bytes = signIntent(f, k.privateKey);
  assert.ok(bytes.length <= 290, `intent is ${bytes.length} bytes`);
  const got = verifyIntent(bytes, new Map([[1, k.publicKey]]));
  assert.equal(got.orderId, f.orderId);
  assert.equal(got.terminalId, f.terminalId);
  assert.equal(got.amount, f.amount);
  assert.equal(got.fiatAmount, f.fiatAmount);
  assert.equal(got.orderNumber, 1042);
  assert.equal(got.itemCount, 2);
  assert.equal(got.reference, f.reference);
  assert.ok(Buffer.byteLength(got.merchantName) <= 24);
  // base64url survives the link round trip
  assert.deepEqual(fromBase64Url(toBase64Url(bytes)), bytes);
});

test('any changed byte breaks the signature', () => {
  const k = ed25519FromSeed(crypto.randomBytes(32));
  const bytes = signIntent(sampleFields(), k.privateKey);
  const keys = new Map([[1, k.publicKey]]);
  // amount lives after version,kid,orderId,orderNumber,itemCount,terminalId,merchantWallet,mint
  const amountOffset = 1 + 1 + 16 + 4 + 2 + 16 + 32 + 32;
  const tampered = Buffer.from(bytes); tampered[amountOffset] ^= 0x01;
  assert.throws(() => verifyIntent(tampered, keys), /INTENT_BAD_SIGNATURE/);
});

test('unknown kid, other key, expiry and bad version are rejected', () => {
  const k1 = ed25519FromSeed(crypto.randomBytes(32));
  const k2 = ed25519FromSeed(crypto.randomBytes(32));
  const bytes = signIntent(sampleFields(), k1.privateKey);
  assert.throws(() => verifyIntent(bytes, new Map([[2, k2.publicKey]])), /INTENT_UNKNOWN_KID/);
  assert.throws(() => verifyIntent(bytes, new Map([[1, k2.publicKey]])), /INTENT_BAD_SIGNATURE/);
  const old = signIntent(sampleFields({ expiresAt: Math.floor(Date.now() / 1000) - 1 }), k1.privateKey);
  assert.throws(() => verifyIntent(old, new Map([[1, k1.publicKey]])), /INTENT_EXPIRED/);
  const v2 = Buffer.from(bytes); v2[0] = 2;
  assert.throws(() => decodeIntent(v2), /INTENT_VERSION_UNSUPPORTED/);
});

test('rotation: intents signed with an older kid still verify', () => {
  const k1 = ed25519FromSeed(crypto.randomBytes(32));
  const k2 = ed25519FromSeed(crypto.randomBytes(32));
  const bytes = signIntent(sampleFields({ kid: 1 }), k1.privateKey);
  const pinned = new Map([[1, k1.publicKey], [2, k2.publicKey]]);
  assert.equal(verifyIntent(bytes, pinned).kid, 1);
  assert.equal(verifyIntent(signIntent(sampleFields({ kid: 2 }), k2.privateKey), pinned).kid, 2);
});

test('merchant names are cut on a character boundary', () => {
  const cut = clampName('Café Crème Brûlée Pâtisserie');
  assert.ok('Café Crème Brûlée Pâtisserie'.startsWith(cut));
  assert.ok(Buffer.byteLength(cut) <= 24 && Buffer.byteLength(cut) >= 22);
  assert.ok(Buffer.byteLength(clampName('ééééééééééééééééééééééééé')) <= 24);
  assert.equal(clampName('ééééééééééééééééééééééééé').length, 12); // 2 bytes each, never half a character
});

test('config reports missing env names and keeps money as integers', () => {
  const cfg = readTapPayConfig({});
  assert.deepEqual(cfg.missing.sort(), ['DYNK_MINT_ADDRESS', 'TAP_PAY_FEE_COLLECTOR', 'TAP_PAY_KEYSTORE_FILE', 'TAP_PAY_KEYSTORE_PASSPHRASE'].sort());
  assert.equal(cfg.platformFeeMicroUsd, 10_000n); // USD 0.01 default
  assert.equal(readTapPayConfig({ TAP_PAY_PLATFORM_FEE_USD: '0' }).missing.includes('TAP_PAY_FEE_COLLECTOR'), false);
  assert.equal(readTapPayConfig({ TAP_PAY_PLATFORM_FEE_USD: '1.234567' }).platformFeeMicroUsd, 1_234_567n);
  assert.throws(() => readTapPayConfig({ TAP_PAY_PLATFORM_FEE_USD: '0.0000001' }), /TAP_PAY_PLATFORM_FEE_USD/);
  assert.throws(() => readTapPayConfig({ DYNK_MINT_ADDRESS: 'not-a-key' }), /DYNK_MINT_ADDRESS/);
  assert.equal(readTapPayConfig({}).androidPackage, 'io.dynk.www');
});
