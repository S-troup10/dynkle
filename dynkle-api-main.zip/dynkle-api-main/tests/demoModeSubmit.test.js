// With DEMO_MODE=true, a fake hash still needs the explicit demo submit.
// Run: node --test tests/demoModeSubmit.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';

process.env.SOLANA_RPC = 'http://127.0.0.1:9';
process.env.DEMO_MODE = 'true';
const { verifyParsedTransaction } = await import('../src/services/solana.js');

test('DEMO_MODE alone never accepts a fake hash', async () => {
  const order = { referenceKey: null, tokenSymbol: 'SOL', cryptoAmount: '1' };
  await assert.rejects(verifyParsedTransaction(order, 'sol_test_abc'), /INVALID_TRANSACTION_SIGNATURE/);
  await assert.rejects(verifyParsedTransaction(order, '5Kd' + 'x'.repeat(70), { allowDemoHash: true }), /TRANSACTION_NOT_FOUND|fetch failed|ECONNREFUSED|TRANSACTION/);
});

test('only the explicit legacy demo submit may use a sol_test_ hash', async () => {
  const order = { referenceKey: null, tokenSymbol: 'SOL', cryptoAmount: '1' };
  const r = await verifyParsedTransaction(order, 'sol_test_abc', { allowDemoHash: true });
  assert.equal(r.verified, true);
});
