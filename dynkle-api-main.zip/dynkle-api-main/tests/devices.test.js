// Counter-device pairing and auth (src/devices). Run: node --test tests/devices.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import os from 'node:os';
import path from 'node:path';

// Isolated store so tests never touch devices_store.json.
process.env.DEVICES_STORE_PATH = path.join(os.tmpdir(), `devices-test-${process.pid}.json`);
const { deviceStore, formatPairingCode } = await import('../src/devices/deviceStore.js');
const { verifyDeviceSignature, isValidPublicKey, signDeviceToken, deviceFromToken, reachableBaseUrl } = await import('../src/devices/deviceAuth.js');

function androidKey() {
  // Same key type the app creates in AndroidKeyStore: EC P-256, public key as X.509 SPKI DER, base64.
  const { publicKey, privateKey } = crypto.generateKeyPairSync('ec', { namedCurve: 'prime256v1' });
  return { privateKey, publicB64: publicKey.export({ type: 'spki', format: 'der' }).toString('base64') };
}

test('pairing code is 8 unambiguous characters, single use, formatted XXXX-XXXX', () => {
  const p = deviceStore.createPairing({ merchantId: 'm1', terminalId: 'POS_T1', label: null });
  assert.match(p.code, /^[ABCDEFGHJKMNPQRSTUVWXYZ23456789]{8}$/);
  assert.equal(formatPairingCode(p.code), `${p.code.slice(0, 4)}-${p.code.slice(4)}`);
  // The app strips the dash and uppercases; lower-case with a dash must still match.
  const claimed = deviceStore.claimPairing(formatPairingCode(p.code).toLowerCase());
  assert.equal(claimed.id, p.id);
  claimed.deviceId = 'dev-x';
  assert.equal(deviceStore.claimPairing(p.code), null, 'a used code cannot pair a second device');
});

test('device signature over the challenge verifies with the stored public key (SHA256withECDSA, DER)', () => {
  const { privateKey, publicB64 } = androidKey();
  assert.ok(isValidPublicKey(publicB64));
  const nonce = crypto.randomBytes(32).toString('base64');
  const sig = crypto.sign('sha256', Buffer.from(nonce), privateKey).toString('base64');
  assert.ok(verifyDeviceSignature(publicB64, nonce, sig));
  assert.ok(!verifyDeviceSignature(publicB64, nonce + 'x', sig), 'a different nonce must fail');
  assert.ok(!verifyDeviceSignature(androidKey().publicB64, nonce, sig), 'another device key must fail');
  assert.ok(!isValidPublicKey('not-a-key'));
});

test('challenge is single use', () => {
  const { nonce } = deviceStore.createChallenge('dev-c');
  assert.ok(deviceStore.takeChallenge('dev-c', nonce));
  assert.ok(!deviceStore.takeChallenge('dev-c', nonce));
});

test('device token works until the device is revoked', () => {
  const d = deviceStore.create({ merchantId: 'm-test', terminalId: 'POS_TEST', label: 'Test', publicKey: androidKey().publicB64 });
  const token = signDeviceToken(d);
  assert.equal(deviceFromToken(token).id, d.id);
  deviceStore.update(d.id, { status: 'REVOKED' });
  assert.throws(() => deviceFromToken(token), (e) => e.code === 'DEVICE_REVOKED');
  assert.throws(() => deviceFromToken('garbage'), (e) => e.code === 'INVALID_TOKEN');
});

test('pairing endpoint is reachable from a real device (never localhost or the emulator alias)', () => {
  const mk = (host) => ({ headers: { host }, socket: {} });
  assert.equal(reachableBaseUrl(mk('pos.example.com')), 'http://pos.example.com');
  for (const host of ['localhost:4100', '127.0.0.1:4100', '10.0.2.2:4100']) {
    assert.doesNotMatch(reachableBaseUrl(mk(host)), /localhost|127\.0\.0\.1|10\.0\.2\.2/);
  }
});
