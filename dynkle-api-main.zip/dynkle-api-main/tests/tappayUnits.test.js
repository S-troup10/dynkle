// Tap-and-pay helpers that need no chain or database.
// Run: node --test tests/tappayUnits.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import { signServiceRequest, callDynk } from '../src/tappay/dynkService.js';
import { signReceipt, verifyReceipt, sealForPhone, openFromBackend } from '../src/tappay/crypto.js';
import { ed25519FromSeed } from '../src/tappay/keystore.js';
import { base58 } from '../src/tappay/service.js';

test('service requests are HMAC-signed over time, nonce, method, path and body', () => {
  const h = signServiceRequest({ secret: 's'.repeat(40), method: 'post', path: '/internal/x', body: '{"a":1}', ts: 1700000000000, nonce: 'ab' });
  const want = crypto.createHmac('sha256', 's'.repeat(40)).update(`1700000000000.ab.POST./internal/x.${crypto.createHash('sha256').update('{"a":1}').digest('hex')}`).digest('hex');
  assert.equal(h['x-dynkle-signature'], want);
  const other = signServiceRequest({ secret: 's'.repeat(40), method: 'post', path: '/internal/x', body: '{"a":2}', ts: 1700000000000, nonce: 'ab' });
  assert.notEqual(other['x-dynkle-signature'], want);
});

test('the DYNK client refuses to run without a strong shared secret', async () => {
  await assert.rejects(callDynk('POST', '/internal/session/verify', {}, { env: {} }), /DYNK_INTERNAL_BASE_URL/);
  await assert.rejects(callDynk('POST', '/x', {}, { env: { DYNK_INTERNAL_BASE_URL: 'http://x', DYNKLE_SERVICE_SECRET: 'short' } }), /32\+ chars/);
});

test('receipts verify offline and any change breaks them', () => {
  const k = ed25519FromSeed(crypto.randomBytes(32));
  const r = signReceipt({ orderId: crypto.randomUUID(), txSignature: '5'.repeat(88), amount: 123n, mint: 'M', merchantWallet: 'W', merchantName: 'Café', confirmedAt: new Date().toISOString() }, { kid: 3, privateKey: k.privateKey });
  const keys = new Map([[3, k.publicKey]]);
  assert.equal(verifyReceipt(r, keys), true);
  assert.throws(() => verifyReceipt({ ...r, amount: '124' }, keys), /RECEIPT_BAD_SIGNATURE/);
  assert.throws(() => verifyReceipt({ ...r, kid: 4 }, keys), /RECEIPT_UNKNOWN_KID/);
});

test('the precheck blob is bound to the order id', () => {
  const phone = crypto.generateKeyPairSync('x25519');
  const raw = phone.publicKey.export({ format: 'der', type: 'spki' }).subarray(-32);
  const orderId = crypto.randomUUID();
  const blob = sealForPhone({ dynkBalance: '5' }, { phoneEphemeralPub: raw, orderId });
  assert.equal(openFromBackend(blob, { phonePrivateKey: phone.privateKey, orderId }).dynkBalance, '5');
  assert.throws(() => openFromBackend(blob, { phonePrivateKey: phone.privateKey, orderId: crypto.randomUUID() }));
});

test('base58 matches Solana signatures and keeps leading zero bytes', () => {
  assert.equal(base58(Buffer.from([0, 0, 1])), '112');
  assert.equal(base58(Buffer.alloc(32)), '1'.repeat(32));
});

test('tap-and-pay routes are rate limited', async () => {
  const express = (await import('express')).default;
  const router = (await import('../src/tappay/routes.js')).default;
  const app = express(); app.use(router);
  const server = app.listen(0); await new Promise((r) => server.once('listening', r));
  const url = `http://127.0.0.1:${server.address().port}/api/pay/status`;
  let last;
  for (let i = 0; i < 61; i++) last = await fetch(url);
  assert.equal(last.status, 429);
  assert.equal((await last.json()).error, 'RATE_LIMITED');
  server.close();
  setTimeout(() => process.exit(0), 100).unref();
});
