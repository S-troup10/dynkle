// A cloudflared that lost its connections still reports a hostname; customer
// links must not use it. Run: node --test tests/publicUrlTunnel.test.js
import test from 'node:test';
import assert from 'node:assert/strict';
import http from 'node:http';

const metrics = (ready, hostname) => http.createServer((req, res) => {
  res.setHeader('Content-Type', 'application/json');
  if (req.url === '/ready') {
    res.statusCode = ready ? 200 : 503;
    return res.end(JSON.stringify({ status: res.statusCode, readyConnections: ready ? 1 : 0 }));
  }
  if (req.url === '/quicktunnel') return res.end(JSON.stringify({ hostname }));
  res.statusCode = 404; res.end('{}');
});
const listen = (s) => new Promise((r) => s.listen(0, '127.0.0.1', () => r(s.address().port)));

test('a dead tunnel is skipped and a connected one is used', async () => {
  const dead = metrics(false, 'dead-tunnel.trycloudflare.com');
  const live = metrics(true, 'live-tunnel.trycloudflare.com');
  const [deadPort, livePort] = [await listen(dead), await listen(live)];
  try {
    process.env.CLOUDFLARED_METRICS = `${deadPort},${livePort}`;
    process.env.PUBLIC_BASE_URL = 'http://localhost:4100';
    const { customerBaseUrl } = await import('../src/services/publicUrl.js?tunnel-test');
    await new Promise((r) => setTimeout(r, 500)); // first refresh runs on import
    assert.equal(customerBaseUrl(null, 'http://192.168.1.2:4100'), 'https://live-tunnel.trycloudflare.com');
  } finally {
    dead.close(); live.close();
  }
});
