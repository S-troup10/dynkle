// Phase 1 cleanup: no path may fake a payment outside an explicit legacy demo.
// Run: node --test tests/noFakePayments.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';

// Unreachable RPC: anything that needs the chain must fail, never invent data.
process.env.SOLANA_RPC = 'http://127.0.0.1:9';
// Pin DEMO_MODE off: dotenv never overrides a value that is already set.
process.env.DEMO_MODE = 'false';
const { assertNoPaymentBypass } = await import('../src/config.js');
const { verifyParsedTransaction, fetchSolanaBlockhash } = await import('../src/services/solana.js');

test('the retired OTP_DEV_BYPASS refuses to start the server outside tests', () => {
  assert.throws(() => assertNoPaymentBypass({ OTP_DEV_BYPASS: 'true' }), /no longer allowed/);
  assert.throws(() => assertNoPaymentBypass({ OTP_DEV_BYPASS: 'true', NODE_ENV: 'production' }), /no longer allowed/);
  assert.doesNotThrow(() => assertNoPaymentBypass({ OTP_DEV_BYPASS: 'true', NODE_ENV: 'test' }));
  assert.doesNotThrow(() => assertNoPaymentBypass({ OTP_DEV_BYPASS: 'false' }));
  assert.doesNotThrow(() => assertNoPaymentBypass({}));
});

test('test-hash prefixes are never accepted as payments', async () => {
  const order = { referenceKey: null, tokenSymbol: 'SOL', cryptoAmount: '1' };
  for (const fake of ['sol_test_abc', 'sol_tx_abc', 'mock_abc', '5Kd' + 'x'.repeat(10)]) {
    await assert.rejects(verifyParsedTransaction(order, fake), /INVALID_TRANSACTION_SIGNATURE|TRANSACTION_NOT_FOUND|fetch failed|ECONNREFUSED/, fake);
    // Even when a caller asks for it, DEMO_MODE is off here.
    await assert.rejects(verifyParsedTransaction(order, fake, { allowDemoHash: true }), /INVALID_TRANSACTION_SIGNATURE|TRANSACTION_NOT_FOUND|fetch failed|ECONNREFUSED/, fake);
  }
});

test('no invented blockhash when Solana is unreachable', async () => {
  await assert.rejects(fetchSolanaBlockhash(), /BLOCKHASH_UNAVAILABLE/);
});
