// USDC is the stable settlement token (AUDC retired); venue amounts stay in AUD.
// Run: node --test tests/usdcSettlement.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import { audToUsdc, calculateCustomerFee, getCachedPriceAUD } from '../src/services/priceService.js';
import {
  getAcceptedCurrencySymbols,
  getMerchantSplitSwapPreview,
  merchantState,
  normalizeSettle,
  setMerchantWallets,
} from '../src/merchantStore.js';

test('AUD converts to USDC at the USDC/AUD price, not 1:1', () => {
  const price = getCachedPriceAUD('USDC');
  assert.ok(price > 1, 'USDC is worth more than 1 AUD');
  assert.equal(audToUsdc(price * 10), 10);
  assert.equal(getCachedPriceAUD('AUDC'), 0, 'AUDC is no longer priced');
});

test('USDC keeps the 0.5% stablecoin fee', () => {
  assert.equal(calculateCustomerFee('USDC', 100), 0.5);
});

test('USDC is directly accepted and AUDC is gone', () => {
  const accepted = getAcceptedCurrencySymbols();
  assert.ok(accepted.includes('USDC'));
  assert.ok(!accepted.includes('AUDC'));
  assert.ok(!merchantState.currencies.swapAndSend.some((c) => c.symbol === 'USDC'), 'USDC is not a swap-and-send token');
});

test('stable buckets settle in USDC; split amounts are converted from AUD', () => {
  const preview = getMerchantSplitSwapPreview(100, 'ETH');
  const stable = preview.walletAllocations.filter((w) => w.token === 'USDC');
  assert.ok(stable.length > 0);
  for (const w of stable) assert.equal(Number(w.amount), audToUsdc(w.shareAUD));
  assert.match(preview.summary, /USDC/);
  assert.doesNotMatch(JSON.stringify(preview), /AUDC/);
});

test('old clients sending settle "AUDC" are mapped to USDC', () => {
  assert.equal(normalizeSettle('AUDC'), 'USDC');
  assert.equal(normalizeSettle('Hold'), 'Hold');
  const before = merchantState.wallets;
  try {
    setMerchantWallets(before.map((w, i) => ({ ...w, settle: i === 0 ? 'AUDC' : w.settle })));
    assert.equal(merchantState.wallets[0].settle, 'USDC');
  } finally {
    merchantState.wallets = before;
  }
});
