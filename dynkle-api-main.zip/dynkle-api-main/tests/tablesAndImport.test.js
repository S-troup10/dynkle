// Table payments and catalogue import: pure helpers (no database, no network).
import { test } from 'node:test';
import assert from 'node:assert/strict';

const tables = await import('../src/tables/service.js');
const extract = await import('../src/catalog/extract.js');
const importer = await import('../src/catalog/importService.js');
const appLinks = await import('../src/tappay/appLinks.js');

// ── Tables ──────────────────────────────────────────────────────────────

test('tag codes: generated codes are valid, unguessable and unique', () => {
  const seen = new Set();
  for (let i = 0; i < 500; i++) {
    const c = tables.newTagCode();
    assert.match(c, /^[a-z2-9]{12}$/);
    assert.equal(tables.normalizeTagCode(c), c);
    seen.add(c);
  }
  assert.equal(seen.size, 500);
});

test('tag codes: normalisation accepts printed codes and refuses junk', () => {
  assert.equal(tables.normalizeTagCode(' Table-Two '), 'table-two');
  assert.equal(tables.normalizeTagCode('abc'), null); // too short
  assert.equal(tables.normalizeTagCode('-abcd'), null);
  assert.equal(tables.normalizeTagCode('a b c d'), null);
  assert.equal(tables.normalizeTagCode('../etc'), null);
  assert.equal(tables.normalizeTagCode('x'.repeat(41)), null);
});

test('table counter code is stable and short', () => {
  const t = { id: '8598722d-dea6-46d3-96f5-f42fbd40f601' };
  assert.equal(tables.tableCounterCode(t), 'TB-8598722DDE');
});

test('tableDto: totals, no order before sending, lock only while active', () => {
  const base = {
    id: 't1', floorPlanId: 'p1', zoneId: 'z1', name: '4', seats: 2, shape: 'rect', x: 0, y: 0, w: 80, h: 64,
    tagCode: null, status: 'OCCUPIED', boundOrderId: null, sentAt: null, paidAt: null, version: 3,
    items: [{ productId: 'a', name: 'Flat white', variants: [], unitCents: 480, qty: 2 }, { productId: 'b', name: 'Banh mi', variants: [], unitCents: 1450, qty: 1 }],
    lockedBy: 'device:x', lockLabel: 'Bar till', lockedUntil: new Date(Date.now() + 30_000),
  };
  const d = tables.tableDto(base, { id: 'o1' });
  assert.equal(d.subtotalCents, 2410);
  assert.equal(d.itemCount, 3);
  assert.equal(d.order, null);
  assert.equal(d.tagUrl, null);
  assert.equal(d.lock.label, 'Bar till');
  const expired = tables.tableDto({ ...base, lockedUntil: new Date(Date.now() - 1) });
  assert.equal(expired.lock, null);
});

test('tableDto: a sent table shows its order and the tag URL', () => {
  const d = tables.tableDto(
    { id: 't1', floorPlanId: 'p', zoneId: 'z', name: '1', seats: 2, shape: 'round', x: 1, y: 2, w: 80, h: 80, tagCode: 'abcd1234', status: 'READY', items: [], version: 1 },
    { id: 'o1', displayNumber: 12, status: 'QUOTED', totalAUD: '9.02', customerFeeAUD: '0.0150', quoteExpiresAt: new Date('2026-10-16T05:00:00Z') },
  );
  assert.equal(d.order.totalCents, 902);
  assert.equal(d.order.feeCents, 2);
  assert.equal(d.order.holdExpiresAt, '2026-10-16T05:00:00.000Z');
  assert.match(d.tagUrl, /\/tb\/abcd1234$/);
});

test('app links open DYNK for table tags as well as payment links', () => {
  const aasa = appLinks.appleAppSiteAssociation({ APPLE_TEAM_ID: 'TEAM', IOS_BUNDLE_ID: 'io.dynk.www' });
  assert.deepEqual(aasa.applinks.details[0].paths, ['/o/*', '/tb/*']);
});

// ── Menu reading ────────────────────────────────────────────────────────

test('sniffType trusts file contents, not names', () => {
  assert.equal(extract.sniffType(Buffer.from('%PDF-1.7 xxxxxxxx')), 'application/pdf');
  assert.equal(extract.sniffType(Buffer.from([0x89, 0x50, 0x4e, 0x47, 0x0d, 0x0a, 0x1a, 0x0a, 0, 0, 0, 0])), 'image/png');
  assert.equal(extract.sniffType(Buffer.from([0xff, 0xd8, 0xff, 0xe0, 0, 0, 0, 0, 0, 0, 0, 0])), 'image/jpeg');
  assert.equal(extract.sniffType(Buffer.from('RIFF\0\0\0\0WEBPVP8 ')), 'image/webp');
  assert.equal(extract.sniffType(Buffer.from('<html><script>alert(1)</script>')), null);
  assert.equal(extract.sniffType(Buffer.from('short')), null);
});

test('parseJsonLoose reads plain, fenced and wrapped JSON', () => {
  assert.deepEqual(extract.parseJsonLoose('{"items":[]}'), { items: [] });
  assert.deepEqual(extract.parseJsonLoose('```json\n{"items":[1]}\n```'), { items: [1] });
  assert.deepEqual(extract.parseJsonLoose('Here you go: {"a":2} hope that helps'), { a: 2 });
  assert.throws(() => extract.parseJsonLoose('no json here'), (e) => e.code === 'EXTRACT_UNREADABLE');
});

test('normalizeRows: names, prices, two-level categories, GST, confidence', () => {
  const { rows, notes } = extract.normalizeRows({
    notes: 'check specials',
    items: [
      { name: 'Flat white .....', price: '4,80', section: 'COFFEE', confidence: 0.97 },
      { name: 'House red, glass', price: 11, section: 'Drinks', subsection: 'Wine', confidence: 0.7 },
      { name: 'Sourdough loaf', price: 8, section: 'Bakery', gst: 'free', confidence: 0.94 },
      { name: 'Mystery', price: null, section: 'Specials', confidence: 0.99 },
      { name: 'x', price: 3 },
      { name: 'Huge', price: 1e9 },
    ],
  });
  assert.equal(notes, 'check specials');
  assert.equal(rows.length, 5);
  assert.deepEqual(rows[0], { name: 'Flat white', price: 4.8, category: 'Coffee', gst: 'inc', confidence: 0.97, page: 1 });
  assert.equal(rows[1].category, 'Drinks > Wine');
  assert.equal(rows[2].gst, 'free');
  assert.equal(rows[3].price, null);
  assert.ok(rows[3].confidence <= 0.4, 'unreadable price is flagged');
  assert.equal(rows[4].price, null);
  assert.equal(rows[4].category, 'Uncategorised');
});

test('extraction config: cheapest configured reader first, Sonnet as fallback', () => {
  assert.deepEqual(
    (({ primary, fallback }) => ({ primary, fallback }))(extract.extractionConfig({ GEMINI_API_KEY: 'g', ANTHROPIC_API_KEY: 'a' })),
    { primary: 'gemini', fallback: 'anthropic' },
  );
  assert.equal(extract.extractionConfig({ ANTHROPIC_API_KEY: 'a' }).primary, 'anthropic');
  assert.equal(extract.extractionConfig({ ANTHROPIC_API_KEY: 'a' }).fallback, null);
  assert.equal(extract.extractionConfig({ CATALOG_EXTRACT_PROVIDER: 'gemini', ANTHROPIC_API_KEY: 'a' }).primary, 'anthropic');
});

const row = (name, confidence) => ({ name, price: 5, category: 'A', gst: 'inc', confidence, page: 1 });
const fakeImpl = (first, second, calls) => ({
  gemini: async () => { calls.push('gemini'); return { rows: first, notes: '', provider: 'gemini' }; },
  anthropic: async () => { calls.push('anthropic'); return { rows: second, notes: '', provider: 'anthropic' }; },
});
const env = { GEMINI_API_KEY: 'g', ANTHROPIC_API_KEY: 'a' };

test('extractMenu: a clean read stays on the cheap model', async () => {
  const calls = [];
  const r = await extract.extractMenu([], env, fakeImpl([row('a', 0.95), row('b', 0.7)], [], calls));
  assert.deepEqual(calls, ['gemini']);
  assert.equal(r.provider, 'gemini');
  assert.equal(r.escalated, false);
  assert.equal(r.uncertain, 1);
});

test('extractMenu: several uncertain rows are re-read by the premium model', async () => {
  const calls = [];
  const r = await extract.extractMenu([], env, fakeImpl([row('a', 0.5), row('b', 0.6), row('c', 0.7)], [row('a', 0.95), row('b', 0.9), row('c', 0.6)], calls));
  assert.deepEqual(calls, ['gemini', 'anthropic']);
  assert.equal(r.provider, 'anthropic');
  assert.equal(r.escalated, true);
  assert.equal(r.uncertain, 1);
});

test('extractMenu: a worse or failing second read keeps the first', async () => {
  const calls = [];
  const first = [row('a', 0.5), row('b', 0.6), row('c', 0.7)];
  const r = await extract.extractMenu([], env, fakeImpl(first, [], calls));
  assert.equal(r.provider, 'gemini');
  const failing = { gemini: async () => ({ rows: first, notes: '', provider: 'gemini' }), anthropic: async () => { throw new Error('down'); } };
  assert.equal((await extract.extractMenu([], env, failing)).provider, 'gemini');
});

test('extractMenu: nothing configured, or nothing found, is a clear error', async () => {
  await assert.rejects(extract.extractMenu([], {}, {}), (e) => e.code === 'EXTRACT_NOT_CONFIGURED');
  assert.equal(extract.extractionConfig({ DEMO_MODE: 'true' }).primary, 'demo');
  assert.equal(extract.extractionConfig({ CATALOG_EXTRACT_PROVIDER: 'demo' }).primary, null, 'demo reader only in DEMO_MODE');
  await assert.rejects(extract.extractMenu([], { GEMINI_API_KEY: 'g' }, fakeImpl([], [], [])), (e) => e.code === 'NOTHING_FOUND');
});

// ── Import commit validation ────────────────────────────────────────────

test('validateRow: clean rows pass with tax and two-level category', () => {
  const v = importer.validateRow({ name: '  Flat   white ', price: '$4.80', category: 'Drinks > Coffee > Hot', gst: 'inc', icon: '☕' });
  assert.equal(v.ok, true);
  assert.deepEqual(
    (({ name, price, category, tax, icon }) => ({ name, price, category, tax, icon }))(v.product),
    { name: 'Flat white', price: 4.8, category: 'Drinks > Coffee', tax: '10', icon: '☕' },
  );
  assert.equal(importer.validateRow({ name: 'Loaf', price: 8, gst: 'free' }).product.tax, '0');
  assert.equal(importer.validateRow({ name: 'Loaf', price: 8, tax: '0' }).product.tax, '0');
  assert.equal(importer.validateRow({ name: 'Loaf', price: 8 }).product.category, 'Uncategorised');
});

test('validateRow: bad rows are flagged with a reason', () => {
  assert.equal(importer.validateRow({ name: '', price: 3 }).reason, 'Missing product name.');
  assert.equal(importer.validateRow({ name: 'A', price: '' }).ok, false);
  assert.equal(importer.validateRow({ name: 'A', price: 'abc' }).ok, false);
  assert.equal(importer.validateRow({ name: 'A', price: 0 }).reason, 'Price must be above zero.');
  assert.equal(importer.validateRow({ name: 'A', price: 1e7 }).ok, false);
  assert.equal(importer.validateRow({ name: 'x'.repeat(81), price: 1 }).ok, false);
  assert.equal(importer.validateRow({ name: 'A', price: 1, icon: 'not-an-emoji' }).product.icon, undefined);
});

// ── Waiter ownership and service mode ───────────────────────────────────

test('ownership: a waiter edits own and unowned tables, only views others; the merchant edits all', () => {
  const waiterA = { kind: 'device', ownerKey: 'device:a' };
  const waiterB = { kind: 'device', ownerKey: 'device:b' };
  const merchant = { kind: 'portal', ownerKey: 'merchant' };
  const free = { ownerKey: null };
  const aTable = { ownerKey: 'device:a' };
  const mTable = { ownerKey: 'merchant' };
  assert.equal(tables.canEdit(free, waiterB), true);
  assert.equal(tables.canEdit(aTable, waiterA), true);
  assert.equal(tables.canEdit(aTable, waiterB), false);
  assert.equal(tables.canEdit(mTable, waiterA), false, 'merchant-opened tables wait for a handover');
  assert.equal(tables.canEdit(aTable, merchant), true);
});

test('service mode: set explicitly, else tables for cafés/restaurants/bars or venues with tables', () => {
  assert.equal(tables.resolveServiceMode({ serviceMode: 'COUNTER', industry: 'cafe' }, 5), 'COUNTER');
  assert.equal(tables.resolveServiceMode({ serviceMode: 'TABLES', industry: 'fashion' }), 'TABLES');
  assert.equal(tables.resolveServiceMode({ industry: 'restaurant' }), 'TABLES');
  assert.equal(tables.resolveServiceMode({ industry: 'fashion' }), 'COUNTER');
  assert.equal(tables.resolveServiceMode({ industry: 'bakery' }, 3), 'TABLES');
  assert.equal(tables.resolveServiceMode(null), 'COUNTER');
});

// ── Connected tables (events) ───────────────────────────────────────────

test('groups: members point at the first table; names in order; title for customers', () => {
  const lead = { id: 'a', name: '2', groupLeaderId: null, groupName: 'Birthday', tagCode: 'tag-2' };
  const m1 = { id: 'b', name: '1', groupLeaderId: 'a', tagCode: 'tag-1' };
  const m3 = { id: 'c', name: '3', groupLeaderId: 'a', tagCode: 'tag-3' };
  const loner = { id: 'd', name: '9', groupLeaderId: null };
  const all = [lead, m1, m3, loner];
  const g = tables.groupOf(m3, all);
  assert.equal(g.leaderId, 'a');
  assert.deepEqual(g.names, ['1', '2', '3']);
  assert.equal(tables.groupTitle(g), 'Birthday · Tables 1 + 2 + 3');
  assert.equal(tables.groupOf(loner, all), null);
  assert.equal(tables.groupTitle({ name: null, names: ['Window', 'Bar 2'] }), 'Window + Bar 2');
});

test('groups: first tap wins until the hold runs out', () => {
  const now = Date.parse('2026-10-16T10:00:00Z');
  const open = { status: 'READY', groupClaimTag: null, groupClaimUntil: null };
  assert.deepEqual(tables.claimDecision(open, 'tag-1', now), { allowed: true, claim: true });
  const held = { ...open, groupClaimTag: 'tag-1', groupClaimUntil: new Date(now + 60_000) };
  assert.equal(tables.claimDecision(held, 'tag-1', now).allowed, true, 'the same tag again');
  assert.deepEqual(tables.claimDecision(held, 'tag-2', now), { allowed: false, by: 'tag-1' });
  const lapsed = { ...held, groupClaimUntil: new Date(now - 1) };
  assert.equal(tables.claimDecision(lapsed, 'tag-2', now).allowed, true, 'a lapsed hold frees the group');
  assert.equal(tables.claimDecision({ status: 'FREE' }, 'tag-2', now).claim, false, 'nothing to pay: no hold');
  assert.equal(tables.claimDecision({ status: 'PAID' }, 'tag-2', now).claim, false);
});
