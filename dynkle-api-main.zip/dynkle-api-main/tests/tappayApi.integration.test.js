// Tap-and-pay endpoints end to end: real routes, a real local validator and a
// separate test database. Nothing is faked on the payment path; the only
// stand-in is the DYNK backend's session check (an HTTP server that verifies
// the HMAC headers like the real one will).
//
// Needs:
//   solana-test-validator --reset --quiet &
//   TAPPAY_TEST_RPC=http://127.0.0.1:8899
//   TAPPAY_TEST_DATABASE_URL=<postgres url of an EMPTY, migrated test database>
//   node --test tests/tappayApi.integration.test.js
import { test, describe, before, after } from 'node:test';
import assert from 'node:assert/strict';
import crypto from 'node:crypto';
import http from 'node:http';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';

const RPC = process.env.TAPPAY_TEST_RPC;
const DB = process.env.TAPPAY_TEST_DATABASE_URL;
const skip = !(RPC && DB) && 'set TAPPAY_TEST_RPC and TAPPAY_TEST_DATABASE_URL';

const SECRET = crypto.randomBytes(24).toString('hex'); // 48 chars
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'tappay-api-'));

describe('tap-and-pay API', { skip }, () => {
  let web3, spl, prisma, service, intentLib, cryptoLib, chainLib, tapRequestLib, keystore, deviceStore, signDeviceToken, appLinks;
  let conn, server, base, dynkMock, dynkUsers;
  let auth, customer, poorCustomer, otherCustomer, merchantWallet, collector, mint;
  // Stand-in Swap and Pay (DYNK backend): a real SPL delegate on a local "vault".
  let usdcMint, swapCustomer, vaultOwner, delegate, vault, treasury;
  const swap = { quotes: new Map(), confirmed: [], released: [], refuseCosign: false };
  const pushes = [];
  let merchant, device, deviceToken, publicKeys;

  async function api(method, url, body, token = deviceToken) {
    const r = await fetch(`${base}${url}`, {
      method,
      headers: { 'content-type': 'application/json', ...(token ? { authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      redirect: 'manual',
    });
    const text = await r.text();
    let json = null;
    try { json = JSON.parse(text); } catch { /* not json */ }
    return { status: r.status, json, headers: r.headers };
  }

  const eph = () => crypto.generateKeyPairSync('x25519');
  const rawPub = (k) => Buffer.from(k.publicKey.export({ format: 'der', type: 'spki' }).subarray(-32));

  async function newPayment(totalCents = 300) {
    const termEph = eph();
    const body = { totalCents, terminalEphemeralPub: rawPub(termEph).toString('base64'), bleSessionId: crypto.randomBytes(8).toString('base64') };
    let r = await api('POST', '/api/terminals/me/payments', body);
    // The suite makes more than the real limit of 30 payments a minute per terminal: wait it out.
    for (let i = 0; r.status === 429 && i < 15; i++) {
      await new Promise((ok) => setTimeout(ok, 5000));
      r = await api('POST', '/api/terminals/me/payments', body);
    }
    assert.equal(r.status, 200, JSON.stringify(r.json));
    return r.json;
  }

  async function payOffline(orderId, payer, { tamper = false } = {}) {
    const phone = eph();
    const pre = await api('POST', '/api/pay/relay/precheck', { orderId, customerPubkey: payer.publicKey.toBase58(), phoneEphemeralPub: rawPub(phone).toString('base64') });
    const built = await api('POST', '/api/pay/relay/build', { orderId, customerPubkey: payer.publicKey.toBase58(), option: 'DIRECT' });
    assert.equal(built.status, 200, JSON.stringify(built.json));
    // Phone side: the exact message bytes inside the transaction it received.
    const msg = web3.VersionedTransaction.deserialize(Buffer.from(built.json.transaction, 'base64')).message.serialize();
    const toSign = tamper ? Buffer.concat([Buffer.from(msg), Buffer.from([0])]) : Buffer.from(msg);
    const signature = Buffer.from(signWith(payer, toSign)).toString("base64");
    const sub = await api('POST', '/api/pay/relay/submit', { orderId, quoteId: built.json.quoteId, customerPubkey: payer.publicKey.toBase58(), signature });
    return { pre, built, sub, phone };
  }

  function signWith(kp, message) {
    const pkcs8 = Buffer.concat([Buffer.from('302e020100300506032b657004220420', 'hex'), Buffer.from(kp.secretKey.subarray(0, 32))]);
    return crypto.sign(null, message, crypto.createPrivateKey({ key: pkcs8, format: 'der', type: 'pkcs8' }));
  }

  async function waitAttempt(orderId, quoteId, want, ms = 40000) {
    const end = Date.now() + ms;
    let last;
    while (Date.now() < end) {
      last = await api('GET', `/api/pay/relay/attempts/${quoteId}?orderId=${orderId}`);
      if (want.includes(last.json?.status)) return last.json;
      await new Promise((r) => setTimeout(r, 500));
    }
    throw new Error(`attempt stayed ${last?.json?.status}`);
  }

  // 1 DYNK = 0.10 USDC. DYNK top-up rounded up to 6 decimals (as direct-buy), USDC rounded up.
  function swapMock(op, b, reply) {
    const ix = (i) => ({ programId: i.programId.toBase58(), keys: i.keys.map((k) => ({ pubkey: k.pubkey.toBase58(), isSigner: k.isSigner, isWritable: k.isWritable })), data: Buffer.from(i.data).toString('base64') });
    if (op === 'quote') {
      const short = BigInt(b.dynkShortfall);
      const dynkAmount = ((short + 999n) / 1000n) * 1000n;
      const usdcAmount = (dynkAmount + 9_999n) / 10_000n;
      const cust = new web3.PublicKey(b.customerPubkey);
      const instructions = [
        ix(spl.createTransferCheckedInstruction(spl.getAssociatedTokenAddressSync(usdcMint, cust), usdcMint, treasury, cust, usdcAmount, 6)),
        ix(spl.createTransferCheckedInstruction(vault, mint, spl.getAssociatedTokenAddressSync(mint, cust, true), delegate.publicKey, dynkAmount, 9)),
      ];
      const quoteId = b.dryRun ? null : crypto.randomUUID();
      const expiresAt = new Date(Math.min(Date.parse(b.expiresAt), Date.now() + 90_000)).toISOString();
      const q = { quoteId, usdcMint: usdcMint.toBase58(), usdcAmount: usdcAmount.toString(), dynkMint: mint.toBase58(), dynkAmount: dynkAmount.toString(), treasuryUsdcAccount: treasury.toBase58(), vault: vault.toBase58(), delegate: delegate.publicKey.toBase58(), instructions, expiresAt };
      if (quoteId) swap.quotes.set(quoteId, { ...q, state: 'RESERVED' });
      return reply(200, q);
    }
    const q = swap.quotes.get(b.quoteId);
    if (!q) return reply(404, { error: 'QUOTE_NOT_FOUND' });
    if (op === 'cosign') {
      if (swap.refuseCosign || q.state !== 'RESERVED') return reply(409, { error: 'COSIGN_REFUSED' });
      const msg = web3.Message.from(Buffer.from(b.message, 'base64'));
      const got = msg.instructions.map((i) => JSON.stringify({ programId: msg.accountKeys[i.programIdIndex].toBase58(), keys: i.accounts.map((a) => msg.accountKeys[a].toBase58()), data: web3.Message.from ? Buffer.from(require58(i.data)).toString('base64') : '' }));
      const want = q.instructions.map((i) => JSON.stringify({ programId: i.programId, keys: i.keys.map((k) => k.pubkey), data: i.data }));
      if (!want.every((w) => got.includes(w))) return reply(409, { error: 'MESSAGE_MISMATCH' });
      q.state = 'COSIGNED';
      q.txSignature = b.feePayerSignature;
      return reply(200, { signature: Buffer.from(signWith(delegate, Buffer.from(b.message, 'base64'))).toString('base64'), delegate: delegate.publicKey.toBase58() });
    }
    if (op === 'confirm') { q.state = 'CONFIRMED'; swap.confirmed.push(b); return reply(200, { status: 'CONFIRMED' }); }
    if (op === 'release') { if (q.state !== 'CONFIRMED') q.state = 'RELEASED'; swap.released.push(b.quoteId); return reply(200, { released: true }); }
    return reply(404, { error: 'NOT_FOUND' });
  }
  // Message.instructions[].data is base58 in web3.js 1.x.
  const B58 = '123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz';
  function require58(str) {
    let n = 0n;
    for (const c of str) n = n * 58n + BigInt(B58.indexOf(c));
    let hex = n.toString(16); if (hex.length % 2) hex = '0' + hex;
    const lead = [...str].findIndex((c) => c !== '1');
    return Buffer.concat([Buffer.alloc(lead < 0 ? str.length : lead), n === 0n ? Buffer.alloc(0) : Buffer.from(hex, 'hex')]);
  }

  before(async () => {
    process.env.DATABASE_URL = DB;
    process.env.SOLANA_RPC = RPC;
    process.env.DEVICES_STORE_PATH = path.join(tmp, 'devices.json');
    process.env.DEMO_MODE = 'false';
    web3 = await import('@solana/web3.js');
    spl = await import('@solana/spl-token');
    conn = new web3.Connection(RPC, 'confirmed');

    // Chain fixtures: a DYNK-like mint (9 decimals), funded customers.
    [auth, customer, poorCustomer, otherCustomer, merchantWallet, collector] = [0, 1, 2, 3, 4, 5].map(() => web3.Keypair.generate());
    const drop = async (pk) => { const s = await conn.requestAirdrop(pk, 2e9); await conn.confirmTransaction({ signature: s, ...(await conn.getLatestBlockhash()) }, 'confirmed'); };
    await drop(auth.publicKey);
    mint = await spl.createMint(conn, auth, auth.publicKey, null, 9, web3.Keypair.generate(), { commitment: 'confirmed' });
    for (const [kp, amount] of [[customer, 10_000n], [otherCustomer, 10_000n], [poorCustomer, 1n]]) {
      const ata = await spl.getOrCreateAssociatedTokenAccount(conn, auth, mint, kp.publicKey, false, 'confirmed', { commitment: 'confirmed' });
      await spl.mintTo(conn, auth, mint, ata.address, auth, amount * 10n ** 9n, [], { commitment: 'confirmed' });
    }
    // Swap and Pay fixtures: USDC (6 decimals), a DYNK vault with a capped delegate, a USDC treasury,
    // and a customer with 1 DYNK + 100 USDC.
    [swapCustomer, vaultOwner, delegate] = [0, 1, 2].map(() => web3.Keypair.generate());
    usdcMint = await spl.createMint(conn, auth, auth.publicKey, null, 6, web3.Keypair.generate(), { commitment: 'confirmed' });
    vault = (await spl.getOrCreateAssociatedTokenAccount(conn, auth, mint, vaultOwner.publicKey, false, 'confirmed', { commitment: 'confirmed' })).address;
    await spl.mintTo(conn, auth, mint, vault, auth, 1_000_000n * 10n ** 9n, [], { commitment: 'confirmed' });
    await drop(vaultOwner.publicKey);
    await spl.approve(conn, auth, vault, delegate.publicKey, vaultOwner, 50_000n * 10n ** 9n, [], { commitment: 'confirmed' });
    treasury = (await spl.getOrCreateAssociatedTokenAccount(conn, auth, usdcMint, web3.Keypair.generate().publicKey, false, 'confirmed', { commitment: 'confirmed' })).address;
    const swapDynk = await spl.getOrCreateAssociatedTokenAccount(conn, auth, mint, swapCustomer.publicKey, false, 'confirmed', { commitment: 'confirmed' });
    await spl.mintTo(conn, auth, mint, swapDynk.address, auth, 1n * 10n ** 9n, [], { commitment: 'confirmed' });
    const swapUsdc = await spl.getOrCreateAssociatedTokenAccount(conn, auth, usdcMint, swapCustomer.publicKey, false, 'confirmed', { commitment: 'confirmed' });
    await spl.mintTo(conn, auth, usdcMint, swapUsdc.address, auth, 100n * 10n ** 6n, [], { commitment: 'confirmed' });

    // Keystore with a funded sponsor.
    keystore = await import('../src/tappay/keystore.js');
    const sponsor = web3.Keypair.generate();
    await drop(sponsor.publicKey);
    const seed = crypto.randomBytes(32);
    const ksFile = path.join(tmp, 'ks.json');
    fs.writeFileSync(ksFile, JSON.stringify(keystore.encryptKeystore({ activeKid: 7, intentKeys: [{ kid: 7, seed: seed.toString('base64') }], sponsorSecretKey: Buffer.from(sponsor.secretKey).toString('base64') }, 'test keystore passphrase')));

    // Stand-in DYNK backend: verifies HMAC headers, maps token -> wallets.
    dynkUsers = new Map([
      ['tok-customer', { userId: 1, wallets: [customer.publicKey.toBase58()] }],
      ['tok-swap', { userId: 2, wallets: [swapCustomer.publicKey.toBase58()] }],
    ]);
    dynkMock = http.createServer((req, res) => {
      let body = '';
      req.on('data', (c) => { body += c; });
      req.on('end', () => {
        const ts = req.headers['x-dynkle-ts']; const nonce = req.headers['x-dynkle-nonce'];
        const want = crypto.createHmac('sha256', SECRET).update(`${ts}.${nonce}.${req.method}.${req.url}.${crypto.createHash('sha256').update(body).digest('hex')}`).digest('hex');
        if (want !== req.headers['x-dynkle-signature'] || Math.abs(Date.now() - Number(ts)) > 60000) { res.writeHead(401); return res.end('{"error":"BAD_HMAC"}'); }
        const reply = (status, json) => { res.writeHead(status, { 'content-type': 'application/json' }); res.end(JSON.stringify(json)); };
        const b = JSON.parse(body || '{}');
        if (req.url === '/internal/session/verify') {
          const u = dynkUsers.get(b.token);
          return reply(u ? 200 : 401, u || { error: 'UNAUTHENTICATED' });
        }
        if (req.url.startsWith('/internal/swap/')) return swapMock(req.url.slice('/internal/swap/'.length), b, reply);
        if (req.url === '/internal/push/payment-status') { pushes.push(b); return reply(200, { sent: true }); }
        reply(404, { error: 'NOT_FOUND' });
      });
    }).listen(0);
    await new Promise((r) => dynkMock.once('listening', r));

    Object.assign(process.env, {
      DYNK_MINT_ADDRESS: mint.toBase58(), DYNK_MINT_DECIMALS: '9',
      TAP_PAY_KEYSTORE_FILE: ksFile, TAP_PAY_KEYSTORE_PASSPHRASE: 'test keystore passphrase',
      TAP_PAY_FEE_COLLECTOR: collector.publicKey.toBase58(), TAP_PAY_PLATFORM_FEE_USD: '0.01',
      PUBLIC_PAY_DOMAIN: 'pay.test.dynkle.io', USDC_MINT_ADDRESS: usdcMint.toBase58(),
      DYNK_INTERNAL_BASE_URL: `http://127.0.0.1:${dynkMock.address().port}`, DYNKLE_SERVICE_SECRET: SECRET,
      DYNK_SESSION_CHECK: '', // a local .env may set the hosted-profile test mode; these tests use the HMAC stand-in
    });

    prisma = (await import('../src/db.js')).default;
    service = await import('../src/tappay/service.js');
    intentLib = await import('../src/tappay/intent.js');
    cryptoLib = await import('../src/tappay/crypto.js');
    chainLib = await import('../src/tappay/chain.js');
    tapRequestLib = await import('../src/tappay/tapRequest.js');
    appLinks = await import('../src/tappay/appLinks.js');
    ({ deviceStore } = await import('../src/devices/deviceStore.js'));
    ({ signDeviceToken } = await import('../src/devices/deviceAuth.js'));
    const tappayRouter = (await import('../src/tappay/routes.js')).default;
    await service.initTapPay({ connection: conn, log: { log() {}, warn() {}, error: console.error } });
    assert.equal(service.tapPay.ready, true, service.tapPay.reason);

    // Merchant with a Solana wallet, and a paired device on POS_TEST.
    merchant = await prisma.merchant.create({ data: { legalName: 'Test Pty Ltd', tradingName: 'Test Café', businessType: 'company', registeredAddress: '1 Test St, Sydney' } });
    await prisma.wallet.create({ data: { merchantId: merchant.id, label: 'Main', blockchain: 'solana', address: merchantWallet.publicKey.toBase58() } });
    device = deviceStore.create({ merchantId: merchant.id, terminalId: `POS_T${Date.now() % 100000}`, label: 'Test device', publicKey: 'x' });
    deviceToken = signDeviceToken(device);

    const express = (await import('express')).default;
    const app = express();
    app.use(express.json());
    app.use(tappayRouter);
    app.use('/api/solana-pay', (await import('../src/routes/solanaPay.js')).default);
    app.use('/api/auto-swap', (await import('../src/routes/autoSwap.js')).default);
    app.use('/api/orders', (await import('../src/routes/orders.js')).default);
    server = app.listen(0);
    await new Promise((r) => server.once('listening', r));
    base = `http://127.0.0.1:${server.address().port}`;
    publicKeys = new Map([[7, keystore.ed25519FromSeed(seed).publicKey]]);
  });

  after(async () => {
    server?.close(); dynkMock?.close();
    if (prisma && merchant) await prisma.merchant.delete({ where: { id: merchant.id } }).catch(() => {});
    await prisma?.$disconnect();
    // confirm loops and housekeeping timers must not keep the run alive
    setTimeout(() => process.exit(0), 200).unref();
  });

  test('create payment returns a signed intent and a /o/ link', async () => {
    const p = await newPayment(300);
    assert.match(p.link, new RegExp(`^https://pay\\.test\\.dynkle\\.io/o/${p.orderId}#[A-Za-z0-9_-]+$`));
    assert.equal(p.link.split('#')[1], p.intent);
    const intent = intentLib.verifyIntent(intentLib.fromBase64Url(p.intent), publicKeys);
    assert.equal(intent.orderId, p.orderId);
    assert.equal(intent.terminalId, device.id);
    assert.equal(intent.fiatAmount, 300n);
    assert.equal(intent.mint, mint.toBase58());
    assert.equal(intent.merchantWallet, merchantWallet.publicKey.toBase58());
    assert.equal(intent.merchantName, 'Test Café');
    assert.ok(p.ttlSeconds > 100 && p.ttlSeconds <= 120);
    const order = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(p.orderNumber, order.displayNumber);
    assert.deepEqual(p.dynk, {
      amount: order.tapPayAmount.toString(), fee: order.tapPayFee.toString(),
      total: (BigInt(order.tapPayAmount) + BigInt(order.tapPayFee)).toString(), decimals: 9,
    });
    const keys = await api('GET', '/api/pay/intent-keys', null, null);
    assert.deepEqual(keys.json.keys.map((k) => k.kid), [7]);
  });

  test('refresh gives a new intent for the same order without extending it', async () => {
    const p = await newPayment(450);
    // New session keys (what the terminal sends every 60 s) -> a different intent.
    const fresh = await api('POST', `/api/terminals/me/payments/${p.orderId}/intent`, {
      terminalEphemeralPub: rawPub(eph()).toString('base64'), bleSessionId: crypto.randomBytes(8).toString('base64'),
    });
    assert.equal(fresh.status, 200);
    assert.notEqual(fresh.json.intent, p.intent);
    assert.equal(fresh.json.expiresAt, p.expiresAt);
    const a = intentLib.decodeIntent(intentLib.fromBase64Url(p.intent));
    const b = intentLib.decodeIntent(intentLib.fromBase64Url(fresh.json.intent));
    assert.equal(a.expiresAt, b.expiresAt, 'refresh never extends the order');
    assert.notDeepEqual(a.bleSessionId, b.bleSessionId);
    // Without new keys it re-signs the same terms (Ed25519 is deterministic).
    const same = await api('POST', `/api/terminals/me/payments/${p.orderId}/intent`, {});
    assert.equal(same.json.intent, fresh.json.intent);
    // v6: one intent per issue, for QR and tap alike; only the newest is current.
    assert.equal(await prisma.paymentIntent.count({ where: { orderId: p.orderId, supersededAt: null } }), 1);
    assert.equal(await prisma.paymentIntent.count({ where: { orderId: p.orderId } }), 3);
    assert.equal('tapIntent' in p, false);
  });

  test('relay: precheck hides balances from the terminal; the phone can read them', async () => {
    const p = await newPayment(300);
    const phone = eph();
    const pre = await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(phone).toString('base64') });
    assert.equal(pre.status, 200);
    assert.equal(pre.json.result, 'OK');
    assert.deepEqual(Object.keys(pre.json).sort(), ['build', 'expiresAt', 'fee', 'private', 'result']);
    assert.ok(!JSON.stringify(pre.json).includes('10000000000000'), 'no clear balance');
    const opened = cryptoLib.openFromBackend(pre.json.private, { phonePrivateKey: phone.privateKey, orderId: p.orderId });
    assert.equal(opened.dynkBalance, (10_000n * 10n ** 9n).toString());
    assert.equal(opened.fee, pre.json.fee.baseUnits);
    const other = eph();
    assert.throws(() => cryptoLib.openFromBackend(pre.json.private, { phonePrivateKey: other.privateKey, orderId: p.orderId }));
    const poor = await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: poorCustomer.publicKey.toBase58(), phoneEphemeralPub: rawPub(phone).toString('base64') });
    assert.equal(poor.json.result, 'INSUFFICIENT');
    assert.equal(poor.json.build, null, 'nothing to sign when there is not enough');
  });

  test('QR (v6): the transaction is built in parallel with the balance check and arrives with the precheck; sign it directly -> PAID', async () => {
    const p = await newPayment(305);
    const pre = await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64'), phoneOnline: false });
    assert.equal(pre.json.result, 'OK');
    const b = pre.json.build;
    assert.equal(b.option, 'DIRECT');
    assert.equal(b.feePayer, service.tapPay.keys.sponsor.publicKey.toBase58());
    const vtx = web3.VersionedTransaction.deserialize(Buffer.from(b.transaction, 'base64'));
    assert.ok(await conn.isBlockhashValid(vtx.message.recentBlockhash, { commitment: 'confirmed' }).then((r) => r.value));
    const signature = Buffer.from(signWith(customer, Buffer.from(vtx.message.serialize()))).toString('base64');
    const sub = await api('POST', '/api/pay/relay/submit', { orderId: p.orderId, quoteId: b.quoteId, customerPubkey: customer.publicKey.toBase58(), signature });
    assert.equal(sub.json.status, 'SUBMITTED', JSON.stringify(sub.json));
    assert.equal((await waitAttempt(p.orderId, b.quoteId, ['CONFIRMED', 'FAILED'])).status, 'CONFIRMED');
  });

  test('relay: build -> sign -> submit -> confirmed on-chain -> PAID with a signed receipt', async () => {
    const p = await newPayment(300);
    const { built, sub } = await payOffline(p.orderId, customer);
    assert.equal(sub.status, 200, JSON.stringify(sub.json));
    assert.equal(sub.json.status, 'SUBMITTED');
    const done = await waitAttempt(p.orderId, built.json.quoteId, ['CONFIRMED', 'FAILED']);
    assert.equal(done.status, 'CONFIRMED', JSON.stringify(done));
    const order = await prisma.order.findUnique({ where: { id: p.orderId }, include: { transaction: true } });
    assert.equal(order.status, 'PAID');
    assert.equal(order.transaction.txHash, done.txSignature);
    assert.equal(cryptoLib.verifyReceipt(done.receipt, publicKeys), true);
    assert.equal(done.receipt.amount, order.tapPayAmount.toString());
    // The chain agrees with the books.
    const merchantAta = spl.getAssociatedTokenAddressSync(mint, merchantWallet.publicKey, true);
    const bal = await spl.getAccount(conn, merchantAta, 'confirmed');
    assert.ok(bal.amount >= order.tapPayAmount);
    // Submitting again is idempotent.
    const again = await api('POST', '/api/pay/relay/submit', { orderId: p.orderId, quoteId: built.json.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: 'AAAA' });
    assert.equal(again.json.status, 'CONFIRMED');
    // The paid order can't be paid again.
    const late = await api('POST', '/api/pay/relay/build', { orderId: p.orderId, customerPubkey: otherCustomer.publicKey.toBase58() });
    assert.equal(late.status, 409);
    assert.equal(late.json.error, 'ORDER_PAID');
  });

  test('two customers racing on one order: only one is submitted', async () => {
    const p = await newPayment(200);
    const prep = async (kp) => {
      const b = await api('POST', '/api/pay/relay/build', { orderId: p.orderId, customerPubkey: kp.publicKey.toBase58() });
      const msg = web3.VersionedTransaction.deserialize(Buffer.from(b.json.transaction, 'base64')).message.serialize();
      return { quoteId: b.json.quoteId, customerPubkey: kp.publicKey.toBase58(), signature: Buffer.from(signWith(kp, Buffer.from(msg))).toString('base64') };
    };
    const [x, y] = await Promise.all([prep(customer), prep(otherCustomer)]);
    const [rx, ry] = await Promise.all([
      api('POST', '/api/pay/relay/submit', { orderId: p.orderId, ...x }),
      api('POST', '/api/pay/relay/submit', { orderId: p.orderId, ...y }),
    ]);
    const statuses = [rx, ry].map((r) => r.json?.status || r.json?.error).sort();
    assert.deepEqual(statuses, ['PAYMENT_IN_PROGRESS', 'SUBMITTED'], JSON.stringify([rx.json, ry.json]));
    const winner = rx.json.status === 'SUBMITTED' ? x : y;
    await waitAttempt(p.orderId, winner.quoteId, ['CONFIRMED']);
  });

  test('a signature over different bytes is refused and nothing is sent', async () => {
    const p = await newPayment(150);
    const { sub } = await payOffline(p.orderId, customer, { tamper: true });
    assert.equal(sub.status, 400);
    assert.equal(sub.json.error, 'BAD_SIGNATURE');
    const order = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(order.paymentLock, null);
    assert.notEqual(order.status, 'PAID');
  });

  test('not enough DYNK: simulation declines (signed), the lock is released, nothing lands', async () => {
    const p = await newPayment(5000);
    const { sub } = await payOffline(p.orderId, poorCustomer);
    assert.equal(sub.json.status, 'DECLINED');
    assert.equal(sub.json.failureCode, 'INSUFFICIENT_FUNDS');
    assert.equal(sub.json.reason, 'INSUFFICIENT');
    assert.equal('swapAvailable' in sub.json, false);
    assert.equal(cryptoLib.verifyDecline(sub.json.decline, publicKeys), true);
    assert.equal(sub.json.decline.customerPubkey, poorCustomer.publicKey.toBase58());
    const order = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(order.paymentLock, null);
    assert.equal(order.status, 'CUSTOMER_DETECTED');
  });

  test('expired orders refuse precheck, build and refresh', async () => {
    const p = await newPayment(100);
    await prisma.order.update({ where: { id: p.orderId }, data: { quoteExpiresAt: new Date(Date.now() - 1000) } });
    const pre = await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64') });
    assert.equal(pre.status, 410);
    const b = await api('POST', '/api/pay/relay/build', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58() });
    assert.equal(b.status, 410);
    const r = await api('POST', `/api/terminals/me/payments/${p.orderId}/intent`, {});
    assert.equal(r.status, 409);
  });

  test('a device can only use orders on its own counter', async () => {
    const p = await newPayment(100);
    const stranger = deviceStore.create({ merchantId: merchant.id, terminalId: 'POS_OTHER', label: 'Other', publicKey: 'y' });
    const r = await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64') }, signDeviceToken(stranger));
    assert.equal(r.status, 404);
    const d = await api('GET', `/api/terminals/me/payments/${p.orderId}/display`, null, signDeviceToken(stranger));
    assert.equal(d.status, 404);
    const mine = await api('GET', `/api/terminals/me/payments/${p.orderId}/display`);
    assert.deepEqual(mine.json, { merchantName: 'Test Café', location: '1 Test St, Sydney' });
  });

  test('online: DYNK session checked via HMAC; only your own wallet can pay', async () => {
    const p = await newPayment(250);
    const noAuth = await api('POST', '/api/pay/online/precheck', { orderId: p.orderId }, null);
    assert.equal(noAuth.status, 401);
    const bad = await api('POST', '/api/pay/online/precheck', { orderId: p.orderId }, 'tok-unknown');
    assert.equal(bad.status, 401);
    const notMine = await api('POST', '/api/pay/online/precheck', { orderId: p.orderId, customerPubkey: otherCustomer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64') }, 'tok-customer');
    assert.equal(notMine.status, 403);
    const intent = await api('GET', `/api/pay/orders/${p.orderId}/intent`, null, 'tok-customer');
    assert.equal(intent.json.intent, p.intent);
    const disp = await api('GET', `/api/pay/orders/${p.orderId}/display`, null, 'tok-customer');
    assert.equal(disp.json.location, '1 Test St, Sydney');

    const phone = eph();
    const pre = await api('POST', '/api/pay/online/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(phone).toString('base64') }, 'tok-customer');
    assert.equal(pre.json.result, 'OK');
    const b = await api('POST', '/api/pay/online/build', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58() }, 'tok-customer');
    const msg = web3.VersionedTransaction.deserialize(Buffer.from(b.json.transaction, 'base64')).message.serialize();
    const s = await api('POST', '/api/pay/online/submit', { orderId: p.orderId, quoteId: b.json.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: Buffer.from(signWith(customer, Buffer.from(msg))).toString('base64') }, 'tok-customer');
    assert.equal(s.json.status, 'SUBMITTED', JSON.stringify(s.json));
    // An offline quote id can't be submitted on the online channel and vice versa.
    const cross = await api('POST', '/api/pay/relay/submit', { orderId: p.orderId, quoteId: b.json.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: 'AAAA' });
    assert.equal(cross.status, 404);
    const end = Date.now() + 40000;
    let st;
    while (Date.now() < end) {
      st = await api('GET', `/api/pay/online/attempts/${b.json.quoteId}?orderId=${p.orderId}`, null, 'tok-customer');
      if (st.json.status !== 'SUBMITTED') break;
      await new Promise((r) => setTimeout(r, 500));
    }
    assert.equal(st.json.status, 'CONFIRMED');
  });

  test('decline records the choice and keeps the order open', async () => {
    const p = await newPayment(120);
    await api('POST', '/api/pay/online/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64') }, 'tok-customer');
    const d = await api('POST', '/api/pay/online/decline', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58() }, 'tok-customer');
    assert.equal(d.json.declined, true);
    const a = await prisma.paymentAttempt.findFirst({ where: { orderId: p.orderId } });
    assert.equal(a.status, 'CUSTOMER_DECLINED');
    const o = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(o.status, 'QUOTED');
  });

  test('abandoned attempts are deleted (no pubkeys kept)', async () => {
    const p = await newPayment(110);
    await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: customer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64') });
    await prisma.paymentAttempt.updateMany({ where: { orderId: p.orderId }, data: { createdAt: new Date(Date.now() - 11 * 60 * 1000) } });
    assert.ok((await service.sweepAbandoned()) >= 1);
    assert.equal(await prisma.paymentAttempt.count({ where: { orderId: p.orderId } }), 0);
  });

  test('website wallet: the server-built transaction is verified on-chain and booked PAID', async () => {
    const p = await newPayment(275);
    // A browser wallet pays its own Solana fee, so the customer needs SOL here.
    const s1 = await conn.requestAirdrop(customer.publicKey, 1e9);
    await conn.confirmTransaction({ signature: s1, ...(await conn.getLatestBlockhash()) }, 'confirmed');
    const { transaction } = await service.buildForWebWallet({ orderId: p.orderId, account: customer.publicKey.toBase58() });
    const vtx = web3.VersionedTransaction.deserialize(Buffer.from(transaction, 'base64'));
    assert.equal(vtx.message.staticAccountKeys[0].toBase58(), customer.publicKey.toBase58(), 'customer is the fee payer');
    vtx.sign([customer]);
    const sig = await conn.sendRawTransaction(vtx.serialize());
    await conn.confirmTransaction({ signature: sig, ...(await conn.getLatestBlockhash()) }, 'confirmed');
    // The watcher finds it by the reference and books it.
    const end = Date.now() + 30000;
    let order;
    while (Date.now() < end) {
      await service.watchWebPayments();
      order = await prisma.order.findUnique({ where: { id: p.orderId }, include: { transaction: true } });
      if (order.status === 'PAID') break;
      await new Promise((r) => setTimeout(r, 500));
    }
    assert.equal(order.status, 'PAID');
    assert.equal(order.transaction.txHash, sig);
    const attempt = await prisma.paymentAttempt.findUnique({ where: { txSignature: sig } });
    assert.equal(attempt.channel, 'WEBSITE');
    assert.equal(cryptoLib.verifyReceipt(attempt.receipt, publicKeys), true);
    // Reporting the same signature again changes nothing.
    assert.equal((await service.confirmWebSignature(order, sig)).status, 'CONFIRMED');
  });

  test('website wallet: a transfer with the reference but the wrong amount is never booked', async () => {
    const p = await newPayment(180);
    const order = await prisma.order.findUnique({ where: { id: p.orderId } });
    const merchantAta = spl.getAssociatedTokenAddressSync(mint, merchantWallet.publicKey, true);
    const customerAta = spl.getAssociatedTokenAddressSync(mint, customer.publicKey, false);
    const tx = new web3.Transaction();
    tx.add(spl.createAssociatedTokenAccountIdempotentInstruction(customer.publicKey, merchantAta, merchantWallet.publicKey, mint));
    const ix = spl.createTransferCheckedInstruction(customerAta, mint, merchantAta, customer.publicKey, BigInt(order.tapPayAmount) - 1n, 9);
    ix.keys.push({ pubkey: new web3.PublicKey(order.referenceKey), isSigner: false, isWritable: false });
    tx.add(ix);
    const sig = await web3.sendAndConfirmTransaction(conn, tx, [customer], { commitment: 'confirmed' });
    const r = await service.confirmWebSignature(order, sig);
    assert.equal(r.status, 'NOT_A_PAYMENT');
    await service.watchWebPayments();
    const after = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.notEqual(after.status, 'PAID');
    assert.equal(after.paymentLock, null);
  });

  test('/o/:orderId sends browsers to the checkout; app links come only from env', async () => {
    const r = await api('GET', '/o/0b6b1e1e-1111-4222-8333-944444444444', null, null);
    assert.equal(r.status, 302);
    assert.equal(r.headers.get('location'), '/pay.html?orderId=0b6b1e1e-1111-4222-8333-944444444444&via=link');
    assert.equal((await api('GET', '/o/not-a-uuid', null, null)).status, 404);
    assert.deepEqual(appLinks.androidAssetLinks({}), []);
    assert.deepEqual(appLinks.appleAppSiteAssociation({}).applinks.details, []);
    const al = appLinks.androidAssetLinks({ ANDROID_CERT_SHA256: 'aa:bb, CC:DD' });
    assert.deepEqual(al[0].target, { namespace: 'android_app', package_name: 'io.dynk.www', sha256_cert_fingerprints: ['AA:BB', 'CC:DD'] });
    const aasa = appLinks.appleAppSiteAssociation({ APPLE_TEAM_ID: 'ABCDE12345', IOS_BUNDLE_ID: 'io.dynk.www' });
    assert.deepEqual(aasa.applinks.details[0].appIDs, ['ABCDE12345.io.dynk.www']);
    assert.deepEqual(aasa.applinks.details[0].paths, ['/o/*', '/tb/*']);
  });
  // ── Tap and Pay (Cases 3 and 4), spec v6 ──────────────────────────────

  /**
   * One tap as terminal and phone run it: the phone's public key (GET_IDENTITY)
   * -> tap/prepare -> the phone checks the NFC request (intent, tap quote,
   * transaction) and partially signs. Returns what the terminal would submit.
   */
  async function tap(orderId, payer, { phoneOnline = false } = {}) {
    const prep = await api('POST', '/api/terminals/me/tap/prepare', { orderId, customerPubkey: payer.publicKey.toBase58(), phoneOnline });
    if (prep.json?.result !== 'OK') return { prep };
    const r = tapRequestLib.decodeTapRequest(Buffer.from(prep.json.request, 'base64'));
    const intent = intentLib.verifyIntent(r.intent, publicKeys);
    assert.equal(intent.orderId, orderId);
    assert.equal(cryptoLib.verifyTapQuote(r.tapQuote, publicKeys), true);
    const msg = web3.Transaction.from(r.transaction).serializeMessage();
    assert.equal(chainLib.sha256Hex(msg), r.tapQuote.messageHash, 'the quote binds this exact transaction');
    return { prep, request: r, msg, quoteId: prep.json.quoteId, signature: Buffer.from(signWith(payer, msg)).toString('base64') };
  }

  async function fundDynk(kp, baseUnits) {
    const ata = await spl.getOrCreateAssociatedTokenAccount(conn, auth, mint, kp.publicKey, false, 'confirmed', { commitment: 'confirmed' });
    await spl.mintTo(conn, auth, mint, ata.address, auth, baseUnits, [], { commitment: 'confirmed' });
  }

  /** Moves all of kp's DYNK away (the authority pays the fee). */
  async function drain(kp) {
    const from = spl.getAssociatedTokenAddressSync(mint, kp.publicKey);
    const { amount } = await spl.getAccount(conn, from, 'confirmed');
    const to = (await spl.getOrCreateAssociatedTokenAccount(conn, auth, mint, auth.publicKey, false, 'confirmed', { commitment: 'confirmed' })).address;
    await spl.transfer(conn, auth, from, to, kp, amount, [], { commitment: 'confirmed' });
  }

  async function waitTapPaid(orderId, ms = 40000) {
    const end = Date.now() + ms;
    let o;
    while (Date.now() < end) {
      o = await prisma.order.findUnique({ where: { id: orderId }, include: { paymentAttempts: true } });
      if (o.status === 'PAID') return o;
      await new Promise((r) => setTimeout(r, 500));
    }
    throw new Error(`order stayed ${o?.status}`);
  }

  test('tap prepare: balance check and build in parallel -> the NFC request (intent, signed tap quote, backend-built transaction)', async () => {
    const p = await newPayment(330);
    const t = await tap(p.orderId, customer, { phoneOnline: true });
    assert.equal(t.prep.status, 200, JSON.stringify(t.prep.json));
    assert.equal(Buffer.from(t.request.intent).toString('base64url'), p.intent, 'the same intent as the QR');
    const order = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(t.request.tapQuote.fee, String(order.tapPayFee));
    assert.equal(t.request.tapQuote.quoteId, t.quoteId);
    const tx = web3.Transaction.from(t.request.transaction);
    assert.equal(tx.feePayer.toBase58(), service.tapPay.keys.sponsor.publicKey.toBase58());
    assert.ok(await conn.isBlockhashValid(tx.recentBlockhash, { commitment: 'confirmed' }).then((r) => r.value));
    const a = await prisma.paymentAttempt.findUnique({ where: { quoteId: t.quoteId } });
    assert.deepEqual([a.channel, a.status, a.option], ['TAP_ONLINE', 'BUILT', 'DIRECT']);
    assert.ok(!JSON.stringify(t.prep.json).match(/"(dynk|usdc)?[bB]alance"/), 'no balances to the terminal');
  });

  test('tap (Case 4): phone partially signs during the tap, terminal submits -> PAID; a late copy changes nothing', async () => {
    const p = await newPayment(260);
    const t = await tap(p.orderId, customer);
    const r = await api('POST', '/api/terminals/me/tap/submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: t.signature });
    assert.equal(r.status, 200, JSON.stringify(r.json));
    assert.equal(r.json.status, 'SUBMITTED');
    const o = await waitTapPaid(p.orderId);
    const a = o.paymentAttempts.find((x) => x.status === 'CONFIRMED');
    assert.equal(a.channel, 'TAP_OFFLINE');
    assert.equal(cryptoLib.verifyReceipt(a.receipt, publicKeys), true);
    // The phone also delivers the same signature over the internet: same attempt, nothing new.
    const late = await api('POST', '/api/pay/tap/late-submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: t.signature }, 'tok-customer');
    assert.equal(late.status, 200, JSON.stringify(late.json));
    assert.equal(late.json.status, 'CONFIRMED');
    assert.equal(late.json.quoteId, a.quoteId);
    assert.equal(await prisma.paymentAttempt.count({ where: { orderId: p.orderId } }), 1);
  });

  test('tap (Case 3, pulled away before "Sent"): only the phone delivers the signature -> PAID', async () => {
    const p = await newPayment(240);
    const t = await tap(p.orderId, customer, { phoneOnline: true });
    const late = await api('POST', '/api/pay/tap/late-submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: t.signature }, 'tok-customer');
    assert.equal(late.json.status, 'SUBMITTED', JSON.stringify(late.json));
    const o = await waitTapPaid(p.orderId);
    assert.equal(o.paymentAttempts.find((x) => x.status === 'CONFIRMED').channel, 'TAP_ONLINE');
    // Not your wallet: refused before anything else.
    const p2 = await newPayment(240);
    const other = await tap(p2.orderId, otherCustomer);
    const notMine = await api('POST', '/api/pay/tap/late-submit', { orderId: p2.orderId, quoteId: other.quoteId, customerPubkey: otherCustomer.publicKey.toBase58(), signature: other.signature }, 'tok-customer');
    assert.equal(notMine.status, 403);
  });

  test('tap: a signature over anything but the quoted message is refused; nothing is sent', async () => {
    const p = await newPayment(210);
    const t = await tap(p.orderId, customer);
    const forged = Buffer.from(t.msg); forged[forged.length - 1] ^= 1;
    const r = await api('POST', '/api/terminals/me/tap/submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: Buffer.from(signWith(customer, forged)).toString('base64') });
    assert.equal(r.status, 400);
    assert.equal(r.json.error, 'BAD_SIGNATURE');
    const o = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(o.paymentLock, null);
    assert.notEqual(o.status, 'PAID');
    const wrongQuote = await api('POST', '/api/terminals/me/tap/submit', { orderId: p.orderId, quoteId: crypto.randomUUID(), customerPubkey: customer.publicKey.toBase58(), signature: t.signature });
    assert.equal(wrongQuote.status, 404);
  });

  test('tap: a tap quote cannot be submitted over the relay (QR) path', async () => {
    const p = await newPayment(205);
    const t = await tap(p.orderId, customer);
    const viaRelay = await api('POST', '/api/pay/relay/submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: t.signature });
    assert.equal(viaRelay.status, 404);
  });

  test('tap (Cases 3 and 4) without enough DYNK: declined during the tap, nothing to sign, order stays open', async () => {
    for (const phoneOnline of [true, false]) {
      const p = await newPayment(4000);
      const t = await tap(p.orderId, poorCustomer, { phoneOnline });
      assert.equal(t.prep.json.result, 'INSUFFICIENT', JSON.stringify(t.prep.json));
      assert.equal('request' in t.prep.json, false, 'no transaction to sign');
      const notice = JSON.parse(Buffer.from(t.prep.json.declineBytes, 'base64').toString('utf8'));
      assert.deepEqual(notice, t.prep.json.decline);
      assert.equal(notice.reason, 'INSUFFICIENT');
      assert.equal(cryptoLib.verifyDecline(notice, publicKeys), true);
      const rows = await prisma.paymentAttempt.findMany({ where: { orderId: p.orderId } });
      assert.deepEqual(rows.map((x) => [x.channel, x.status, x.messageBytes]), [[phoneOnline ? 'TAP_ONLINE' : 'TAP_OFFLINE', 'DECLINED', null]]);
      const o = await prisma.order.findUnique({ where: { id: p.orderId } });
      assert.equal(o.paymentLock, null);
      assert.ok(['CUSTOMER_DETECTED', 'QUOTED'].includes(o.status));
    }
  });

  test('tap: balance gone after the prepare -> simulation DECLINED {reason}, nothing lands', async () => {
    const p = await newPayment(4000);
    const rich = web3.Keypair.generate();
    await fundDynk(rich, BigInt((await prisma.order.findUnique({ where: { id: p.orderId } })).tapPayAmount) * 2n);
    const t = await tap(p.orderId, rich);
    assert.equal(t.prep.json.result, 'OK');
    await drain(rich);
    const r = await api('POST', '/api/terminals/me/tap/submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: rich.publicKey.toBase58(), signature: t.signature });
    assert.equal(r.json.status, 'DECLINED', JSON.stringify(r.json));
    assert.equal(r.json.reason, 'INSUFFICIENT');
    assert.equal(cryptoLib.verifyDecline(r.json.decline, publicKeys), true);
    assert.equal((await prisma.order.findUnique({ where: { id: p.orderId } })).paymentLock, null);
  });

  test('tap: a new tap replaces the unsent quote of the earlier one; tap/report is gone', async () => {
    const p = await newPayment(190);
    const first = await tap(p.orderId, customer);
    const second = await tap(p.orderId, customer);
    const old = await prisma.paymentAttempt.findUnique({ where: { quoteId: first.quoteId } });
    assert.equal(old.status, 'EXPIRED');
    const r = await api('POST', '/api/terminals/me/tap/submit', { orderId: p.orderId, quoteId: first.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: first.signature });
    assert.equal(r.status, 409);
    assert.equal((await api('POST', '/api/terminals/me/tap/report', { orderId: p.orderId, status: 'INSUFFICIENT' })).status, 404);
    assert.ok(second.quoteId);
  });

  test('balances: your own wallet only', async () => {
    const r = await api('GET', `/api/pay/balances?customerPubkey=${customer.publicKey.toBase58()}`, null, 'tok-customer');
    assert.equal(r.status, 200, JSON.stringify(r.json));
    assert.equal(r.json.dynk.mint, mint.toBase58());
    assert.equal(r.json.dynk.decimals, 9);
    assert.match(r.json.dynk.amount, /^\d+$/);
    assert.equal('usdc' in r.json, false, 'Tap and Pay needs the DYNK balance only (v5)');
    const other = await api('GET', `/api/pay/balances?customerPubkey=${otherCustomer.publicKey.toBase58()}`, null, 'tok-customer');
    assert.equal(other.status, 403);
    assert.equal((await api('GET', `/api/pay/balances?customerPubkey=${customer.publicKey.toBase58()}`, null, null)).status, 401);
  });

  test('live status (SSE): PROCESSING then CONFIRMED with the receipt; no wallet in events', async () => {
    const p = await newPayment(170);
    const ctrl = new AbortController();
    const res = await fetch(`${base}/api/pay/orders/${p.orderId}/events`, { headers: { authorization: 'Bearer tok-customer' }, signal: ctrl.signal });
    assert.equal(res.status, 200);
    assert.match(res.headers.get('content-type'), /text\/event-stream/);
    const events = [];
    const reading = (async () => {
      const dec = new TextDecoder();
      let buf = '';
      for await (const chunk of res.body) {
        buf += dec.decode(chunk);
        let i;
        while ((i = buf.indexOf('\n\n')) >= 0) {
          const block = buf.slice(0, i); buf = buf.slice(i + 2);
          const data = block.split('\n').find((l) => l.startsWith('data: '));
          if (data) events.push(JSON.parse(data.slice(6)));
        }
        if (events.some((e) => e.status === 'CONFIRMED')) break;
      }
    })().catch(() => {});
    const t = await tap(p.orderId, customer, { phoneOnline: true });
    await api('POST', '/api/pay/tap/late-submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: t.signature }, 'tok-customer');
    const end = Date.now() + 40000;
    while (Date.now() < end && !events.some((e) => e.status === 'CONFIRMED')) await new Promise((r) => setTimeout(r, 300));
    ctrl.abort();
    await reading;
    assert.deepEqual(events.map((e) => e.status), ['PROCESSING', 'CONFIRMED']);
    assert.equal(cryptoLib.verifyReceipt(events[1].receipt, publicKeys), true);
    assert.ok(events.every((e) => !('customerPubkey' in e)));
  });

  test('live status (SSE) is a backup: a phone subscribing after the result still gets it (v5)', async () => {
    const p = await newPayment(175);
    const t = await tap(p.orderId, customer);
    const r = await api('POST', '/api/terminals/me/tap/submit', { orderId: p.orderId, quoteId: t.quoteId, customerPubkey: customer.publicKey.toBase58(), signature: t.signature });
    assert.equal((await waitAttempt(p.orderId, r.json.quoteId, ['CONFIRMED'])).status, 'CONFIRMED');
    const first = async (token) => {
      const ctrl = new AbortController();
      const res = await fetch(`${base}/api/pay/orders/${p.orderId}/events`, { headers: { authorization: `Bearer ${token}` }, signal: ctrl.signal });
      const dec = new TextDecoder();
      let buf = '';
      const timer = setTimeout(() => ctrl.abort(), 3000);
      try {
        for await (const chunk of res.body) {
          buf += dec.decode(chunk);
          const data = buf.split('\n').find((l) => l.startsWith('data: '));
          if (data) return JSON.parse(data.slice(6));
        }
      } catch { /* aborted: nothing was sent */ } finally { clearTimeout(timer); ctrl.abort(); }
      return null;
    };
    const e = await first('tok-customer');
    assert.equal(e?.status, 'CONFIRMED', JSON.stringify(e));
    assert.equal(cryptoLib.verifyReceipt(e.receipt, publicKeys), true);
    assert.equal('customerPubkey' in e, false);
    assert.equal(await first('tok-swap'), null, "another user's stream gets nothing about this payment");
  });
  // ── Swap and Pay (stand-in DYNK service, real SPL delegate) ───────────

  async function tokenAmount(owner, m) {
    return (await spl.getAccount(conn, spl.getAssociatedTokenAddressSync(m, owner, true), 'confirmed')).amount;
  }

  // Over Bluetooth via the terminal. phoneOnline: true = Case 1 (Swap and Pay possible), false = Case 2.
  async function relayPay(orderId, payer, option, { phoneOnline = true } = {}) {
    const phone = eph();
    const pre = await api('POST', '/api/pay/relay/precheck', { orderId, customerPubkey: payer.publicKey.toBase58(), phoneEphemeralPub: rawPub(phone).toString('base64'), phoneOnline });
    const opened = cryptoLib.openFromBackend(pre.json.private, { phonePrivateKey: phone.privateKey, orderId });
    const built = await api('POST', '/api/pay/relay/build', { orderId, customerPubkey: payer.publicKey.toBase58(), option });
    if (built.status !== 200) return { pre, opened, built };
    const vtx = web3.VersionedTransaction.deserialize(Buffer.from(built.json.transaction, 'base64'));
    const signature = Buffer.from(signWith(payer, Buffer.from(vtx.message.serialize()))).toString('base64');
    const sub = await api('POST', '/api/pay/relay/submit', { orderId, quoteId: built.json.quoteId, customerPubkey: payer.publicKey.toBase58(), signature });
    return { pre, opened, built, vtx, sub };
  }

  test('Swap and Pay: SWAP_OFFER -> one transaction (USDC in, DYNK top-up, merchant paid 100%) -> PAID -> confirm', async () => {
    const p = await newPayment(1500); // $15 = 100 DYNK at 0.15; the customer has 1 DYNK + 100 USDC
    const usdcBefore = await tokenAmount(swapCustomer.publicKey, usdcMint);
    const { pre, opened, built, vtx, sub } = await relayPay(p.orderId, swapCustomer, 'SWAP');
    assert.equal(pre.json.result, 'SWAP_OFFER');
    assert.ok(!JSON.stringify(pre.json).includes(opened.swap.usdcAmount + '"'), 'USDC amount only inside the private blob');
    assert.equal(opened.swap.delegate, delegate.publicKey.toBase58());
    assert.equal(built.json.option, 'SWAP');
    const signers = vtx.message.staticAccountKeys.slice(0, vtx.message.header.numRequiredSignatures).map((k) => k.toBase58());
    assert.deepEqual(signers.sort(), [service.tapPay.keys.sponsor.publicKey.toBase58(), swapCustomer.publicKey.toBase58(), delegate.publicKey.toBase58()].sort());
    assert.equal(sub.json.status, 'SUBMITTED', JSON.stringify(sub.json));
    const done = await waitAttempt(p.orderId, built.json.quoteId, ['CONFIRMED', 'FAILED']);
    assert.equal(done.status, 'CONFIRMED', JSON.stringify(done));
    const order = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(order.status, 'PAID');
    assert.equal(usdcBefore - (await tokenAmount(swapCustomer.publicKey, usdcMint)), BigInt(opened.swap.usdcAmount));
    const attempt = await prisma.paymentAttempt.findFirst({ where: { orderId: p.orderId, status: 'CONFIRMED' } });
    assert.equal(attempt.option, 'SWAP');
    const end = Date.now() + 10000;
    while (Date.now() < end && !swap.confirmed.some((c) => c.quoteId === attempt.swapQuoteId)) await new Promise((r) => setTimeout(r, 200));
    assert.deepEqual(swap.confirmed.find((c) => c.quoteId === attempt.swapQuoteId), { quoteId: attempt.swapQuoteId, txSignature: done.txSignature });
    assert.equal(swap.quotes.get(attempt.swapQuoteId).txSignature, Buffer.from(require58(done.txSignature)).toString('base64'), 'cosign was told the tx id');
  });

  test('Swap and Pay: no USDC -> INSUFFICIENT and the quote is released; SWAP build refused', async () => {
    const p = await newPayment(1500);
    const released = swap.released.length;
    const { pre, built } = await relayPay(p.orderId, poorCustomer, 'SWAP');
    assert.equal(pre.json.result, 'INSUFFICIENT');
    assert.equal(swap.released.length, released + 1);
    assert.equal(built.status, 409);
    assert.equal(built.json.error, 'SWAP_UNAVAILABLE');
  });

  test('Swap and Pay: cosign refused -> FAILED SWAP_UNAVAILABLE, lock and quote released', async () => {
    const p = await newPayment(1500);
    swap.refuseCosign = true;
    try {
      const { sub } = await relayPay(p.orderId, swapCustomer, 'SWAP');
      assert.equal(sub.json.status, 'FAILED');
      assert.equal(sub.json.failureCode, 'SWAP_UNAVAILABLE');
    } finally { swap.refuseCosign = false; }
    const o = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.equal(o.paymentLock, null);
    const a = await prisma.paymentAttempt.findFirst({ where: { orderId: p.orderId } });
    assert.ok(swap.released.includes(a.swapQuoteId));
  });

  test('Case 2 (phone offline over Bluetooth): short DYNK with USDC -> INSUFFICIENT, no quote asked, SWAP build refused', async () => {
    const p = await newPayment(1500);
    const quotes = swap.quotes.size;
    const { pre, opened, built } = await relayPay(p.orderId, swapCustomer, 'SWAP', { phoneOnline: false });
    assert.equal(pre.json.result, 'INSUFFICIENT');
    assert.equal(opened.swap, null);
    assert.equal(opened.usdcBalance, '0', 'USDC is not read where Swap and Pay is impossible');
    assert.equal(swap.quotes.size, quotes, 'the DYNK backend was never asked for a quote');
    assert.equal(built.status, 409);
    assert.equal(built.json.error, 'SWAP_UNAVAILABLE');
  });

  test('relay precheck: only phoneOnline === true counts as online', async () => {
    const p = await newPayment(1500);
    const quotes = swap.quotes.size;
    for (const phoneOnline of ['true', 1, null, undefined]) {
      const r = await api('POST', '/api/pay/relay/precheck', { orderId: p.orderId, customerPubkey: swapCustomer.publicKey.toBase58(), phoneEphemeralPub: rawPub(eph()).toString('base64'), phoneOnline });
      assert.equal(r.json.result, 'INSUFFICIENT', String(phoneOnline));
    }
    assert.equal(swap.quotes.size, quotes);
  });

  test('tap with USDC but short DYNK: declined during the tap; never a Swap and Pay offer', async () => {
    const p = await newPayment(1500);
    const quotes = swap.quotes.size;
    const t = await tap(p.orderId, swapCustomer, { phoneOnline: true });
    assert.equal(t.prep.json.result, 'INSUFFICIENT', JSON.stringify(t.prep.json));
    assert.equal(t.prep.json.decline.reason, 'INSUFFICIENT');
    assert.equal('swapAvailable' in t.prep.json.decline, false);
    assert.equal(swap.quotes.size, quotes, 'no Swap and Pay quote after a tap');
    const o = await prisma.order.findUnique({ where: { id: p.orderId } });
    assert.notEqual(o.status, 'PAID');
  });
  // ── Fix round: push backup, demo gating, rate limits, dashboard channel ──

  test('push backup: CONFIRMED goes to the DYNK backend with display data only', async () => {
    const p = await newPayment(310);
    const { built } = await payOffline(p.orderId, customer);
    await waitAttempt(p.orderId, built.json.quoteId, ['CONFIRMED']);
    const end = Date.now() + 10000;
    let push;
    while (Date.now() < end && !(push = pushes.find((x) => x.orderId === p.orderId))) await new Promise((r) => setTimeout(r, 200));
    assert.ok(push, 'push sent');
    assert.equal(push.status, 'CONFIRMED');
    assert.equal(push.customerPubkey, customer.publicKey.toBase58());
    assert.equal(push.merchantName, 'Test Café');
    assert.match(push.amountFiat, /^\$\d+\.\d{2} AUD$/);
    assert.deepEqual(Object.keys(push).sort(), ['amountFiat', 'customerPubkey', 'merchantName', 'orderId', 'status'], 'no balances');
  });

  test('demo-only simulation is refused unless DEMO_MODE; config tells pages', async () => {
    const r = await api('POST', '/api/auto-swap/simulate-payment', { amountAUD: 10, currency: 'SOL', buckets: [{ id: 'a', pct: 100 }] }, null);
    assert.equal(r.status, 404);
    assert.equal(r.json.error, 'DEMO_ONLY');
    const c = await api('GET', '/api/pay/config', null, null);
    assert.equal(c.json.demoMode, false);
    const demo = await api('GET', '/api/orders/demo-123', null, null);
    assert.equal(demo.status, 404, 'demo* ids are not special outside DEMO_MODE');
  });

  test('website checkout routes are rate limited', async () => {
    const id = crypto.randomUUID();
    let last;
    for (let i = 0; i < 31; i++) last = await api('POST', `/api/solana-pay/${id}`, { account: customer.publicKey.toBase58() }, null);
    assert.equal(last.status, 429);
    for (let i = 0; i < 21; i++) last = await api('POST', `/api/orders/${id}/submit`, { txHash: 'x' }, null);
    assert.equal(last.status, 429);
  });

  test('dashboard list shows how each order was paid (channel, Swap and Pay)', async () => {
    const r = await api('GET', `/api/orders?settled=true&merchantId=${merchant.id}`, null, null);
    assert.equal(r.status, 200);
    const channels = new Set(r.json.orders.map((o) => o.channel).filter(Boolean));
    for (const c of ['QR_BLE', 'QR_INTERNET', 'TAP_OFFLINE', 'TAP_ONLINE', 'WEBSITE']) assert.ok(channels.has(c), `channel ${c} listed`);
    assert.ok(r.json.orders.some((o) => o.swapAndPay === true), 'a Swap and Pay order is flagged');
  });
});
