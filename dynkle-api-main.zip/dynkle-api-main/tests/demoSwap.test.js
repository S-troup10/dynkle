// Swap and Pay demo stand-in (src/tappay/demoSwap.js). Run: node --test tests/demoSwap.test.js
import { test } from 'node:test';
import assert from 'node:assert/strict';
import fs from 'fs';
import os from 'os';
import path from 'path';
import { Keypair, PublicKey, Transaction } from '@solana/web3.js';
import { TOKEN_PROGRAM_ID, createTransferCheckedInstruction } from '@solana/spl-token';
import { demoSwapActive, demoSwapService, setDemoSwapContext } from '../src/tappay/demoSwap.js';
import { instructionFromJson } from '../src/tappay/chain.js';

const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'demo-swap-'));
const keyFile = path.join(dir, 'demo-swap.json');
const owner = Keypair.generate();
fs.writeFileSync(keyFile, JSON.stringify(Array.from(owner.secretKey)));
const env = { DEMO_MODE: 'true', DEMO_SWAP_USDC_MINT: Keypair.generate().publicKey.toBase58(), DEMO_SWAP_KEYPAIR: keyFile };
const dynkMint = Keypair.generate().publicKey;
const sponsor = Keypair.generate().publicKey;
const customer = Keypair.generate().publicKey;

setDemoSwapContext(() => ({
  ready: true,
  cfg: { mint: dynkMint },
  mint: { programId: TOKEN_PROGRAM_ID, decimals: 9 },
  connection: { getTokenAccountBalance: async () => ({ value: { amount: '1000000000000' } }) },
}));

const quoteFor = (dynk = '50000000000') => demoSwapService.quote(
  { customerPubkey: customer.toBase58(), dynkShortfall: dynk, expiresAt: new Date(Date.now() + 60_000).toISOString() }, { env },
);

function message(ixs) {
  const tx = new Transaction();
  ixs.forEach((ix) => tx.add(ix));
  tx.recentBlockhash = Keypair.generate().publicKey.toBase58();
  tx.feePayer = sponsor;
  return Buffer.from(tx.serializeMessage()).toString('base64');
}

test('only with DEMO_MODE and the demo set-up', () => {
  assert.equal(demoSwapActive(env), true);
  assert.equal(demoSwapActive({ ...env, DEMO_MODE: 'false' }), false);
  assert.equal(demoSwapActive({ ...env, DEMO_SWAP_USDC_MINT: '' }), false);
});

test('quotes the shortfall with two instructions, USDC rounded up', async () => {
  const q = await quoteFor();
  assert.match(q.quoteId, /^demo-/);
  assert.equal(q.dynkAmount, '50000000000');
  assert.equal(q.delegate, owner.publicKey.toBase58());
  assert.equal(q.instructions.length, 2);
  assert.ok(BigInt(q.usdcAmount) > 0n);
});

test('co-signs the exact quoted swap once', async () => {
  const q = await quoteFor();
  const msg = message(q.instructions.map(instructionFromJson));
  const c = await demoSwapService.cosign({ quoteId: q.quoteId, message: msg }, { env });
  assert.equal(c.delegate, owner.publicKey.toBase58());
  assert.equal(Buffer.from(c.signature, 'base64').length, 64);
  await assert.rejects(demoSwapService.cosign({ quoteId: q.quoteId, message: msg }, { env }), { code: 'QUOTE_USED' });
});

test('refuses a changed amount, a missing leg or an extra use of the demo wallet', async () => {
  const q = await quoteFor();
  const [usdcLeg, topUp] = q.instructions.map(instructionFromJson);
  const bigger = createTransferCheckedInstruction(topUp.keys[0].pubkey, dynkMint, topUp.keys[2].pubkey, owner.publicKey, 999999999999n, 9, [], TOKEN_PROGRAM_ID);
  await assert.rejects(demoSwapService.cosign({ quoteId: q.quoteId, message: message([usdcLeg, bigger]) }, { env }), { code: 'UNEXPECTED_INSTRUCTION' });
  await assert.rejects(demoSwapService.cosign({ quoteId: q.quoteId, message: message([topUp]) }, { env }), { code: 'WRONG_SIGNERS' });
  const drain = createTransferCheckedInstruction(topUp.keys[0].pubkey, dynkMint, new PublicKey(sponsor), owner.publicKey, 1n, 9, [], TOKEN_PROGRAM_ID);
  await assert.rejects(demoSwapService.cosign({ quoteId: q.quoteId, message: message([usdcLeg, topUp, drain]) }, { env }), { code: 'UNEXPECTED_INSTRUCTION' });
  // Still unused after the refusals: the genuine message signs.
  const ok = await demoSwapService.cosign({ quoteId: q.quoteId, message: message([usdcLeg, topUp]) }, { env });
  assert.equal(ok.delegate, owner.publicKey.toBase58());
});

test('released quotes cannot be signed', async () => {
  const q = await quoteFor();
  assert.deepEqual(await demoSwapService.release({ quoteId: q.quoteId }), { released: true });
  await assert.rejects(demoSwapService.cosign({ quoteId: q.quoteId, message: message(q.instructions.map(instructionFromJson)) }, { env }), { code: 'QUOTE_NOT_FOUND' });
});
