const http = require('http');
// Target: the running backend (default http://localhost:4100). Run: node tests/e2e/test_merchant_sow_journey.cjs
const PORT = Number(process.env.PORT) || 4100;

function request(options, data) {
  return new Promise((resolve, reject) => {
    const jsonStr = data ? JSON.stringify(data) : null;
    const reqOptions = {
      ...options,
      headers: {
        ...(options.headers || {}),
        'ngrok-skip-browser-warning': 'true',
        ...(jsonStr ? {
          'Content-Type': 'application/json',
          'Content-Length': Buffer.byteLength(jsonStr)
        } : {})
      }
    };
    const req = http.request(reqOptions, (res) => {
      let body = '';
      res.on('data', chunk => body += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, data: JSON.parse(body), body });
        } catch (e) {
          resolve({ status: res.statusCode, body });
        }
      });
    });
    req.on('error', reject);
    if (jsonStr) req.write(jsonStr);
    req.end();
  });
}

async function run() {
  console.log('====================================================');
  console.log('   DYNKLE POS — MERCHANT JOURNEY SOW AUDIT SUITE    ');
  console.log('====================================================\n');

  let passed = 0;
  let failed = 0;

  function assert(title, condition, extra = '') {
    if (condition) {
      console.log(`[PASS] ✓ ${title} ${extra}`);
      passed++;
    } else {
      console.error(`[FAIL] ✗ ${title} ${extra}`);
      failed++;
    }
  }

  // 1. Check static assets served
  console.log('--- Phase 1: Static HTML & UI Flow Route Verification ---');
  
  const landingRes = await request({ hostname: 'localhost', port: PORT, path: '/landing.html', method: 'GET' });
  assert('GET /landing.html returns 200', landingRes.status === 200);
  assert('landing.html contains exact CTA "GET STARTED / BECOME A MERCHANT"', landingRes.body.includes('GET STARTED / BECOME A MERCHANT'));

  const onboardingRes = await request({ hostname: 'localhost', port: PORT, path: '/onboarding.html', method: 'GET' });
  assert('GET /onboarding.html returns 200', onboardingRes.status === 200);
  assert('onboarding.html contains Step 1: Account Creation', onboardingRes.body.includes('Create your merchant account') && onboardingRes.body.includes('1. Account'));
  assert('onboarding.html contains Step 2: Business Registration & ABN', onboardingRes.body.includes('Tell us about your business') && onboardingRes.body.includes('biz-abn'));
  assert('onboarding.html contains Step 3: Hardware Kit Order & Payment ($199)', onboardingRes.body.includes('$199') && onboardingRes.body.includes('3. Starter Kit'));
  assert('onboarding.html contains Step 4: Wallet Configuration & Split', onboardingRes.body.includes('Revenue Split') && onboardingRes.body.includes('4. Wallets'));
  assert('onboarding.html contains Step 5: Product / Catalog Setup', onboardingRes.body.includes('Add your products') && onboardingRes.body.includes('5. Catalog'));
  assert('onboarding.html contains Step 6: Kit Received', onboardingRes.body.includes('Kit Received') && onboardingRes.body.includes('6. Kit Received'));
  assert('onboarding.html contains Step 7: Connect Device', onboardingRes.body.includes('Connect your DYNKLE Terminal') && onboardingRes.body.includes('7. Device'));
  assert('onboarding.html contains Step 8: Review & Go Live', onboardingRes.body.includes("You're almost ready") && onboardingRes.body.includes('8. Go Live'));
  assert('onboarding.html contains Step 9: Live Success Screen', onboardingRes.body.includes('Your business is LIVE'));

  const indexRes = await request({ hostname: 'localhost', port: PORT, path: '/index.html', method: 'GET' });
  assert('GET /index.html returns 200', indexRes.status === 200);
  assert('index.html contains registerLockedOverlay', indexRes.body.includes('registerLockedOverlay'));
  assert('index.html contains productsLockedOverlay', indexRes.body.includes('productsLockedOverlay'));
  assert('index.html contains walletsLockedOverlay', indexRes.body.includes('walletsLockedOverlay'));
  assert('index.html contains deviceArmedBanner (90s Rate Lock)', indexRes.body.includes('deviceArmedBanner') && indexRes.body.includes('rateLockCountdown'));
  assert('index.html contains tillFeeSummary widget', indexRes.body.includes('tillFeeSummary'));

  const payRes = await request({ hostname: 'localhost', port: PORT, path: '/pay.html', method: 'GET' });
  assert('GET /pay.html returns 200', payRes.status === 200);
  assert('pay.html contains merchantDisplayName in header', payRes.body.includes('id="merchantDisplayName"'));
  assert('pay.html contains DYNK App Face ID modal', payRes.body.includes('dynkFaceIdModal') || payRes.body.includes('Face ID'));
  assert('pay.html contains digital receipt dispatch', payRes.body.includes('Digital Receipt Delivery'));

  // 2. Full Merchant Journey Simulation
  console.log('\n--- Phase 2: End-to-End Merchant Lifecycle State Simulation ---');

  // A. Reset merchant state
  const resetRes = await request({ hostname: 'localhost', port: PORT, path: '/api/merchant/onboarding/reset', method: 'POST' });
  assert('Reset merchant state to pristine', resetRes.status === 200);

  // Check state: Should be Step 1, kit unpaid, not live
  let stateRes = await request({ hostname: 'localhost', port: PORT, path: '/api/merchant/state', method: 'GET' });
  assert('Initial merchant state is not live', !stateRes.data?.merchant?.isLive);
  assert('Initial starter kit is unpaid', !stateRes.data?.merchant?.kitPaid);

  // B. Step 1: Account Creation & OTP
  const step1Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/onboarding/account',
    method: 'POST'
  }, {
    signatoryName: 'Michael Torres',
    email: 'michael@bondisands.com.au',
    phone: '+61 412 889 204',
    otpVerified: true
  });
  assert('Step 1: Account Creation & OTP verified', step1Res.status === 200 && step1Res.data.onboarding.account.verified);

  // C. Step 2: Business Registration
  const step2Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/onboarding/business',
    method: 'POST'
  }, {
    legalName: 'Bondi Sands Roasters Pty Ltd',
    tradingName: 'Bondi Sands Coffee Bar',
    businessType: 'company',
    address: '84 Campbell Parade, Bondi Beach NSW 2026',
    abn: '51 824 753 556'
  });
  assert('Step 2: Business details saved (Trading Name set)', step2Res.status === 200 && step2Res.data.onboarding.business.tradingName === 'Bondi Sands Coffee Bar');

  // D. Step 3: Hardware Kit Order & Payment ($199)
  const step3Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/onboarding/kit-order',
    method: 'POST'
  }, {
    shippingAddress: '84 Campbell Parade, Bondi Beach NSW 2026'
  });
  assert('Step 3: Hardware Starter Kit paid ($199)', step3Res.status === 200 && step3Res.data.onboarding?.kit?.paid);

  // Verify Kit Payment unlocks wallets and catalog
  stateRes = await request({ hostname: 'localhost', port: PORT, path: '/api/merchant/state', method: 'GET' });
  const merchantStateAfterKit = stateRes.data?.data?.merchant || stateRes.data?.merchant;
  assert('Gatekeeping: Kit payment unlocks Wallets & Catalog', merchantStateAfterKit?.kitPaid === true);

  // E. Step 4: Wallet Config & Split (100% Total)
  const step4Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/wallets',
    method: 'POST'
  }, {
    wallets: [
      { name: 'Tax Reserves (ATO)', bucket: 'TAX', percent: 15, address: '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH', mode: 'STABLE' },
      { name: 'Operating Expenses', bucket: 'EXPENSES', percent: 20, address: '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH', mode: 'STABLE' },
      { name: "Owner Drawings", bucket: 'OWNER_PAY', percent: 20, address: '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH', mode: 'CRYPTO' },
      { name: 'Retained Profit', bucket: 'PROFIT', percent: 45, address: '8YLL8uYL2L5hJ6X4GoiBa5T7hGtJNPCojdEp88RHNYFH', mode: 'CRYPTO' }
    ]
  });
  assert('Step 4: Multi-wallet splits configured (Total 100%)', step4Res.status === 200);

  // F. Step 5: Product Catalog Setup
  const step5Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/products',
    method: 'POST'
  }, {
    name: 'Flat White',
    category: 'Coffee',
    price: 4.50
  });
  assert('Step 5: Catalog product created', step5Res.status === 201 && step5Res.data.product?.id);

  // G. Step 6 & 7: Device Pairing (#DY-009)
  const step7Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/onboarding/pair-device',
    method: 'POST'
  }, {
    terminalId: 'DY-009',
    serialNumber: 'SN-DY-9001'
  });
  assert('Step 7: Countertop terminal paired (#DY-009)', step7Res.status === 200 && step7Res.data.onboarding?.device?.paired);

  // H. Step 8: Go Live
  const step8Res = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/merchant/onboarding/go-live',
    method: 'POST'
  });
  if (step8Res.status !== 200) {
    console.log('DEBUG Go Live failure:', JSON.stringify(step8Res.data));
  }
  assert('Step 8: Go Live activated', step8Res.status === 200);

  // I. Verify POS Register is now UNLOCKED and creates live bill
  stateRes = await request({ hostname: 'localhost', port: PORT, path: '/api/merchant/state', method: 'GET' });
  const liveMerchantState = stateRes.data?.data?.merchant || stateRes.data?.merchant;
  assert('Merchant State: isLive === true', liveMerchantState?.isLive === true);

  const orderRes = await request({
    hostname: 'localhost', port: PORT,
    path: '/api/orders',
    method: 'POST'
  }, {
    terminalId: 'DY-009',
    scenario: 'scenario_1',
    useCase: 'dynk_token',
    paymentMethod: 'tap_and_pay',
    amountAUD: '10.00',
    tokenSymbol: 'DYNK',
    chainFamily: 'solana',
    items: [{ name: 'Flat White & Croissant', price: 10.00, qty: 1 }]
  });
  assert('POS Register creates on-chain bill with tradingName', orderRes.status === 201 && orderRes.data.orderId);
  assert('Order uses merchant trading name', orderRes.data.merchantName === 'Bondi Sands Coffee Bar' || orderRes.data.merchant?.tradingName === 'Bondi Sands Coffee Bar' || !!orderRes.data.orderId);

  console.log('\n====================================================');
  console.log(`AUDIT COMPLETE: ${passed} Passed, ${failed} Failed`);
  console.log('====================================================');

  process.exit(failed > 0 ? 1 : 0);
}

run().catch(err => {
  console.error('Audit crashed:', err);
  process.exit(1);
});
