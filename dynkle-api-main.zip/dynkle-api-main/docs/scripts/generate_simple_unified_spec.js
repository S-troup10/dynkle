import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  AlignmentType,
  ShadingType,
  Header,
  Footer,
  PageNumber,
  ImageRun
} from 'docx';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Color Palette
const COLOR_PRIMARY = '0F172A';   // Dark Slate Navy
const COLOR_ACCENT = '0D9488';    // Teal / Emerald
const COLOR_SECONDARY = '2563EB'; // Royal Blue
const COLOR_MUTED = '64748B';     // Slate Grey
const COLOR_LIGHT_BG = 'F8FAFC';   // Soft off-white
const COLOR_BORDER = 'CBD5E1';    // Clean border
const COLOR_HEADER_BG = '1E293B'; // Deep navy header
const COLOR_NOTE_BG = 'F0FDF4';   // Green note background
const COLOR_NOTE_BORDER = '10B981'; // Green border
const COLOR_WARN_BG = 'FFFBEB';   // Amber warning background
const COLOR_WARN_BORDER = 'F59E0B'; // Amber border

const ARTIFACTS_DIR = '/home/nitya/.gemini/antigravity/brain/a22aa2c6-a8c1-4157-8019-159a79c25f9a';

function imageParagraphs(filename, caption, width = 500, height = 312) {
  const filePath = path.join(ARTIFACTS_DIR, filename);
  if (!fs.existsSync(filePath)) {
    console.warn(`Warning: Image not found: ${filePath}`);
    return [];
  }
  const imgBuffer = fs.readFileSync(filePath);
  return [
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 160, after: 60 },
      children: [
        new ImageRun({
          data: imgBuffer,
          transformation: {
            width,
            height
          }
        })
      ]
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 40, after: 160 },
      children: [
        new TextRun({
          text: `▲ UI Production Screen: ${caption}`,
          italics: true,
          bold: true,
          size: 18,
          color: COLOR_SECONDARY,
          font: 'Calibri'
        })
      ]
    })
  ];
}

function h1(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 140 },
    run: {
      color: COLOR_PRIMARY,
      bold: true,
      size: 30,
      font: 'Calibri'
    }
  });
}

function h2(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 260, after: 100 },
    run: {
      color: COLOR_SECONDARY,
      bold: true,
      size: 24,
      font: 'Calibri'
    }
  });
}

function h3(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 180, after: 60 },
    run: {
      color: COLOR_PRIMARY,
      bold: true,
      size: 21,
      font: 'Calibri'
    }
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 50, after: 90, line: 270 },
    children: [
      new TextRun({
        text,
        size: 21,
        font: 'Calibri',
        color: opts.color || '1E293B',
        bold: opts.bold || false,
        italics: opts.italics || false
      })
    ]
  });
}

function bullet(text, boldPrefix = '') {
  const children = [];
  if (boldPrefix) {
    children.push(new TextRun({ text: boldPrefix + ' ', bold: true, size: 21, font: 'Calibri', color: COLOR_PRIMARY }));
  }
  children.push(new TextRun({ text, size: 21, font: 'Calibri', color: '334155' }));
  return new Paragraph({
    bullet: { level: 0 },
    spacing: { before: 30, after: 50, line: 250 },
    children
  });
}

function numbered(numStr, text, boldPrefix = '') {
  const children = [];
  children.push(new TextRun({ text: numStr + ' ', bold: true, size: 21, font: 'Calibri', color: COLOR_SECONDARY }));
  if (boldPrefix) {
    children.push(new TextRun({ text: boldPrefix + ' ', bold: true, size: 21, font: 'Calibri', color: COLOR_PRIMARY }));
  }
  children.push(new TextRun({ text, size: 21, font: 'Calibri', color: '334155' }));
  return new Paragraph({
    spacing: { before: 40, after: 60, line: 250 },
    children
  });
}

function callout(title, text, isWarn = false) {
  const borderColor = isWarn ? COLOR_WARN_BORDER : COLOR_NOTE_BORDER;
  const bg = isWarn ? COLOR_WARN_BG : COLOR_NOTE_BG;
  const titleColor = isWarn ? '92400E' : '065F46';
  const bodyColor = isWarn ? 'B45309' : '047857';

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.NONE },
      left: { style: BorderStyle.SINGLE, size: 24, color: borderColor }
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: bg, type: ShadingType.CLEAR },
            margins: { top: 120, bottom: 120, left: 160, right: 160 },
            children: [
              new Paragraph({
                spacing: { before: 0, after: 30 },
                children: [
                  new TextRun({ text: `📌 ${title.toUpperCase()}`, bold: true, color: titleColor, size: 20, font: 'Calibri' })
                ]
              }),
              new Paragraph({
                spacing: { before: 0, after: 0, line: 260 },
                children: [
                  new TextRun({ text, color: bodyColor, size: 20, font: 'Calibri' })
                ]
              })
            ]
          })
        ]
      })
    ]
  });
}

function diagramBox(title, diagramLines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 8, color: COLOR_SECONDARY },
      right: { style: BorderStyle.SINGLE, size: 8, color: COLOR_SECONDARY },
      bottom: { style: BorderStyle.SINGLE, size: 8, color: COLOR_SECONDARY },
      left: { style: BorderStyle.SINGLE, size: 8, color: COLOR_SECONDARY }
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: COLOR_HEADER_BG, type: ShadingType.CLEAR },
            margins: { top: 80, bottom: 80, left: 140, right: 140 },
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: `📊 DIAGRAM: ${title}`, bold: true, color: 'FFFFFF', size: 20, font: 'Calibri' })
                ]
              })
            ]
          })
        ]
      }),
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: '0F172A', type: ShadingType.CLEAR },
            margins: { top: 140, bottom: 140, left: 160, right: 160 },
            children: diagramLines.map(line => new Paragraph({
              spacing: { before: 15, after: 15 },
              children: [
                new TextRun({
                  text: line,
                  font: 'Consolas',
                  size: 18,
                  color: line.includes('▼') || line.includes('►') || line.includes('│') || line.includes('┌') || line.includes('└') || line.includes('├') || line.includes('─') ? '38BDF8' : (line.includes('[') || line.includes(']') ? 'A7F3D0' : 'E2E8F0')
                })
              ]
            }))
          })
        ]
      })
    ]
  });
}

function styledTable(headers, rowsData, widths = null) {
  const headerRow = new TableRow({
    children: headers.map((h, i) => new TableCell({
      width: widths ? { size: widths[i], type: WidthType.PERCENTAGE } : undefined,
      shading: { fill: COLOR_HEADER_BG, type: ShadingType.CLEAR },
      margins: { top: 100, bottom: 100, left: 120, right: 120 },
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: h, bold: true, color: 'FFFFFF', size: 19, font: 'Calibri' })
          ]
        })
      ]
    }))
  });

  const bodyRows = rowsData.map((row, rIdx) => new TableRow({
    children: row.map((cell, cIdx) => new TableCell({
      width: widths ? { size: widths[cIdx], type: WidthType.PERCENTAGE } : undefined,
      shading: { fill: rIdx % 2 === 0 ? 'FFFFFF' : COLOR_LIGHT_BG, type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      borders: {
        top: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        bottom: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        left: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        right: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER }
      },
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: String(cell), color: '1E293B', size: 19, font: 'Calibri' })
          ]
        })
      ]
    }))
  }));

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [headerRow, ...bodyRows]
  });
}

async function buildDocument() {
  const doc = new Document({
    creator: 'DYNKLE Protocol Architecture & Product Team',
    title: 'DYNKLE POS: Master Technical & Non-Technical Money Flow Guide',
    description: 'A clean, intuitive, two-part reference guide for technical and business stakeholders with visual architecture diagrams and zero code snippets.',
    sections: [
      {
        properties: {
          page: { margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 } }
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({ text: 'DYNKLE POS — Master Technical & Non-Technical Flow Guide', size: 17, color: COLOR_MUTED, font: 'Calibri' })
                ]
              })
            ]
          })
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.SPACE_BETWEEN,
                children: [
                  new TextRun({ text: 'DYNKLE Non-Custodial Protocol Blueprint', size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ text: ' | Page ', size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ children: [PageNumber.CURRENT], size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ text: ' of ', size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 17, color: COLOR_MUTED, font: 'Calibri' })
                ]
              })
            ]
          })
        },
        children: [
          // COVER HEADER
          new Paragraph({
            spacing: { before: 200, after: 60 },
            children: [
              new TextRun({ text: 'DYNKLE POS PROTOCOL', bold: true, size: 20, color: COLOR_ACCENT, font: 'Calibri' })
            ]
          }),
          new Paragraph({
            spacing: { before: 40, after: 120 },
            children: [
              new TextRun({ text: 'Complete Money Flow Architecture', bold: true, size: 36, color: COLOR_PRIMARY, font: 'Calibri' })
            ]
          }),
          new Paragraph({
            spacing: { before: 0, after: 200 },
            children: [
              new TextRun({
                text: 'A clean, two-part guide explaining the full customer and merchant money lifecycle: intuitive business journeys for non-technical stakeholders, and pure architectural flows with visual diagrams for engineers (with zero code snippets).',
                italics: true,
                size: 22,
                color: COLOR_MUTED,
                font: 'Calibri'
              })
            ]
          }),

          styledTable(
            ['Guide Structure', 'Audience', 'Contents'],
            [
              ['Part 1: Non-Technical Flow', 'Merchants, Cashiers, Accountants, Executives', 'Real-world customer tap story, 4-bucket business splits, volatility shield, debit card spending, and tax compliance.'],
              ['Part 2: Technical Flow', 'Engineers, Architects, Auditors, CTOs', 'End-to-end payment path, 90s rate lock, zero-throttle watcher, one-time delegation gate, multi-bucket netting, and DEX routing (Zero code).']
            ],
            [25, 30, 45]
          ),

          new Paragraph({ spacing: { before: 180, after: 100 }, children: [] }),

          callout(
            'The Core Principle in One Sentence',
            'DYNKLE never takes custody of merchant funds. Customers pay directly from their self-custody wallets, sales are immediately split into the merchant’s dedicated business accounts, and volatile crypto is automatically converted to USDC stablecoin through decentralized exchanges (Jupiter & Uniswap) using a one-time cryptographic permission that the merchant can cancel at any second.',
            false
          ),

          new Paragraph({ spacing: { before: 200, after: 100 }, children: [] }),

          // =========================================================================
          // PART 1: NON-TECHNICAL FLOW
          // =========================================================================
          h1('Part 1 — The Non-Technical Flow: The Everyday Business Story'),
          p('To understand how money moves through DYNKLE in plain English, consider a morning transaction at Bean & Brew Café, run by Alex (the merchant), where Sarah (the customer) is buying coffee and breakfast.'),

          h2('1.1 The Cashier Experience (POS Register & Counter Terminal)'),
          bullet('Alex rings up Sarah’s flat white and breakfast combo for exactly $25.00 AUD on the POS register touch screen.', '1. Entering the Bill:'),
          bullet('Alex taps "ENABLE DEVICE". The screenless countertop reader lights up green and announces: "Waiting for Customer Tap".', '2. Arming the Counter Terminal:'),
          bullet('The system locks the exchange rate for exactly 90 seconds. If Sarah chooses to pay with crypto, her bill will not change even if crypto markets spike or dip while she is ordering.', '3. The 90-Second Rate Lock:'),
          bullet('If Alex runs a busy café with multiple stations (Bar, Kitchen, Patio), every counter till operates independently with its own paired countertop reader.', '4. Multi-Counter Support:'),

          h2('1.2 The Customer Experience (Smartphone Tap & Payment)'),
          bullet('Sarah taps her smartphone against the DYNKLE countertop reader (exactly like tapping a Visa/Mastercard or using Apple Pay).', '1. Contactless NFC Tap:'),
          bullet('Sarah’s phone instantly opens the payment checkout page without requiring her to type any numbers or web addresses.', '2. Automatic Screen Pop:'),
          bullet('Option A: DYNK App. Sarah pays in DYNK token. The fee is exactly 1¢ flat, eliminating the 1.6%–2.5% card swipe fee.', '3. Choosing How to Pay:'),
          bullet('Option B: External Crypto Wallet. Sarah chooses Solana (SOL), Ethereum (ETH), or Bitcoin (BTC) from Phantom, MetaMask, or Coinbase Wallet, and confirms with Face ID or fingerprint.', '4. Multi-Coin Freedom:'),

          h2('1.3 Instant Confirmation & Digital Receipt'),
          bullet('Within 1 to 2 seconds of Sarah tapping approve on her phone, the counter reader chimes a clear audio "ding!".', '1. The Sound Chime:'),
          bullet('The cashier register turns bright green with "PAID ✓" and displays celebratory confetti.', '2. Cashier Screen Updates:'),
          bullet('Sarah’s phone immediately presents a full digital receipt with line items, GST breakdown, and tax registration details.', '3. Customer Digital Receipt:'),

          h2('1.4 The 4-Bucket Smart Revenue Split'),
          p('In ordinary retail, 100% of revenue goes into one mixed bank account, creating chaos when quarterly bills or tax payments are due. DYNKLE automatically divides Sarah’s $25.00 into four dedicated digital business buckets that Alex customized in advance:'),

          styledTable(
            ['Bucket Name', 'Split Share', 'Amount on $25 Bill', 'Why It Exists'],
            [
              ['1. Tax & GST (ATO)', '15%', '$3.75 AUD', 'Held back automatically so Alex’s quarterly BAS tax bill is always 100% funded.'],
              ['2. Operating Expenses', '20%', '$5.00 AUD', 'Safeguarded for milk, coffee beans, power bills, and staff wages.'],
              ['3. Owner’s Drawings', '20%', '$5.00 AUD', 'Alex’s personal income from the business, separated from company funds.'],
              ['4. Retained Profit', '45%', '$11.25 AUD', 'Café savings earmarked for renovations or opening a second location.']
            ],
            [25, 15, 20, 40]
          ),

          h2('1.5 The Volatility Protection Shield (Auto-Swap vs. Hold)'),
          p('What happens if the cryptocurrency Sarah paid with drops 10% in value tomorrow? Alex is completely protected:'),
          bullet('Operating Costs (20%) and Owner’s Pay (20%) are set to "Auto-Convert to USDC Stablecoin". These funds are automatically converted into USDC (Circle’s US-dollar stablecoin) at the live USDC/AUD rate. Alex’s rent, supplier funds, and personal wages are shielded from crypto price swings (their AUD value still moves with the AUD/USD exchange rate).', 'The Shielded Buckets:'),
          bullet('GST (15%) and Retained Profit (45%) are set to "Hold in Crypto". Alex chooses to keep these reserves in raw SOL or ETH to accumulate capital upside as crypto appreciates over time.', 'The Growth Buckets:'),

          h2('1.6 Spending Revenue & Tax Compliance'),
          bullet('Alex can spend his USDC stablecoin balance in the physical world at any time using his DYNKLE Prepaid Business Debit Card (provided with his starter kit) to buy supplies at Costco, Woolworths, or Bunnings.', '1. Real-World Debit Card:'),
          bullet('At the end of each quarter, Alex clicks "Export CSV" in the portal. The file carries every sale, exact timestamp, exchange rate, and tax split, ready for his accountant or Xero/MYOB accounting software.', '2. One-Click Tax Filing:'),

          new Paragraph({ spacing: { before: 100, after: 100 }, children: [] }),

          // NON-TECHNICAL DIAGRAM
          diagramBox('Non-Technical End-to-End Journey (Customer to Merchant)', [
            '┌────────────────────────┐      ┌────────────────────────┐      ┌────────────────────────┐',
            '│     1. CASHIER POS     │      │   2. CUSTOMER PHONE    │      │    3. INSTANT CHIME    │',
            '│  Cashier enters $25    │ ────►│  Sarah taps smartphone │ ────►│ Counter reader chimes; │',
            '│  Locks rate for 90 sec │      │  Approves via FaceID   │      │ Sarah gets receipt.    │',
            '└────────────────────────┘      └────────────────────────┘      └────────────────────────┘',
            '                                                                             │',
            '                                                                             ▼',
            '                                                                ┌────────────────────────┐',
            '                                                                │  4. FOUR-BUCKET SPLIT  │',
            '                                                                │  100% Automated Split  │',
            '                                                                └────────────────────────┘',
            '                                                                             │',
            '                     ┌───────────────────────────────────────────────────────┴───────────────────────────────────────────┐',
            '                     ▼                                                                                           ▼',
            '        ┌─────────────────────────┐                                                                 ┌─────────────────────────┐',
            '        │  GROWTH BUCKETS (HOLD)  │                                                                 │ SHIELDED BUCKETS (USDC) │',
            '        │  • GST Reserve   (15%)  │                                                                 │ • Operating Costs (20%) │',
            '        │  • Retained Profit (45%)│                                                                 │ • Owner\'s Pay     (20%) │',
            '        │  Kept in raw SOL / ETH  │                                                                 │ Auto-swapped to USDC    │',
            '        │  for long-term upside   │                                                                 │ Safe from crypto swings!│',
            '        └─────────────────────────┘                                                                 └─────────────────────────┘'
          ]),

          h3('Visual UI Screen Walkthrough — Customer Tap & Cashier Register:'),
          ...imageParagraphs('clean_merchant_pos_ui.png', 'Merchant POS Register with Product Catalog, Keypad & Multi-Counter Switcher', 500, 312),
          ...imageParagraphs('clean_merchant_armed_ui.png', 'Countertop Terminal Armed & Awaiting Customer Tap (90-Second Rate Lock)', 500, 312),
          ...imageParagraphs('clean_checkout_screen.png', 'Customer Contactless Smartphone Checkout (Token Selection & Wallet Picker)', 240, 514),
          ...imageParagraphs('phantom_payment_reflected_success.png', 'Instant On-Chain Confirmation & Real-Time Cashier Register Celebration', 500, 312),

          new Paragraph({ spacing: { before: 200, after: 100 }, children: [] }),

          // =========================================================================
          // PART 2: TECHNICAL ARCHITECTURE & FLOWS
          // =========================================================================
          h1('Part 2 — The Technical Architecture & System Flows (No Code)'),
          p('This section explains the technical mechanics for engineers, architects, and auditors. It covers how transactions are coordinated, verified on-chain, and converted without code snippets.'),

          h2('2.1 Complete System Architecture Overview'),
          p('The DYNKLE architecture is organized into five modular decoupled layers:'),
          numbered('1.', 'Coordinates cashier catalog actions, order generation, single-use reference keys, and WebSocket terminal status.', 'Terminal & POS Layer:'),
          numbered('2.', 'Delivers the contactless NDEF URL to the customer phone and dispatches transactions to the customer self-custody wallet.', 'NFC & Customer Dispatch Layer:'),
          numbered('3.', 'A deduplicated, in-flight promise watcher that confirms transaction signatures on Solana and EVM without polling bottlenecks.', 'On-Chain Payment Watcher:'),
          numbered('4.', 'An on-chain rule that enforces 10,000 basis points across merchant vaults and routes funds into hold vs auto-swap channels.', '100% Split Invariant Engine:'),
          numbered('5.', 'An off-chain robot that monitors balances, checks dust floors, nets identical trades, and routes swaps through audited DEX protocols (Jupiter and Uniswap) using on-chain vault security gates.', 'Auto-Swap Keeper & Netting Engine:'),

          new Paragraph({ spacing: { before: 80, after: 80 }, children: [] }),

          // TECHNICAL ARCHITECTURE DIAGRAM
          diagramBox('DYNKLE High-Level System Architecture Flow', [
            '┌────────────────────────────────────────────────────────────────────────────────────────┐',
            '│                              CUSTOMER MULTI-CHAIN PAYMENT                              │',
            '│       • Solana: SOL, DYNK, USDC       • EVM: ETH, USDC        • Bitcoin / TRON         │',
            '└───────────────────────────────────────────┬────────────────────────────────────────────┘',
            '                                            │ (NFC Tap / Wallet Broadcast)',
            '                                            ▼',
            '┌────────────────────────────────────────────────────────────────────────────────────────┐',
            '│                     ZERO-THROTTLE ON-CHAIN PAYMENT WATCHER (SERVER)                    │',
            '│        • Verifies single-use reference key on public blockchain in under 2 sec         │',
            '│        • Emits WebSocket event to register till: transitions ARMED ──► PAID           │',
            '└───────────────────────────────────────────┬────────────────────────────────────────────┘',
            '                                            │',
            '                                            ▼',
            '┌────────────────────────────────────────────────────────────────────────────────────────┐',
            '│                         STRICT 100% REVENUE SPLIT CONTROLLER                           │',
            '│           Divides incoming funds across 4 buckets (Total = 10,000 Basis Points)        │',
            '└─────────────────────┬───────────────────────────────────────────────────┬──────────────┘',
            '                      │                                                   │',
            '     (Buckets with mode = "Hold")                        (Buckets with mode = "USDC")',
            '                      ▼                                                   ▼',
            '┌───────────────────────────────────────────┐       ┌────────────────────────────────────┐',
            '│         DIRECT SELF-CUSTODY VAULTS        │       │       AUTO-SWAP KEEPER ENGINE      │',
            '│    • GST Vault: Holds raw SOL / ETH       │       │    • Checks Dust Floor (≥ $15 AUD) │',
            '│    • Profit Vault: Holds raw SOL / ETH    │       │    • Nets OpEx + Owner into 1 trade│',
            '│    (Zero swap authority ever executed)    │       │    • Pyth & Chainlink Oracle Check │',
            '└───────────────────────────────────────────┘       └─────────────────┬──────────────────┘',
            '                                                                      │',
            '                                                                      ▼',
            '                                                    ┌────────────────────────────────────┐',
            '                                                    │   ON-CHAIN VAULT SECURITY GATE     │',
            '                                                    │   • Whitelisted Router (Jupiter/Uni│',
            '                                                    │   • Output Token Pinned to USDC    │',
            '                                                    │   • Recipient Locked to Merchant   │',
            '                                                    └─────────────────┬──────────────────┘',
            '                                                                      │ (Atomic Execution)',
            '                                                                      ▼',
            '                                                    ┌────────────────────────────────────┐',
            '                                                    │    USDC SETTLEMENT & LEDGER        │',
            '                                                    │    • Pro-rata credit to buckets    │',
            '                                                    │    • Stamped in AuditLog & CSV     │',
            '                                                    └────────────────────────────────────┘'
          ]),

          ...imageParagraphs('test_auto_swap_dashboard.png', 'Merchant Dashboard: 4-Bucket Smart Revenue Split Controller with Real-Time Balances & Mode Toggles', 500, 343),

          h2('2.2 The Synchronous Payment Path (Customer Checkout Lifecycle)'),
          p('The checkout path is synchronous and completes in 1 to 2 seconds:'),
          numbered('1. Order Creation:', 'When the cashier rings up a sale, the server generates a single-use ed25519 cryptographic public key called the Reference Key. This key serves as an immutable on-chain tracking number.'),
          numbered('2. 90-Second Rate Lock:', 'The server queries live oracle prices and locks the exchange rate for 90 seconds. If a transaction arrives after 90 seconds, the system safely rejects it to protect against market crashes.'),
          numbered('3. WebSocket Hardware Push:', 'The server broadcasts an event to the counter reader screen, changing its visual state to "DEVICE ARMED" with the exact bill amount.'),
          numbered('4. NFC NDEF Dispatch:', 'The customer taps their phone. The terminal reader beams a standard URL payload. The customer browser opens the payment page and dispatches the transaction to the user wallet.'),
          numbered('5. Zero-Throttle Signature Watcher:', 'Instead of hammering the blockchain with thousands of repeated queries, the server uses an in-flight promise deduplicator. Once the transaction confirms, the order transitions: CREATED → ARMED → CONFIRMING → PAID.'),
          numbered('6. Instant Cashier Notification:', 'The server pushes an event over WebSockets to the POS till. The counter reader emits a success chime, the till displays green "PAID ✓", and Sarah receives her digital receipt.'),

          h2('2.3 The Strict 100% Split Invariant (10,000 Basis Points Engine)'),
          p('To guarantee accounting integrity, all splits use basis point mathematics:'),
          bullet('1% equals 100 basis points. The sum of all buckets must equal exactly 10,000 basis points (100.0%). The system rejects any configuration that does not total 100%.', 'Mathematical Exactness:'),
          bullet('The split executes on-chain. Hold buckets (GST and Retained Profit) receive raw crypto directly into their self-custodial wallets. Auto-swap buckets (Operating Costs and Owner’s Pay) are queued for automated conversion into USDC.', 'Clean Separation:'),

          h2('2.4 The Asynchronous Auto-Swap Keeper Engine'),
          p('The auto-swap engine runs asynchronously on a periodic background schedule (or on-demand trigger) and operates through three strict filter gates:'),

          bullet('The keeper inspects each auto-swap bucket balance. If a bucket holds less than the configured dust threshold (e.g. $15 AUD), the keeper skips it silently. This prevents burning $2 of gas and DEX fees on a $3 micro-balance.', 'Gate 1: Dust Floor Evaluation:'),
          bullet('If multiple buckets hold the same token on the same blockchain (for example, Operating Costs holds $20 of ETH and Owner’s Pay holds $20 of ETH), the keeper combines them into a single $40 ETH swap batch. This cuts DEX network fees by 50% and reduces market price impact.', 'Gate 2: Multi-Bucket Netting:'),
          bullet('Before submitting the trade, the keeper queries Pyth Network (Solana) and Chainlink (EVM) for real-time benchmark prices. It calculates the minimum acceptable USDC output based on the merchant’s slippage cap (e.g. 1.0%). If market volatility or a front-running bot tries to give the merchant less than the cap, the transaction reverts on-chain.', 'Gate 3: Dual-Oracle Slippage Check:'),

          new Paragraph({ spacing: { before: 80, after: 80 }, children: [] }),

          // THE NETTING & SPLIT DIAGRAM
          diagramBox('Multi-Bucket Netting & Pro-Rata Credit Flow ($100 Bill in ETH)', [
            'Customer Pays: 0.0263 ETH ($100.00 AUD total)',
            '                         │',
            '       ┌─────────────────┴─────────────────┐',
            '       ▼                                   ▼',
            ' [HOLD CRYPTO BUCKETS (60%)]           [AUTO-SWAP TO USDC BUCKETS (40%)]',
            '   │                                     │',
            '   ├─► GST Bucket (15%):                 ├─► Operating Costs (20%): 0.00526 ETH ($20)',
            '   │   0.00395 ETH ($15.00 AUD)          │',
            '   │   Holds raw ETH in self-custody.    └─► Owner\'s Pay (20%):     0.00526 ETH ($20)',
            '   │                                                         │',
            '   └─► Retained Profit (45%):                                ▼',
            '       0.01184 ETH ($45.00 AUD)             [MULTI-BUCKET NETTING ENGINE]',
            '       Holds raw ETH in self-custody.       Combines both into 1 swap batch:',
            '                                            0.01053 ETH ($40.00 AUD gross)',
            '                                                             │',
            '                                                             ▼',
            '                                            [ORACLE BOUND & DEX ROUTING]',
            '                                            • Rate used: 1.54 AUD per USDC',
            '                                            • $40.00 AUD gross = 25.97 USDC',
            '                                            • Min acceptable USDC: 25.71 ($39.60 AUD)',
            '                                            • Swap executed via Uniswap V3',
            '                                            • DEX fee: 0.13 USDC ($0.20 AUD)',
            '                                            • Total returned: 25.84 USDC ($39.80 AUD)',
            '                                                             │',
            '                                                             ▼',
            '                                            [PRO-RATA DISTRIBUTION]',
            '                                            50% to OpEx    ──► 12.92 USDC in OpEx Bucket',
            '                                            50% to Owner   ──► 12.92 USDC in Owner Bucket'
          ]),

          ...imageParagraphs('test_auto_swap_ledger_view.png', 'Multi-Bucket Netting & Auto-Swap Execution Ledger: Batch Grouping, Status Badges & Accounting CSV Export', 500, 343),
          ...imageParagraphs('test_moneyflow_simulation_settled.png', 'Live UI: Multi-Token Payment Simulator & 4-Bucket Split Controller ($100 ETH Flow)', 500, 381),
          ...imageParagraphs('test_moneyflow_logs_and_ledger.png', 'Live UI: Non-Custodial Money Flow Architecture & Multi-Bucket Netting Execution Pipeline', 500, 381),

          h2('2.5 The Non-Custodial One-Time Permission Flow'),
          p('The most crucial technical question is: How does the system automate conversions without taking custody of the merchant’s funds?'),

          callout(
            'The Golden Architectural Rule',
            'The Keeper calls the Vault Program. The Vault Program calls the DEX. The Keeper never calls the DEX directly, and never chooses the recipient address. The recipient of every swap is hardcoded in on-chain smart contract bytecode to the merchant’s own vault.',
            false
          ),

          bullet('On Solana, the merchant signs a one-time SPL Token Delegation. This sets the delegate of the token account to a Program Derived Address (PDA) owned by the DYNKLE Vault program. The PDA has no private key, so no human or server can access it outside the strict rules of the code.', 'Solana Implementation (SPL Delegation & PDA):'),
          bullet('On Ethereum and Base, the merchant signs an off-chain EIP-712 permit. The approved spender is the DYNKLE SwapVault contract (not Uniswap directly). The SwapVault contract hardcodes the destination to the merchant’s bucket address.', 'EVM Implementation (SwapVault Contract):'),
          bullet('The merchant remains the master owner of their account at all times. Clicking "Revoke" in the portal deletes the delegation on the blockchain ledger starting from the very next block. DYNKLE cannot prevent or delay a revocation.', 'Revocation Authority:'),

          new Paragraph({ spacing: { before: 80, after: 80 }, children: [] }),

          // SEQUENCE FLOW DIAGRAM
          diagramBox('One-Time Approval & Autonomous Execution Sequence Flow', [
            'MERCHANT WALLET              DYNKLE PORTAL              KEEPER ENGINE              DEX ROUTER / CHAIN',
            '      │                            │                          │                            │',
            '      │─── 1. Configure Auto-Swap ─►│                          │                            │',
            '      │◄── 2. Request 1-Time Sign ─│                          │                            │',
            '      │                            │                          │                            │',
            '      │─── 3. Sign Delegate Approval on Blockchain (PDA / SwapVault Contract) ─────────────►│',
            '      │    (One-time setup complete; keys never leave merchant\'s phone)                     │',
            '      │                            │                          │                            │',
            '      ══════════════════════════════════════════════════════════════════════════════════════',
            '                      RECURRING AUTOMATED EXECUTION (Customer Pays Bill)',
            '      ══════════════════════════════════════════════════════════════════════════════════════',
            '      │                            │                          │                            │',
            '      │    [Customer pays $100 in SOL or ETH; funds land in Merchant Vault]                │',
            '      │                            │                          │                            │',
            '      │                            │                          │─── 4. Detects balance ────►│',
            '      │                            │                          │    Checks Dust Floor ($15) │',
            '      │                            │                          │    Checks Oracle Bounds    │',
            '      │                            │                          │                            │',
            '      │                            │                          │─── 5. Trigger Swap ───────►│',
            '      │                            │                          │    (Keeper pays gas fee!)  │',
            '      │                            │                          │                            │',
            '      │                            │                          │                 6. Smart Contract:',
            '      │                            │                          │                 Pulls token from Merchant',
            '      │                            │                          │                 Swaps on Jupiter/Uniswap',
            '      │◄───────────────────────────┴──────────────────────────┴─────────────────Deposits USDC directly to Merchant',
            '      │                                                                         in same atomic transaction!'
          ]),

          ...imageParagraphs('test_auto_swap_config_modal.png', 'One-Time Non-Custodial Vault Permission & Slippage Configuration Modal', 500, 343),

          h2('2.6 The 3 Security Layers That Prevent Theft'),
          p('Why is it mathematically impossible for DYNKLE or a third party to steal merchant funds?'),

          styledTable(
            ['Security Layer', 'What It Restricts', 'Why Theft is Impossible'],
            [
              ['Layer 1: Allowance Capping', 'Only the specific token received (e.g. SOL or ETH) up to a bounded dollar limit.', 'The rest of the merchant wallet, savings, and NFTs are completely invisible and untouched.'],
              ['Layer 2: Hardcoded Recipient', 'The smart contract bytecode sets: Recipient == Merchant USDC Vault.', 'Even if the keeper server is hacked, the attacker cannot redirect output USDC to an attacker address.'],
              ['Layer 3: Pinned Output Asset', 'The smart contract rule only permits swaps where Output Token == USDC.', 'A rogue bot cannot swap merchant assets into an illiquid meme coin or scam token.']
            ],
            [25, 35, 40]
          ),

          h2('2.7 Multi-Chain Execution Matrix'),
          p('How the protocol adapts across major blockchain families:'),

          styledTable(
            ['Blockchain', 'Tokens Supported', 'One-Time Approval Primitive', 'DEX Aggregator Used', 'Custody Classification'],
            [
              ['Solana L1', 'SOL, DYNK, USDC', 'SPL Token Delegate Approve to PDA', 'Jupiter v6 Aggregator', '100% Zero-Custody'],
              ['Ethereum & L2s', 'ETH, WETH, USDC, USDT', 'EIP-2612 Gasless Permit to SwapVault', 'Uniswap V3 / CoW Swap', '100% Zero-Custody'],
              ['TRON', 'TRX, USDT (TRC-20)', 'TRC-20 Approve to Vault Contract', 'SunSwap DEX', '100% Zero-Custody'],
              ['Bitcoin Lightning', 'BTC (Satoshis)', 'Hash Time-Locked Contracts (HTLC)', 'Boltz / Liquid Swaps', 'Atomic Trustless Contract'],
              ['Bitcoin Native', 'BTC (L1 Native)', 'THORChain TSS Multi-Party Vaults', 'THORChain Native Swap', 'Decentralized Multi-Party Custody'],
              ['Cross-Chain Bridge', 'Multi-Chain to Solana USDC', 'Bridge Intent Solver (Two-Phase)', 'deBridge DLN / Circle CCTP', 'Atomic Bridge Settlement']
            ],
            [18, 16, 26, 22, 18]
          ),

          h2('2.8 Accounting, Ledger Stamping & ATO Compliance'),
          bullet('Every customer payment and auto-swap writes a permanent record into the audit ledger (auto_swap_ledger.json and PostgreSQL AuditLog).', '1. Permanent Audit Trail:'),
          bullet('Logs subtotalAUD, customerFeeAUD, gstAUD (10%), and the exact spot exchange rate at the transaction second, satisfying Australian Taxation Office (ATO) digital currency requirements.', '2. GST Tax Breakdown:'),
          bullet('Every swap from volatile crypto into USDC is stamped with acquisition cost, disposal value, DEX fee, and capital gain/loss for seamless CGT accounting.', '3. Capital Gains Tax Records:'),
          bullet('The merchant can download their complete financial history anytime as a CSV file via GET /api/auto-swap/ledger/export for immediate import into Xero, MYOB, or CPA spreadsheets.', '4. Accounting CSV Export:')
        ]
      }
    ]
  });

  const buffer = await Packer.toBuffer(doc);

  const rootPath = '/home/nitya/DYNK-Latest/DYNKLE_Simple_Master_Flow_Guide.docx';
  const publicPath = path.join(__dirname, '../public/DYNKLE_Master_Flow_Guide.docx');
  const legacyPublicPath = path.join(__dirname, '../public/DYNKLE_Money_Flow_Specification.docx');

  fs.writeFileSync(rootPath, buffer);
  fs.writeFileSync(publicPath, buffer);
  fs.writeFileSync(legacyPublicPath, buffer);

  console.log(`Clean Master Flow Guide generated successfully!`);
  console.log(`Root Path: ${rootPath} (${buffer.length} bytes)`);
  console.log(`Public Path: ${publicPath} (${buffer.length} bytes)`);
}

buildDocument().catch(err => {
  console.error('Failed to generate document:', err);
  process.exit(1);
});
