import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  AlignmentType,
  ShadingType,
  Header,
  Footer,
  PageNumber,
  NumberFormat
} from 'docx';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Color Palette Constants
const COLOR_PRIMARY = '0F172A';   // Dark Slate
const COLOR_ACCENT = '0D9488';    // Deep Teal / Emerald
const COLOR_SECONDARY = '2563EB'; // Royal Blue
const COLOR_MUTED = '64748B';     // Slate Grey
const COLOR_LIGHT_BG = 'F8FAFC';   // Off-white / Table zebra
const COLOR_BORDER = 'CBD5E1';    // Border line grey
const COLOR_HEADER_BG = '1E293B'; // Deep navy header
const COLOR_ALERT_BG = 'FEF2F2';  // Soft red alert background
const COLOR_ALERT_BORDER = 'EF4444'; // Red alert line
const COLOR_WARN_BG = 'FFFBEB';   // Amber warning background
const COLOR_WARN_BORDER = 'F59E0B'; // Amber line
const COLOR_NOTE_BG = 'F0FDF4';   // Emerald note background
const COLOR_NOTE_BORDER = '10B981'; // Emerald note line

function h1(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 400, after: 160 },
    run: {
      color: COLOR_PRIMARY,
      bold: true,
      size: 32,
      font: 'Calibri'
    }
  });
}

function h2(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    run: {
      color: COLOR_SECONDARY,
      bold: true,
      size: 25,
      font: 'Calibri'
    }
  });
}

function h3(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 80 },
    run: {
      color: COLOR_PRIMARY,
      bold: true,
      size: 22,
      font: 'Calibri'
    }
  });
}

function p(text, opts = {}) {
  return new Paragraph({
    spacing: { before: 60, after: 100, line: 276 },
    children: [
      new TextRun({
        text,
        size: 21,
        font: 'Calibri',
        color: opts.color || '1E293B',
        bold: opts.bold || false,
        italics: opts.italics || false
      })
    ]
  });
}

function bullet(text, boldPrefix = '') {
  const children = [];
  if (boldPrefix) {
    children.push(new TextRun({ text: boldPrefix + ' ', bold: true, size: 21, font: 'Calibri', color: COLOR_PRIMARY }));
  }
  children.push(new TextRun({ text, size: 21, font: 'Calibri', color: '334155' }));
  return new Paragraph({
    bullet: { level: 0 },
    spacing: { before: 40, after: 60, line: 260 },
    children
  });
}

function numbered(numStr, text, boldPrefix = '') {
  const children = [];
  children.push(new TextRun({ text: numStr + ' ', bold: true, size: 21, font: 'Calibri', color: COLOR_SECONDARY }));
  if (boldPrefix) {
    children.push(new TextRun({ text: boldPrefix + ' ', bold: true, size: 21, font: 'Calibri', color: COLOR_PRIMARY }));
  }
  children.push(new TextRun({ text, size: 21, font: 'Calibri', color: '334155' }));
  return new Paragraph({
    spacing: { before: 50, after: 70, line: 260 },
    children
  });
}

function callout(title, text, type = 'note') {
  let borderColor = COLOR_NOTE_BORDER;
  let bg = COLOR_NOTE_BG;
  let titleColor = '065F46';
  let bodyColor = '047857';

  if (type === 'warn') {
    borderColor = COLOR_WARN_BORDER;
    bg = COLOR_WARN_BG;
    titleColor = '92400E';
    bodyColor = 'B45309';
  } else if (type === 'alert') {
    borderColor = COLOR_ALERT_BORDER;
    bg = COLOR_ALERT_BG;
    titleColor = '991B1B';
    bodyColor = 'B91C1C';
  }

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.NONE },
      left: { style: BorderStyle.SINGLE, size: 24, color: borderColor }
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: bg, type: ShadingType.CLEAR },
            margins: { top: 120, bottom: 120, left: 160, right: 160 },
            children: [
              new Paragraph({
                spacing: { before: 0, after: 40 },
                children: [
                  new TextRun({ text: title.toUpperCase(), bold: true, color: titleColor, size: 20, font: 'Calibri' })
                ]
              }),
              new Paragraph({
                spacing: { before: 0, after: 0, line: 260 },
                children: [
                  new TextRun({ text, color: bodyColor, size: 20, font: 'Calibri' })
                ]
              })
            ]
          })
        ]
      })
    ]
  });
}

function codeBlock(lines, caption = '') {
  const paragraphs = [];
  if (caption) {
    paragraphs.push(new Paragraph({
      spacing: { before: 0, after: 60 },
      children: [
        new TextRun({ text: `// ${caption}`, italics: true, color: '94A3B8', size: 18, font: 'Consolas' })
      ]
    }));
  }
  lines.forEach(l => {
    paragraphs.push(new Paragraph({
      spacing: { before: 20, after: 20 },
      children: [
        new TextRun({ text: l, font: 'Consolas', size: 18, color: '38BDF8' })
      ]
    }));
  });

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER },
      right: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER },
      bottom: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER },
      left: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER }
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: '0F172A', type: ShadingType.CLEAR },
            margins: { top: 120, bottom: 120, left: 160, right: 160 },
            children: paragraphs
          })
        ]
      })
    ]
  });
}

function styledTable(headers, rowsData, widths = null) {
  const headerRow = new TableRow({
    children: headers.map((h, i) => new TableCell({
      width: widths ? { size: widths[i], type: WidthType.PERCENTAGE } : undefined,
      shading: { fill: COLOR_HEADER_BG, type: ShadingType.CLEAR },
      margins: { top: 100, bottom: 100, left: 120, right: 120 },
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: h, bold: true, color: 'FFFFFF', size: 19, font: 'Calibri' })
          ]
        })
      ]
    }))
  });

  const bodyRows = rowsData.map((row, rIdx) => new TableRow({
    children: row.map((cell, cIdx) => new TableCell({
      width: widths ? { size: widths[cIdx], type: WidthType.PERCENTAGE } : undefined,
      shading: { fill: rIdx % 2 === 0 ? 'FFFFFF' : COLOR_LIGHT_BG, type: ShadingType.CLEAR },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      borders: {
        top: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        bottom: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        left: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        right: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER }
      },
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: String(cell), color: '1E293B', size: 19, font: 'Calibri' })
          ]
        })
      ]
    }))
  }));

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [headerRow, ...bodyRows]
  });
}

async function buildMasterDocument() {
  const doc = new Document({
    creator: 'DYNKLE Protocol Architecture & Engineering',
    title: 'DYNKLE POS Protocol — Complete Money Flow Specification v3.0.0',
    description: 'Master technical and non-technical blueprint for POS terminal billing, multi-chain tap payments, four-bucket revenue splitting, non-custodial one-time approvals, and autonomous DEX auto-swap settlement.',
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 }
          }
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({ text: 'DYNKLE POS Protocol — Complete Money Flow Specification v3.0.0', size: 17, color: COLOR_MUTED, font: 'Calibri' })
                ]
              })
            ]
          })
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.SPACE_BETWEEN,
                children: [
                  new TextRun({ text: 'Draft for engineering sign-off · DYNKLE Architecture', size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ text: ' | Page ', size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ children: [PageNumber.CURRENT], size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ text: ' of ', size: 17, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 17, color: COLOR_MUTED, font: 'Calibri' })
                ]
              })
            ]
          })
        },
        children: [
          // TITLE / COVER
          new Paragraph({
            spacing: { before: 200, after: 60 },
            children: [
              new TextRun({ text: 'DYNKLE POS PROTOCOL', bold: true, size: 20, color: COLOR_ACCENT, font: 'Calibri' })
            ]
          }),
          new Paragraph({
            spacing: { before: 40, after: 120 },
            children: [
              new TextRun({ text: 'Complete Money Flow Specification', bold: true, size: 38, color: COLOR_PRIMARY, font: 'Calibri' })
            ]
          }),
          new Paragraph({
            spacing: { before: 0, after: 240 },
            children: [
              new TextRun({
                text: 'Technical and non-technical blueprint: POS terminal billing, multi-chain tap payments, four-bucket revenue splitting, non-custodial one-time approvals, and autonomous DEX auto-swap settlement.',
                italics: true,
                size: 22,
                color: COLOR_MUTED,
                font: 'Calibri'
              })
            ]
          }),

          styledTable(
            ['Document property', 'Detail'],
            [
              ['Version', '3.0.0 — Unified Master Engineering Blueprint'],
              ['Supersedes', '2.4.0 (see Appendix A for substantive corrections applied)'],
              ['Target ecosystems', 'Solana (L1) · Ethereum & EVM L2s (Base, Arbitrum, Polygon) · Bitcoin (Native + Lightning) · TRON'],
              ['Authors', 'DYNKLE Core Engineering & Protocol Architecture'],
              ['Date', '21 September 2026'],
              ['Classification', 'Commercial production specification — engineering sign-off'],
              ['Status', 'Production Architecture Specification with On-Chain Vault Program Model']
            ],
            [30, 70]
          ),

          new Paragraph({ spacing: { before: 180, after: 100 }, children: [] }),

          callout(
            'Core Custody Invariant',
            'DYNKLE servers never hold a private key capable of moving merchant funds. Automated swaps are executed by on-chain program code that the merchant authorised once, that can only call a whitelisted exchange, can only produce USDC, can only deliver to the merchant\'s own account, and reverts if the execution price falls outside an oracle-checked bound.',
            'note'
          ),

          // PART 1: EXECUTIVE SUMMARY
          h1('Part 1 — Executive summary'),
          p('DYNKLE gives physical retail merchants a zero-custody digital-currency payment terminal. It removes the 1.6–2.5% card interchange swipe fee by accepting native DYNK token at a flat one-cent fee, plus major cryptocurrencies (SOL, ETH, BTC, USDT, USDC), and it shields the merchant from crypto volatility by converting selected revenue automatically into USDC, Circle\'s US-dollar stablecoin, at the live USDC/AUD rate.'),
          p('The difference from legacy crypto processors — BitPay, Coinbase Commerce, Stripe Crypto — is structural rather than cosmetic. Those providers pool merchant balances into company-owned omnibus accounts, which makes the merchant an unsecured creditor of the processor. DYNKLE never takes possession: funds land in merchant-owned wallet addresses, and every automated conversion is authorised by an on-chain permission the merchant grants once and can revoke at any time.'),
          p('What this document covers:'),
          bullet('The customer and merchant journey in plain language, with no blockchain terminology.', 'Part 2:'),
          bullet('The synchronous payment path — order creation, NFC tap, payment detection, and split settlement.', 'Part 3:'),
          bullet('The asynchronous auto-swap path — cryptographic delegation, the on-chain vault program, multi-bucket netting, and per-chain mechanisms.', 'Part 4:'),
          bullet('A worked numerical example ($100 bill in ETH) detailing cents, basis points, gas, and remainder absorption.', 'Part 5:'),
          bullet('Multi-chain liquidity matrix across Solana, EVM, TRON, Bitcoin, and cross-chain solvers.', 'Part 6:'),
          bullet('Security invariants, attack resistance, merchant portal UI, ATO tax compliance, QA testing, and open engineering items.', 'Parts 7–12:'),

          // PART 2: THE NON-TECHNICAL MONEY FLOW
          h1('Part 2 — The non-technical money flow'),
          p('Consider Sarah ordering a flat white coffee and a breakfast combo — $25.00 AUD — at Bean & Brew Café, run by Alex.'),

          h2('2.1 The cashier rings up the sale'),
          p('Alex enters $25.00 on the counter register, or selects items from the touch catalogue, and taps ENABLE DEVICE. The countertop reader illuminates green and shows "Waiting for Customer Tap".'),
          bullet('The exchange rate freezes for 90 seconds, so market movement during Sarah\'s order cannot change her final bill.', 'Rate lock guarantee:'),
          bullet('Alex can run Bar, Kitchen, and Patio stations at once, each mapped to its own hardware reader in real time.', 'Multi-counter synchronisation:'),

          h2('2.2 Sarah taps her phone to pay'),
          p('Sarah taps her phone on the reader, the same motion as a contactless card. Her phone opens the payment page with two primary routes:'),
          bullet('Pays in DYNK token at a flat 1¢ fee — no card surcharge for either side.', 'DYNK app:'),
          bullet('Phantom, MetaMask, Solflare, or Coinbase Wallet, paying in SOL, ETH, or BTC, authorised with Face ID or Touch ID.', 'External wallet:'),

          h2('2.3 Instant confirmation and receipt'),
          p('Within one to two seconds the reader chimes, Sarah gets a digital receipt with the tax breakdown on her screen, and Alex\'s register turns green with PAID. Neither of them waits on slow blockchain confirmation times.'),

          h2('2.4 The four-bucket revenue split'),
          p('In ordinary retail, revenue lands in one bank account and the owner reconciles it later. DYNKLE divides the $25.00 immediately across four buckets Alex configured in advance:'),

          styledTable(
            ['Bucket', 'Share', 'Amount', 'What it is for'],
            [
              ['Tax & GST reserve (ATO)', '15%', '$3.75', 'Held back so the quarterly BAS bill is already funded'],
              ['Operating expenses', '20%', '$5.00', 'Milk, beans, power, staff wages, supplier invoices'],
              ['Owner\'s drawings', '20%', '$5.00', 'Alex\'s salary from the business'],
              ['Retained profit', '45%', '$11.25', 'Savings toward café expansion']
            ],
            [30, 15, 15, 40]
          ),

          h2('2.5 Volatility protection: auto-swap or hold'),
          p('Alex sets each bucket independently, according to what that money is for:'),
          bullet('Operating costs and owner\'s pay convert automatically into USDC, a US-dollar stablecoin, at the live USDC/AUD rate. Rent and wage reserves are protected from crypto price swings; their AUD value still moves with the AUD/USD exchange rate.', 'Shielded (auto-convert to USDC):'),
          bullet('GST and retained profit stay in native SOL or ETH, so those reserves track the market upward. This is a deliberate risk choice: they track it downward too.', 'Hold in crypto:'),

          h2('2.6 Spending it and filing tax'),
          bullet('Alex taps his DYNKLE prepaid business debit card at Costco or Woolworths, drawing on his settled USDC balance.', 'Spending:'),
          bullet('At quarter end he clicks Export CSV. The file carries every transaction, the exchange rate at the moment it happened, and the split breakdown, ready for his accountant.', 'Tax compliance:'),

          // PART 3: TECHNICAL ARCHITECTURE - PAYMENT PATH
          h1('Part 3 — Technical architecture: payment path'),
          p('The lifecycle divides into two independent flows. The payment path is synchronous and must complete in roughly two seconds. The swap path, covered in Part 4, is asynchronous and runs on its own schedule.'),

          h2('3.1 Phase 1 — Cryptographic order creation'),
          p('When the register opens a sale with POST /api/orders, the server performs three steps:'),
          numbered('1.', 'A single-use ed25519 keypair is generated with @solana/web3.js. Its public key becomes an immutable, single-use Solana Pay reference — the idempotent on-chain fingerprint for this order.', 'Reference key generation:'),
          numbered('2.', 'Live oracle spot prices are queried and quoteExpiresAt is set to now + 90 000 ms. A payment arriving after that is rejected with HTTP 410 QUOTE_EXPIRED.', '90-second rate lock:'),
          numbered('3.', 'The server pushes DEVICE_ARMED with the order id, reference key, and total over the WebSocket mounted at /ws/terminal.', 'WebSocket broadcast:'),

          codeBlock([
            '// Server-side order initialisation snippet',
            'const reference = Keypair.generate().publicKey;',
            'const quoteExpiresAt = new Date(Date.now() + 90 * 1000);',
            'const order = await prisma.order.create({',
            '  data: {',
            '    orderNumber: `DY-${Date.now().toString().slice(-6)}`,',
            '    totalAUD: new Decimal(25.00),',
            '    tokenSymbol: "SOL",',
            '    cryptoAmount: new Decimal(0.1096),',
            '    quotePrice: new Decimal(228.00),',
            '    quoteExpiresAt,',
            '    referenceKey: reference.toBase58(),',
            '    status: "DEVICE_ARMED"',
            '  }',
            '});'
          ], 'Server-Side Order Creation'),

          h2('3.2 Phase 2 — NFC payload and multi-chain wallet dispatch'),
          p('The reader radiates an NDEF payload pointing at /pay.html?order=<UUID>. The page then dispatches by chosen currency:'),

          styledTable(
            ['Route', 'Mechanism', 'Notes'],
            [
              ['Solana / DYNK', 'solana:<merchantVault>?amount=…&reference=…&label=…', 'Standard Solana Pay transfer specification'],
              ['Ethereum / EVM', 'eth_sendTransaction to the merchant EVM address', 'Exact wei value computed client-side from the locked quote'],
              ['DYNK native app', 'dynk://pay?orderId=<UUID>', 'Internal transfer signed in the biometric secure enclave']
            ],
            [25, 45, 30]
          ),

          callout(
            'Naming Standard',
            'Write merchantVault rather than Vault everywhere in code and diagrams. In a specification whose central claim is non-custody, an unqualified "Vault" reads as a platform-held account and invites exactly the wrong conclusion in audit.',
            'warn'
          ),

          h2('3.3 Phase 3 — Zero-throttle reference watcher'),
          p('To avoid RPC rate-limit exhaustion and the false "payment not completed" modal a customer sees when returning from a wallet app, detection uses an in-flight deduplicator:'),
          bullet('Concurrent polls from the customer phone, the register, and background workers share one active RPC promise via an inFlightChecks map.', 'Promise deduplication:'),
          bullet('Queries getSignaturesForAddress(referenceKey), then confirms parsedTx.meta.err === null and verifies both the recipient account and the transferred amount.', 'Signature verification:'),
          bullet('Order state advances CREATED → ARMED → CONFIRMING → PAID → SETTLED, and PAYMENT_SUCCESS reaches every active counter in under 200 ms.', 'State propagation:'),

          h2('3.4 Phase 4 — Strict 100% split allocation'),
          p('Bucket shares are stored in basis points, where 1% equals 100 bps and the four buckets must sum to exactly 10,000. The split is executed on-chain — atomically via multi-instruction on Solana, via a multisend contract on EVM and TRON, and by accept-then-resplit on Lightning. The backend records the split; it does not perform it.'),

          callout(
            'Why That Distinction Matters',
            'A Node server cannot credit an on-chain balance. Any diagram or sentence showing the backend moving crypto into buckets contradicts the custody claim and will be read as evidence of custody during due diligence. The value-moving arrow must originate at the chain; the server\'s arrow is a ledger write.',
            'alert'
          ),

          // PART 4: NON-CUSTODIAL AUTO-SWAP CRYPTOGRAPHIC DEEP DIVE
          h1('Part 4 — Non-custodial auto-swap: cryptographic deep dive'),
          p('This is the part of the system that carries the most risk and the most explaining. The question it answers: how can a background service convert merchant funds on a schedule, with no merchant involvement, without ever having the power to steal them?'),

          h2('4.1 The underlying problem & the architectural rule'),
          p('An ordinary wallet address has no concept of conditional authority. It either holds the private key and can sign anything, or it does not. So "automated but non-custodial" cannot be achieved by giving a keeper service a private key — that is custody with extra steps.'),
          p('The solution is to move the authorisation logic on-chain. The merchant grants a narrow, revocable permission not to a person or a server, but to a piece of program code whose own rules the merchant can inspect before approving. The keeper then holds no authority at all: it can ask the program to run, and the program decides whether that is allowed.'),

          callout(
            'The Architectural Rule',
            'The keeper calls the vault program. The vault program calls the exchange. The keeper never calls the exchange directly, and never supplies the recipient address as a parameter. This is the single most important structural requirement in this document.',
            'alert'
          ),

          h2('4.2 Solana — SPL token delegation with a PDA-owned vault program'),
          p('Every SPL token account carries an owner and an optional delegate. The merchant\'s one-time authorisation writes a delegate into their own token account, and that delegate is a program-derived address (PDA) belonging to the DYNKLE vault program — not a keypair anyone holds.'),
          numbered('1.', 'The merchant signs spl_token::instruction::approve, writing Delegate = vault program PDA and a bounded Delegated Amount into the ledger.', 'One-time delegation:'),
          numbered('2.', 'The same setup transaction writes a policy account holding the whitelisted router program id (Jupiter v6), the permitted instruction discriminator, the USDC mint as the pinned output, and a maximum slippage in basis points.', 'Policy account:'),
          numbered('3.', 'When the keeper invokes execute_swap, the program asserts every policy condition, reads the Pyth price account in the same instruction, and only then signs the CPI into Jupiter using its own PDA seeds via invoke_signed. A PDA has no private key, so nothing outside the program can exercise that authority.', 'Constrained execution:'),

          codeBlock([
            '// One-time merchant authorisation (merchant signs once)',
            'spl_token::instruction::approve(',
            '    &token_program_id,',
            '    &merchant_token_account, // source, owned by merchant',
            '    &vault_program_pda,      // delegate = PROGRAM, not a keypair',
            '    &merchant_wallet_pubkey, // merchant signature',
            '    amount_allowance_limit   // bounded ceiling',
            ');',
            '',
            '// Inside the vault program\'s execute_swap instruction',
            'require!(ctx.accounts.router.key() == policy.whitelisted_router, ErrorCode::BadRouter);',
            'require!(ctx.accounts.out_mint.key() == policy.usdc_mint, ErrorCode::BadOutputMint);',
            'require!(oracle_bounded(pyth_price, quoted_out, policy.max_slippage_bps), ErrorCode::PriceOutOfBounds);',
            '',
            '// Recipient is derived in-program, NEVER accepted from caller calldata',
            'let recipient = merchant_usdc_ata(&policy.merchant);'
          ], 'Solana: Delegation and On-Chain Security Gate'),

          h2('4.3 EVM — Allowance to a vault contract, not to the router'),
          p('On Ethereum and its L2s the equivalent primitive is the ERC-20 allowance, optionally granted gaslessly through an EIP-2612 permit signature. The critical detail is the identity of the approved spender.'),

          callout(
            'EVM Security Architecture',
            'The approved spender must be the DYNKLE SwapVault contract, not the Uniswap router. A Uniswap router takes its recipient address as ordinary calldata and enforces nothing about it — whoever composes the call chooses where the output goes. Approving the router directly therefore does not deliver a fixed-destination guarantee; approving a vault contract that hardcodes the recipient in its own bytecode does.',
            'warn'
          ),

          codeBlock([
            '// SwapVault.sol — the approved spender contract',
            'function executeSwap(address bucket, uint256 amountIn) external {',
            '    require(msg.sender == keeper || msg.sender == owner, "unauthorised caller");',
            '    uint256 floor = OracleLib.minOut(',
            '        amountIn, priceFeed, policy[bucket].maxSlippageBps',
            '    ); // Chainlink feed read in the same transaction',
            '',
            '    IERC20(tokenIn).transferFrom(bucket, address(this), amountIn);',
            '    IERC20(tokenIn).approve(WHITELISTED_ROUTER, amountIn);',
            '',
            '    uint256 out = ISwapRouter(WHITELISTED_ROUTER).exactInputSingle(',
            '        ISwapRouter.ExactInputSingleParams({',
            '            tokenIn: tokenIn,',
            '            tokenOut: USDC,            // pinned constant, not a parameter',
            '            recipient: bucket,         // pinned to the source bucket',
            '            amountOutMinimum: floor    // oracle-derived, enforced on-chain',
            '        })',
            '    );',
            '    require(out >= floor, "price out of bounds");',
            '    emit SwapExecuted(bucket, amountIn, out);',
            '}'
          ], 'EVM: SwapVault Contract with Hardcoded Recipient'),

          h2('4.4 TRON'),
          p('TRON\'s virtual machine is EVM-compatible, so the pattern is identical to 4.3: a TRC-20 allowance granted to a TVM-deployed vault contract with the same hardcoded router, pinned output token, and on-chain price bound. Energy costs differ; the security model does not.'),

          h2('4.5 Bitcoin — A genuinely different trust model'),
          p('Bitcoin has no account-level allowance or delegate concept and no programmable account layer, so the pattern above cannot be reproduced. Two mechanisms are available, and neither is equivalent to the others:'),
          bullet('Hash time-locked contracts give a genuinely trustless atomic swap: both sides reveal a matching secret within a time window, and funds return automatically to their owner if either side fails to act. There is no standing delegated permission — each swap is its own contract.', 'Lightning — HTLC submarine swaps:'),
          bullet('Funds are held by a distributed validator set under a threshold signature scheme. No single party, DYNKLE included, holds the key. This is decentralised multi-party custody, which is materially different from the zero-custody model used on the other chains.', 'Native BTC — THORChain TSS vaults:'),

          callout(
            'Honest Phrasing in Product Copy',
            'The BTC leg is not "non-custodial in the exact same way" as the Solana and EVM legs, and reusing the same Enable Auto-Swap wording for it would overstate the guarantee. Give BTC its own distinct trust-model explanation in the portal.',
            'warn'
          ),

          h2('4.6 Revocation mechanics'),
          p('The merchant remains the account owner throughout. Revoking is a transaction only their key can sign: spl_token::instruction::revoke on Solana, or approve(vault, 0) / the vault\'s own pause() on EVM and TRON. It does not depend on DYNKLE infrastructure being available.'),

          callout(
            'Revocation Timing Reality',
            'Revocation takes effect from the next block, not instantly. A swap already broadcast and sitting in the mempool when the revoke is sent can still confirm first. Describe it as "effective from the next block" rather than "cancels immediately" — the difference will matter in a support conversation.',
            'note'
          ),

          // PART 5: NUMERICAL WALKTHROUGH ($100 IN ETH)
          h1('Part 5 — Numerical walkthrough: $100 paid in ETH'),
          p('A $100.00 AUD bill paid as 0.026316 ETH, at roughly $3,800 AUD per ETH, across four configured buckets:'),

          styledTable(
            ['Bucket', 'Mode', 'Split', 'Basis points', 'ETH share', 'AUD equivalent'],
            [
              ['GST / tax reserve', 'Hold ETH', '15.0%', '1,500 bps', '0.003947 ETH', '$15.00 AUD'],
              ['Retained profit', 'Hold ETH', '45.0%', '4,500 bps', '0.011842 ETH', '$45.00 AUD'],
              ['Operating costs', 'Auto-swap', '20.0%', '2,000 bps', '0.005263 ETH', '$20.00 AUD'],
              ['Owner\'s pay', 'Auto-swap', '20.0%', '2,000 bps', '0.005263 ETH', '$20.00 AUD'],
              ['Total', '—', '100.0%', '10,000 bps', '0.026316 ETH', '$100.00 AUD']
            ],
            [25, 15, 12, 16, 16, 16]
          ),

          h2('5.1 Netting execution'),
          p('Rather than two separate $20 swaps, each paying its own gas and fixed DEX cost, the keeper nets the two auto-swap buckets into one trade:'),
          numbered('1.', 'Operating costs and owner\'s pay combine into a single batch of 0.010526 ETH ($40.00 AUD).', 'Aggregate:'),
          numbered('2.', 'At 1.54 AUD per USDC the $40.00 AUD batch is worth 25.97 USDC. Minimum acceptable output = 25.97 * (1 - 0.010) = 25.71 USDC ($39.60 AUD) at a 1.0% cap.', 'Oracle bound:'),
          numbered('3.', 'The swap returns 25.84 USDC ($39.80 AUD) against 0.13 USDC ($0.20 AUD) of cost — above the floor, so it does not revert.', 'Execute:'),
          numbered('4.', '25.84 USDC divides 50/50 into 12.92 each, because both buckets contributed equally.', 'Credit pro-rata:'),

          h2('5.2 Final balance state'),
          styledTable(
            ['Bucket', 'Asset held', 'Nominal AUD', 'Risk profile'],
            [
              ['GST / tax', '0.003947 ETH', '$15.00 AUD', 'Exposed to ETH price in both directions'],
              ['Retained profit', '0.011842 ETH', '$45.00 AUD', 'Exposed to ETH price in both directions'],
              ['Operating costs', '12.92 USDC', '$19.90 AUD', 'Protected from crypto price (USD stablecoin)'],
              ['Owner\'s pay', '12.92 USDC', '$19.90 AUD', 'Protected from crypto price (USD stablecoin)'],
              ['Total', 'Multi-asset', '$99.80 AUD', 'Reconciled and audited']
            ],
            [25, 25, 20, 30]
          ),

          callout(
            'Two Realities This Example Makes Visible',
            'The merchant\'s total is $99.80, not $100.00 — the $0.20 swap cost is real and belongs in the ledger rather than being rounded away. And the 50/50 split is exact only because the two weights are equal; with a 20/45 pair the last bucket absorbs the sub-cent remainder, which is the reason that rule exists.',
            'note'
          ),

          h2('5.3 The cross-chain caveat in this example'),
          p('USDC is native on Ethereum as well as Solana, so an ETH-denominated bucket can swap to USDC on Ethereum directly through Uniswap. Stable buckets settle on Solana, though, so that USDC still has to cross through Circle CCTP or deBridge. A bridge hop is asynchronous: it can sit pending for minutes and it can fail after the swap has already executed.'),

          callout(
            'Two-Phase Settlement Reality',
            'The single-atomic-transaction guarantee holds for Solana-native routes only. For EVM routes the settlement is two-phase, and the specification must not describe it as atomic. A distinct BRIDGE_PENDING state, a timeout, and a reconciliation path are required.',
            'alert'
          ),

          // PART 6: MULTI-CHAIN MATRIX
          h1('Part 6 — Multi-chain liquidity and execution matrix'),
          p('How delegation, routing, and price validation differ across the supported ecosystems. The delegation-mechanism column is the one that determines the custody model:'),

          styledTable(
            ['Chain family', 'Tokens', 'Delegation mechanism', 'Primary router', 'Oracle', 'Custody model'],
            [
              ['Solana L1', 'SOL, DYNK, USDC', 'SPL approve → vault program PDA', 'Jupiter v6', 'Pyth', 'Zero custody'],
              ['Ethereum / EVM', 'ETH, WETH, USDC, USDT', 'EIP-2612 permit → SwapVault contract', 'Uniswap V3 / CoW', 'Chainlink', 'Zero custody'],
              ['Base / Arbitrum', 'ETH, USDC, DAI', 'ERC-4337 session keys or permit', 'Uniswap V3', 'Chainlink L2', 'Zero custody'],
              ['TRON', 'TRX, USDT (TRC-20)', 'TRC-20 approve → vault contract', 'SunSwap', 'TRON oracle', 'Zero custody'],
              ['Bitcoin native', 'BTC (L1)', 'THORChain TSS multi-party vaults', 'THORChain', 'THOR consensus', 'Decentralised custody'],
              ['Bitcoin Lightning', 'BTC (sats)', 'HTLC submarine swap (per swap)', 'Boltz / Liquid', 'L402 gateway', 'Atomic, per-swap'],
              ['Cross-chain to Solana USDC', 'Multi-chain', 'Bridge intent after local swap', 'deBridge DLN / CCTP', 'Dual validator', 'Two-phase']
            ],
            [16, 16, 22, 16, 15, 15]
          ),
          p('The last three rows are the ones to read carefully. Only the first four deliver the delegate-to-verifiable-code model described in Part 4; the Bitcoin and cross-chain rows involve a different set of trust assumptions, and any blanket "fully non-custodial across all chains" claim in marketing material would be inaccurate as a result.'),

          // PART 7: SECURITY & ATTACK RESISTANCE
          h1('Part 7 — Security, attack resistance and risk invariants'),
          p('Every guarantee below is a consequence of one fact — that spending authority lives in on-chain code rather than in a DYNKLE-held key — and is therefore only as strong as the vault program that enforces it:'),

          styledTable(
            ['Threat', 'Custodial processor', 'DYNKLE, if Part 4 is implemented as specified'],
            [
              ['Server breach', 'Attacker takes private keys and drains hot wallets', 'Servers hold no key with spending authority. A breached keeper can trigger legitimate swaps; it cannot redirect them.'],
              ['Rogue keeper', 'Malicious actor redirects swap proceeds', 'Recipient is fixed inside the vault program and never supplied by the caller. Any other destination reverts.'],
              ['MEV sandwich attack', 'Front-runners extract value through a thin pool', 'Oracle-derived minimum output is enforced in the same transaction, so a manipulated price reverts the trade.'],
              ['Stale oracle feed', 'Outdated quotes produce bad execution', 'Staleness bounds — Pyth 60 s, Chainlink 3600 s — abort the swap rather than proceed on an old price.'],
              ['RPC outage / timeout', 'Transactions stall in undefined state', 'Idempotency locks and explicit retry states prevent double-swaps on retry.'],
              ['Regulatory freeze', 'Intermediary freezes funds during a dispute', 'Assets never leave merchant-owned addresses on public ledgers.'],
              ['Processor insolvency', 'Merchant becomes an unsecured creditor', 'There is no pooled balance to be administered.']
            ],
            [20, 35, 45]
          ),

          h2('7.1 Three qualifications that belong with the table'),
          bullet('It cannot steal, but it can grief: repeatedly triggering swaps at the very edge of the slippage cap, or draining bucket gas reserves through churn. Rate limiting per bucket, and an alert on abnormal swap frequency, are required controls rather than nice-to-haves.', 'A breached keeper is not harmless:'),
          bullet('A slippage cap bounds the loss from a sandwich attack; it does not prevent the attack. An attacker can still extract value up to the cap on every trade. Tightening the cap, randomising execution timing, or routing through a private mempool are the mitigations that actually reduce extraction.', '"Prevented" overstates MEV protection:'),
          bullet('If a single DYNKLE-held key can upgrade the vault program or contract, then DYNKLE can rewrite the rules the merchant approved, and the architecture is non-custodial in mechanism but not in practice. The upgrade authority must be revoked, or held by a timelocked multisig whose membership and delay are publicly visible.', 'The guarantees are conditional on the upgrade authority:'),

          // PART 8: MERCHANT PORTAL UI & UX REQUIREMENTS
          h1('Part 8 — Merchant portal: UI and UX requirements'),
          p('Removing the merchant from the swap loop does not remove the need for merchant-facing surface. It changes the portal\'s job from "approve each conversion" to "understand what is being done on your behalf, and stop it if you want to":'),

          styledTable(
            ['#', 'Screen or component', 'Requirement', 'Priority'],
            [
              ['1', 'Per-bucket auto-swap setup', 'One flow per bucket, not a global switch. States the scope, the USDC-only output, and revocability in plain language before the wallet prompt appears.', 'P0'],
              ['2', 'Authorisation signing states', 'Wallet not connected, wrong network, user rejected, pending, confirmed, failed — each a distinct state, not one spinner.', 'P0'],
              ['3', 'Automation status per bucket', 'On / Off / Paused, with the pause reason named (low gas reserve, allowance revoked externally), last swap time and next check.', 'P0'],
              ['4', 'Revocation control', 'Prominent, one tap, with its own pending and confirmed states. Copy says effective from next block, not immediate.', 'P0'],
              ['5', 'Swap execution ledger', 'Per-bucket, filterable: input token and amount, USDC out, route, fee, timestamp, tx hash. CSV export.', 'P0'],
              ['6', 'Gas reserve warning', 'A bucket whose native reserve is too low for automation shows a warning before automation silently stalls.', 'P1'],
              ['7', 'Dust floor settings', 'Per chain or per bucket, with a sensible default ($15 AUD) — the old warn-and-confirm prompt no longer exists to catch a bad value.', 'P1'],
              ['8', 'Post-swap notification', 'In-app, push, or email digest. Informational, never a gate.', 'P1'],
              ['9', 'BTC-specific treatment', 'Distinct copy and flow — the trust model differs and the standard wording would overstate it.', 'P1'],
              ['10', 'Automation failure states', 'Swap reverted on price bound, allowance revoked outside the app, bridge pending beyond timeout, long dust-floor stall.', 'P1']
            ],
            [5, 25, 60, 10]
          ),

          callout(
            'Open UX Question: Calibration of Detail',
            'How much of the mechanism — delegate scope, PDA, oracle cross-check — should the portal actually surface to a café owner? Too little reads as opaque; too much reads as alarming. This is a trust-calibration decision that deserves a real copy pass with someone who has watched merchants use the product, not a choice made incidentally during implementation.',
            'note'
          ),

          // PART 9: REGULATORY & ATO COMPLIANCE
          h1('Part 9 — Regulatory compliance and tax accounting'),
          p('Under ATO guidance, a business accepting digital currency must record the AUD market value at the time of the transaction for GST and income tax. DYNKLE automates the record-keeping rather than the judgement:'),
          numbered('1.', 'Every transaction logs subtotalAUD, customerFeeAUD, gstAUD at 10%, and the exact spot rate at the timestamp.', 'GST accounting record:'),
          numbered('2.', 'Each auto-swap stamps acquisition cost, disposal value, DEX fee, and the resulting gain or loss into the execution ledger — a swap from a volatile asset into a stablecoin is a CGT event, and the ledger must treat it as one.', 'CGT tracking:'),
          numbered('3.', 'Full history via GET /api/auto-swap/ledger/export, formatted for ingestion into Xero, MYOB, or a CPA\'s system.', 'ATO-compliant export:'),

          callout(
            'Worth Raising With An Australian Tax Adviser',
            'Two points sit outside engineering\'s remit and should be confirmed rather than assumed. First, holding GST reserves in a volatile asset means the AUD value of the tax set-aside can fall below the liability it was meant to cover — the product should at minimum warn about this, since the merchant remains liable for the full amount. Second, whether the pro-rata credit-back across buckets after a netted swap creates any additional reporting obligation is a question for a tax professional, not for this document.',
            'warn'
          ),

          // PART 10: TESTING AND QA REQUIREMENTS
          h1('Part 10 — Testing and QA requirements'),
          p('Fund-moving code needs adversarial tests, not only happy-path coverage. Every case below must run on devnet or a mainnet fork — never against live funds:'),

          styledTable(
            ['Area', 'Test case', 'Expected result'],
            [
              ['Vault gate', 'Swap attempted through a non-whitelisted router', 'Revert'],
              ['Vault gate', 'Output token is anything other than USDC', 'Revert'],
              ['Vault gate', 'Oracle price deviates beyond the slippage cap', 'Revert'],
              ['Vault gate', 'Caller supplies an attacker address as recipient', 'Revert or ignored — recipient is derived in-program'],
              ['Keeper', 'Balance below dust floor', 'Skip, log, roll into next cycle — no transaction'],
              ['Keeper', 'Two buckets, same token, same chain', 'Exactly one swap transaction, not two'],
              ['Keeper', 'Keeper crashes mid-cycle, then restarts', 'No double swap; idempotency lock holds'],
              ['Credit-back', 'Odd amount across 20/45 weights', 'Sum of credits equals amount received, to the smallest unit'],
              ['Revocation', 'Revoke lands between keeper read and swap submit', 'Swap reverts; no funds move'],
              ['Revocation', 'Revoke broadcast while a swap sits in the mempool', 'Swap may still confirm — document, do not claim otherwise'],
              ['Cross-chain', 'Bridge stalls after swap completes', 'BRIDGE_PENDING state, timeout, reconciliation — not a silent loss'],
              ['Payment', 'Customer pays after the 90 s quote expiry', 'HTTP 410 QUOTE_EXPIRED with a clear customer-facing message'],
              ['Payment', 'Same order opened on two devices', 'Only one can claim; the other gets a distinct state']
            ],
            [15, 45, 40]
          ),

          callout(
            'Audit, Not Code Review',
            'The Solana program and the EVM vault contract move merchant money under delegated authority. They need a third-party smart-contract audit before mainnet, covering account and PDA validation, CPI authority, arbitrary external calls, upgrade authority, decimal and rounding correctness, and stuck-fund scenarios. An internal code review is not a substitute, and the difference will be the first question a serious counterparty asks.',
            'alert'
          ),

          // PART 11: EVIDENCE AND VERIFICATION STATUS
          h1('Part 11 — Evidence and verification status'),
          p('The following table records the implementation status of each component against the DYNKLE codebase:'),

          styledTable(
            ['Component', 'Referenced implementation', 'Status in pos-backend'],
            [
              ['Reference watcher, payment detection', 'src/services/solana.js', 'Implemented & verified (in-flight deduplicator active)'],
              ['Basis-point split engine', 'src/merchantStore.js', 'Implemented & verified (10,000 bps invariant enforced)'],
              ['Keeper, dust floor, netting, credit-back', 'src/services/autoSwapKeeperService.js', 'Implemented & verified (passes 9/9 automated tests)'],
              ['Audit ledger and CSV export', 'auto_swap_ledger.json, prisma.auditLog', 'Implemented & verified (downloadable endpoint active)'],
              ['Dynamic UUID bucket resolution', 'autoSwapKeeperService.js, autoSwap.js', 'Implemented & verified (resolves PostgreSQL rule UUIDs)'],
              ['On-chain Vault Program / SwapVault contract', 'Anchor Program (Solana) / Solidity Contract (EVM)', 'Smart contracts specified; audited deployment required before mainnet']
            ],
            [30, 30, 40]
          ),

          // PART 12: OPEN ITEMS BEFORE PRODUCTION
          h1('Part 12 — Open items before production'),
          p('Six items, ordered by what they put at risk. The first two determine whether the custody claim in Part 7 is true as built:'),

          styledTable(
            ['#', 'Item', 'Risk if unresolved', 'Owner'],
            [
              ['1', 'Approved spender is the DEX router rather than a vault contract', 'The router takes recipient from calldata and enforces nothing — the fixed-destination guarantee does not exist', 'Blockchain eng'],
              ['2', 'Oracle bound checked off-chain by the keeper', 'An off-chain read guarantees nothing; a compromised keeper can submit any minimum-output it likes', 'Blockchain eng'],
              ['3', 'Program and contract upgrade authority unspecified', 'A single DYNKLE-held upgrade key means DYNKLE can rewrite the rules the merchant approved', 'Security / founders'],
              ['4', 'Router address labelled Uniswap V3 is the V2 router', '0x7a250d…F2488D is UniswapV2Router02 on mainnet; whitelisting the wrong router is a production bug', 'Blockchain eng'],
              ['5', 'EVM route described as atomic', 'Swap plus bridge is two-phase and can fail between phases; merchant-facing copy would be inaccurate', 'Product + eng'],
              ['6', 'BTC leg uses a different trust model', 'THORChain TSS is decentralised custody, not zero custody; reusing the standard UI copy overstates it', 'Product']
            ],
            [5, 30, 50, 15]
          ),

          h2('12.1 Recommended sequencing'),
          numbered('1.', 'Resolve Part 11 against the actual repository before any further design work.', 'Confirm what exists:'),
          numbered('2.', 'Close items 1–4. These are correctness and custody, not polish.', 'Contract security:'),
          numbered('3.', 'Ship Solana first. It is the cleanest mechanism, it is where stable buckets settle in native USDC, and it avoids the two-phase bridge problem entirely — it is the right surface on which to prove the model.', 'Rollout priority:'),
          numbered('4.', 'Third-party smart-contract audit of the program and the contract.', 'Audit before mainnet:'),
          numbered('5.', 'Then EVM, then BTC. Each with its own trust-model explanation in the portal.', 'Expansion:'),

          // APPENDIX A: CORRECTIONS APPLIED
          h1('Appendix A — Corrections applied against version 2.4.0'),
          p('Version 2.4.0 was marked Production Stable. These are the substantive changes made in this revision and the reason for each, so the delta is reviewable rather than silent:'),

          styledTable(
            ['v2.4.0 said', 'v3.0.0 says', 'Why'],
            [
              ['The EIP-2612 permit authorises the Uniswap V3 Router as approved spender', 'The permit authorises the DYNKLE SwapVault contract; the vault calls the router', 'A router reads recipient from calldata and enforces nothing. Approving it directly voids the fixed-destination guarantee.'],
              ['The keeper queries Pyth / Chainlink for oracle price bounds', 'The vault program reads the oracle inside the swap transaction', 'An off-chain read by the keeper is not a guarantee. The comparison must be an on-chain assertion.'],
              ['Movement into the pool and USDC out occurs within a single atomic block transaction', 'Atomic on Solana-native routes; two-phase on EVM routes that cross a bridge', 'Stable buckets settle in USDC on Solana. An ETH bucket can swap to USDC on Ethereum, but moving it to Solana needs a CCTP or deBridge transfer, which is asynchronous.'],
              ['Uniswap V3 Router 0x7a250d…F2488D', 'Flagged for verification — that address is UniswapV2Router02', 'Whitelisting the wrong router address is a production defect, not a documentation typo.'],
              ['MEV sandwich attack: Prevented', 'Bounded, not prevented — loss is capped at the slippage limit', 'A cap limits extraction per trade; it does not stop the attack.'],
              ['Server breach: Zero Risk', 'No theft risk; griefing and gas-drain risk remain', 'A breached keeper can still churn swaps at the cap edge and drain gas reserves.'],
              ['In 400 ms the delegate authority is deleted', 'Effective from the next block; an in-flight swap may still confirm', 'Sets the right support expectation and avoids a claim that will be contradicted in practice.'],
              ['Backend credits hold buckets directly in raw crypto', 'The split executes on-chain; the backend records it', 'A Node server cannot credit an on-chain balance. As written it implies custody.'],
              ['(absent)', 'Upgrade authority named as an open item', 'If one key can rewrite the vault rules, the custody guarantee is conditional on trusting its holder.'],
              ['Version 2.4.0 Production Stable', '3.0.0 Draft for engineering sign-off', 'Six unresolved items, two of which affect custody. The status line should not outrun the evidence.']
            ],
            [30, 35, 35]
          ),

          // APPENDIX B: GLOSSARY
          h1('Appendix B — Glossary'),
          styledTable(
            ['Term', 'Meaning'],
            [
              ['Basis point (bps)', 'One hundredth of one percent. Bucket splits are stored in bps and must sum to exactly 10,000.'],
              ['CPI', 'Cross-program invocation — one Solana program calling another, the mechanism by which the vault program calls Jupiter.'],
              ['Delegate', 'An SPL token account field naming an address permitted to move up to a bounded amount. Here it names a program, not a person.'],
              ['Dust floor', 'The minimum balance worth converting. Below it, fees would exceed the value moved, so the keeper skips.'],
              ['EIP-2612 permit', 'An off-chain signature that grants an ERC-20 allowance without the merchant paying gas for a separate approve transaction.'],
              ['HTLC', 'Hash time-locked contract — the Bitcoin/Lightning primitive behind trustless submarine swaps.'],
              ['Keeper', 'The off-chain service that decides when to trigger a swap. It holds no authority over funds.'],
              ['Netting', 'Combining same-token, same-chain balances from several buckets into one trade to reduce fees.'],
              ['PDA', 'Program-derived address — a Solana address with no private key, controllable only by its owning program.'],
              ['Pro-rata credit-back', 'Distributing a netted swap\'s output to contributing buckets in proportion to their input, preserving tax quarantine.'],
              ['Reference key', 'A single-use ed25519 public key used as an idempotent on-chain fingerprint for one order.'],
              ['Slippage cap', 'The maximum acceptable deviation from the expected price, enforced on-chain as a minimum output.'],
              ['TSS', 'Threshold signature scheme — a key split across many parties, none of whom can sign alone. THORChain\'s custody model.'],
              ['USDC', 'A US-dollar stablecoin issued by Circle (1 USDC = 1 USD). Native on Solana, where stable buckets settle, and on Ethereum and other chains; Circle CCTP moves it between chains. It is not pegged to AUD: AUD amounts convert at the live USDC/AUD rate.'],
              ['Vault program / SwapVault', 'The on-chain code holding the merchant\'s delegated permission and enforcing every swap constraint.']
            ],
            [25, 75]
          ),

          new Paragraph({ spacing: { before: 200, after: 100 }, children: [] }),
          p('End of specification. Version 3.0.0 — Draft for engineering sign-off. Parts 11 and 12 must be closed before this document is represented as describing a production system.', { italics: true, color: COLOR_MUTED })
        ]
      }
    ]
  });

  const buffer = await Packer.toBuffer(doc);
  
  const rootPath = '/home/nitya/DYNK-Latest/DYNKLE_Complete_Money_Flow_Specification_v3.docx';
  const publicPath = path.join(__dirname, '../public/DYNKLE_Complete_Money_Flow_Specification_v3.docx');
  const legacyPublicPath = path.join(__dirname, '../public/DYNKLE_Money_Flow_Specification.docx');

  fs.writeFileSync(rootPath, buffer);
  fs.writeFileSync(publicPath, buffer);
  fs.writeFileSync(legacyPublicPath, buffer);

  console.log(`Master v3.0.0 Document generated successfully!`);
  console.log(`Root Path: ${rootPath} (${buffer.length} bytes)`);
  console.log(`Public Path: ${publicPath} (${buffer.length} bytes)`);
}

buildMasterDocument().catch(err => {
  console.error('Failed to generate document:', err);
  process.exit(1);
});
