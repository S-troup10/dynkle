import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import {
  Document,
  Packer,
  Paragraph,
  TextRun,
  HeadingLevel,
  Table,
  TableRow,
  TableCell,
  WidthType,
  BorderStyle,
  AlignmentType,
  ShadingType,
  Header,
  Footer,
  PageNumber,
  NumberFormat
} from 'docx';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Color Palette Constants
const COLOR_PRIMARY = '0F172A'; // Dark Slate
const COLOR_ACCENT = '10B981';  // Emerald Green
const COLOR_SECONDARY = '3B82F6'; // Royal Blue
const COLOR_MUTED = '64748B';   // Slate Grey
const COLOR_LIGHT_BG = 'F8FAFC'; // Off-white
const COLOR_BORDER = 'CBD5E1';  // Border grey
const COLOR_HEADER_BG = '1E293B'; // Deep navy

function createHeading1(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_1,
    spacing: { before: 360, after: 180 },
    run: {
      color: COLOR_PRIMARY,
      bold: true,
      size: 32,
      font: 'Calibri'
    }
  });
}

function createHeading2(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 280, after: 120 },
    run: {
      color: COLOR_SECONDARY,
      bold: true,
      size: 26,
      font: 'Calibri'
    }
  });
}

function createHeading3(text) {
  return new Paragraph({
    text,
    heading: HeadingLevel.HEADING_3,
    spacing: { before: 200, after: 80 },
    run: {
      color: COLOR_PRIMARY,
      bold: true,
      size: 22,
      font: 'Calibri'
    }
  });
}

function createParagraph(text, options = {}) {
  return new Paragraph({
    spacing: { before: 80, after: 120, line: 276 },
    children: [
      new TextRun({
        text,
        size: 22,
        font: 'Calibri',
        color: options.color || '1E293B',
        bold: options.bold || false,
        italics: options.italics || false
      })
    ]
  });
}

function createBullet(text, boldPrefix = '') {
  const children = [];
  if (boldPrefix) {
    children.push(new TextRun({ text: boldPrefix + ' ', bold: true, size: 22, font: 'Calibri', color: COLOR_PRIMARY }));
  }
  children.push(new TextRun({ text, size: 22, font: 'Calibri', color: '334155' }));
  return new Paragraph({
    bullet: { level: 0 },
    spacing: { before: 40, after: 60, line: 260 },
    children
  });
}

function createCallout(title, text) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.NONE },
      right: { style: BorderStyle.NONE },
      bottom: { style: BorderStyle.NONE },
      left: { style: BorderStyle.SINGLE, size: 24, color: COLOR_ACCENT }
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: 'F0FDF4', type: ShadingType.CLEAR },
            margins: { top: 140, bottom: 140, left: 180, right: 180 },
            children: [
              new Paragraph({
                children: [
                  new TextRun({ text: `📌 ${title}: `, bold: true, color: '065F46', size: 22, font: 'Calibri' }),
                  new TextRun({ text, color: '047857', size: 22, font: 'Calibri' })
                ]
              })
            ]
          })
        ]
      })
    ]
  });
}

function createCodeBlock(codeLines) {
  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    borders: {
      top: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER },
      right: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER },
      bottom: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER },
      left: { style: BorderStyle.SINGLE, size: 6, color: COLOR_BORDER }
    },
    rows: [
      new TableRow({
        children: [
          new TableCell({
            shading: { fill: '0F172A', type: ShadingType.CLEAR },
            margins: { top: 140, bottom: 140, left: 180, right: 180 },
            children: codeLines.map(line => new Paragraph({
              spacing: { before: 20, after: 20 },
              children: [
                new TextRun({
                  text: line,
                  font: 'Consolas',
                  size: 19,
                  color: '38BDF8'
                })
              ]
            }))
          })
        ]
      })
    ]
  });
}

function createStyledTable(headers, rowsData) {
  const headerRow = new TableRow({
    children: headers.map(h => new TableCell({
      shading: { fill: COLOR_HEADER_BG, type: ShadingType.CLEAR },
      margins: { top: 120, bottom: 120, left: 140, right: 140 },
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: h, bold: true, color: 'FFFFFF', size: 20, font: 'Calibri' })
          ]
        })
      ]
    }))
  });

  const bodyRows = rowsData.map((row, idx) => new TableRow({
    children: row.map(cell => new TableCell({
      shading: { fill: idx % 2 === 0 ? 'FFFFFF' : COLOR_LIGHT_BG, type: ShadingType.CLEAR },
      margins: { top: 100, bottom: 100, left: 140, right: 140 },
      borders: {
        top: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        bottom: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        left: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER },
        right: { style: BorderStyle.SINGLE, size: 4, color: COLOR_BORDER }
      },
      children: [
        new Paragraph({
          children: [
            new TextRun({ text: String(cell), color: '1E293B', size: 20, font: 'Calibri' })
          ]
        })
      ]
    }))
  }));

  return new Table({
    width: { size: 100, type: WidthType.PERCENTAGE },
    rows: [headerRow, ...bodyRows]
  });
}

async function buildDocument() {
  const doc = new Document({
    creator: 'DYNKLE Protocol Architecture Team',
    title: 'DYNKLE POS: Complete Technical & Non-Technical Money Flow Specification',
    description: 'Comprehensive technical whitepaper and merchant operational guide on multi-chain payments, 4-bucket revenue splitting, non-custodial auto-swap, and DEX integration.',
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, bottom: 1440, left: 1440, right: 1440 }
          }
        },
        headers: {
          default: new Header({
            children: [
              new Paragraph({
                alignment: AlignmentType.RIGHT,
                children: [
                  new TextRun({ text: 'DYNKLE POS — Technical & Non-Technical Money Flow Specification', size: 18, color: COLOR_MUTED, font: 'Calibri' })
                ]
              })
            ]
          })
        },
        footers: {
          default: new Footer({
            children: [
              new Paragraph({
                alignment: AlignmentType.SPACE_BETWEEN,
                children: [
                  new TextRun({ text: 'Confidential & Proprietary — DYNKLE Protocol', size: 18, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ text: ' | Page ', size: 18, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ children: [PageNumber.CURRENT], size: 18, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ text: ' of ', size: 18, color: COLOR_MUTED, font: 'Calibri' }),
                  new TextRun({ children: [PageNumber.TOTAL_PAGES], size: 18, color: COLOR_MUTED, font: 'Calibri' })
                ]
              })
            ]
          })
        },
        children: [
          // TITLE / COVER BANNER
          new Paragraph({
            spacing: { before: 400, after: 100 },
            children: [
              new TextRun({
                text: 'DYNKLE POS PROTOCOL',
                bold: true,
                size: 20,
                color: COLOR_ACCENT,
                font: 'Calibri'
              })
            ]
          }),
          new Paragraph({
            spacing: { before: 100, after: 200 },
            children: [
              new TextRun({
                text: 'Complete Technical & Non-Technical Money Flow Specification',
                bold: true,
                size: 38,
                color: COLOR_PRIMARY,
                font: 'Calibri'
              })
            ]
          }),
          new Paragraph({
            spacing: { before: 0, after: 300 },
            children: [
              new TextRun({
                text: 'An In-Depth Blueprint: Point-of-Sale Terminal Billing, Multi-Chain Tap Payments, 4-Bucket Revenue Splitting, Non-Custodial One-Time Approvals, and Autonomous DEX Auto-Swap Settlements.',
                italics: true,
                size: 24,
                color: COLOR_MUTED,
                font: 'Calibri'
              })
            ]
          }),

          createStyledTable(
            ['Document Property', 'Details'],
            [
              ['Version', '2.4.0 (Production Stable)'],
              ['Target Ecosystems', 'Solana (L1), Ethereum / EVM (Base, Arbitrum, Polygon), Bitcoin (Lightning / Native), TRON'],
              ['Authors', 'DYNKLE Core Engineering & Protocol Architecture'],
              ['Date Published', 'September 2026'],
              ['License & Classification', 'Commercial Production Specification']
            ]
          ),

          new Paragraph({ spacing: { before: 300, after: 100 }, children: [] }),

          // EXECUTIVE SUMMARY
          createHeading1('Executive Summary'),
          createParagraph(
            'The DYNKLE Point-of-Sale (POS) Protocol provides physical retail merchants with an institutional-grade, zero-custody digital currency payment terminal. It eliminates traditional 1.6%–2.5% card interchange swipe fees by allowing merchants to accept payments in native DYNK token (1¢ flat fee), major cryptocurrencies (SOL, ETH, BTC, USDT, USDC), and stablecoins, while automatically shielding them from crypto volatility.'
          ),
          createParagraph(
            'Unlike legacy custodial processors (such as BitPay, Coinbase Commerce, or Stripe Crypto) which pool merchant balances into company-owned omnibus accounts, DYNKLE is built strictly on non-custodial smart contracts and decentralized liquidity protocols (Jupiter v6 and Uniswap V3). Merchants retain 100% ownership of their private keys and wallet vaults at all times.'
          ),
          createParagraph(
            'This specification describes both the non-technical customer and merchant journeys, and the low-level technical architecture spanning hardware NFC pairing, cryptographic Solana Pay reference keys, 10,000 basis points split allocations, and Pyth/Chainlink oracle-guaranteed DEX netting execution.'
          ),

          // PART 1: NON-TECHNICAL MONEY FLOW
          createHeading1('Part 1: The Non-Technical Money Flow (The Real-World Story)'),
          createParagraph(
            'To understand how DYNKLE works in daily commerce, consider a customer named Sarah ordering a flat white coffee and breakfast combo ($25.00 AUD) at Bean & Brew Café, managed by the café owner Alex.'
          ),

          createHeading2('1.1 The Cashier Rings Up the Sale'),
          createParagraph(
            'Alex enters $25.00 on the counter register (or selects items from the touch catalog) and taps "ENABLE DEVICE". The DYNKLE countertop reader (a screenless tap terminal) immediately illuminates green and announces: "Waiting for Customer Tap".'
          ),
          createBullet('The exact exchange rate is frozen for 90 seconds. If Sarah chooses to pay in crypto, the rate is guaranteed so that market movements during her coffee order do not change her final bill amount.', 'Rate Lock Guarantee:'),
          createBullet('Alex can run multiple counter stations (Bar, Kitchen, Patio) simultaneously, with each counter mapped to an individual hardware station in real time.', 'Multi-Counter Synchronization:'),

          createHeading2('1.2 Sarah Taps Her Phone to Pay'),
          createParagraph(
            'Sarah taps her smartphone against the counter reader just like an Apple Pay or Mastercard contactless transaction. Her phone instantly opens the payment interface:'
          ),
          createBullet('Sarah pays using DYNK token. The fee is exactly 1¢ flat, saving both Sarah and Alex card processing fees.', 'Option A (DYNK App Tap):'),
          createBullet('Sarah chooses Solana, Ethereum, or Bitcoin from her favorite self-custody wallet (Phantom, MetaMask, Solflare, Coinbase Wallet) and authorizes with FaceID / TouchID.', 'Option B (External Multi-Chain Wallets):'),

          createHeading2('1.3 Instant Confirmation & Receipt'),
          createParagraph(
            'Within 1 to 2 seconds, Sarah’s wallet broadcasts the transaction. The counter terminal chimes a pleasant audio ding, Sarah receives a digital receipt on her phone with tax breakdown, and Alex’s register displays a green "PAID ✓" card.'
          ),

          createHeading2('1.4 The 4-Bucket Smart Revenue Split'),
          createParagraph(
            'In traditional commerce, revenue lands in one messy bank account, leaving business owners scrambling at tax time. DYNKLE immediately splits the $25.00 incoming sale across Alex’s 4 configured business vaults:'
          ),
          createBullet('15% ($3.75 AUD) is automatically diverted into Alex’s tax vault so he is never short on cash when his quarterly BAS tax bill arrives.', '1. Tax & GST Reserve (ATO):'),
          createBullet('20% ($5.00 AUD) is quarantined for milk, coffee beans, power bills, and staff wages.', '2. Operating Expenses:'),
          createBullet('20% ($5.00 AUD) is allocated directly to Alex as business owner salary.', '3. Owner’s Drawings:'),
          createBullet('45% ($11.25 AUD) accumulates in business savings for café expansion.', '4. Retained Profit:'),

          createHeading2('1.5 Volatility Protection: Auto-Swap vs. Crypto Hold'),
          createParagraph(
            'Alex configured his 4 buckets based on his risk preference:'
          ),
          createBullet('Operating Costs and Owner’s Pay are set to "Auto-Convert to USDC Stablecoin". These portions are instantly and autonomously swapped into USDC (Circle’s US-dollar digital stablecoin), converted from AUD at the live USDC/AUD rate. Alex’s rent and wage reserves are shielded from crypto price swings (their AUD value still moves with the AUD/USD exchange rate).', 'Stable Mode (Shielded):'),
          createBullet('GST and Retained Profit are set to "Hold in Crypto". Alex keeps those allocations in native SOL or ETH, letting his tax reserves and retained earnings grow as crypto markets appreciate over time.', 'Crypto Hold Mode (Upside):'),

          createHeading2('1.6 Real-World Spending & Tax Filing'),
          createBullet('Alex taps his DYNKLE Prepaid Business Debit Card (included with his terminal kit) at Costco or Woolworths to spend his settled USDC balance on business supplies.', 'Spending:'),
          createBullet('At the end of each quarter, Alex clicks "Export CSV" on the portal. The file contains a complete audit ledger of every transaction, currency exchange rate, and tax split, ready for his accountant.', 'Tax Compliance:'),

          // PART 2: TECHNICAL ARCHITECTURE
          createHeading1('Part 2: The Deep Technical Architecture Flow'),
          createParagraph(
            'This section breaks down the exact network protocols, cryptographic primitives, and state transitions governing the DYNKLE engine.'
          ),

          createHeading2('2.1 Phase 1: Cryptographic Order Creation & Reference Keys'),
          createParagraph(
            'When the register initiates a sale via POST /api/orders, the server executes the following sequence:'
          ),
          createBullet('A single-use ed25519 cryptographic keypair is generated using @solana/web3.js: Keypair.generate(). The public key acts as an immutable, single-use Solana Pay reference key.', '1. Reference Key Generation:'),
          createBullet('Live oracle spot prices are queried. quoteExpiresAt is calculated as Date.now() + 90000. Orders submitted after 90 seconds are automatically rejected with an EXPIRED state.', '2. 90-Second Rate Lock:'),
          createBullet('The server broadcasts { type: "DEVICE_ARMED", orderId, referenceKey, totalAUD } over the persistent WebSocket server mounted at /ws/terminal.', '3. WebSocket Broadcast:'),

          createCodeBlock([
            '// Server-Side Order Initialization Snippet',
            'const reference = Keypair.generate().publicKey;',
            'const quoteExpiresAt = new Date(Date.now() + 90 * 1000);',
            'const order = await prisma.order.create({',
            '  data: {',
            '    orderNumber: `DY-${Date.now().toString().slice(-6)}`,',
            '    totalAUD: new Decimal(25.00),',
            '    tokenSymbol: "SOL",',
            '    cryptoAmount: new Decimal(0.1096),',
            '    quotePrice: new Decimal(228.00),',
            '    quoteExpiresAt,',
            '    referenceKey: reference.toBase58(),',
            '    status: "DEVICE_ARMED"',
            '  }',
            '});'
          ]),

          createHeading2('2.2 Phase 2: NFC NDEF Payload & Multi-Chain Wallet Dispatch'),
          createParagraph(
            'The counter reader terminal radiates an NDEF NFC payload pointing to the customer payment portal. When Sarah taps her phone, her browser opens /pay.html?order=<UUID>:'
          ),
          createBullet('Formats a standard Solana Pay transfer specification: solana:<VAULT_PUBKEY>?amount=0.1096&reference=<REF_PUBKEY>&label=Bean%20%26%20Brew.', 'Solana Pay Protocol:'),
          createBullet('Dispatches an eth_sendTransaction call targeting the merchant EVM address with exact Wei value calculation.', 'Ethereum / EVM Protocol:'),
          createBullet('Invokes the dynk://pay deep-link scheme, executing an internal atomic transfer signed with biometric enclave keys.', 'DYNK Native App:'),

          createHeading2('2.3 Phase 3: Zero-Throttle In-Flight Reference Watcher'),
          createParagraph(
            'To prevent RPC rate-limit exhaustion and eliminate false "Payment Not Completed" modals when a user returns from their wallet app, DYNKLE utilizes an in-flight check deduplicator:'
          ),
          createBullet('Multiple concurrent polling requests from the customer phone, POS register, and background workers share a single active RPC promise map (inFlightChecks).', 'Promise Deduplication:'),
          createBullet('Queries Solana RPC using getSignaturesForAddress(referenceKey). Confirms parsedTx.meta.err === null and verifies exact recipient and amount.', 'Atomic Signature Verification:'),
          createBullet('Once on-chain finality is verified, the order status transitions atomically: CREATED -> ARMED -> CONFIRMING -> PAID -> SETTLED. The WebSocket broadcasts ORDER_PAID to all active counters in under 200ms.', 'Event Propagation:'),

          // PART 3: CRYPTOGRAPHIC DEEP DIVE
          createHeading1('Part 3: Cryptographic Deep Dive: Non-Custodial One-Time Approvals'),
          createParagraph(
            'The central innovation of DYNKLE is enabling automated background conversions into USDC without taking custody of merchant funds. Here is the technical explanation of how this is achieved.'
          ),

          createCallout(
            'Core Security Invariant',
            'DYNKLE servers never possess or touch the merchant private keys or seed phrase. Funds reside in the merchant self-custody wallet addresses at all times. Automated swaps are governed by cryptographically constrained on-chain allowances.'
          ),

          createHeading2('3.1 How It Works on Solana: SPL Token Delegation'),
          createParagraph(
            'On Solana, every SPL token account has an owner field and an optional delegate field defined in the native SPL Token Program. When the merchant clicks "Sign & Authorize Policy":'
          ),
          createBullet('The merchant signs spl_token::instruction::approve. This writes into the Solana ledger: Delegate = DYNKLE_PDA_PROGRAM, Amount = Limit.', '1. One-Time Delegation:'),
          createBullet('When the keeper executes a swap, it invokes Jupiter v6 Aggregator using the delegate authority. The transaction pulls the token from the merchant account and deposits USDC into the merchant Associated Token Account (ATA).', '2. Atomic Delegation Swap:'),
          createBullet('The program instruction strictly enforces: recipient == merchant_usdc_ata. Even if an attacker compromised the backend server, the contract rejects any transaction directing funds to an unauthorized address.', '3. Recipient Constraint:'),

          createCodeBlock([
            '// Solana SPL Token Delegation Instruction',
            'spl_token::instruction::approve(',
            '    &token_program_id,',
            '    &merchant_token_account,  // Source account owned by merchant',
            '    &keeper_pda_address,      // Authorized delegate program',
            '    &merchant_wallet_pubkey,  // Merchant signs this once',
            '    amount_allowance_limit    // Bounded maximum conversion amount',
            ');'
          ]),

          createHeading2('3.2 How It Works on EVM: EIP-2612 Permits & EIP-712 Signatures'),
          createParagraph(
            'On Ethereum, Base, and Polygon, the merchant signs an off-chain typed signature (EIP-712 Permit):'
          ),
          createBullet('The signature authorizes the Uniswap V3 Router as the approved spender up to a specific dollar allowance.', '1. Gasless Signature:'),
          createBullet('The keeper submits the signed permit alongside the swap instruction. Uniswap executes transferFrom(merchant, pool, amount) and immediately routes the output USDC into merchantAddress.', '2. Atomic Execution:'),
          createBullet('DYNKLE never holds the tokens. The movement of raw token into the liquidity pool and output USDC into the merchant wallet occurs within a single atomic block transaction.', '3. Zero Intermediate Custody:'),

          createHeading2('3.3 Instant On-Chain Revocation'),
          createParagraph(
            'The merchant retains legal ownership of their on-chain account. Clicking "Revoke ✕" in the portal broadcasts spl_token::instruction::revoke or resets the ERC-20 allowance to 0. In 400 milliseconds, the delegate authority is deleted from the blockchain ledger, immediately terminating the keeper authority.'
          ),

          // PART 4: NUMERICAL WALKTHROUGH
          createHeading1('Part 4: Detailed Numerical Walkthrough ($100 Bill in ETH)'),
          createParagraph(
            'To illustrate the mathematical accuracy of the split and netting engine, consider a $100.00 AUD transaction paid in ETH with 4 buckets configured:'
          ),

          createStyledTable(
            ['Bucket Name', 'Target Asset', 'Configured Split %', 'Basis Points', 'ETH Share', 'AUD Equivalent'],
            [
              ['GST / Tax Reserve', 'Hold ETH', '15.0%', '1,500 bps', '0.003947 ETH', '$15.00 AUD'],
              ['Retained Profit', 'Hold ETH', '45.0%', '4,500 bps', '0.011842 ETH', '$45.00 AUD'],
              ['Operating Costs', 'Auto-Swap USDC', '20.0%', '2,000 bps', '0.005263 ETH', '$20.00 AUD'],
              ['Owner’s Pay', 'Auto-Swap USDC', '20.0%', '2,000 bps', '0.005263 ETH', '$20.00 AUD'],
              ['TOTAL', '—', '100.0%', '10,000 bps', '0.026316 ETH', '$100.00 AUD']
            ]
          ),

          createHeading2('4.1 Multi-Bucket Netting Execution'),
          createParagraph(
            'Instead of executing two separate swaps of $20 each (which would incur double gas fees and two DEX fixed charges), the keeper performs multi-bucket netting:'
          ),
          createBullet('The keeper aggregates Operating Costs (20%) and Owner’s Pay (20%) into a single swap batch: 0.010526 ETH ($40.00 AUD).', '1. Netting Aggregation:'),
          createBullet('Checks Pyth & Chainlink oracles: At 1.54 AUD per USDC the $40.00 AUD batch is worth 25.97 USDC, so min acceptable USDC = 25.97 * (1 - 0.010) = 25.71 USDC ($39.60 AUD).', '2. Oracle Bound Check:'),
          createBullet('Uniswap V3 swaps 0.010526 ETH -> 25.84 USDC, worth $39.80 AUD (0.5% DEX swap fee = 0.13 USDC, $0.20 AUD).', '3. Swapping via DEX:'),
          createBullet('The returned 25.84 USDC is divided 50/50: Exactly 12.92 USDC to Operating Costs, and 12.92 USDC to Owner’s Pay. Remainder absorption prevents 1-cent losses.', '4. Pro-Rata Credit:'),

          createHeading2('4.2 Final Balance State'),
          createStyledTable(
            ['Bucket', 'Asset Held in Wallet', 'Nominal AUD Value', 'Risk Profile'],
            [
              ['GST / Tax', '0.003947 ETH', '$15.00 AUD', 'Crypto upside (ETH appreciation)'],
              ['Retained Profit', '0.011842 ETH', '$45.00 AUD', 'Crypto upside (ETH appreciation)'],
              ['Operating Costs', '12.92 USDC', '$19.90 AUD', 'Shielded from Crypto Swings (USD Stablecoin)'],
              ['Owner’s Pay', '12.92 USDC', '$19.90 AUD', 'Shielded from Crypto Swings (USD Stablecoin)'],
              ['TOTAL', 'Multi-Asset Vault', '$99.80 AUD net', 'Fully Reconciled & Audited']
            ]
          ),

          // PART 5: MULTI-CHAIN MATRIX
          createHeading1('Part 5: Multi-Chain Liquidity & Execution Matrix'),
          createParagraph(
            'The following matrix summarizes how DYNKLE handles payments and delegation across all supported blockchain ecosystems:'
          ),

          createStyledTable(
            ['Chain Family', 'Tokens Supported', 'One-Time Delegation Mechanism', 'Primary DEX Router', 'Oracle Source', 'Approval Fee'],
            [
              ['Solana L1', 'SOL, DYNK, USDC', 'SPL Token Approve (Delegate)', 'Jupiter v6 Aggregator', 'Pyth Network', '< $0.001'],
              ['Ethereum / EVM', 'ETH, WETH, USDC, USDT', 'EIP-2612 Permit / ERC-20 Allowance', 'Uniswap V3 / CoW Swap', 'Chainlink Feeds', '$0.00 (Gasless)'],
              ['Base / Arbitrum', 'ETH, USDC, DAI', 'ERC-4337 Session Keys / Permit', 'Uniswap V3 on Base', 'Chainlink L2', '$0.00 (Gasless)'],
              ['TRON', 'TRX, USDT (TRC-20)', 'TRC-20 Approve Allowance', 'SunSwap DEX', 'TRON Oracle', '< $0.50 (Energy)'],
              ['Bitcoin Native', 'BTC (L1 Native)', 'THORChain TSS Multi-Party Vaults', 'THORChain Swap Memo', 'THOR Consensus', 'Standard BTC Fee'],
              ['Bitcoin Lightning', 'BTC (Satoshis)', 'HTLC Submarine Atomic Swaps', 'Boltz / Liquid Swaps', 'L402 Gateways', '< $0.05'],
              ['Cross-Chain Bridge', 'Multi-Chain to Solana USDC', 'Cross-Chain Intent Delegation', 'deBridge DLN / CCTP', 'Dual-Validator Oracles', 'Paid by customer']
            ]
          ),

          // PART 6: SECURITY & ATTACK RESISTANCE
          createHeading1('Part 6: Security, Attack Resistance & Risk Invariants'),
          createParagraph(
            'To protect merchant balances against adversarial attacks, market manipulation, and infrastructure failure, DYNKLE implements strict on-chain invariants:'
          ),

          createStyledTable(
            ['Adversarial Threat', 'Custodial Processor Risk', 'DYNKLE Architectural Defense'],
            [
              ['Central Server Breach', 'Hacker steals private keys and drains company hot wallets.', 'Zero Risk. DYNKLE servers store no merchant private keys.'],
              ['Rogue Keeper Injection', 'Malicious actor attempts to redirect swap proceeds.', 'Blocked on-chain. Swap recipient is hardcoded to merchant vault.'],
              ['MEV Sandwich Attack', 'DEX front-runners drain trade value via illiquid pool.', 'Prevented. Pyth/Chainlink oracle slippage cap reverts the trade.'],
              ['Stale Oracle Feed', 'Outdated price quotes lead to bad execution prices.', 'Safe. Pyth (60s) and Chainlink (3600s) staleness bounds abort stale swaps.'],
              ['Network Outage / RPC Timeout', 'Transactions get stuck in limbo with undefined state.', 'Idempotency Lock. Map-based locks and retry states prevent double-swaps.'],
              ['Regulatory Seizure / Freeze', 'Intermediary freezes business funds during dispute.', 'Protected. Merchant maintains complete self-custody on public ledgers.']
            ]
          ),

          // PART 7: REGULATORY & ATO COMPLIANCE
          createHeading1('Part 7: Regulatory Compliance & Tax Accounting'),
          createParagraph(
            'Under Australian Taxation Office (ATO) guidance, commercial businesses accepting digital currency must record the AUD market value at the time of transaction for GST and income tax purposes. DYNKLE automates this compliance:'
          ),
          createBullet('Every transaction logs subtotalAUD, customerFeeAUD, gstAUD (10%), and the exact spot exchange rate at timestamp.', '1. GST Accounting Record:'),
          createBullet('When auto-swaps execute, the acquisition cost, disposal value, DEX fee, and capital gain/loss percentage are stamped in the execution ledger.', '2. Capital Gains Tax (CGT) Tracking:'),
          createBullet('Merchants can download their full history anytime via GET /api/auto-swap/ledger/export for immediate ingestion into Xero, MYOB, or CPA tax systems.', '3. ATO-Compliant CSV Export:')
        ]
      }
    ]
  });

  const buffer = await Packer.toBuffer(doc);
  
  const rootPath = '/home/nitya/DYNK-Latest/DYNKLE_Money_Flow_Technical_and_NonTechnical_Specification.docx';
  const publicPath = path.join(__dirname, '../public/DYNKLE_Money_Flow_Specification.docx');

  fs.writeFileSync(rootPath, buffer);
  fs.writeFileSync(publicPath, buffer);

  console.log(`Document generated successfully!`);
  console.log(`Root Path: ${rootPath} (${buffer.length} bytes)`);
  console.log(`Public Path: ${publicPath} (${buffer.length} bytes)`);
}

buildDocument().catch(err => {
  console.error('Failed to generate document:', err);
  process.exit(1);
});
